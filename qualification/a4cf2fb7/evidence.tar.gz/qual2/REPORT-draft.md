### 1. Freeze
Worktree `/home/parkave/ccf_wt/qual-a4cf2fb7`, fresh, detached at `a4cf2fb74af4964dcfee29d210d17d94b909d78d`. Tree (freeze hash) `b345b174aa5dbfd28abaa3fa20cae97806659629`, equal to the working-tree hash and to the accepted repair candidate's tree. Parents `1f081151…` and `f23f0a03…`; `f23f0a03`, `1f081151`, `797e1411`, `78d26eee` all ancestors. `main == origin/main == a4cf2fb7`. Porcelain 0, untracked 0, ignored sidecars 0, no tag at HEAD. Frozen 2026-09-25T19:25:31Z.

### 2. Provisioning
Fresh venv: `make venv` (dev extras + `ccf-demo-adapter` 0.1.0) plus the chroma, neo4j, mongo, adk, claude-agent, langgraph, anthropic and harnesses extras, rc=0. Imports proved before any run (pymongo, neo4j, chromadb, psycopg, testcontainers, fastapi, mcp; google-adk 2.5.0, claude-agent-sdk 0.2.128, langgraph 1.2.9); `ccf` and `ccf_runtime` resolve from this worktree's own `src/` and `runtime/`. Python 3.12.3.

### 3. Estate protection
Baseline read (READ ONLY): 30 ledgers, `ccf:main t=1608`, `fibo-v2:main t=5878`. Qualification shell carried zero `CCF_*` variables; no `CCF_TEST_*` named `.76`; writable targets were the disposable local containers and the Postgres testcontainer only.

### 4. Focused D-IMPL-353 qualification
typecheck: Success, 241 source files. lint (all checkers incl. the authorization invariant): rc=0. Focused suites (authz, http_api, mcp, skills, controlplane, deployment, products, workflow, artifacts, crossproc, gates, lints, replay, invariants, surface gates): **5818 passed, 1 skipped (the Fluree snapshot pin, executed in §8), 0 failed, 0 errors**, 3:42.
Severings: **33 of 33** (M29 not run), one uninterrupted pass 19:30:49Z–19:36:33Z; every anchor matched the frozen code exactly once before launch; each severing asserted the tree at the freeze hash before mutation, reddened at least one named control, restored byte-for-byte (SHA-256 per file) and re-hashed equal to the freeze hash. Red counts identical to the `1f081151` campaign; M19–M22 also turn the authorization lint red; M17's two reds are its named fixture-shape controls. Table: `qual2/severings-table.md`.

### 5. Canonical `make test`
Makefile target as written, census posture (zero `CCF_*`), tree hash equal to the freeze hash before and after, junit artifact via `PYTEST_ADDOPTS` only.
| executed | passed | failed | errors | skipped | xfailed | xpassed | deselected | wall clock |
|---|---|---|---|---|---|---|---|---|
| 10 084 | 9128 | 25 | 0 | 857 | 74 | 0 | 225 (`archived`) | 13:01 (19:36:57Z–19:50:01Z) |

### 6. Exact non-pass reconciliation
- **R10: exact match** — the 25 FAILED node ids equal the D-GATE-353 census: 0 missing, 0 new, 0 type changes; failure modes per node as in the census.
- **74 xfailed**: identical set to the `1f081151` run (72 D-IMPL-264, 2 SEC353-G-05).
- **857 skipped**: identical to the `1f081151` run plus exactly one node, the new `test_every_key_the_run_put_in_force_is_under_the_deployments_tenant` in `test_s1_01_output.py` (Fluree-marked module; executed and green in §8). Categories: 660 estate-gated, 135 Fluree, 31 Mongo, 29 Neo4j leg selections, 1 CP-03 live DSN, 2 declared conformance skips. Postgres-marked tests ran inside `make test` through the testcontainer path.

### 7. Static and structural checks (restored frozen tree)
| check | result |
|---|---|
| typecheck / lint | 241 files clean / rc=0 |
| schema headers | red on the two `archive/` scope-mapping documents only (R10 / D-IMPL-351 subjects, carried per the ruling); every `examples/` directory passes |
| schema regeneration/drift | no drift |
| docs-strict | rc=0 |
| public-surface drift/determinism (`dump_surface.py --check`, twice) | **rc=0 both**; `--report`: added 0, removed 0, reshaped 0 |
| surface-change assembler `--check` | rc=0 |
| retirement-couplings freshness | sweep rc=0 (310 rows / 98 files / 3246 scanned); staleness gate green inside docs tests |
| product-gate checker | **30 trees / 519 declared / 519 executing** |
| product-gate self-tests · publish-scan tests · docs tests · tools/lints tests | 48 · 53 · 296 · 579 passed |
| obligation vocabulary + spine separation | 66 passed |
| replay / refusal replay | 201 passed, 1 skipped (Fluree pin) |
| DR-01 | 4 passed |
| DR-02 standalone / after the predecessor import case | 9 skipped without the estate; **9 passed / 17 passed** with `CCF_CP_06C_*` exported read-only |
| governance / door suites | 957 passed |
| D-IMPL-353 served-surface / security controls | 424 passed |
| `make examples` (hw1; informational) | rc=2 at hw1's `server/serve.py`, `SEC353-G-03`, the frozen family's carried stop |
Tree after the batch equal to the freeze hash; porcelain 0; untracked 0.

### 9. CP-03 live prerequisite
`test_the_fixture_still_matches_the_live_estate` against the curated Postgres (schema `ccf_v2`, count queries only, credentials never printed): **EXECUTED — PASS**.

### 10. Decision Replay 1.0 surface
Mode 1 reconstruction, environment replay, refusal replay and retained-record gates: replay suite 201 passed + DR-01 4 passed. Mode 2 packaging, retained trace, model/version and temperature pins, prompt identity, output hash: DR-02 9 passed standalone, 17 passed after the predecessor. Mode 3 and the operator trace inside the replay suite. Nothing out of scope implemented.

### 11. D-IMPL-353 release surface
Unchanged from the previous report and re-executed on this tree (focused suites, severings, 424 security controls): threat model = governed served surfaces; two door mint sites, five composition mint sites; one kind per action; `CompositionRegister` distinct; door and composition cannot mint each other's authority; kind + resource + tenant binding; forgery, retargeting, copy, pickle refused; keyed reads resolve the capability's resource (R11 CLOSED); no kind-less reader (R6 CLOSED); cross-tenant refusals; skill-grant controls; paved road does not self-grant. Carried: R1–R5, R7–R10. SEC-005/006 out; D-IMPL-348 untouched; M29 withdrawn.

### 12. Fluree watermark contract
No migration since v1.0.0: the same 12 files name the ledgers route and the same 39 `unreported` sites exist at `a4cf2fb7` as at `v1.0.0`; the s1-01 repair touched no acquisition, watermark or `ledger_t` path; nothing aliases a watermark from `graph_snapshot_at`.
