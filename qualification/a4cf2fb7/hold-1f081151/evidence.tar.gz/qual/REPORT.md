## RELEASE HOLD

Candidate `main == origin/main == 1f081151` (freeze hash `915ea82bdbb08ea35086cffb52dd30ccc3593a29`), qualified 2026-09-25 in a detached worktree. Nothing in the tree was modified; no commit, no tag. Two of Dave's GO criteria are unmet on new evidence, and two more are unmet on subjects that already carry a disposition.

### Blockers (new evidence)
1. **`s1_01` is not green on a fresh empty Fluree.** Six failed (`test_s1_01_governed_resolver_adoption.py`) and 36 errors (`test_s1_01_output.py`), every one `KeyError: 'events'` at `examples/s1-01-hello-context-product/deployment.py:863`, where the example reads `booted.artifacts["events"]` by its bare name. Under D-IMPL-353 every deployment key is placed under the tenant, so the bare read is a `KeyError` — gap-ledger row `SEC353-G-07`, whose representative is s1-00. R10 lists these six nodes as failing on `CCF_TEST_FLUREE_URL unset`; a live Fluree moved the stop from the environment to the example. The canonical Fluree leg is therefore red as well (6 failed, 250 passed, 36 errors, 12 xfailed); all reds are s1-01, all other Fluree nodes passed.
2. **The committed public-surface manifest is stale.** `docs/surface/v0.2-surface.json` differs from the live surface by nine D-IMPL-353 entries: added `ccf.authz.capability.CompositionRegister`, `ccf_runtime.authz.capability.CompositionRegister`, `ccf_runtime.http_api.grants.absent`, `ccf_runtime.http_api.grants.within_tenant`; reshaped `ccf.controlplane.registry.DerivedRegisterAuthority`, `ccf.controlplane.registry.RegisterAuthority`, `ccf.deployment.manifest.register_manifest_entries`, `ccf.deployment.register_manifest_entries`, `ccf_runtime.http_api.grants.authorized_from_request`. `tools/dump_surface.py --check` exits 1 in two independent runs (deterministically). The standing D-15 test gate is green because fragments `docs/surface-changes/353-0*.md` claim every entry. The manifest was last regenerated at the 353 join (`b1ec0e5e`) and not at the 353 close; v1.0.0 regenerated it at its close, and the previous qualification of record recorded `--check` exit 0 as the pass condition. Documentation-tier, no code effect; the repair is `make surface`, a reviewed nine-entry diff and a commit, which makes a new candidate.

### Criteria unmet on already-dispositioned subjects
3. **Postgres leg not green:** 12 failed, 224 passed, 625 skipped, 73 xfailed. The 12 are exactly R10 members re-selected by the `postgres` marker — `test_s1_00_output.py` ×9 (`KeyError: 'request_contract'`), `test_cp_00_output.py` ×2 (`UnpinnedArtifactError`, manifest key `policy`), `test_cp_01_output.py` ×1 (`KeyError: 'default_perspective'`). No new node.
4. **`make schema-headers` red on two documents,** both under `archive/` (`05-workflow-hitl` and `06-decision-replay` `scope-mapping.yaml`, `scopes.hitl.resource_patterns` required). Same subjects as the two R10 archive nodes; `archive/` is a dated reference surface (D-IMPL-351). Every `examples/` directory passes.

### What this pass does not cover
The canonical `make test` ran in the D-GATE-353 census posture (no `CCF_TEST_*`, no `CCF_CP_*`), because R10 is defined as that census's exact node-id set and only that posture reproduces it. In that posture 660 estate-gated example nodes skip (cp-04 through cp-24, dr-02). The v1.0.0 run of record exported the read-only estate and skipped 2. The gap ledger (`SEC353-G-01..G-08`, STATUS OPEN, awaiting Dave's disposition) records that the frozen specimens and the cp-16..cp-24 doors do not build under Tier 1; blocker 1 is the first executed proof of that class, and an estate-exported run should be expected to show more of it. No such run was made.

---

### 1. Freeze
Worktree `/home/parkave/ccf_wt/qual-1f081151`, detached at `1f081151118b07446b7a4a119f3d06861a6fc2be`; tree `915ea82bdbb08ea35086cffb52dd30ccc3593a29` (equals `HEAD^{tree}` and the tree of candidate `797e1411`); parents `e027f0989df29a29c787177edc35fab71ea52db2` and `797e141150fa9af7a42472983a9a9af231f8a55b`; `78d26eee` and `797e1411` are ancestors; `main == origin/main`; porcelain 0, untracked 0, ignored sidecars 0, tags at HEAD none; frozen 2026-09-25T15:53:39Z.

### 2. Provisioning
`make venv` (dev extras plus `ccf-demo-adapter` 0.1.0), then the `chroma`, `neo4j`, `mongo`, `adk`, `claude-agent`, `langgraph`, `anthropic`, `harnesses` extras, rc=0. Imports proved from the worktree venv before any run: pymongo, neo4j, chromadb, psycopg, testcontainers, fastapi, mcp; google-adk 2.5.0, claude-agent-sdk 0.2.128, langgraph 1.2.9; `ccf` resolved from the worktree's own `src/`. Python 3.12.3.

### 3. Estate protection
Baseline read of `GET /v1/fluree/ledgers` on `.76`: 30 ledgers, `ccf:main t=1608`, `fibo-v2:main t=5878` (measured). The qualification shell carried zero `CCF_*` variables; no `CCF_TEST_*` named `.76` at any point; writable targets were only the disposable local containers and the Postgres testcontainer. Fence: `tests/examples/estate_guard.py` default `CCF_CURATED_ESTATE_HOSTS=192.168.4.76` in the frozen tree. Post-run re-read (§13): byte-identical.

### 4. Focused D-IMPL-353 qualification
| control | result |
|---|---|
| `make typecheck` | Success, 241 source files |
| `make lint` (all checkers incl. the D-IMPL-353 authorization invariant) | rc=0 |
| focused suites: authz, http_api, mcp, skills, controlplane, deployment, products, workflow, artifacts, crossproc, gates, lints, replay, invariants, surface gates | **5818 passed, 1 skipped, 0 failed, 0 errors** (3:42); the skip is the Fluree snapshot pin, executed in §8 |
| served-surface probe, R6 kind-required reader, R11 differing-parameter, CompositionRegister, forgery/copy/pickle, cross-tenant, skill-grant, paved road | all inside the 5818; named tests per bullet in `release-surface-map.txt` |

**Severings: 33 of 33 (M1–M34 less the withdrawn M29).** Per severing the driver asserted the tree hash equal to the freeze hash before mutation, applied the one edit (anchor exactly once), ran the named controls, wrote the original bytes back, asserted the SHA-256 of every touched file, and recomputed the working-tree hash equal to the freeze hash. Every severing reddened at least one named control; M19, M20, M21, M22 also turned the authorization lint red. Two anchors were stale against the frozen code and were re-anchored with the same intent before they could apply: M23 (the composition mint is now `CompositionRegister`) and M27 (the resolution route's tenant check shares R11's line). The driver refused on the stale anchors and wrote nothing. M17 is flagged `family_hit=False` by the driver's convenience regex only; its two reds are its named controls (`test_no_test_in_this_package_subclasses_the_grant`, `test_the_fixture_mints_the_base_contract_and_nothing_else`). Table: `severings-table.md`; logs: `severings/M*.log`.

### 5. Canonical `make test`
The Makefile target as written, worktree venv, tree hash equal to the freeze hash before and after; the only addition was `PYTEST_ADDOPTS=--junitxml=…` for the per-node artifact. No reordering, subset, added skip or xfail, changed expectation, or substituted rerun.

| collected (executed) | passed | failed | errors | skipped | xfailed | xpassed | deselected | wall clock |
|---|---|---|---|---|---|---|---|---|
| 10 083 | 9128 | 25 | 0 | 856 | 74 | 0 | 225 (`archived`) | 13:01 (16:19:53Z–16:32:58Z) |

Raw artifacts: `canonical.log`, `canonical.xml`, `canonical.posture`, `canonical.tree-before/after`, bundled in `evidence-1f081151.tar.gz`. The repository files a per-candidate tarball under `qualification/<sha>/`; that is a commit, so it is left in the scratchpad for Dave to file.

### 6. Exact non-pass reconciliation
- **R10: exact match.** The 25 FAILED node ids equal the D-GATE-353 census set: 0 missing, 0 new, 0 failure-to-error changes. Failure modes per node match the census (`R10-canonical-reasons.txt`).
- **74 xfailed:** 72 D-IMPL-264 quarantines of frozen cp-00..cp-04; 2 `SEC353-G-05` (`xfail(strict=False)`), all pre-existing marks.
- **856 skipped:** 660 estate-gated (`CCF_CP_<n>_*` unset, cp-04..cp-24 and dr-02); 134 Fluree, 31 Mongo, 29 Neo4j leg selections (executed in §8); 1 CP-03 live DSN (executed in §9); 2 `in-sdk reference adapter holds no outcome store` (`tests/conformance/test_orchestration.py`, a declared conformance skip). Postgres-marked tests did not skip: they executed inside `make test` through the testcontainer path (91 passed in the two conformance files) and left no container.

### 7. Static and structural checks
| check | result |
|---|---|
| typecheck / lint | 241 files clean / rc=0 |
| schema headers | red on the two `archive/` documents only (blocker 4) |
| schema regeneration/drift (`dump_schemas.py --check`) | no drift |
| docs-strict (pre-build scan, schema scan, strict build, site scan) | rc=0 |
| public-surface drift / determinism | `--check` rc=1 twice, identical output (blocker 2); D-15 test gate 9 + 17 passed |
| surface-change assembler `--check` | rc=0; `docs/SURFACE-CHANGES.md` carries the 353 entries, incl. 353-09's record that R6 removed the kind-less reader |
| retirement-couplings freshness | sweep rc=0 (309 rows / 98 files / 3246 scanned); staleness gate in docs tests green |
| product-gate checker | **30 trees / 519 declared / 519 executing** |
| product-gate self-tests · publish-scan tests · docs tests · tools/lints tests | 48 · 53 · 296 · 579 passed |
| obligation-vocabulary invariant + spine separation | 66 passed |
| replay / refusal replay (`tests/replay`) | 201 passed, 1 skipped (Fluree pin, §8) |
| DR-01 (`test_recorded_environment.py`) | 4 passed |
| DR-02 standalone | 9 skipped without the estate; **9 passed** with `CCF_CP_06C_*` exported read-only |
| DR-02 after the predecessor import case (`test_product_tree_import_isolation.py` then `test_dr_02_packaging.py`) | **17 passed** |
| governance / door suites (gates, http_api, crossproc, mcp, hitl) | 957 passed |
| D-IMPL-353 served-surface / security controls | 424 passed |
| `make examples` (hw1; informational) | rc=2 at hw1 `server/serve.py`, `SEC353-G-03`, the same stop as the five hw1 R10 nodes |

### 8. Disposable substrates (new container names, each destroyed after its leg)
| leg | readiness | passed | failed | skipped | xfailed | errors |
|---|---|---|---|---|---|---|
| Fluree `fluree/server:4.1.4` (same image id as the v1.0.0-era container) | ledger list before seeding: `[]` | 250 | 6 | 570 | 12 | 36 |
| six `s1_01` nodes on that Fluree | — | 0 | 6 | 0 | 0 | 0 |
| Mongo `mongo:7` | ping ok after 2 s | 38 | 0 | 245 | 0 | 0 |
| Neo4j `neo4j:5-community` | authenticated `RETURN 1` through the driver after 10 s | 29 | 0 | 0 | 0 | 0 |
| Postgres (target's own testcontainer path) | — | 224 | 12 | 625 | 73 | 0 |

Container set before and after the legs is identical; no `ccf-qual-*`, no reaper; pre-existing stopped containers untouched.

### 9. CP-03 live prerequisite
`test_the_fixture_still_matches_the_live_estate` against the curated Postgres (`192.168.4.76`, schema `ccf_v2`, count queries only, credentials read with shell semantics and never printed): **EXECUTED — PASS**. A first attempt failed inside my DSN builder (a `#` comment kept from the `.env` line); the test was not touched.

### 10. Decision Replay 1.0 surface
Mode 1 reconstruction, environment replay, refusal replay and the retained record gates: `tests/replay` 201 passed; DR-01 4 passed; Mode 2 packaging (retained `PackagingTrace`, model/version and temperature pins, prompt identity, output hash, retained-record gate) via DR-02 9 passed standalone and 17 passed after the predecessor; Mode 3 and the operator trace inside the replay suite. Nothing out of scope was implemented.

### 11. D-IMPL-353 release surface
Confirmed by code site and executing test (`release-surface-map.txt`): threat model wording at `capability.py:46`; door mint sites are exactly `http_api/gate.py:532` and `mcp/tenancy.py:806`, composition mint sites the five lint-ruled roots; one `ActionKind` per action; `CompositionRegister` distinct; door cannot mint composition kinds and composition cannot mint `Register` (`TestCompositionKindIsDistinct`, `TestNoDoorMintsTheGovernedRecord`, static controls); kind + resource + tenant binding; forgery, retargeting, copy and pickle refused; keyed reads resolve the capability's resource (R11 CLOSED); the reader has no kind-less form (R6 CLOSED); cross-tenant list/read/write refusals; skill-grant controls; paved road does not self-grant. Carried unchanged: R1–R5, R7–R10. SEC-005/006 out; D-IMPL-348 untouched; M29 withdrawn.

### 12. Fluree watermark contract
No migration: the set of files naming `/v1/fluree/ledgers` and the count of `"unreported"` sites are identical at `v1.0.0` and `1f081151` (12 files, 39 sites); no diff in any example acquisition, projection, deployment or backends file since v1.0.0; no site aliases a watermark from `graph_snapshot_at`.

### 13. Post-run estate integrity
Re-read: 30 ledgers, `ccf:main t=1608`, `fibo-v2:main t=5878`, byte-identical to the baseline — zero movement. Running containers: only the pre-existing `mongo-express`.

### 14. Candidate integrity
HEAD `1f081151…`; tree `915ea82b…` equals the freeze hash; porcelain 0; untracked 0; `main == origin/main == 1f081151`; no commit, no tag (newest tag remains `v1.0.0`). Ignored, never-committed byproducts now present in the worktree: `.hypothesis/` (property-test database), `ccf.egg-info/` and the demo adapter's egg-info (editable installs) — none affects the tree hash.

### 16. Stopped
No fix, merge, commit, tag, v1.0.1 work, residual repair, or reopening of 350/354/348; no example server unfrozen. Evidence: `scratchpad/qual/` and `evidence-1f081151.tar.gz` (414 KB).
