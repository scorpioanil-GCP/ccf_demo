**FINAL QUALIFICATION GO — CCF RELEASE CANDIDATE**

Authoritative merged baseline:

`main == origin/main == 1f081151`

D-IMPL-353 is closed at:

`D-GATE-353 @ 797e1411`

This is a **qualification-only pass**.

Do not modify code, tests, examples, docs, generated artifacts, estate data, or qualification expectations except for the controlled severings explicitly required below.

Do not tag.

## 1. Freeze the qualification candidate

Create a fresh detached worktree from exactly:

`1f081151`

Record:

- full commit SHA;
- tree hash;
- parent SHAs;
- proof `78d26eee` and `797e1411` are ancestors;
- `main == origin/main`;
- detached worktree clean;
- zero untracked files;
- zero ignored sidecars;
- tags currently pointing at HEAD.

This tree hash is the **freeze hash**.

## 2. Provision the qualification environment correctly

Before `make test`, install the repository's canonical qualification environment, including everything required by the normal bootstrap / `make install` path:

- dev extras;
- Chroma;
- Neo4j;
- Mongo;
- `ccf-demo-adapter`;
- other explicitly required optional qualification dependencies.

Prove the required imports succeed before starting the canonical run.

If the environment is incomplete:

> discard that run entirely and reprovision before qualification.

Do not report results from an under-provisioned run.

## 3. Estate protection

Curated `.76` Fluree remains **READ ONLY**.

Measure, do not assume:

- `ccf:main` ledger position;
- `fibo-v2` ledger position;
- curated ledger count if normally measured.

`1608 / 5878` are last-known values only, not assumed truth.

Verify:

- no `CCF_TEST_*` write target points at `.76`;
- writable qualification targets are disposable/local only;
- the session fence is active.

Any curated-estate movement is an immediate:

> **STOP — RELEASE HOLD**

No rewind, deletion, or compensating writes.

## 4. D-IMPL-353 focused security qualification

Run the focused 353 controls before the expensive full suite.

Required:

- mypy strict / canonical typecheck;
- lint;
- surface gates;
- relevant docs/gate-record checks;
- capability controls;
- all D-IMPL-353 severings;
- served-surface probe;
- R6 kind-required reader controls;
- R11 wrong-resource control;
- `CompositionRegister` controls;
- forgery/copy/pickle controls;
- cross-tenant read/write controls;
- skill-grant foreign-key ordering;
- HTTP / MCP / HITL / execute-resume / products / replay / crossproc affected suites.

### Severing rule

The 353 sabotage campaign is explicitly allowed to mutate the qualification worktree temporarily.

For **every severing**:

1. record the freeze hash before mutation;
2. apply the single intended severing;
3. observe the named control go red;
4. restore the changed bytes exactly;
5. verify the worktree returns byte-for-byte to the freeze state;
6. verify the tree hash equals the original freeze hash.

A restored severing does **not** invalidate qualification.

Qualification is invalid only if:

- a severing fails to restore byte-for-byte;
- tree hash differs after restore;
- any unrelated edit occurs;
- any commit or tag is created.

M29 remains withdrawn and must not be reintroduced.

If any focused 353 control fails outside its intentional sabotage:

> **STOP — RELEASE HOLD**

## 5. Canonical full qualification

From the restored frozen tree, run exactly one canonical:

`make test`

Do not:

- reorder tests;
- synthesize a result from subsets;
- add skips or xfails;
- change expectations during the run;
- substitute isolated reruns for the canonical result.

Capture:

- collected;
- passed;
- failed;
- errors;
- skipped;
- xfailed;
- xpassed;
- deselected;
- wall clock.

Preserve the raw test artifact where the repository normally does so.

## 6. Exact non-pass reconciliation

Every canonical non-pass must be named and dispositioned.

### R10

R10 is **not** “25 reds.”

R10 is the **exact node-id set recorded in the D-GATE-353 census**.

Compare the canonical result against that exact set.

If:

- count changes;
- any node ID changes;
- any new node appears;
- a failure becomes an error or vice versa;
- or any ruled node disappears unexpectedly;

then:

> **RELEASE HOLD**

Do not absorb drift into R10.

Every other non-pass must have an existing explicit release disposition.

## 7. Static / structural release checks

Run the normal release checks outside `make test`, including:

- `make typecheck`;
- lint;
- schema headers;
- schema regeneration / drift;
- docs-strict;
- public-surface drift/determinism;
- surface-change assembler;
- retirement-couplings freshness;
- product-gate checker;
- product-gate checker self-tests;
- publish-scan tests;
- docs tests;
- obligation-vocabulary invariant;
- spine separation;
- replay/refusal-replay;
- DR-01;
- DR-02;
- governance/door checks;
- D-IMPL-353 served-surface/security controls.

Report actual:

`trees / declared / executing`

counts.

No stale generated artifact may be carried into release.

## 8. Disposable substrate qualification

Run each writable substrate against a fresh disposable/local instance.

### Fluree

Start empty.

Prove the ledger list is empty before seeding.

Run:

- six `s1_01` nodes;
- canonical Fluree leg.

### MongoDB

Fresh disposable Mongo.

Run canonical Mongo leg.

### Neo4j

Fresh disposable Neo4j.

Wait for authenticated readiness, not merely an open port.

Run canonical Neo4j leg.

### Postgres

Run canonical Postgres leg using its normal disposable/testcontainer path.

Destroy every disposable substrate after its leg.

Report passed / failed / skipped / xfailed / errors for each.

Any required substrate leg with a real failure:

> **RELEASE HOLD**

## 9. CP-03 live prerequisite

Run the existing CP-03 live-DSN qualification unchanged.

Confirm the node actually executes.

Report:

**PASS / FAIL / NOT EXECUTED**

Do not weaken or rewrite it.

## 10. Decision Replay 1.0 surface

Required:

- Mode 1 reconstruction;
- environment replay;
- refusal replay;
- Mode 2 packaging replay;
- retained `PackagingTrace`;
- real model/version pin;
- real temperature pin;
- prompt artifact identity/hash;
- output hash;
- retained-record gate reads replay bytes;
- Mode 3 child replay;
- operator trace without fabricated rationale.

DR-02 must pass:

- standalone;
- after the known poisoning/predecessor import case.

Explicitly outside current release scope:

- three-audience Π projection;
- retention-tier orchestration / severity exemption;
- temporal-boundary indexing;
- automated sabotage-attestation tooling.

Do not implement them during qualification.

## 11. D-IMPL-353 release surface

Confirm:

- threat model = governed served surfaces only;
- hostile arbitrary in-process Python remains outside scope;
- exact ruled mint producers;
- operation-specific capability kinds;
- `CompositionRegister` distinct;
- door cannot mint composition authority;
- composition cannot mint door authority;
- authorization binds kind + resource + tenant;
- held capability cannot forge another;
- copy/pickle controls hold;
- keyed reads use capability-bound resource semantics;
- cross-tenant list/read/write protections hold;
- skill-grant lookup cannot resolve foreign resource before authorization;
- paved road does not self-grant.

Carry exactly:

- R1 max-TTL grammar;
- R2 issuance-table introspection;
- R3 lint excludes examples/tools;
- R4 FastMCP unknown-argument behavior;
- R5 producer-unavailable wording;
- R7 vestigial approval sink;
- R8 duplicate helper spelling;
- R9 CP-20 direct register residual, non-served;
- R10 exact D-GATE-353 census.

R6 and R11 are CLOSED.

SEC-005 / SEC-006 remain out.

D-IMPL-348 untouched.

M29 remains withdrawn.

## 12. Fluree watermark contract

Do not migrate products to:

`/v1/fluree/ledgers`

during qualification.

Current release behavior remains:

> source ledger watermark is reported only when the configured acquisition path exposes it; otherwise `unreported`.

Never synthesize it.
Never alias it from `graph_snapshot_at`.

## 13. Post-run estate integrity

Reread:

- `ccf:main`;
- `fibo-v2`;
- curated ledger count if measured before.

Required:

> zero curated-estate movement

Also verify:

- no throwaway Fluree remains;
- no throwaway Mongo remains;
- no throwaway Neo4j remains;
- no Postgres qualification testcontainer/reaper remains.

Do not disturb pre-existing stopped containers.

## 14. Candidate integrity after qualification

Verify:

- commit SHA unchanged;
- tree hash equals the original freeze hash;
- detached worktree clean;
- no untracked files;
- no generated-file drift;
- `main == origin/main == 1f081151`;
- no qualification commit;
- no tag.

Temporary severings are acceptable **only because each was restored byte-for-byte and revalidated against the freeze hash**.

## 15. Release ruling

The report must begin with exactly one:

## `RELEASE GO`

or

## `RELEASE HOLD`

### RELEASE GO requires

- focused D-IMPL-353 security qualification green;
- all severings redden the named control and restore exactly;
- canonical `make test` has no unexplained/new failure or error;
- R10 matches the exact D-GATE-353 node-id census;
- typecheck green;
- static/docs/schema/surface checks green;
- Decision Replay required surface green;
- all four disposable substrate legs green;
- `s1_01` green on fresh empty Fluree;
- CP-03 live check executed and green;
- curated estate unchanged;
- candidate tree unchanged;
- every remaining non-pass already has an explicit release disposition.

Otherwise:

## `RELEASE HOLD`

Name every blocker exactly and stop.

## 16. Stop

Do not:

- fix anything automatically;
- merge;
- commit;
- create/push a tag;
- start v1.0.1 work;
- fix R1–R10 residuals;
- reopen D-IMPL-350 / 354 / 348;
- unfreeze example servers.

Return the complete qualification report and stop for Dave's final release decision.