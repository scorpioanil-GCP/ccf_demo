# Copyright (c) 2026 David Castillo. All rights reserved.
# Use, copying, modification, and distribution of the covered material
# are governed by the CCF SDK Interim Software and Patent License
# in the repository-root LICENSE.md and any controlling signed agreement.
# Rights under that interim license begin only upon its execution
# and are limited to its stated scope and term.
"""``ContextProductContract`` — the typed delivery contract (whitepaper §6.3).

Whitepaper §6.3 (the specification elements) and §7.6 (delivery); DESIGN.md
§2B.3, which maps the specification *elements* onto the Fig-CH07-13 typed base
*fields* and records the eight-versus-nine element drift under D-IMPL-30.

Nine elements, per D-IMPL-30 reading (a) — Assembly Mode included. They are
borne across two types, and which type bears which is itself ruled rather than
convenient. The mapping, stated once and asserted by
``tests/products/test_contract_elements.py`` so this table cannot drift from
the code that realizes it:

On :class:`ContextProductContract`, the delivered instance:

===========================================  ================================
Field                                        Specification element
===========================================  ================================
``schema_name``                              Schema
``schema_version``                           Semantic Versioning
``expires_at`` + ``ttl_anchor`` + ``ttl_anchor_at``  TTL
``lineage``                                  Lineage
``plan_id``                                  Π identity (binds product to plan)
``payload``                                  the class's declared payload
``debt``                                     D_c in force (§7.7, D-IMPL-100)
===========================================  ================================

On :class:`RegisteredProductClass`, the class-level governance a product is
assembled *under* rather than carries a copy of:

===========================================  ================================
Field                                        Specification element
===========================================  ================================
``assembly_mode``                            Assembly Mode (INV-CH7-55)
``accepted_policy_binding_modes``            Policy Binding
``freshness_sla``                            Freshness SLA
``discovery``                                Discovery
``addressability``                           Addressability
===========================================  ================================

**What the previous version of this table got wrong, named rather than quietly
fixed.** It asserted that Freshness SLA, Discovery and Addressability *lived*
on :class:`RegisteredProductClass` when only ``assembly_mode`` of the four
did; a repo-wide grep for ``freshness_sla`` in ``src/`` returned zero. Plan
``15.5-07`` landed the three fields, and
``tests/products/test_contract_elements.py`` now asserts this table against
``model_fields`` so the prose cannot drift from the types again.

The second correction concerns Policy Binding, which the previous table routed
through ``lineage.policy_bundle_versions``. **Both routes exist and they carry
different things.** That one carries the bundle versions actually bound into
the state a *given product* was assembled from — a per-product fact, and the
one that reaches the replay record. The element's **contract surface** — what
the class accepts, which is what governance means and what
:func:`ccf.products.gates.run_gates` compares against — is
``accepted_policy_binding_modes``. The element is keyed to the second above
because a nested field is not reachable from a top-level ``model_fields``
union, and because keying two elements to one field would collapse them.

**Freshness SLA is class-level by ruling, not by convenience** (D-IMPL-106,
option (b), Dave 2026-08-11). The whitepaper's two enumerations of "the same
seven fields" differ by exactly one element — the Fig-CH07-13 sidebar at
``docs/CCF_Whitepaper_1-2.md:2381`` names freshness SLA where the prose at
``:2381-2405`` names ``plan_id`` — and reading 2 was ruled: the sidebar names a
class-level **promise the product was assembled under**, so both enumerations
are consistent, nothing is missing, and ``plan_id`` keeps its place on the
vessel. It is also the only placement that moves no recorded content address.
Its *shape* is per-signal rather than scalar, following §6.3 at ``:1453``,
which makes the expectation vary with the signal and with the decision;
D-IMPL-106 ruled the placement and left the shape to this plan, stating that
no scalar is ruled in by silence.

**Discovery and Addressability land for real, not declaration-only.**
D-IMPL-98 ruled that the request surface is a typed request contract per
product class and that addressability and the request contract are the same
commitment — which makes ``15.5-CONTEXT.md``'s declaration-only permission
moot. What is here is the *class-level* half: the registry facts a product is
located by, and the address it answers at. The **argument** half — subject and
instant as typed request arguments rather than artifact literals — is that
ruling's own surface and is deliberately not modelled here.

**The payload is a declared schema, not an open dict** (D-IMPL-97 ruling 1).
A class pins its payload schema by ``(key, version)``, resolved at
registration, and :mod:`ccf.products.payload` holds the one comparison that
reads it. Under D-IMPL-102 that is limb 1 — *schema validity at registration*
— and **no fourth gate joins** :func:`ccf.products.gates.run_gates`; the
three shipped validation gates stay at three.

**Semver lanes are per product class** (INV-CH7-49): ``schema_version`` is a
field on the instance and is never compared across classes, so a bump on one
product never touches another.

**Context Debt rides the vessel, and that is what makes it reach a consumer**
(D-IMPL-100). D_c was computed by :mod:`ccf.halflife.debt` and then discarded:
it appeared on neither the product nor the replay record, so five of the six
axes of ``G(E, R, T, P, Π, L)`` reached the wire and the sixth — the one that
says how much to trust the other five — did not. §7.7 and
``docs/CCF_Whitepaper_1-2.md:2696`` are unambiguous that debt is something the
agent has to consume while deciding — a first-class input, not an audit trace
read afterwards — so it is carried **here**, inside the delivered bytes,
rather than beside them.

**The three doors, and what a consumer at each receives.** Every shipped
delivery path serializes ``servable.product`` and **none** reads
``ServedProduct.replay_ref``, so a placement beside the vessel would have
reached an in-process caller and no wire consumer at all. Because debt is on
the vessel, all three carry it with **no code change at any door**:

==================================================================  ==============  ===========
Door                                                                Serializes      Carries D_c
==================================================================  ==============  ===========
``runtime/ccf_runtime/mcp/egress.py::build_egress_server``          the vessel      yes
``runtime/ccf_runtime/http_api/routes/product.py::build_router``    the vessel      yes
``runtime/ccf_runtime/mcp/experience.py::build_experience_server``  the vessel      yes
==================================================================  ==============  ===========

No door is structurally unable to carry it, so nothing is carried forward as a
residual on that account. ``tests/invariants/test_replay_by_construction.py``
registers the claim as a CINV-04 check ranging over
``tests/invariants/test_mcp_role_separation.py``'s exhaustive door enumeration —
one enumeration, because this phase began by discovering that nobody had counted
the doors.

**The content address moves, and it moves reconstructibly.** ``debt`` is inside
the hashed body — :func:`~ccf.contracts.canonical.canonical_bytes` walks a model
field-by-field over ``type(value).model_fields`` — so every address recorded
before this field existed differs from the one the same product produces now.
That is authorized by D-IMPL-100 on one condition, which is structural rather
than procedural: the *record* carries the same assessment on dimension 5, and
:meth:`~ccf.replay.engine.ReplayEnvironment.rehydrate_product` reads it back, so
the engine's check inside ``src/ccf/replay/engine.py::replay`` passes on
identical
bytes rather than on a re-measurement. Debt is **never** re-derived at replay:
it is computed from observations and a ``now`` neither the record nor the
projection re-derives, so a rehydrator that re-measured it would produce a
different decision wearing this one's identifier.

**What debt points at rides beside it, and the address moves a second time**
(D-IMPL-118). ``debt_evidence`` is a *top-level* field, a sibling of ``debt``
rather than a member of the assessment. The nested placement was the cheaper
measured option — it would have ridden ``ContentGenerationPath.debt`` and
reconstructed for nothing — and was declined, so the sibling pays for its own
identity: dimension 5 carries a matching member, and every implementation of
:meth:`~ccf.replay.engine.ReplayEnvironment.rehydrate_product` reads it back.
Without both halves every replay of every product would raise
``ReplayDivergence``, because
:func:`~ccf.contracts.canonical.canonical_bytes` walks a model field-by-field
over ``type(value).model_fields`` and the new field is therefore in the
address. D-IMPL-117 authorized that move in advance — *"surface impact is
accepted"* — so it is a ruled cost rather than a defect.

**When the sources last published rides beside both, and the address moves a
third time** (D-IMPL-112 gap 2, D-IMPL-117, D-IMPL-118).
``source_refresh_recency`` is the second sibling of ``debt`` and takes the same
ruled placement, which D-IMPL-118 says *"price[s] all three Track B
vessel-carried members identically"* — so it pays the same price: a matching
member on dimension 5 and the same read-back in every ``rehydrate_product``.
It is here rather than folded into ``debt.factors.freshness`` because the two
are different facts. F is a *derived* figure — how much of a decay budget the
fabric's own curve has eaten — while this is an *observed* one about the world
outside the fabric. A consumer shown only F cannot tell a source that publishes
daily and is two days late from one that publishes annually and is current.
The SDK stores the instants and draws no conclusion from them; comparing a
refresh against a cadence or a threshold would be salience, which D-IMPL-101
deferred.

**And it names no source** (D-IMPL-124, revising what 15.6-07 shipped). The
member carried a per-source map whose entries named the source each instant
belonged to, and both delivery paths serialise this vessel verbatim to every
principal who can reach the product — so a reader entitled to the product could
learn that a given upstream system exists and when it last published, with no
check that they were entitled to that system's contents. The member now carries
a :class:`~ccf.halflife.assessment.SourceRefreshWindow`: the oldest and the
newest of the deployment's declared refresh instants, with no source identity
and no count. The placement is unchanged — D-IMPL-118's ruling is not amended,
only the member's contents are — so dimension 5 and the read-backs stay exactly
as they were.

**What the signal obliged rides beside all three, and the address moves a
fourth time** (D-IMPL-112 gap 3, D-IMPL-117, D-IMPL-118).
``obligation_in_force`` is the third sibling of ``debt`` and takes the same
ruled placement, so it pays the same price: a matching member on dimension 5
and the same read-back in every ``rehydrate_product``. It carries the
obligation the deployment's :class:`~ccf.controlplane.artifacts.DebtProfile`
bound to the routing state *this* decision landed in — the resolved value, not
the mapping. A consumer handed the mapping would be holding the calibration
rather than the decision, and a consumer handed nothing would have to resolve
the profile again at read time, which is the substitution D-IMPL-26's
exact-version rule forbids. **The SDK carries it and acts on it nowhere**:
what an obligation requires is user configuration (CLAUDE.md §11), and a
module that branched on the value would have chosen the vocabulary.

**What may be put in it is constrained, and the constraint is standing**
(D-IMPL-119). Evidence pointers are entitlement-sensitive, and the shipped
assembly path is not principal-scoped: :class:`ccf.halflife.assessment
.DebtEvidencePointer` documents what that refuses until the gap is closed.
Nothing carried here varies by principal, which is what keeps a field inside
the content address compatible with D-IMPL-105's one-figure-per-product
reading.

**One figure per product, not one per principal** (D-IMPL-105). Different
principals legitimately receive different products, assembled from what each may
consult — but debt is not one of the things that differs. A refused consultation
is simply not part of ``C_required`` for that principal, so its absence is not a
shortfall. Under the per-principal reading the completeness number would move
when a source was withheld, and a caller could then infer *what they are not
allowed to see* from the debt they were shown — an oracle over the entitlement
configuration, quieter than a refusal because nothing in the response says a
consultation was declined. There is no per-principal figure here to difference.

**MAX_TTL has no SDK default** (D-IMPL-39). It is required Control Plane
configuration per product class, and the absence of a registered value is a
failure at *class registration* — before any product of that class can exist —
rather than a surprise on the first serve. This module therefore holds no TTL
number, no freshness figure, and no threshold of any kind (CLAUDE.md §11,
CINV-01).

Algorithmic module (CINV-03).
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime
from decimal import Decimal
from typing import TYPE_CHECKING, Any, Literal

from pydantic import Field, field_validator, model_validator

from ccf.contracts.base import CCFContract
from ccf.contracts.canonical import HASH_TRANSPARENT_KEY
from ccf.controlplane.artifact_base import validate_semver
from ccf.controlplane.registry import ControlPlaneMissing, ControlPlaneProtocol
from ccf.graph.protocols import LineageMode, PolicyBindingMode
from ccf.halflife.assessment import (
    NO_DEBT_EVIDENCE,
    NO_OBLIGATION_IN_FORCE,
    NO_SOURCE_REFRESH_RECENCY,
    DebtAssessment,
    DebtEvidence,
    ObligationInForce,
    SourceRefreshRecency,
)

if TYPE_CHECKING:  # pragma: no cover - typing only
    from ccf.projection.engine import ExecutionResult

__ccf_mode__ = "algorithmic"

__all__ = [
    "NOT_ADDRESSABLE",
    "NOT_DISCOVERABLE",
    "NO_PAYLOAD_SCHEMA",
    "NO_PRODUCT_GATE",
    "NO_REQUEST_CONTRACT",
    "NO_SERVE_OBLIGATIONS",
    "NO_VALIDITY_FLOORS",
    "UNMEASURED_FRESHNESS_SLA",
    "AssemblyMode",
    "ComputedEmptyFinding",
    "ConstituentValidityFloors",
    "ContextProductContract",
    "DeclaredProductGate",
    "FreshnessSLA",
    "MaxTTL",
    "ProductAddress",
    "ProductClassRegistrationError",
    "ProductDiscovery",
    "ProductLineage",
    "RegisteredProductClass",
    "ChildRequirement",
    "OptionalAbsenceTreatment",
    "ServeObligations",
    "requirements_declaration_is_coherent",
    "RefusalCause",
    "SeamRefusalCause",
    "SUBJECT_WITHHOLDING_NEVER",
    "SUBJECT_WITHHOLDING_POSSIBLE",
    "SubjectWithholding",
    "TTLAnchor",
    "register_product_class",
    "version_satisfies_floor",
]

#: Whitepaper §7.6 TTL granularity (D-IMPL-31): a product's expiry is anchored
#: either to the decision that requested it or to the freshness of the entities
#: it was assembled from. Which one is a per-class declaration.
TTLAnchor = Literal["from_decision", "from_entity_freshness"]

#: Whitepaper §7.6 assembly modes (INV-CH7-55, the ninth contract element per
#: D-IMPL-30). I.1 is Mode 1 throughout — no LLM participates anywhere in the
#: fabric core.
AssemblyMode = Literal["algorithmic", "llm_packaged", "swarm_assembled"]

#: Whether a product class's answers may withhold their subject from the
#: principal who asked (Dave's Q12, 2026-10-07; ``D-IMPL-378``; SDK-defined,
#: CLAUDE.md §11). ``"may-withhold"`` — the default every class carries until it
#: says otherwise — and ``"never"``, the affirmation a class makes so that its
#: decision records may be read back by their owners. A record's dimension 1 is
#: the real read (``D-IMPL-371``), so a record of a class that may withhold can
#: name a subject its answer hid; only a class affirming ``"never"`` can be
#: listed in a tenant's
#: :attr:`~ccf.products.entitlement.ProductEntitlementPolicy.evidence_readable_classes`,
#: and the governed resolver refuses a withheld answer from such a class.
SubjectWithholding = Literal["may-withhold", "never"]

#: The default posture: answers of the class may withhold their subject.
SUBJECT_WITHHOLDING_POSSIBLE: SubjectWithholding = "may-withhold"

#: The affirmation: answers of the class never withhold their subject.
SUBJECT_WITHHOLDING_NEVER: SubjectWithholding = "never"

#: What the fabric determined when a subject is not served, as
#: :class:`~ccf.products.refusal.SubjectUnavailableRefusal` carries it.
#:
#: **Declared once, and here rather than beside that class**, for the reason
#: `TTLAnchor` and `AssemblyMode` are here: this module is the shared ancestor
#: every consumer already imports. `ccf.controlplane.artifacts` needs it for
#: `SeamRefusalBinding.cause`, and importing it from `ccf.products.refusal`
#: closes a real cycle — `artifacts` -> `refusal` -> `composite` ->
#: `halflife.debt` -> `artifacts` — which only fails when `artifacts` is
#: imported first, so mypy and a passing suite both miss it.
#:
#: Restating the literal instead is what the guard at
#: `tests/invariants/test_no_obligation_vocabulary.py` measures: `artifacts.py`
#: is one of its two scanned roots, and the copy took it from 54 passed to 43
#: failed (`D-IMPL-117`, CLAUDE.md §11 — the SDK owns mechanism, not
#: vocabularies it enumerates by hand).
RefusalCause = Literal["nonexistent", "unauthorized", "undisclosed"]

#: What a class may declare an exception at a seam MEANS (`D-IMPL-347` B2):
#: one of the three subject causes above, or ``source-unavailable``.
#:
#: ``source-unavailable`` is not a fourth subject cause — it says nothing about
#: the subject at all — so it is not in :data:`RefusalCause`, and a
#: :class:`~ccf.products.refusal.SubjectUnavailableRefusal` can never carry it.
#: A binding declaring it mints a
#: :class:`~ccf.products.refusal.SourceUnavailableRefusal` instead (`CP06C-F-06`;
#: Dave, 2026-10-16 12:11, option B): before it, an outage could only be
#: refused as *"the requested subject is not available to this principal"*,
#: which is false for an outage and reads as a missing entitlement.
SeamRefusalCause = RefusalCause | Literal["source-unavailable"]


class ProductClassRegistrationError(ValueError):
    """A product class cannot be registered as configured.

    Raised — never returned, never warned — because a class whose governance
    configuration is absent or malformed must not become servable. D-IMPL-39.
    """


class MaxTTL(CCFContract):
    """The per-class TTL ceiling, as a Control Plane artifact.

    A typed artifact rather than a bare integer so that registering the wrong
    thing under the MAX_TTL key is a detectable error rather than a plausible
    one, and so the ceiling gets its own content-addressed version — which is
    what lands in the policy-bindings replay dimension.

    ``seconds`` is declared with no default: a missing ceiling is a deployment
    error, not a number the SDK is entitled to choose (D-IMPL-38).
    """

    seconds: int


class FreshnessSLA(CCFContract):
    """§6.3 **Freshness SLA** — the per-signal currency expectation (D-IMPL-106).

    §6.3 (``docs/CCF_Whitepaper_1-2.md:1453``) separates two primitives that
    are easy to conflate. This one is an *expectation* — how recent a signal
    has to be before the product may rest on it. :class:`MaxTTL` is a
    *bound* — how long the assembled product stays usable once that recency
    can no longer be guaranteed. §6.3 calls them siblings rather than
    duplicates, which is why both exist here and neither is a respelling of
    the other.

    **Per signal, not a scalar.** §6.3 makes the expectation vary by signal
    and by decision, and warns that collapsing signals of different currency
    into one undeclared figure yields an input an agent cannot rely on. A
    single number for a product assembled from an end-of-day filing *and* an
    intraday blotter entry hides exactly that difference. D-IMPL-106 ruled
    the *placement* and left the shape here, recording that no scalar was
    ruled in by silence.

    The mapping is keyed by the deployment's own signal-type identifiers and
    the SDK never interprets one — the opaque-identifier discipline
    :class:`~ccf.skills.catalog.SkillRequirements` already holds. This class
    therefore ships no signal name and no number (CLAUDE.md §11, CINV-01).

    Attributes:
        max_age_seconds_by_signal: Per signal type, the greatest age at which
            an observation of it still satisfies this class's currency
            expectation. An empty mapping is the positive statement
            :data:`UNMEASURED_FRESHNESS_SLA` documents, not a silence.
    """

    max_age_seconds_by_signal: Mapping[str, int]

    def __hash__(self) -> int:
        # The generated frozen-model hash cannot hash a mapping field; hash
        # the same values equality compares (the SkillArgumentSchema
        # precedent, and for the same reason — the value is carried inside
        # types that are compared as members of sets).
        return hash(
            (type(self), tuple(sorted(self.max_age_seconds_by_signal.items())))
        )


class ConstituentValidityFloors(CCFContract):
    """D-IMPL-31's declarable floors, whose breach refuses assembly.

    Ruled 2026-07-25 as part of the two-granularity TTL reading: *"Product
    classes may declare constituent-validity floors whose breach refuses
    assembly rather than emitting a product fresher-labeled than its stalest
    load-bearing constituent (the mixing-refusal rule, formally footed)."*
    The declaration is here; **the refusal that reads it is plan ``15.5-12``**,
    and nothing in the registration path consumes a floor, because a
    mixing-refusal enforced at wiring time would be a rule applied at the
    wrong moment — the mix does not exist until assembly.

    Distinct from :class:`FreshnessSLA` and not a restatement of it: the SLA
    is the currency the class *expects* of a signal, the floor is the
    remaining validity a constituent must still have for the product to be
    assemblable at all. One is an expectation, the other a refusal condition.

    Attributes:
        min_validity_seconds_by_signal: Per signal type, the least remaining
            validity a load-bearing constituent of that type must have.
            Deployment-declared identifiers, never interpreted here.
    """

    min_validity_seconds_by_signal: Mapping[str, int]

    def __hash__(self) -> int:
        return hash(
            (
                type(self),
                tuple(sorted(self.min_validity_seconds_by_signal.items())),
            )
        )


class ProductDiscovery(CCFContract):
    """§6.3 **Discovery** — the registry facts a class is located by.

    §6.3 (``docs/CCF_Whitepaper_1-2.md:1463``) puts a registry in front of the
    fabric: products are located by the intent they serve, the domain they
    belong to, and the capability they offer, and an agent turns a name into
    an endpoint at run time rather than at wiring time. The three fields below
    are those three axes. ``capabilities`` is the declared manifest §6.3's
    worked registry entry carries. ``audiences`` is a fourth, SDK-defined axis
    per ``docs/DECISIONS.md`` D-IMPL-135 — see that field's own docstring.

    Every value is a deployment-declared opaque identifier. The SDK matches
    them structurally and interprets none, so no intent vocabulary, domain
    taxonomy, capability list or audience vocabulary exists in this module
    (CLAUDE.md §11).

    Attributes:
        domain: The domain the class belongs to.
        intents: The decision intents the class is registered as serving.
        capabilities: The class's declared capability manifest.
        audiences: The audiences the class is declared for — e.g.
            ``{"analyst", "investment_banker"}``. **Not**
            :class:`~ccf.projection.plan.Perspective`: ``Perspective``
            conditions Π's view of the graph under a caller's grant at run
            time; ``audiences`` advertises an intended readership to a
            registry and conditions nothing. D-IMPL-135 (Dave, 2026-08-14)
            ruled the axis on exactly this distinction — a role maps onto
            none of ``domain``, ``intents`` or ``capabilities``, and the two
            come apart the moment one role serves several intents.

            Defaults to the empty frozenset, the honest reading of an absent
            ``audiences:`` block — *this class declares no audience* — on
            the same footing as :data:`NOT_DISCOVERABLE`'s reading of an
            absent registry entry. The rejected alternative was a required
            field with every one of the tree's ``ProductDiscovery``
            construction sites moved to supply it, which D-IMPL-136 §10's
            compatibility posture forbids by analogy for a shipped §6.3
            element with no migration path.
    """

    domain: str
    intents: frozenset[str]
    capabilities: frozenset[str]
    audiences: frozenset[str] = frozenset()


class ProductAddress(CCFContract):
    """§6.3 **Addressability** — the address a class answers at.

    §6.3 (``docs/CCF_Whitepaper_1-2.md:1465``) commits every product to an
    interface an agent can query by name, parameterised by the intent, the
    role and the freshness it needs. The section works that commitment as a
    path plus a query string, of the shape
    ``/context-products/{domain}/{entity-kind}/{id}?intent=…&freshness=…``.

    **The path half only, deliberately.** D-IMPL-98 ruled that the request
    surface is a *typed request contract per product class* and that
    addressability and that contract are the same commitment; the query half
    of the worked pattern — subject and instant as typed **arguments** rather
    than artifact literals — is that ruling's own surface. Modelling query
    parameters here would foreclose its shape, so this class declares where a
    class is reached and says nothing about what it is called with.

    Attributes:
        address_template: The address pattern the class answers at. A
            template rather than a resolved address, because the subject is
            an argument of the request and not a property of the class.
    """

    address_template: str


#: A class that states no per-signal currency expectation.
#:
#: The positive assertion, in the ``NO_HITL_ACTIONS`` / ``NO_ADAPTER`` voice:
#: *this class's freshness is bounded by its TTL alone and it measures no
#: signal separately*. It is not "freshness unknown" — §6.3 makes SLA and TTL
#: siblings, and a class that declares only the TTL has made a smaller promise
#: rather than no promise. Every class registered before D-IMPL-106 was in
#: exactly this posture, which is why this is the default: the 29
#: :func:`register_product_class` call sites the ruling priced keep saying
#: what they always said.
UNMEASURED_FRESHNESS_SLA = FreshnessSLA(max_age_seconds_by_signal={})

#: A class that declares no constituent-validity floors (D-IMPL-31).
#:
#: The positive assertion *no constituent of this class is load-bearing enough
#: to refuse assembly on its staleness alone* — which is a governance
#: statement, not an omission, and is what every class shipped before the
#: floors existed was in fact asserting.
NO_VALIDITY_FLOORS = ConstituentValidityFloors(min_validity_seconds_by_signal={})

#: A class not published to the discovery registry.
#:
#: The positive assertion *this class is reached by direct reference and is
#: not offered for intent-, domain- or capability-based lookup*. A class with
#: no registry entry is a real and legitimate deployment choice — it is the
#: choice every class in this tree has made until now — and it is a different
#: statement from an entry nobody filled in.
NOT_DISCOVERABLE = ProductDiscovery(
    domain="not-discoverable",
    intents=frozenset(),
    capabilities=frozenset(),
    audiences=frozenset(),
)

#: A class with no declared external address.
#:
#: The positive assertion *this class is served in process and publishes no
#: address pattern*, which is exactly what the in-process delivery path this
#: tree ships has always done.
NOT_ADDRESSABLE = ProductAddress(address_template="not-addressable")

#: A class that declares no payload schema (D-IMPL-97 ruling 1).
#:
#: Carried on **both** halves of the pin so that "no schema" is one visible
#: state rather than a key and a version disagreeing. The positive assertion
#: *this class has not yet declared what its payload must look like*, which is
#: honest about a gap rather than papering over it: until a class declares a
#: schema, its payload is the unchecked ``Mapping[str, Any]`` D-IMPL-97 named
#: as the substantive defect, and that is visible in the registration rather
#: than inferred from a missing field.
NO_PAYLOAD_SCHEMA = "no-payload-schema"

#: A class that declares no request contract (D-IMPL-98).
#:
#: Defined **here**, beside the field it defaults, on
#: :data:`NO_PAYLOAD_SCHEMA`'s own placement and for a hard reason as well as a
#: tidy one: :mod:`ccf.products.request` — where the request surface itself
#: lives — imports :class:`ProductClassRegistrationError` from this module, so
#: the sentinel cannot live there and still be readable from
#: :class:`RegisteredProductClass`'s default. It is re-exported from
#: :mod:`ccf.products.request`, which is where an adopter authoring a contract
#: will look for it, exactly as :mod:`ccf.products.bind` reads
#: :data:`NO_PAYLOAD_SCHEMA` from here.
#:
#: Carried on **both** halves of the pin so that "no contract" is one visible
#: state rather than a key and a version disagreeing. The positive assertion is
#: *this class has not yet declared the questions it answers* — until it does,
#: its subject and its instant are whatever an artifact happened to author, and
#: that gap is visible in the declaration rather than inferred from a missing
#: field.
NO_REQUEST_CONTRACT = "no-request-contract"


class ServeObligations(CCFContract):
    """What a product class declares about serving — one obligation and one default.

    SDK-defined per CLAUDE.md §11; whitepaper §7.6 (the delivery contract and
    its validation gates) and §7.7.4–§7.7.8 (Context Debt gating Forced LLM
    and Fail-Closed behavior). Ledger rows ``24.5-L-14`` and ``24.6-L-04`` (the
    debt figure) and ``24.5-L-26`` (the per-attribute lineage obligation).

    **The two members are no longer the same kind of thing, and that is the
    point** (``D-IMPL-251`` C1=A, recorded as ``D-IMPL-240`` amendment 2).
    ``lineage_inputs_at`` is an *obligation*: the one structural serve-time
    gate ``D-IMPL-237`` licenses holds the product to it and refuses by name
    (:data:`~ccf.products.gates.GATE_DECLARED_OBLIGATIONS`).
    ``default_debt_tolerance`` is a *default*: Dave's *"a product class cannot
    independently withhold otherwise deliverable context because its own debt
    preference was exceeded"* — the class value *"can be a declared/default
    tolerance characteristic, but it is not itself a policy boundary"*.

    **The three debt concepts, which this field is exactly one of**
    (``D-IMPL-240`` amendment 2):

    1. the product's own figure — *informative*, and applied only as a
       **default** when the caller states no tolerance (worked case 2);
    2. the consumer's declared ``debt_tolerance`` — enforced **as requested**,
       looser or tighter, because the consumer owns fitness (``C2=B``);
    3. an applicable regulatory or enterprise policy constraint — enforced as
       **governance**, through :mod:`ccf.products.constraints` and never
       through this artifact (*"policy limits are not placed in product-class
       registration"*).

    All three reach one place: the Authority layer resolves them into one
    :class:`~ccf.products.provenance.EffectiveParameter` carrying the
    authority that established it, and
    :func:`~ccf.products.gates.refuse_over_tolerance` holds an already-admitted
    product to it. Nothing here is a ceiling and nothing here is folded with
    ``min``.

    Attributes:
        default_debt_tolerance: The class's declared ``D_c`` tolerance, a
            proportion in ``[0, 1]`` (the interval
            :class:`~ccf.halflife.assessment.DebtAssessment` already holds
            ``debt`` to). ``None`` is the positive sentinel *this class
            declares no default* — under which no tolerance applies unless a
            caller or a policy states one. It is the effective tolerance ONLY
            when the caller omits ``debt_tolerance``, and it is then recorded
            with authority ``default`` and this artifact's pin as its source.
            A caller's *looser* value is honored, because a class preference
            is not governance. The NUMBER is the deployment's to author in its
            product-class artifact; the SDK ships no default and no threshold
            (CINV-01, CLAUDE.md §11).
        lineage_inputs_at: The TOP-LEVEL payload members that must be present
            and non-empty at serve — the class's per-attribute lineage
            obligation (``24.5-L-26``; the SDK's declared form of what cp-03
            carries as a product gate). The empty set is the positive sentinel
            *no obligation declared*. Names only: which members a class
            obliges is the class's to say, and what those members contain is
            never read here.

    **The name moved with the meaning** (``D-IMPL-253`` Q9). Dave: *"Rename
    it."* — keeping the previous name, which called this figure a ceiling,
    *"after changing its authority would perpetuate the conceptual error we
    just fixed."* The field is the same field, renamed at ``24.6-04``; its
    hash posture and its sentinel are unchanged. The previous name is spelled
    nowhere in ``src/``, ``runtime/`` or ``tools/``; under ``tests/`` it appears
    only in the assertions that assert its ABSENCE, so a reader grepping for it
    finds those and the dated records that made it.

    Both fields are hash-transparent at their sentinels under ``D-IMPL-243``
    amendment 2 (Dave: *"``ServeObligations``' two fields at empty True —
    empty ≡ pre-phase 'nothing enforced'"*): a model absent at ``13bd250``
    whose empty form obliges nothing is omitted member-by-member at that
    value, so a class declaring a tolerance and no lineage obligation renders
    the tolerance alone.
    """

    default_debt_tolerance: Decimal | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )
    lineage_inputs_at: frozenset[str] = Field(
        default=frozenset(), json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )

    @field_validator("default_debt_tolerance")
    @classmethod
    def _default_tolerance_is_a_proportion(
        cls, value: Decimal | None
    ) -> Decimal | None:
        if value is not None and not (Decimal(0) <= value <= Decimal(1)):
            raise ValueError(
                "default_debt_tolerance must lie in [0, 1]: D_c is a "
                "proportion (whitepaper §7.7.4), so a tolerance outside that "
                "interval either withholds everything or nothing "
                "(24.5-L-14, 24.6-L-04)"
            )
        return value


#: A class that declares nothing about serving — no default debt tolerance,
#: no lineage member. The positive assertion every product class registered
#: before ``24.5-L-14`` / ``24.5-L-26`` existed was already making, so every
#: pre-phase registration and every pre-phase ``run_gates`` call site says
#: exactly what it always said (``D-10``, additive; ``D-IMPL-240`` amendment
#: 2: a class declaring no tolerance contributes no default, and a request
#: under such a class is bounded by a caller's or a policy's value or by
#: nothing at all).
NO_SERVE_OBLIGATIONS = ServeObligations()


class DeclaredProductGate(CCFContract):
    """The governed IDENTITY of a product class's own runtime invariant.

    SDK-defined per CLAUDE.md §11. The rulings of record are ``D-IMPL-224``
    (a product gate is a **declared**, CI-checked property of a class) and
    ``D-IMPL-282`` ``R-11`` option 1a (Dave, 2026-09-08), which gives that
    declaration a runtime home: *"The gate identity/version remain declared in
    the Control Plane; implementation is deployment-supplied."*

    **Two halves, and they stay apart.** This member is the half the Control
    Plane governs — *which* invariant a class declares, under what id, at what
    lane. The other half, what the invariant actually computes, is a
    :class:`~ccf.products.resolver.ProductGateProtocol` callable the deployment
    supplies to :func:`~ccf.products.resolver.build_governed_resolver`. Nothing
    here evaluates anything and the SDK reads neither string: both are the
    deployment's own vocabulary (CLAUDE.md §6.4). What the split buys is
    ``D-14`` — a refusal can name the gate that produced it
    (:class:`~ccf.products.gates.ProductInvariantRefusal`), and an admitted
    determination names the gate that ran through the declaration its served
    record already pins, because a declared identity is pinned by pinning the
    document that declares it.

    **Not a widening of the gate vocabulary** (``D-11``, ``D-13``).
    :data:`~ccf.products.gates.GATE_DECLARED_OBLIGATIONS` and its one-member
    ``Literal`` are untouched by this class existing; a class declaring a gate
    here joins no token to :func:`~ccf.products.gates.run_gates`' sequence, and
    what a deployment gains is a product invariant rather than a policy
    vocabulary.

    Attributes:
        gate_id: The deployment's own name for the invariant. The empty string
            is one half of :data:`NO_PRODUCT_GATE` and is never a declared id.
        gate_version: The lane that id is declared at, so replay resolves the
            gate a determination ran under rather than the gate in force now
            (whitepaper §7.10; CLAUDE.md §7.4 — replay resolves exact versions,
            never *"latest"*).

    **A half-declared identity is refused at parse.** An id with no lane, or a
    lane with no id, cannot be recorded in a replay record that has to answer
    *which gate, at which version* — and the author is the only one who knows
    which half they meant, so this refuses rather than repairs, in
    :func:`~ccf.deployment.binder.refuse_operator_set_divergence`'s voice.

    Both members are hash-transparent at the empty string, on
    :class:`ServeObligations`' precedent and for a harder reason than tidiness:
    a class declaring no gate must canonicalize byte-identically to the same
    class before this member existed, because pin identity IS content identity
    (``src/ccf/deployment/pins.py::ArtifactPin``) and every committed
    declaration in this tree — and every adopter's, cp-05's included — would
    otherwise move.
    """

    gate_id: str = Field(
        default="", json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )
    gate_version: str = Field(
        default="", json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )

    @model_validator(mode="after")
    def _an_identity_is_whole_or_absent(self) -> DeclaredProductGate:
        if bool(self.gate_id) != bool(self.gate_version):
            raise ValueError(
                "a declared product gate carries both `gate_id` and"
                f" `gate_version` or neither; this one declares gate_id"
                f" {self.gate_id!r} and gate_version {self.gate_version!r}."
                " Half an identity cannot be recorded in a replay record that"
                " has to answer WHICH gate at WHICH version (`D-IMPL-282`"
                " `R-11`), and only the author knows which half was meant"
            )
        return self


#: A product class that declares no runtime invariant of its own.
#:
#: The positive assertion *this class holds itself to the SDK's universal
#: gates and to nothing further* — which is what every product class in this
#: tree, and every one an adopter has already authored, is in fact saying.
#: Written in :data:`NO_SERVE_OBLIGATIONS`' voice and never as a blank: an
#: absent gate is a governance statement, not an unfilled field.
NO_PRODUCT_GATE = DeclaredProductGate()


#: The strength-factor bounds D-IMPL-336's declared-absence treatment sits in.
_ZERO = Decimal(0)
_ONE = Decimal(1)


class OptionalAbsenceTreatment(CCFContract):
    """How a composite treats a DECLARED-ABSENT optional child (D-IMPL-336).

    SDK-defined (CLAUDE.md §11). Declared per requirement in versioned
    product-class configuration, **with no SDK numeric default**: what a
    missing optional input costs is a domain judgement, and a default here
    would be the SDK holding a value (CLAUDE.md §11 *"mechanism, not
    values"*; D-IMPL-38).

    **Absence is not refusal, invalidation, or unauthorized access**, and this
    contract governs only the first. The other three are governed outcomes with
    their own evidence and their own replay rows; letting a policy failure be
    treated as a data gap would make a governance event read as a shortfall.

    Attributes:
        completeness_when_absent: The ``C`` factor this requirement contributes
            when the child is declared absent — a strength factor in ``[0, 1]``
            where lower is worse, entering the composite's per-factor minimum
            exactly as an admitted child's would. **No default.** The composite
            may still refuse on tolerance; this value decides how much the
            absence costs, never whether the product serves.
        omissible_outcomes: Which optional outcomes policy permits omitting
            from the **served payload** — never from replay, where every
            requirement keeps a row. Declared by the deployment and
            interpreted nowhere in the SDK.
    """

    completeness_when_absent: Decimal
    omissible_outcomes: frozenset[str]

    @field_validator("completeness_when_absent")
    @classmethod
    def _is_a_strength_factor(cls, value: Decimal) -> Decimal:
        if not (_ZERO <= value <= _ONE):
            raise ValueError(
                "completeness_when_absent is a strength factor in [0, 1],"
                f" got {value}; a value outside that range cannot enter the"
                " per-factor minimum D-IMPL-104 composes over"
            )
        return value


class ChildRequirement(CCFContract):
    """One child Context Product class a composite requires (D-IMPL-336).

    SDK-defined (CLAUDE.md §11). Names a **class**, never a skill: which
    granted skill satisfies it is resolved at assembly from the agent's
    in-force grants, and a requirement naming an implementation would make the
    composite depend on the thing this pattern exists to decouple from.

    Attributes:
        product_class: The child's ``schema_name``. Matched against a skill
            catalog entry's ``produces``.
        required: Whether the composite can be served without this child.
            **No default** — an author who does not say has not said ``True``,
            and silence is not a declaration (D-IMPL-38).
        compatible_from: The lowest child ``schema_version`` this composite
            composes over. The compatibility rule is **caret-shaped and stated
            rather than parsed**: an admitted child must share this version's
            **major** lane and be **at or above** it. No range grammar is
            introduced — the SDK has none, and inventing one to express a
            single rule would be a new surface for no gain.
        absence_treatment: Required when ``required`` is ``False``, and
            refused when it is ``True`` — a required child has no
            declared-absent case, so carrying a treatment for one would be a
            declaration that can never fire.
    """

    product_class: str
    required: bool
    compatible_from: str
    # ``True`` — transparent at ``None``. A REQUIRED requirement can never
    # carry a treatment (the validator below refuses one), so rendering the key
    # for every required slot would put a permanent ``null`` into the canonical
    # form of every composite class declaration to say something its own
    # ``required`` flag already says.
    absence_treatment: OptionalAbsenceTreatment | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )

    @field_validator("compatible_from")
    @classmethod
    def _floor_is_semver(cls, value: str) -> str:
        return validate_semver(value)

    @model_validator(mode="after")
    def _treatment_matches_optionality(self) -> "ChildRequirement":
        if self.required and self.absence_treatment is not None:
            raise ValueError(
                f"requirement {self.product_class!r} is required and carries an"
                " absence treatment; a required child has no declared-absent"
                " case, so the treatment could never fire (D-IMPL-336)"
            )
        if not self.required and self.absence_treatment is None:
            raise ValueError(
                f"requirement {self.product_class!r} is optional and declares"
                " no absence treatment; what a missing optional input costs is"
                " the class's to state and the SDK holds no default"
                " (D-IMPL-336, D-IMPL-38)"
            )
        return self

    def compatibility_rule(self) -> str:
        """The compatibility rule, stated precisely (`D-IMPL-336` Am. 3, F10).

        Returned as text so a refusal can quote the rule rather than the word
        *"caret"*, which names a convention without defining it.
        """
        return (
            f"same MAJOR lane as {self.compatible_from} and precedence at or"
            " above it, by semantic-version precedence (numeric core compared"
            " field-wise; a pre-release ranks BELOW its own release; build"
            " metadata ignored)"
        )

    def accepts(self, *, child_version: str) -> bool:
        """Whether ``child_version`` is inside this requirement's lane.

        Same major as :attr:`compatible_from`, and at or above it by **semantic
        version precedence** — which is not the same as tuple order once
        pre-releases exist: ``1.2.0-rc1`` precedes ``1.2.0``, per the semver
        specification, and build metadata does not participate at all.

        **Total on every form the grammar accepts** (F10). The earlier body did
        ``int(part)`` over ``split(".")``, so the floor parse raised
        ``ValueError`` mid-admission for a ``compatible_from`` that
        :func:`~ccf.controlplane.artifact_base.validate_semver` had already
        accepted at registration — a broken-deployment error surfacing at the
        wrong boundary — and a legitimate ``1.2.0-rc1`` child was silently
        refused. Both forms are supported here rather than narrowed at
        registration, because the grammar already admits them and taking them
        away would shrink a shipped surface.
        """
        return version_satisfies_floor(floor=self.compatible_from, version=child_version)


def version_satisfies_floor(*, floor: str, version: str) -> bool:
    """Whether ``version`` lies inside the lane ``floor`` opens: same major, at or above.

    The ONE floor rule (`D-IMPL-343` R-13: *"versions_from is a floor
    everywhere"*), stated once and read from three places — a composite's
    :meth:`ChildRequirement.accepts` at admission, a producer's declared offer
    when a consumer's floor is held to it at derivation, and the standard
    door when an address names a floor the served lane must satisfy. Total
    on every form the semver grammar accepts, and ``False`` (never a raise)
    for a string that is not a version, so a malformed floor is a refusal at
    the boundary that read it rather than an error mid-admission.
    """
    try:
        floor_key = _precedence(floor)
        actual = _precedence(version)
    except ValueError:
        return False
    # actual[0] is the (major, minor, patch) CORE; the lane is its MAJOR.
    return actual[0][0] == floor_key[0][0] and actual >= floor_key


def _precedence(version: str) -> tuple[tuple[int, int, int], tuple[object, ...]]:
    """Semantic-version precedence, as a sortable key.

    Implements the specification's ordering rather than approximating it:
    the numeric core compares field-wise; **build metadata is discarded**; a
    version WITH a pre-release ranks below the same version without one; and
    pre-release identifiers compare field-wise with numeric identifiers below
    alphanumeric ones.

    Raises:
        ValueError: ``version`` is not a semantic version.
    """
    validate_semver(version)
    core, _, rest = version.partition("-")
    if not rest:
        core, _, _build = version.partition("+")
        pre: tuple[object, ...] = ()
    else:
        rest, _, _build = rest.partition("+")
        # An empty tuple sorts BELOW a populated one, so a release must sort
        # ABOVE its pre-releases: rank 1 for a release, 0 for a pre-release.
        pre = tuple(
            (0, int(part), "") if part.isdigit() else (1, 0, part)
            for part in rest.split(".")
        )
    major, minor, patch = (int(part) for part in core.split("."))
    rank = 1 if not pre else 0
    return ((major, minor, patch), (rank, *pre))


def requirements_declaration_is_coherent(
    requires: tuple[ChildRequirement, ...],
) -> None:
    """Refuse a requirement list that cannot resolve (D-IMPL-336).

    One rule: **no duplicate ``product_class``**. Two requirements naming one
    class have no distinct resolution — the same granted skill would satisfy
    both under two names, invoked twice, recorded twice, and composed twice.

    Raises:
        ValueError: a class appears more than once.
    """
    seen: set[str] = set()
    for requirement in requires:
        if requirement.product_class in seen:
            raise ValueError(
                f"product class {requirement.product_class!r} appears twice in"
                " `requires`; two requirements naming one class have no"
                " distinct resolution (D-IMPL-336)"
            )
        seen.add(requirement.product_class)


class RegisteredProductClass(CCFContract):
    """Class-level governance of one product class, resolved at registration.

    Attributes:
        schema_name: Class identity.
        schema_version: The class's own semver lane (INV-CH7-49).
        ttl_anchor: Declared TTL derivation anchor (D-IMPL-31).
        assembly_mode: Declared mode (INV-CH7-55).
        max_ttl_key: Control Plane key of the class's MAX_TTL artifact.
        max_ttl_version: The pinned version of it. Pinned rather than
            "latest" so that the ceiling a decision was gated against is
            re-resolvable years later (whitepaper §7.10, D-IMPL-26).
        accepted_policy_binding_modes: The **accepted modes** of the
            ``policy_binding`` attestation dimension — SDK-defined per
            CLAUDE.md §11, realizing D-09 (see
            :class:`~ccf.controlplane.artifacts.ProductClassDeclaration`
            for the authored side). An unordered set, never an ordered
            minimum: no strength ordering between modes is invented. The
            default is the tier-1 ``{"assembly-stamped"}`` posture every
            pre-attestation class already lived under, so tier-2
            consumption is deny-by-default until a class opts in. Carried
            here because this is the value ``run_gates`` receives — the
            gate derives the class side of the attestation comparison from
            what it already holds.
        accepted_lineage_modes: The accepted modes of the ``lineage``
            attestation dimension, under exactly the same discipline;
            tier-1 default ``{"graph-supplied"}``.
        freshness_sla: The §6.3 **Freshness SLA** element, per signal
            (D-IMPL-106 option (b)). Defaults to
            :data:`UNMEASURED_FRESHNESS_SLA`.
        discovery: The §6.3 **Discovery** element. Defaults to
            :data:`NOT_DISCOVERABLE`.
        addressability: The §6.3 **Addressability** element, path half only;
            the argument half is D-IMPL-98's typed request contract. Defaults
            to :data:`NOT_ADDRESSABLE`.
        constituent_validity_floors: D-IMPL-31's declarable floors. Declared
            here, refused on at assembly by plan ``15.5-12``. Defaults to
            :data:`NO_VALIDITY_FLOORS`.
        payload_schema_key: Control Plane key of the class's declared payload
            schema, or :data:`NO_PAYLOAD_SCHEMA`.
        payload_schema_version: The pinned version of it, on the same
            (key, version) discipline as ``max_ttl_version`` and for the same
            reason — the schema a payload was held to must be re-resolvable
            years later — or :data:`NO_PAYLOAD_SCHEMA`. The pair moves
            together; half a pin is refused at registration.
        request_contract_key: Control Plane key of the class's declared
            request contract (D-IMPL-98's typed request surface — *which
            questions this class answers*), or
            :data:`~ccf.products.request.NO_REQUEST_CONTRACT`. The mirror of
            :attr:`~ccf.controlplane.artifacts.ProductClassDeclaration
            .request_contract_key`, resolved at registration rather than
            trusted from the declaration.
        request_contract_version: The pinned version of it, on the same
            (key, version) discipline as the payload-schema pin and for the
            same reason — the surface a *question* was validated against has
            to be re-resolvable years later for a decision to replay — or
            the same sentinel. The pair moves together; half a pin is refused
            at registration.
        serve_obligations: The class's declared :class:`ServeObligations`
            (``24.5-L-14``, ``24.5-L-26``; ``D-IMPL-237``) — the debt ceiling
            and the lineage members the ONE structural declared-obligations
            gate in :func:`~ccf.products.gates.run_gates` holds a served
            product to. Carried here because this is the value the gate
            receives, on the ``accepted_lineage_modes`` reasoning. Defaults to
            :data:`NO_SERVE_OBLIGATIONS`, under which the gate is silent.
            Hash-transparent at that sentinel (``D-IMPL-243``): a class
            obliging nothing is every pre-phase class, so the field is
            omitted from the canonical form at that value and rendered at
            any declared obligation.
    """

    schema_name: str
    schema_version: str
    ttl_anchor: TTLAnchor
    assembly_mode: AssemblyMode
    max_ttl_key: str
    max_ttl_version: str
    accepted_policy_binding_modes: frozenset[PolicyBindingMode] = frozenset(
        {"assembly-stamped"}
    )
    accepted_lineage_modes: frozenset[LineageMode] = frozenset(
        {"graph-supplied"}
    )
    freshness_sla: FreshnessSLA = UNMEASURED_FRESHNESS_SLA
    discovery: ProductDiscovery = NOT_DISCOVERABLE
    addressability: ProductAddress = NOT_ADDRESSABLE
    constituent_validity_floors: ConstituentValidityFloors = NO_VALIDITY_FLOORS
    payload_schema_key: str = NO_PAYLOAD_SCHEMA
    payload_schema_version: str = NO_PAYLOAD_SCHEMA
    request_contract_key: str = NO_REQUEST_CONTRACT
    request_contract_version: str = NO_REQUEST_CONTRACT
    serve_obligations: ServeObligations = Field(
        default=NO_SERVE_OBLIGATIONS, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )
    requires: tuple[ChildRequirement, ...] = Field(
        default=(), json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )

    @model_validator(mode="after")
    def _requirements_resolve(self) -> "RegisteredProductClass":
        requirements_declaration_is_coherent(self.requires)
        return self


class ProductLineage(CCFContract):
    """The L axis as it appears on a delivered product (INV-CH7-47).

    Attributes:
        operators_invoked: The operator set the *producer declares* it ran.
            Declared, not observed — the L6 lineage gate compares it against
            the engine's independent record, and a field the engine filled in
            would make that comparison vacuous.
        policy_bundle_versions: Every Control Plane policy-bundle version bound
            into the state this product was assembled from. A set, because
            state assembled under two bundle versions has two bindings and
            collapsing them would lose the one that mattered.
        graph_snapshot_at: The temporal anchor of the graph state read.

    **The substrate's transaction-time head is NOT here** (``D-IMPL-309``).
    It was, from ledger row ``24.5-L-02`` until `MOD-05`, and it made the same
    governed question seal to two addresses when a ledger advanced between two
    runs for reasons unrelated to the question. Dave's ruling: *"Logical
    determination identity is addressed. Physical store furniture is
    recorded."* The head is execution provenance — recorded authoritatively in
    :class:`~ccf.replay.record.ContextFabricSnapshot`, derived there from the
    execution rather than from this lineage, compared at replay, and reached
    through the product's replay reference. It is **absent** here rather than
    merely excluded from the hash because
    :func:`~ccf.contracts.canonical.canonical_bytes` is at once this model's
    address, its stored form and its wire form: a field omitted from it is not
    excluded from identity but erased, and read back as the sentinel — a
    positive claim that the substrate exposes no head, which would be a false
    fact the fabric manufactured about its own evidence. This changes where
    the evidence lives, not whether it exists. A snapshot the caller
    *declared* is a different thing: a semantic input to the determination,
    addressed like any other declared context.
    """

    operators_invoked: frozenset[str]
    policy_bundle_versions: frozenset[str]
    graph_snapshot_at: datetime


class ComputedEmptyFinding(CCFContract):
    """The search behind an empty answer — SDK-defined (CLAUDE.md §11).

    Whitepaper §7.6 for the vessel this rides on; the finding itself is an SDK
    extension and its ruling of record is ``D-IMPL-242`` **amendment 1** with
    ``D-IMPL-253`` Q11/Q12 and ``D-IMPL-255`` (2) (ledger row ``24.6-L-06``).

    **An operator that ran and returned nothing computed something.** Until
    ``24.6-05`` that observation was a refusal — the returned half of the
    empty-operator gate, ``empty-operator-result`` — which conflated *absence
    of input* with *absence of execution*. Dave: *"An operator successfully
    evaluating an empty graph did compute something. Calling it uncomputed
    conflates absence of input with absence of execution. Serve computed-empty
    with the evidence-derived Debt."* So the emptiness is served, and it is
    served **with its search attached**: a consumer reading an empty payload
    sees what ran, what it ran over and where, rather than silence.

    Only the DECLARED half of gate 1 still refuses
    (:func:`~ccf.products.gates._refuse_empty_operators`, INV-CH7-46): a
    product computed by nothing was not computed at all.

    **``emptiness`` is a statement about EVIDENCE QUALITY and never about
    Debt** (``D-IMPL-255`` (2): *"Cardinality never determines Context Debt.
    Evidence determines Context Debt"*, and *"do not let 'unattested
    emptiness' itself secretly become the new Debt = 1 shortcut"*). It is
    written here by the resolver from :func:`~ccf.products.debt_scorer.emptiness_of`
    and it is read by no scorer the SDK ships. A consumer weighing an empty
    answer reads it beside ``debt``; nothing in the fabric turns it into a
    number.

    Attributes:
        operators_returned_empty: Every operator key whose output view carried
            zero entities and zero relationships, as the engine observed it
            (:attr:`~ccf.projection.engine.ExecutionResult.empty_results`).
            Never empty on a constructed finding — the absence of the finding
            is how *no operator returned empty* is said, so a finding naming
            nothing would be a second spelling of ``None``.
        operators_invoked: Every operator the execution invoked, so the
            emptiness is legible as a fraction of the search rather than as a
            bare list: one empty operator out of four is a different fact from
            four out of four.
        plan_id: The projection plan that ran. The question's own identity
            travels on the vessel; this is the interpretation's.

        emptiness: ``"attested"`` when a query actually executed against a
            source attesting coverage, ``"unattested"`` otherwise. The
            classification is :func:`~ccf.products.debt_scorer.emptiness_of`'s
            and the vocabulary is closed here.

    Hash-transparent **only at its absence** on the vessel: see
    :attr:`ContextProductContract.computed_empty`. The finding itself declares
    no optional member, because every member is a fact about a search that did
    happen.
    """

    operators_returned_empty: frozenset[str]
    operators_invoked: frozenset[str]
    plan_id: str
    emptiness: Literal["attested", "unattested"]

    @field_validator("operators_returned_empty")
    @classmethod
    def _a_finding_names_at_least_one_operator(
        cls, value: frozenset[str]
    ) -> frozenset[str]:
        if not value:
            raise ValueError(
                "a computed-empty finding names at least one operator that "
                "returned empty; the ABSENCE of the finding "
                "(`ContextProductContract.computed_empty is None`) is how "
                "`no operator returned empty` is said, and a second spelling "
                "of it would make two products with the same search hash "
                "differently (24.6-L-06)"
            )
        return value

    @classmethod
    def of(
        cls,
        execution: "ExecutionResult",
        *,
        emptiness: Literal["attested", "unattested"],
    ) -> "ComputedEmptyFinding | None":
        """The finding for ``execution``, or ``None`` when nothing returned empty.

        ``None`` rather than an empty finding, for the reason the validator
        above states: the two would be the same claim written two ways, and
        one of them is what every product assembled before this field existed
        already says.

        ``execution`` is read structurally and this module imports the
        projection engine only under :data:`typing.TYPE_CHECKING`:
        :mod:`ccf.projection.engine` imports *this* module, so a runtime
        import would be a cycle — and the attributes read here are the
        engine's own record, which is the only source this finding is allowed
        to have (``D-IMPL-238`` limb 3: operator keys and the execution
        record, never the payload). The execution's store head is **not**
        among them (``D-IMPL-309``): it is execution provenance, it is
        recorded in replay dimension 1, and a finding that sealed it would
        make two identical searches two findings.
        """
        if not execution.empty_results:
            return None
        return cls(
            operators_returned_empty=frozenset(execution.empty_results),
            operators_invoked=frozenset(execution.operators_invoked),
            plan_id=execution.plan_id,
            emptiness=emptiness,
        )


class ContextProductContract(CCFContract):
    """The typed unit L6 delivers — and the only thing an agent may consume.

    Whitepaper §6.3, §7.6; DESIGN.md §2B.3. ``extra=forbid`` and frozen by
    inheritance from :class:`~ccf.contracts.base.CCFContract`: an unvalidated
    or forged product is a validation failure, never a served product.

    Constructing an instance of this class is *not* the same as having
    something servable. This type is the candidate; :class:`
    ~ccf.products.gates.ServableProduct` is the gated result, and only
    :mod:`ccf.products.gates` can mint one.

    Attributes:
        debt: The :class:`~ccf.halflife.assessment.DebtAssessment` in force
            when this product was assembled (§7.7, D-IMPL-99/100) — per factor,
            so a consumer can see *which* of freshness, completeness or
            semantic consistency collapsed rather than only how far. ``None``
            is the positive assertion *this product was assembled with no debt
            assessment*, in the :data:`~ccf.replay.record.NO_HITL_ACTIONS`
            voice: it is what every product shipped before this field existed
            was in fact asserting, and an unassessed product and one whose
            assessment somebody dropped would otherwise be the same artifact.
            The default is what keeps all 42 existing construction sites saying
            exactly what they always said.
        debt_evidence: What that assessment points at (D-IMPL-118) — the
            handles for the things whose decay it summarises. A **sibling of**
            ``debt`` rather than a member of it, which is the ruled placement
            and not a convenience: see the note below for what the sibling
            costs and why the cost was authorized. Defaults to
            :data:`~ccf.halflife.assessment.NO_DEBT_EVIDENCE`, the positive
            assertion *this product was assembled with no evidence pointers*,
            so every construction site written before this field existed says
            exactly what it always said.
        source_refresh_recency: When the oldest and the newest of the
            assembling deployment's sources last refreshed, as that deployment
            declares it (D-IMPL-112 gap 2, D-IMPL-117, D-IMPL-124). A **second
            sibling of** ``debt`` under the same ruled placement, and a fact
            distinct from the ``debt.factors.freshness`` beside it: F says how
            much of a decay budget has been spent, and says nothing about when
            the upstream registry last published. It is a
            :class:`~ccf.halflife.assessment.SourceRefreshWindow` and **not** a
            per-source map: D-IMPL-124 ruled that the field's purpose is
            freshness rather than source enumeration, so no source identity and
            no count crosses onto the vessel. Reducing a deployment's declared
            per-source instants to this window is the deployment's work — it is
            the only party that knows its own set is complete. Defaults to
            :data:`~ccf.halflife.assessment.NO_SOURCE_REFRESH_RECENCY`, the
            positive assertion *this product records nothing about when its
            sources last refreshed*.
        obligation_in_force: What the deployment's debt profile bound to the
            routing state this decision landed in (D-IMPL-112 gap 3,
            D-IMPL-117). A **third sibling of** ``debt`` under the same ruled
            placement. The *resolved* reference for this decision's signal, not
            the profile's whole mapping — the vessel records what this decision
            was obliged to do, and the calibration stays on the artifact that
            owns it. Opaque: the SDK never parses it and never acts on it.
            Defaults to
            :data:`~ccf.halflife.assessment.NO_OBLIGATION_IN_FORCE`, the
            positive assertion *no obligation was bound to the state this
            decision landed in*. Carried as
            :data:`~ccf.halflife.assessment.ObligationInForce`, which admits
            that sentinel or a declared reference and refuses a blank — the
            third state that asserts neither and would reproduce inside this
            product's content address as if it did.
        computed_empty: The search behind an empty answer
            (:class:`ComputedEmptyFinding`; ``24.6-L-06``, ``D-IMPL-242``
            amendment 1). A **fourth sibling of** ``debt`` under the same
            ruled placement, and a fact of a different kind from the three
            beside it: those describe how much of a decay or coverage budget
            was spent, while this names *which operators ran and returned
            nothing*, over which plan and which store head. ``None`` is the
            positive assertion *no operator returned empty* — which is what
            every product assembled before this field existed was in fact
            saying, and what a product whose operators all returned rows says
            now. **Hash-transparent at ``None``** under ``D-IMPL-243``: a
            product with no such finding renders exactly as it did before the
            field existed, so no content address moved and the golden
            ``13bd250`` record still replays.

            The finding is EVIDENCE, never a verdict: nothing in the SDK reads
            ``computed_empty.emptiness`` back into ``debt``
            (``D-IMPL-255`` (2)).
    """

    schema_name: str
    schema_version: str
    plan_id: str
    tenant_id: str
    temporal_boundary: datetime
    expires_at: datetime
    ttl_anchor: TTLAnchor
    # `D-IMPL-341` R-2: the instant the class's anchor resolved to — the
    # decision instant for `from_decision`, the freshest contributing evidence
    # instant for `from_entity_freshness` — so a reader can see the basis
    # rather than infer one. `expires_at - ttl_anchor_at` is the declared
    # window for a plain product; for a COMPOSITE it is at most that, because
    # `expires_at` is `D-IMPL-336` F14's floor over the children and a floor is
    # a bound rather than a freshness claim (design §8). Hash-transparent at ``None``: a product minted before the member
    # existed keeps its address, and ``None`` is that pre-341 sentinel only —
    # never a shortcut on a new product.
    ttl_anchor_at: datetime | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )
    lineage: ProductLineage
    payload: Mapping[str, Any]
    debt: DebtAssessment | None = None
    debt_evidence: DebtEvidence = NO_DEBT_EVIDENCE
    source_refresh_recency: SourceRefreshRecency = NO_SOURCE_REFRESH_RECENCY
    obligation_in_force: ObligationInForce = NO_OBLIGATION_IN_FORCE
    computed_empty: ComputedEmptyFinding | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )


def register_product_class(
    *,
    registry: ControlPlaneProtocol,
    schema_name: str,
    schema_version: str,
    ttl_anchor: TTLAnchor,
    assembly_mode: AssemblyMode,
    max_ttl_key: str,
    max_ttl_version: str,
    accepted_policy_binding_modes: frozenset[PolicyBindingMode] = frozenset(
        {"assembly-stamped"}
    ),
    accepted_lineage_modes: frozenset[LineageMode] = frozenset(
        {"graph-supplied"}
    ),
    freshness_sla: FreshnessSLA = UNMEASURED_FRESHNESS_SLA,
    discovery: ProductDiscovery = NOT_DISCOVERABLE,
    addressability: ProductAddress = NOT_ADDRESSABLE,
    constituent_validity_floors: ConstituentValidityFloors = NO_VALIDITY_FLOORS,
    payload_schema_key: str = NO_PAYLOAD_SCHEMA,
    payload_schema_version: str = NO_PAYLOAD_SCHEMA,
    request_contract_key: str = NO_REQUEST_CONTRACT,
    request_contract_version: str = NO_REQUEST_CONTRACT,
    requires: tuple[ChildRequirement, ...] = (),
    serve_obligations: ServeObligations = NO_SERVE_OBLIGATIONS,
) -> RegisteredProductClass:
    """Register a product class, requiring its MAX_TTL to already exist.

    Whitepaper §7.6; D-IMPL-39. The MAX_TTL is resolved *here*, at
    registration, so a deployment that forgot to configure a ceiling finds out
    while wiring the fabric rather than when a product is about to be served —
    at which point the only remaining options are a silent default (forbidden)
    or a failure in front of a caller.

    ``accepted_policy_binding_modes`` / ``accepted_lineage_modes`` carry the
    class's D-09 accepted attestation modes onto the registered value (from
    :class:`~ccf.controlplane.artifacts.ProductClassDeclaration`'s fields of
    the same names). Their defaults are the tier-1 posture, so a caller that
    registered before attestation existed registers exactly what it always
    implicitly demanded.

    The three §6.3 elements landed by plan ``15.5-07`` — ``freshness_sla``
    (D-IMPL-106), ``discovery`` and ``addressability`` (D-IMPL-98) — and
    D-IMPL-31's ``constituent_validity_floors`` all default to named positive
    sentinels rather than to required arguments, so every registration written
    before they existed keeps asserting exactly what it always asserted. See
    each sentinel for what it asserts.

    **The payload-schema pin, and why it is resolved here** (D-IMPL-102 limb
    1, *schema validity at registration*). A class that declares a payload
    schema names it by ``(key, version)`` and the schema must already be
    registered, on exactly the MAX_TTL reasoning: a deployment that pinned a
    schema that is not there finds out while wiring the fabric, not when a
    request is about to be bound to it. The well-formedness half of limb 1 is
    structural rather than a check that could be forgotten — a malformed
    :data:`~ccf.products.payload.ProductPayloadSchema` cannot be constructed
    at all (D-IMPL-56's required-names validator and D-IMPL-103's nesting
    ceiling both refuse at construction), so what remains for registration is
    that the pinned artifact **is** one, which is checked by type exactly as
    MAX_TTL's is.

    **No fourth gate follows from any of this** (D-IMPL-102, limb 3). The
    conformity comparison the pin makes possible runs at bind — request time
    — on the surface D-IMPL-98 creates. :func:`ccf.products.gates.run_gates`
    is untouched and the three shipped validation gates stay at three.

    ``serve_obligations`` (``24.5-L-14``, ``24.5-L-26``) is passed straight
    through onto the registered value: it is a declared obligation the ONE
    structural gate ``D-IMPL-237`` licenses reads at serve, not a payload
    gate, and its default — :data:`NO_SERVE_OBLIGATIONS` — keeps every
    registration written before it existed asserting exactly what it always
    asserted.

    Raises:
        ProductClassRegistrationError: no MAX_TTL is registered at
            ``(max_ttl_key, max_ttl_version)``, or the artifact there is not a
            :class:`MaxTTL`; or the payload-schema pin is half-declared, names
            nothing registered, or names an artifact that is not a payload
            schema; or ``serve_obligations`` declares a default for a
            parameter the class's request contract does not declare as an
            argument (``D-IMPL-258`` (5) —
            :func:`~ccf.products.request.refuse_undeclared_class_default`).
    """
    try:
        artifact = registry.resolve(max_ttl_key, max_ttl_version)
    except ControlPlaneMissing as missing:
        raise ProductClassRegistrationError(
            f"product class {schema_name!r} declares MAX_TTL at "
            f"({max_ttl_key!r}, {max_ttl_version!r}), which is not registered; "
            "MAX_TTL is required Control Plane configuration per product class "
            "and the SDK ships no default (D-IMPL-39)"
        ) from missing
    if not isinstance(artifact, MaxTTL):
        raise ProductClassRegistrationError(
            f"product class {schema_name!r} declares MAX_TTL at "
            f"({max_ttl_key!r}, {max_ttl_version!r}), which holds "
            f"{type(artifact).__name__}, not MaxTTL"
        )
    _refuse_payload_schema_pin(
        registry=registry,
        schema_name=schema_name,
        payload_schema_key=payload_schema_key,
        payload_schema_version=payload_schema_version,
    )
    # The import is function-local for exactly the reason the payload one
    # below is, and one reason more: `ccf.products.request` imports
    # `ProductClassRegistrationError` from THIS module, so a top-level import
    # here would close the cycle directly rather than through the skills
    # catalog. The resolution happens once per class registration, at wiring
    # time, so the deferral costs nothing.
    from ccf.products.request import (
        refuse_request_contract_pin,
        refuse_undeclared_class_default,
    )

    declared = refuse_request_contract_pin(
        registry=registry,
        schema_name=schema_name,
        schema_version=schema_version,
        request_contract_key=request_contract_key,
        request_contract_version=request_contract_version,
    )
    # `D-IMPL-258` (5): a default naming a parameter the request contract does
    # not expose is a malformed declaration, and it fails HERE — where the
    # author can still fix it — rather than producing a shell to a caller. The
    # contract is the one the pin refusal just resolved, so the two checks
    # cannot disagree about what this class's request surface is.
    refuse_undeclared_class_default(
        schema_name=schema_name,
        schema_version=schema_version,
        serve_obligations=serve_obligations,
        declared=declared,
    )
    return RegisteredProductClass(
        schema_name=schema_name,
        schema_version=schema_version,
        ttl_anchor=ttl_anchor,
        assembly_mode=assembly_mode,
        max_ttl_key=max_ttl_key,
        max_ttl_version=max_ttl_version,
        accepted_policy_binding_modes=accepted_policy_binding_modes,
        accepted_lineage_modes=accepted_lineage_modes,
        freshness_sla=freshness_sla,
        discovery=discovery,
        addressability=addressability,
        constituent_validity_floors=constituent_validity_floors,
        payload_schema_key=payload_schema_key,
        payload_schema_version=payload_schema_version,
        request_contract_key=request_contract_key,
        request_contract_version=request_contract_version,
        requires=requires,
        serve_obligations=serve_obligations,
    )


def _refuse_payload_schema_pin(
    *,
    registry: ControlPlaneProtocol,
    schema_name: str,
    payload_schema_key: str,
    payload_schema_version: str,
) -> None:
    """Raise unless the class's payload-schema pin resolves to a schema.

    Split out of :func:`register_product_class` rather than inlined so the
    MAX_TTL resolution above stays readable as one thing; the refusal
    discipline is identical to it — raised, never returned or warned, naming
    both sides, because a class whose governance configuration is absent or
    malformed must not become servable (D-IMPL-39's reasoning, applied to
    D-IMPL-102 limb 1).

    The import of the payload module is function-local, and deliberately.
    :mod:`ccf.products.payload` reaches
    :class:`~ccf.skills.catalog.SkillArgumentSchema`, and
    :mod:`ccf.skills.catalog` completes its own definitions by importing
    :mod:`ccf.agents.definitions`, which imports this module — so a top-level
    import here would close a cycle at load time. The deferral is the same
    device :mod:`ccf.skills.catalog` already uses at its own foot, for the
    same reason, and it costs nothing: the resolution happens once per class
    registration, at wiring time.
    """
    from ccf.products.payload import ProductPayloadSchema

    declared_key = payload_schema_key != NO_PAYLOAD_SCHEMA
    declared_version = payload_schema_version != NO_PAYLOAD_SCHEMA
    if declared_key != declared_version:
        raise ProductClassRegistrationError(
            f"product class {schema_name!r} declares half a payload-schema "
            f"pin: key={payload_schema_key!r}, version="
            f"{payload_schema_version!r}. A schema is pinned by (key, "
            "version) so that the schema a payload was held to is "
            f"re-resolvable years later; either both are {NO_PAYLOAD_SCHEMA!r} "
            "or neither is (D-IMPL-102, D-IMPL-26)"
        )
    if not declared_key:
        return
    try:
        artifact = registry.resolve(payload_schema_key, payload_schema_version)
    except ControlPlaneMissing as missing:
        raise ProductClassRegistrationError(
            f"product class {schema_name!r} declares its payload schema at "
            f"({payload_schema_key!r}, {payload_schema_version!r}), which is "
            "not registered; a declared schema is resolved at registration so "
            "that a deployment which pinned a schema that is not there finds "
            "out while wiring the fabric rather than at bind (D-IMPL-102 "
            "limb 1)"
        ) from missing
    if not isinstance(artifact, ProductPayloadSchema):
        raise ProductClassRegistrationError(
            f"product class {schema_name!r} declares its payload schema at "
            f"({payload_schema_key!r}, {payload_schema_version!r}), which "
            f"holds {type(artifact).__name__}, not a payload schema "
            f"({ProductPayloadSchema.__name__})"
        )
