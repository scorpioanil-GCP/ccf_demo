# Copyright (c) 2026 David Castillo. All rights reserved.
# Use, copying, modification, and distribution of the covered material
# are governed by the CCF SDK Interim Software and Patent License
# in the repository-root LICENSE.md and any controlling signed agreement.
# Rights under that interim license begin only upon its execution
# and are limited to its stated scope and term.
"""L6 — Context Products, the System of Delivery.

Whitepaper §6.3 (the Context Product Contract specification) and §7.6 (the
delivery layer and its three validation gates); DESIGN.md §2B.3.

A Context Product is a typed, governed, decision-ready unit of meaning shaped
jointly by Intent, Perspective, Time, and Policy (INV-CH6-02) — runtime
assembled, TTL-bound, policy-formative. It is not a data product with better
manners.

Five modules: :mod:`ccf.products.contract` declares the typed contract and the
product-class registration that MAX_TTL configuration hangs off,
:mod:`ccf.products.gates` holds the three-gate sequence, which is the *only*
construction path of anything servable, :mod:`ccf.products.entitlement`
declares the Control Plane artifact stating which product classes a principal
may be served and which roles it may assert — ``P`` applied at delivery, where
the operators apply it during assembly (CLAUDE.md §8.3;
``docs/CONTEXT_PRODUCT_REVISION.md`` §10) — and :mod:`ccf.products.payload`
holds the **declared payload schema** a product class registers and the one
pure comparison that decides whether a payload conforms to it (D-IMPL-97
ruling 1; D-IMPL-102, which put schema validity at registration and payload
conformity at bind and added **no** fourth gate; D-IMPL-103, which widened the
already-proven declaration machinery by one level of nesting rather than
inventing a second one), and :mod:`ccf.products.request` holds the **typed
request contract** a product class declares and the one pure comparison that
decides whether a caller's question conforms to it — the surface that makes a
Context Product *callable* rather than configurable, so its subject and its
instant are arguments the caller supplies rather than literals authored in a
YAML file (D-IMPL-98). Its parameter comparison delegates to
:func:`~ccf.products.payload.refuse_payload` rather than restating it, so one
reading of "conforms" serves both surfaces; its verdict type is distinct, so
the two cannot be confused. The **door** wiring that carries a typed request
across the delivery seam is deliberately not here: D-IMPL-108 ruled that
:class:`~ccf_runtime.mcp.egress.ProductResolverProtocol` and its Experience
sibling are widened exactly once, by plan ``15.5-15``, carrying the request and
the authorized :class:`~ccf.projection.plan.Perspective` together.

Alongside them, :mod:`ccf.products.composition` holds the three
rules by which an aggregate product composes from constituents — the N-way
lineage union, the TTL floor, and D-IMPL-31's mixing refusal. It composes **no
debt**: D-IMPL-104 ruled aggregate debt to be the per-factor maximum across
constituents and deferred implementing it until an aggregate-product surface
exists, so the meaning is on record and the combinator is not.

:mod:`ccf.products.debt_scorer` holds the SDK's reference
:class:`~ccf.products.resolver.AssemblyDebtScorerProtocol` — the thin
``GraphView`` → :class:`~ccf.halflife.assessment.DebtFactors` adapter over the
scoring machinery :mod:`ccf.halflife.debt` already ships. It is here rather than
in :mod:`ccf.halflife` because the Protocol it conforms to is declared beside
:class:`~ccf.products.resolver.GovernedResolver`, and a reference
implementation living apart from its Protocol is the seam a reader has to
discover twice. The ruling of record is
``docs/superpowers/specs/2026-08-16-reference-plan-factory-and-debt-scorer.md``
**Amendment A.1**, which also rules the *plan* factory's reference
implementation impossible as scoped — so this package ships one of the two and
says why it does not ship the other.

The three validation gates remain three. Nothing in
:mod:`ccf.products.payload` is reachable from :func:`ccf.products.gates.run_gates`,
and :class:`~ccf.products.payload.PayloadSchemaViolation` deliberately does not
derive from :class:`~ccf.products.gates.GateRefusal`, so a payload verdict
cannot travel as a gate verdict even by accident. The same holds for
:class:`~ccf.products.composition.MixingRefusal`, which is D-IMPL-31's
assembly-time rule and not a fourth gate.

The package re-exports nothing, deliberately: a second import path for the same
symbol is a second surface the drift manifest has to track.

Algorithmic package (CINV-03).
"""

from __future__ import annotations

__ccf_mode__ = "algorithmic"
