# Copyright (c) 2026 David Castillo. All rights reserved.
# Use, copying, modification, and distribution of the covered material
# are governed by the CCF SDK Interim Software and Patent License
# in the repository-root LICENSE.md and any controlling signed agreement.
# Rights under that interim license begin only upon its execution
# and are limited to its stated scope and term.
"""The seam that yields a *gate-admitted* product, declared in ``src/``.

**SDK-defined, not whitepaper-derived** (CLAUDE.md §11). The whitepaper
specifies the Context Product Contract (§6.3), the three validation gates
(§7.6) and the Decision Replay record (§7.10); it specifies no client, and so
no seam through which a client reaches a served product. The ruling of record
is ``docs/superpowers/specs/2026-08-15-ccf-client-design.md`` **Amendment 1
§B** (Dave, 2026-08-15): *the resolver Protocol is declared in* ``src/``, *and
the SDK ships its reference implementation in* ``src/`` *as well*.

Why the ruling was needed
-------------------------
Phase 17 research measured that **no** ``src/``-resident seam yields a
gate-admitted product, and that **no** module under ``src/`` imports
``ccf_runtime``. The two seams that do yield one live in ``runtime/``, behind
the two MCP doors. The nearest ``src/`` seam,
:class:`~ccf.agents.assembler.ContextAssemblerProtocol`, sits one level *below*
the vessel: its :class:`~ccf.agents.assembler.AssemblyOutcome` carries a
payload, and no contract, no gates and no replay record. A client had no
implementable path.

That gap has a second face. The SDK ships every *part* of assemble → gate →
serve — :func:`~ccf.products.gates.run_gates` and
:func:`~ccf.replay.serve.serve` are both ``src/``-resident — and has never
shipped the *composition*, so every deployment writes it. The rejected first
example wrote it in front of a reader who wanted to ask one question. **The
missing resolver and the oversized example are the same defect seen from two
directions**, which is why :class:`GovernedResolver` ships here rather than
being described in a guide.

The two widenings, and the measured reason for each
---------------------------------------------------
This seam's five arguments are copied from
:class:`~ccf_runtime.mcp.egress.ProductResolverProtocol` **exactly** — same
names, same order, same keyword-only discipline, same nullability — so a
deployment that already wrote a resolver for a door recognises the signature on
sight and maintains one shape rather than two. Only the *return type* widens,
in the two ways research measured to be missing:

**DIV-2 — a replay reference.** The seam returns
:class:`~ccf.replay.serve.ServedProduct`, not
:class:`~ccf.products.gates.ServableProduct`. The first carries ``product``
*and* ``replay_ref``; the second carries only the product.
:mod:`ccf.replay.serve` records the measurement plainly in its own docstring:
all three shipped delivery paths serialize the servable's product and **none**
of them reads its replay reference. The seam being typed to the narrower vessel
is precisely why no door can reach a replay reference. The ruled client
``Result`` exposes one, so the seam must carry one.

**DIV-4 — a refusal.** Every refusal the fabric produces behind the current
seam has nowhere to go: the seam admits no refusal in its union, so a
``GateRefusal`` or a request-conformity verdict either becomes an exception or
becomes silence. :class:`~ccf.products.refusal.RefusalEnvelope` is where it
goes, and :data:`ResolverOutcome` is the union that carries it.

A named divergence, recorded rather than left to be discovered
--------------------------------------------------------------
**The two** ``runtime/`` **seams are unchanged by this module**, and both
remain typed to the narrower vessel:
:class:`~ccf_runtime.mcp.egress.ProductResolverProtocol` and
:class:`~ccf_runtime.mcp.experience.ExperienceProductResolverProtocol`. So
there are, for now, two return shapes across three seams. Unifying them is not
in scope for this phase, is not ruled, and would be a door's worth of work;
stating the divergence here is what keeps it a known cost rather than a
surprise for whoever reads the three seams side by side.

Where the debt scorer's default lives, and what the choice cost
----------------------------------------------------------------
The 2026-08-16 spec §6 requires the reference debt scorer to be selected
automatically *"when the caller does not pass one"*, so that **a deployment
providing only data never has to know the Protocol exists** — and it leaves the
location open: :class:`GovernedResolver` itself, or *"a thin*
``build_governed_resolver(...)`` *helper"*.

**It is the helper**, and the choice was forced by two measurements rather than
settled by taste:

1. **The default is not a value; it is a construction that needs four inputs
   this class does not hold.** :class:`~ccf.products.debt_scorer.AssemblyDebtScorer`
   takes a ``λ_c`` table, a debt profile, and a
   :class:`~ccf.halflife.debt.DebtFactorScorerProtocol` for each of ``C`` and
   ``S``. Only the first two are resolvable from the booted fabric, and only
   given the *keys* that name them; ``C`` and ``S`` have **no** SDK
   measurement at all (:class:`~ccf.halflife.assessment.DebtFactors` records
   that position in its own words). Defaulting on the class would therefore
   have grown it from thirteen arguments to seventeen — four of them dead
   whenever an explicit scorer *is* supplied — in order to give one argument a
   default. A default that enlarges its own seam is not a default.
2. **A shipped assertion already forbids it, and weakening a shipped assertion
   to admit a feature is this phase's signature defect.**
   ``tests/products/test_resolver_seam.py::test_no_constructor_argument_carries_a_default``
   reads every field off the dataclass and requires ``default`` and
   ``default_factory`` to be ``MISSING``. Defaulting here would have required
   deleting or narrowing that test.

So :class:`GovernedResolver` keeps the property its docstring claims —
*"nothing has a default"* — verbatim and under test, and
:func:`build_governed_resolver` is the seam where the SDK selects its own
reference implementation. **What that costs, stated rather than glossed:** there
are now two ways to obtain a resolver, and a reader who finds only the class
will not learn that the SDK ships a scorer. That cost is paid down here, at the
class's own ``debt_scorer`` attribute, and in the helper's docstring — not left
for a reader to discover from a support ticket. **A second default should not be
added without re-reading both measurements above**, because the argument that
selected a helper is about *this* Protocol's shape and does not transfer for
free.

Dependency direction
--------------------
This module lives in :mod:`ccf.products`, beside :mod:`ccf.products.gates` and
:mod:`ccf.products.request`, because it is **product machinery a client
consumes** rather than client machinery. The edge therefore runs one way:
``ccf.client`` depends on ``ccf.products``, never the reverse. A resolver
importing the client would make the fabric's product surface conditional on a
delivery surface, which is the inversion CLAUDE.md §10 keeps out of the layer
stack.

No boundary is crossed to achieve any of this: nothing imported below leaves
``ccf``. ``tests/invariants/test_src_does_not_import_runtime.py`` asserts that
for the whole tree rather than for this module's good intentions.

**Determination → Authority → Disclosure → Delivery** — the architectural
invariant of ``D-IMPL-254``, SDK-defined under CLAUDE.md §11 and not
whitepaper-derived (the whitepaper is deliberately not edited, ``D-IMPL-253``
Q28). Dave's text: *"Internal truth, governing authority, and permitted
disclosure are distinct concerns. The fabric preserves the governed truth of
why a determination was reached; Policy determines what of that truth may cross
the consumer boundary; the response shell expresses only the permitted
disclosure. Decision Replay preserves sufficient governed evidence to
reconstruct both the determination and the disclosure decision."*

**This module is where the four layers meet, and it is the only place they
do.** :class:`GovernedResolver` resolves the request against its authorities
(Authority), assembles and gates it (Determination), and hands every governed
"no" to :class:`ReplayRefusalRecorder` — the one seam that records the internal
truth and returns the shell :func:`~ccf.products.disclosure.disclose` permitted
(Disclosure). What a door does with that shell is Delivery, and a door decides
nothing.

This module is algorithmic (CINV-03): no LLM client on this path, ever. The
gate sequence and the replay append are the algorithmic half of the
Algorithmic ⇄ Semantic Alternation (whitepaper §7.6.6), and a model call
anywhere in the composition would put an unrecorded, irreproducible step
between a candidate and its content address.
"""

from __future__ import annotations

import inspect
import threading
import weakref
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from itertools import islice
from pathlib import Path
from types import (
    BuiltinFunctionType,
    FunctionType,
    GetSetDescriptorType,
    MappingProxyType,
    MemberDescriptorType,
    MethodType,
    MethodWrapperType,
    ModuleType,
)
from typing import Any, Final, Protocol, TypeVar, cast, runtime_checkable

from ccf.artifacts.file_store import FileArtifactStore
from ccf.artifacts.protocol import ArtifactStoreProtocol, DerivedWrite, WriteKinds
from ccf.erasure.index import ErasureIndexProtocol
from ccf.erasure.approval import PinnedPolicySource
from ccf.products.demonstration_clock import DeclaredServeClock, compose_serve_clock
from ccf.erasure.store import ErasureCompositionRefused, compose_erasure_consult
from ccf.erasure.trust import ErasureTrust
from ccf.contracts.base import CCFContract
from ccf.contracts.claims import LineageEntry
from ccf.controlplane.artifacts import (
    DebtProfile,
    RequestBoundParameter,
    DeclaredArtifact,
    HalfLifeTable,
    OperatorParametersArtifact,
    ProductClassDeclaration,
    ReplayBinding,
    TtlBinding,
)
from ccf.controlplane.registry import ControlPlaneProtocol, CrossTenantKeyRefused
from ccf.controlplane.temporal_boundary import (
    PinnedTemporalBoundary,
    resolve_temporal_boundary,
)
from ccf.contracts.canonical import canonical_bytes, content_hash
from ccf.deployment import (
    BootedFabric,
    build_operator_registry,
    refuse_operator_set_divergence,
)
from ccf.graph.protocols import EntityRecord, GraphView, RelationshipRecord, TraversalDepthCapability
from pydantic import ValidationError

from ccf.halflife.assessment import NO_OBLIGATION_IN_FORCE
from ccf.products.composite import (
    ADMITTED_CHILD_CONTRACT_CLASS,
    ChildAdmissionRefusal,
    ChildContractView,
    CompositeChildResolverProtocol,
    AgentConditionedChildResolverProtocol,
    RequestAwareChildResolverProtocol,
    CompositionOutcome,
    GATE_CHILD_ADMISSION,
    child_contract_view,
    compose_children,
    resolve_child_outcomes,
)
from ccf.halflife.debt import DebtAssessment, DebtSignal, assess_debt, context_debt
from ccf.halflife.decay import TemporalOrderError
from ccf.products.contract import (
    AssemblyMode,
    ComputedEmptyFinding,
    ContextProductContract,
    MaxTTL,
    ProductClassRegistrationError,
    ProductLineage,
    RegisteredProductClass,
    SUBJECT_WITHHOLDING_NEVER,
    register_product_class,
)
from ccf.halflife.assessment import (
    DebtFactors,
    NO_SOURCE_REFRESH_RECENCY,
    SourceRefreshRecency,
)
from ccf.products.expiry import (
    FROM_ENTITY_FRESHNESS,
    TTLAnchorUndeclared,
    TTLAnchorResolution,
    refuse_undeclared_ttl_anchor,
    resolve_ttl_anchor,
)
from ccf.products.debt_scorer import (
    AssemblyDebtScorer,
    DeclaredFactor,
    ExecutionEvidence,
    emptiness_of,
)
from ccf.products.constraints import (
    CAPABILITY_TRAVERSAL_DEPTH,
    PolicyConstraintResolver,
    ReferencePolicyConstraintResolver,
    TechnicalCapability,
    _ConstraintSource,
)
from ccf.products.disclosure import (
    DISCLOSURE_MINIMAL,
    DisclosureLevel,
    disclose,
)
from ccf.products.entitlement import (
    ProductEntitlementPolicy,
    product_entitlement_key,
)
from ccf.products.gates import (
    DEBT_TOLERANCE_PARAMETER,
    GATE_LINEAGE_EQUALITY,
    EvidenceAfterDecisionRefusal,
    GateRefusal,
    TTLAnchorRefusal,
    LineageMismatchRefusal,
    ProductInvariantRefusal,
    ServableProduct,
    refuse_over_tolerance,
    run_gates,
)
from ccf.products.provenance import EffectiveRequest, ProvenanceSource
from ccf.products.refusal import (
    refuse_temporal_bound,
    NO_REPLAY_REFERENCE,
    RESOLVED_BY_THE_RESOLVER,
    GovernedRefusalRaised,
    RefusalEnvelope,
    RefusalEvidence,
    RequestIdentity,
    SourceUnavailableRefusal,
    SubjectUnavailableRefusal,
    envelope_for,
)
from ccf.products.request import (
    ProductRequest,
    ProductRequestContract,
    ProductRequestViolation,
    refuse_floor,
    refuse_intent,
    refuse_undeclared_class_default,
    request_seeds,
)
from ccf.products.subject_disclosure import SubjectDisclosurePolicy
from ccf.projection.engine import ExecutionResult, ProjectionEngine
from ccf.projection.plan import Perspective, ProjectionPlan
from ccf.controlplane.artifacts import SeamRefusalBinding
from ccf.replay.record import (
    NO_REFUSAL_SEAM,
    REFUSAL_SEAMS,
    ChildResolution,
    PackagingTrace,
    PerspectiveConditioning,
    PolicyBinding,
    ResolutionNotApplicable,
    build_replay_record,
    new_issuance,
)
from ccf.replay.serve import (
    QueryPinWriter,
    ReplayWriter,
    ServedProduct,
    record_refusal,
    serve,
)
from ccf.authz.capability import (
    CompositionRegister,
    COMPOSITION_PRINCIPAL,
    Authorized,
    Register,
    ReplayMint,
    mint_at_composition,
    verify,
)

__ccf_mode__ = "algorithmic"

__all__ = [
    "DEBT_SCORER_INPUTS",
    "EARLY_POLICY_ACQUISITION_REFUSAL",
    "SHARED_OWNER_WALK_DEPTH",
    "SHARED_OWNER_WALK_OBJECTS",
    "UNHELD_SUBJECT_PROBE",
    "UNHELD_SUBJECT_PROBE_REFUSAL",
    "AcquiredFabricReused",
    "AcquisitionNeedsAQuestionFabric",
    "AcquisitionOverUnverifiableStore",
    "AcquisitionSeamProtocol",
    "AssemblyDebtScorerProtocol",
    "GovernedResolver",
    "IncompatibleRefusalRecorder",
    "InstantAwareDebtScorerProtocol",
    "NeverWithholdingContradicted",
    "NeverWithholdingNeedsAPositiveDeclaration",
    "NeverWithholdingProjectionCanWithhold",
    "NonWithholdingPlanFactoryProtocol",
    "ProductGateProtocol",
    "ProductNotResolvable",
    "WithholdingClassListedReadable",
    "ChildAwareDebtScorerProtocol",
    "CompositeNeedsAnEarlyPolicy",
    "CompositeNeedsAWithholdingStance",
    "CompositePlanFactoryProtocol",
    "CompositeWithheldLate",
    "EarlyPolicyNeedsRequestAwareChildren",
    "PackagingTraceProtocol",
    "PopulationAcquisitionSeamProtocol",
    "PopulationPhaseSharesAnOwner",
    "PopulationQuestion",
    "PopulationReadInSubjectKeyedPhase",
    "ProjectionPlanFactoryProtocol",
    "QuestionStoreReopened",
    "RefusalRecorderProtocol",
    "ReplayRefusalRecorder",
    "SharedOwnerWalkIncomplete",
    "UndeclaredMechanismClass",
    "UnsupportedComposition",
    "ResolverOutcome",
    "ServedProductResolverProtocol",
    "SubjectDisclosingPlanFactoryProtocol",
    "UndisclosedSubjectAnswered",
    "UndisclosedSubjectSubstituteIsHeld",
    "UnheldSubjectProbeIsHeld",
    "UnmarkedStoreNotPresumedFresh",
    "build_governed_resolver",
    "declared_refusal_recorder",
    "refuse_incompatible_refusal_recorder",
]

_Artifact = TypeVar("_Artifact", bound=CCFContract)

#: The four values :func:`build_governed_resolver` needs to construct the SDK's
#: reference debt scorer, named once so the refusals below enumerate them from
#: one place rather than from three hand-written lists.
#:
#: **Why the reference needs four inputs at all**, when "the SDK ships a
#: default" sounds like it should need none: two of ``D_c``'s three factors have
#: no SDK measurement, and the two that name Control Plane artifacts cannot be
#: discovered — the 2026-08-16 spec §6 rules out *"discovery or registration
#: machinery"* in this change, so a key is named or it is not resolvable. What
#: the default supplies is the **machinery** (the ``GraphView`` → ``DebtFactors``
#: adapter, the decay computation, the pinning) and never the **values**.
DEBT_SCORER_INPUTS: Final[tuple[str, ...]] = (
    "half_life_key",
    "debt_profile_key",
    "declared_completeness",
    "declared_semantic_consistency",
)


#: Of those four, the ones that are material for the reference scorer and for
#: **nothing else**.
#:
#: ``24.11-03`` / ``24.10-F-08``. ``debt_profile_key`` is deliberately absent,
#: and its absence is the repair. The mutual exclusion below refuses an
#: explicit ``debt_scorer`` alongside scorer material on the stated ground that
#: *"the material for building the reference would be read by nothing"* — true
#: of these three, and no longer true of the profile. A ``DebtProfile`` also
#: binds the obligation the served product carries, which ``D-IMPL-118`` gave
#: **its own identity on the vessel** rather than making it a rider on debt.
#:
#: So the two are alternatives about **scoring** and never about the
#: **declaration**: a deployment may supply its own scorer *and* name its bands,
#: and before ``24.11-03`` it could not — which made an obligation unreachable
#: on the governed path for every deployment that scores for itself.
_SCORER_ONLY_INPUTS: Final[tuple[str, ...]] = (
    "half_life_key",
    "declared_completeness",
    "declared_semantic_consistency",
)


#: The seam exceptions the SDK ITSELF raises, and therefore knows the meaning of.
#:
#: `D-IMPL-357` B3 — amends `D-IMPL-347` B2 for **SDK-raised** seam classes only.
#: B2's reasoning was that the SDK cannot know whether a deployment's
#: ``ControlRoomUnreachable`` means *the subject is unavailable* or *this
#: deployment is broken*, so only the product may say, in a declared artifact.
#: That reasoning does not reach the SDK's own exceptions: it knows what
#: ``IdentityRefused`` means, because it is the thing that raises it — a source
#: record whose identity value names no entity. Nothing declared a binding for
#: it (B1 introduced the type; no product class mentions it), so the SDK's own
#: refusal escaped the paved road as an untyped error carrying no record.
#:
#: **WHAT THIS MAP IS NOT: A TRUST BOUNDARY.** An earlier revision of this
#: comment claimed a deployment "cannot widen this map, by three separate
#: mechanisms". That was false twice over, and the false half mattered more than
#: the true half, because a guarantee documented wider than it is implemented
#: removes the reader's reason to check. Measured, one line each:
#:
#: * **A module-attribute rebind widens it.** ``ccf.products.resolver`` is an
#:   ordinary module and :data:`Final` is a type-checker annotation with no
#:   runtime force, so ``resolver.SDK_SEAM_REFUSALS = dict(...) | {...}`` simply
#:   rebinds the name.
#: * **A write through the wrapped dictionary widens it.** A
#:   :func:`~types.MappingProxyType` is a view: the garbage collector hands back
#:   its one referent, an in-place insert succeeds, and the proxy then reports
#:   the smuggled key itself.
#:
#: **No in-process mechanism can close either route, and none is attempted.**
#: Both require code already executing in this process, which is inside the
#: trust boundary; the seam callable is deployment code and can obtain the same
#: conversion by importing :class:`~ccf.assembly.worker.IdentityRefused` and
#: raising it. **The match authenticates nothing** — it compares the raised
#: value's own self-reported ``module.QualName``, which any object may spell as
#: it likes — and the authority it grants is exactly the authority of raising
#: the SDK's class directly, which every seam callable already has. Nothing here
#: defends the SDK against its own deployment, and nothing here needs to.
#:
#: **What the three real mechanisms do, stated at their true width:**
#:
#: 1. The :func:`~types.MappingProxyType` refuses **accidental and typed**
#:    mutation — ``SDK_SEAM_REFUSALS[...] = ...`` raises, ``.clear()`` does not
#:    exist — which is what makes the roster assertion in the tests meaningful
#:    rather than a snapshot of whatever the last importer left behind. It is a
#:    hygiene barrier, not a boundary.
#: 2. The bindings **inside** the map are :class:`~ccf.contracts.base.CCFContract`
#:    instances and therefore frozen, so no entry can be retargeted in place:
#:    assigning to ``binding.cause`` raises. Even code that reaches the referent
#:    has to replace a whole entry rather than quietly change what an existing
#:    SDK-owned name means. This is the one mechanism the earlier revision did
#:    not claim, and it is the one that survives the routes above.
#: 3. Every entry names a type inside the ``ccf`` package, and a test resolves
#:    each name to a real exception class to prove the string is not merely
#:    plausible. The SDK still **matches, never imports** (B2): the name is
#:    compared against the raised value's own ``module.QualName``, so nothing
#:    here resolves a dotted path and a misspelling never matches rather than
#:    executing something. The importing is the test's job, not this module's.
#:
#: A fourth mechanism was claimed and is STRUCK, because nothing calls it.
#: ``refuse_seam_refusal_widening`` holds a deployment to a subset of its
#: product class's map, and a whole-tree read finds its definition, its
#: re-export and one unit test — no door in ``src/`` or ``runtime/`` invokes it,
#: and no deployment artifact carries a field naming seam-refusal types that
#: could ever supply its argument. Citing it as a mechanism made this map look
#: narrower than it is: *declaration is not a door* (``D-IMPL-324``). Whether
#: that helper gets a door is a surface question for the project owner, not a
#: claim this constant may rest on.
#:
#: Consulted BEFORE a product class's declared map, so the SDK's meaning is the
#: one minted for its own type: a class cannot restate "this record names no
#: entity" as "you may not see it" and borrow the SDK's authority for it — and a
#: class that declares one of these types is refused at registration rather than
#: quietly overridden (:func:`_refuse_sdk_owned_seam_refusal`).
#:
#: **The second entry — `D-IMPL-364` SEC-008 B2, Dave's choice 1.**
#: :class:`~ccf.signal.envelope.TemporalWriteRefused` is the `D-IMPL-358` step-8
#: write guard's refusal: an acquired envelope whose instant lies outside the
#: tenant's declared temporal window, refused at the acquisition seam BEFORE
#: L2's one writer sees it. Measured before this entry existed, it escaped
#: ``OpenedProduct.answer`` as an untyped error with no record whenever the
#: fabric's second clock read (``ingress_at``, at the seam) had moved past the
#: first (``served_at``) — close-panel finding 3. It is raised INSIDE a governed
#: serve that otherwise produces a record, which is exactly the case
#: `D-IMPL-358` ruling 5 reserves for *"audited through the existing
#: write/admission mechanism where one exists"*: the mechanism is this map, and
#: no record is fabricated for a write path that produces none (a direct caller
#: of the writer is outside the supported ingress surface and gets the writer's
#: own audit, as the writer's docstrings state). The cause is ``nonexistent`` —
#: the fabric holds no admissible observation for this question at this
#: instant — the same reading ``IdentityRefused`` carries, and the vocabulary is
#: closed (:data:`~ccf.products.contract.RefusalCause`). The detail is the
#: refusal's own message, which carries the envelope id, the policy key and the
#: instant verbatim.
SDK_SEAM_REFUSALS: Final[Mapping[str, SeamRefusalBinding]] = MappingProxyType(
    {
        "ccf.assembly.worker.IdentityRefused": SeamRefusalBinding(
            exception="ccf.assembly.worker.IdentityRefused",
            cause="nonexistent",
            error_code="identity-refused",
        ),
        "ccf.signal.envelope.TemporalWriteRefused": SeamRefusalBinding(
            exception="ccf.signal.envelope.TemporalWriteRefused",
            cause="nonexistent",
            error_code="temporal-write-refused",
        ),
    }
)


def _refuse_sdk_owned_seam_refusal(
    declaration: ProductClassDeclaration,
    *,
    _sdk_seam_refusals: Mapping[str, SeamRefusalBinding] = SDK_SEAM_REFUSALS,
) -> None:
    """Raise unless the class leaves the SDK's own seam classes alone.

    `D-IMPL-357` B3, round 3. A class may declare a binding for any exception
    type it owns the meaning of; it may not declare one for a type in
    :data:`SDK_SEAM_REFUSALS`, because the SDK consults its own map first and
    the declaration would therefore do **nothing at all**.

    **Why it is refused rather than ignored.** This project's own doctrine,
    written one function away for the deployment-narrowing case: *an ignored
    widening and an honored narrowing are the same green build, and the operator
    who wrote the extra name would never learn it did nothing.* The class
    declaration is the **control evidence** — reviewed, versioned,
    content-hashed and shown to an examiner — so a class saying that an identity
    failure means *"you may not see it"* while the fabric mints *"does not
    exist"* is a deployed behavior that disagrees with its own approved control
    document, with nothing in the record admitting it. A silently inert control
    is worse than a rejected one.

    **Why REGISTRATION and not the seam.** Refusing when the exception is
    actually raised would turn a governance mistake into precisely the runtime
    failure B3 exists to remove — an untyped error mid-assembly, after a seam the
    deployment supplied had already run. Here both documents are in hand before
    any of that, so the failure names the two things that disagree and the author
    can still fix it.

    **WHEN "at registration" IS PRE-QUESTION, AND WHEN IT IS THE FIRST
    QUESTION.** Both, depending on the caller, and the difference is worth
    stating rather than implying:

    * :mod:`ccf.client.adapters.inprocess` and :mod:`ccf.replay.environment`
      build their resolver while OPENING, so no request exists yet and the
      refusal is genuinely **before any question**;
    * the **paved road** boots a fresh fabric per question and builds the
      resolver inside :meth:`~ccf.products.product.OpenedProduct.answer`, so the
      refusal lands **on the first question asked** — the answering call is
      already in flight. What holds there is the part that matters: it runs
      before the acquisition seam, before the plan, before the gates and before
      any delivery, so nothing is half-assembled, no product is served, and no
      refusal record is minted for what is a governance mistake rather than a
      determination. A later signal than the other two callers get, not a
      different kind of one.

    The check is NOT on
    :class:`~ccf.controlplane.artifacts.ProductClassDeclaration` itself: that
    module cannot import this one (the import direction this module's own
    ``register_product_class`` neighbours already document as a cycle), and a
    model validator is the wrong altitude for a question about a mapping that
    lives here.

    The SDK-first consult order stays as the runtime backstop for anything that
    reaches a resolver by another route, and a control keeps proving it holds.

    **ONE MAP, TWO READERS, THE SAME OBJECT.** ``_sdk_seam_refusals`` is never
    passed by a caller; its default binds the same mapping object
    :meth:`GovernedResolver._declared_seam_refusal` binds, at definition time.
    That is a coherence requirement rather than a hardening one: while this
    function read the module-level NAME and dispatch read the bound OBJECT, a
    rebind made the two disagree — measured — and the refusal then PERMITTED a
    declaration that dispatch still converted under the SDK's cause. A permitted
    declaration that does nothing is precisely the silently-inert control this
    function exists to refuse, so the refusal reproducing it was the worst
    possible place for the inconsistency to live.
    """
    conflicting = [
        binding
        for binding in declaration.seam_refusals
        if binding.exception in _sdk_seam_refusals
    ]
    if not conflicting:
        return
    named = conflicting[0]
    owned = _sdk_seam_refusals[named.exception]
    raise ProductClassRegistrationError(
        f"product class {declaration.schema_name!r} declares a seam refusal for"
        f" {named.exception!r}, which is an exception the SDK RAISES and whose"
        f" meaning the SDK owns: it is bound to cause {owned.cause!r} / code"
        f" {owned.error_code!r} and that binding is consulted first, so this"
        f" declaration's cause {named.cause!r} / code {named.error_code!r} could"
        " never be minted. Drop it from `seam_refusals`. A class declaration is"
        " control evidence, and a control that silently does nothing is worse"
        " than one that is refused (D-IMPL-357 B3)"
    )


#: What a resolver returns: a served product, or the refusal that stands
#: instead of one.
#:
#: A **named** alias rather than an inline union, so the two halves are one
#: nameable thing a ``match`` statement, a decoder and a docstring can all
#: spell identically. An inline union spelled at each of those sites is three
#: places to add a third member to, and the client's decoder is required to be
#: total over exactly this set.
#:
#: Both halves are frozen, ``extra=forbid`` contracts, so an outcome is a value
#: the caller carries onward — it holds no handle, no session and no callback,
#: which is what lets the same shape cross an in-process call and a wire.
ResolverOutcome = ServedProduct | RefusalEnvelope


class ProductNotResolvable(LookupError):
    """The resolver holds no product at the address it was called with.

    An **absence**, so a ``LookupError``, in the voice
    :class:`~ccf_runtime.mcp.egress.ProductNotServable` already uses at the
    egress door. Deliberately a distinct type rather than that one: importing
    it would be the first ``src`` → ``runtime`` edge in the tree, which is
    exactly what Amendment 1 §B ruled out. The two are siblings by shape, not
    by inheritance, and neither is reachable from the other's tree.

    **Raised, never returned**, and the distinction is the one
    :class:`~ccf.products.request.ProductRequestViolation` draws for itself: a
    question this class does not answer is a *bad question* and comes back as a
    refusal value, while an address this resolver was never wired to serve is a
    *broken deployment* and comes back as an exception. Reporting the two the
    same way would let a mis-wiring read to a caller as a governed "no".
    """


class UnsupportedComposition(ProductNotResolvable):
    """A composition SEC-020's rulings do not support, refused by name before it can answer.

    ``D-IMPL-378`` (Dave, 2026-10-07 19:31 MST, Q7–Q9; SDK-defined, CLAUDE.md
    §11). SEC-020 stays OPEN. Each subclass names one combination; every one is
    decided by the composition, never by the subject a question names, so the
    refusal is not itself an existence signal. A ``ProductNotResolvable``, so a
    door's opaque-failure wrap applies: it is a broken composition, not a
    governed "no".
    """


class AcquisitionNeedsAQuestionFabric(UnsupportedComposition):
    """An acquisition phase was about to run over a fabric not booted for its question.

    Q9: *"Enforce a fresh fabric per question whenever acquisition exists."* A
    fabric that outlives its question answers the next one over what this one
    acquired (review finding M-6: asking about a withheld subject and then
    about an identifier that names nothing measured whether the source holds
    the first). Raised by :meth:`GovernedResolver.__call__` immediately before
    the first acquisition phase, before anything is read or fetched for the
    question, unless the fabric was booted with ``for_question=True``
    (:class:`~ccf.deployment.manifest.BootedFabric`). Checked there rather than
    at construction because a resolver built over a fabric it never acquires
    into — the one :class:`~ccf.replay.environment.RecordedEnvironment` builds to
    rebuild a plan — is a supported composition. Over a store whose connection
    names no path, which no boot can make a question fabric, the composition
    is refused at construction instead
    (:class:`AcquisitionOverUnverifiableStore`).
    """


class AcquisitionOverUnverifiableStore(AcquisitionNeedsAQuestionFabric):
    """An acquisition phase composed over a store whose fresh creation the SDK cannot verify, refused before any question runs.

    SEC-020 P4 (a) made strict, ``D-IMPL-378`` (Dave, 2026-10-08 12:29 MST:
    *"Require verifiable fresh creation or refuse acquisition-backed serving.
    Unsupported network compositions must refuse before questions run."*). A
    question fabric is one the boot verified fresh: a store minted at a path
    that did not exist, reserved exclusively by its marker
    (:class:`~ccf.deployment.manifest.QuestionFabricNotFresh` otherwise). A
    store whose adapter connection names no path — a network store's address,
    an in-process store — offers nothing to verify or to mark
    (:attr:`~ccf.deployment.manifest.BootedFabric.store_creation`
    ``"unverifiable"``), so no fabric over it is ever a question fabric and an
    acquisition composition over it could never answer. It is refused at the
    earliest point where the composition and the store kind are both known:
    when :class:`GovernedResolver` is constructed with an acquisition or a
    population phase over such a fabric, and when the paved road is opened
    over a substrate setting its adapter does not take as a path
    (:func:`~ccf.products.product.open_product`). Measured before this: the
    first was refused only at its first call, the second at every question's
    boot. A subclass of :class:`AcquisitionNeedsAQuestionFabric`, whose
    refusal it moves earlier. An adapter declaring its own freshness (P4 (b))
    is not built; until then such a store serves only compositions with no
    acquisition phase.
    """


class PopulationPhaseSharesAnOwner(UnsupportedComposition):
    """The population phase and the subject-keyed phase share an owner: one holds the other.

    Q7: *"Subject-independent acquisition must not receive the requested
    subject indirectly through context or closures. Unsupported combinations
    must refuse construction."* State on the subject-keyed phase's object
    carries a subject that phase was handed into a later question's population
    phase wherever the population phase can reach that object. Refused when the
    resolver is constructed (and, on the paved road, when the product is
    opened): one callable declared as both phases, two phases bound to one
    object, and either phase holding the other phase or the object the other
    is bound to, found by a walk of what it holds.

    The walk (``D-IMPL-378`` decision 3 (a), Dave, 2026-10-09: *"(a). Extend
    the shared-state guard, with a bounded walk and an explicit statement of
    what it cannot detect."*) starts at each phase and follows, one step per
    reference: the object a method is bound to and the function behind it; a
    function's closure cells, default arguments and attributes; an object's
    declared slots (``__slots__``) and instance attributes; the members of a
    ``list``, ``tuple``, ``set`` or ``frozenset`` and the keys and values of a
    ``dict``, subclasses included. It reads what each object stores and calls
    nothing an object defines. It stops after
    :data:`SHARED_OWNER_WALK_DEPTH` steps from a phase, or once it has read
    :data:`SHARED_OWNER_WALK_OBJECTS` references from it. A declared slot
    never assigned and an empty closure cell hold nothing, and the walk reads
    them so (measured by
    ``tests/products/test_q7_walk_unreadable_member_and_unread_holders.py::test_q7_control_a_slot_never_assigned_still_reads_as_holding_nothing``
    and
    ``tests/products/test_q7_walk_unreadable_member_and_unread_holders.py::test_q7_control_an_empty_closure_cell_still_reads_as_holding_nothing``).
    Where reading what an object holds raises otherwise (such as another
    class's member descriptor in a slotted class's namespace), the walk cannot
    complete and the two phases are refused rather than admitted
    (:class:`SharedOwnerWalkIncomplete`, ``D-IMPL-378`` repair 1.8; measured by
    ``tests/products/test_q7_walk_unreadable_member_and_unread_holders.py::test_q7_a_member_the_walk_cannot_read_is_refused_by_name``).

    **What it cannot detect**, stated here and in the security how-to,
    section 4.12:

    * anything further from both phases than either bound;
    * state the two phases share through a third object that neither phase is
      nor is bound to, such as a dictionary both hold;
    * state reached only through a property, another descriptor,
      ``__getattr__`` or ``__getattribute__``, including the dictionary of a
      class that replaces ``__dict__``;
    * state a C-extension object keeps in its own fields, which the walk does
      not read: a ``functools.partial``'s arguments, a
      ``collections.deque``'s members, a ``types.MappingProxyType``'s
      mapping, a generator's frame, an ``operator.methodcaller``'s arguments,
      and a closure cell's contents where the cell is held anywhere but in a
      function's closure (each measured by
      ``tests/products/test_q7_walk_unreadable_member_and_unread_holders.py::test_q7_limit_a_holder_the_walk_does_not_read_is_not_seen``);
    * module globals, and class attributes, a class's own ``__call__``
      included;
    * an object reached only through a weak reference or an external store.

    Keeping the two phases free of shared state beyond what the walk sees is
    the deployment's statement to keep.
    """


class SharedOwnerWalkIncomplete(PopulationPhaseSharesAnOwner):
    """The shared-owner walk could not read everything a phase holds, so the two phases are refused rather than admitted.

    ``D-IMPL-378`` repair 1.8 (Dave, 2026-10-09 10:54 MST: *"Implement the
    specified documentation, citation-checker and shared-owner fixes."*), as
    the findings brief specified it: *"Handle a foreign member descriptor's
    ``TypeError`` as the walk handles an unread slot (or refuse, per 2.4)"* —
    read with repair 2.4 (b), ruled in the same text: *"Refuse when the
    shared-owner walk reaches a limit before completing."* SDK-defined,
    CLAUDE.md §11. SEC-020 stays OPEN.

    Repair 2.4 (b) itself is not built. A walk cut off at either of its
    bounds, :data:`SHARED_OWNER_WALK_DEPTH` or
    :data:`SHARED_OWNER_WALK_OBJECTS`, raises neither this refusal nor any
    other: it admits the two phases, and what lies past the bound is not
    checked (measured by
    ``tests/products/test_q7_shared_owner_bounded_walk.py::test_q7_limit_an_object_one_step_past_the_depth_bound_is_not_seen``
    and
    ``tests/products/test_q7_shared_owner_bounded_walk.py::test_q7_limit_an_object_reached_after_the_object_bound_is_spent_is_not_seen``).
    The walk also reads the SDK's own state a phase holds, which grows as a
    service runs, so it reaches its reference bound sooner the longer a
    service runs (measured by
    ``tests/products/test_q7_paved_road_keeps_answering_as_questions_accumulate.py``;
    the security how-to, section 4.12).

    Raised where :class:`PopulationPhaseSharesAnOwner` is (at construction,
    and on the paved road when the product is opened) when reading what an
    object the walk reached holds raises — such as a slotted class whose
    namespace holds another class's member descriptor, which raises
    ``TypeError`` for this object. The walk cannot show that the object holds
    nothing of the other phase, so it does not admit the pair. A declared slot
    never assigned and an empty closure cell are not such cases, although
    reading either raises: each holds nothing, and is read so (measured by
    ``tests/products/test_q7_walk_unreadable_member_and_unread_holders.py::test_q7_control_a_slot_never_assigned_still_reads_as_holding_nothing``
    and
    ``tests/products/test_q7_walk_unreadable_member_and_unread_holders.py::test_q7_control_an_empty_closure_cell_still_reads_as_holding_nothing``).

    A :class:`PopulationPhaseSharesAnOwner`, so what handles that refusal
    handles this one. The message names the phase the walk started from, the
    cause (the type of the error, never its text), the step it was reading and
    the references it had read: nothing any object holds.
    """


#: SEC-020, ``D-IMPL-378`` ruling P6 (a) (Dave, 2026-10-08 16:40 MST, a
#: conditional implementation go; SDK-defined, CLAUDE.md §11). The identifier
#: the subject-keyed acquisition phase is asked about, in place of the
#: question's subject, before it is asked about that subject
#: (:class:`PopulationReadInSubjectKeyedPhase`). It lies inside
#: :data:`~ccf.products.request.SUBJECT_FLOOR_V1`; a source sees it as one more
#: identifier it does not hold. That it names nothing is checked, not assumed:
#: the fabric is read for it before the call and after it
#: (:class:`UnheldSubjectProbeIsHeld`). For a class with a declared early policy
#: it is the baseline the declared stand-in is compared with: the phase is asked
#: about it and then about the stand-in (``D-IMPL-378`` decision 4 (a),
#: :class:`UndisclosedSubjectSubstituteIsHeld`). SEC-020 stays OPEN.
UNHELD_SUBJECT_PROBE: Final[str] = "ccf-sdk:unheld-subject-probe"


#: The ONE refusal every refusal the subject-keyed acquisition phase raises becomes
#: for a class with a declared early policy (``D-IMPL-378`` repair 2.2 (a),
#: SDK-defined, CLAUDE.md §11; SEC-020 stays OPEN). Dave, 2026-10-09 10:54 MST:
#: *"Replace acquisition-refusal free text under early withholding with constant
#: SDK text in responses and records. Verify that neither the stand-in identifier
#: nor another distinguishing value survives."*
#:
#: Under the early policy that phase is asked about the policy's stand-in in place
#: of a subject the policy does not disclose, and about the asked subject
#: otherwise. What a source says back can carry what it was asked: a refusal's
#: text or its ``error_code`` naming the stand-in for the withheld subject and the
#: asked identifier for a nonexistent one, and a source that answers the stand-in
#: otherwise than another identifier it does not hold choosing another cause or
#: another refusal kind (measured by
#: ``tests/products/test_sec020_early_policy_acquisition_refusal.py``). So, for
#: every question of such a class, whatever the policy decides for the asked
#: subject, a refusal that phase raises — the typed handoff
#: (:class:`~ccf.products.refusal.GovernedRefusalRaised`) carrying any refusal
#: kind or a refusal shell, recorded by its raiser or not, or a type the class or
#: the SDK declares at the seam — is served and recorded as this value, with
#: nothing the source said: one kind (``subject-unavailable``), one cause, one
#: code and one text. The cause is ``undisclosed``, the positive statement that
#: which of the other two applies is not stated, and no code is carried. The
#: record still files it at the ``acquisition`` seam, with the caller's question.
#: A declared population phase is handed no subject, so its refusal carries
#: nothing of the asked subject or the stand-in, and it is kept as its source
#: stated it (measured alike for a withheld and a nonexistent subject by the same
#: module); a class with no early policy keeps its source's refusal as before.
EARLY_POLICY_ACQUISITION_REFUSAL: Final[SubjectUnavailableRefusal] = SubjectUnavailableRefusal(
    cause="undisclosed",
    detail=(
        "the subject-keyed acquisition phase refused this question; under this"
        " class's declared early policy the SDK keeps no statement of the"
        " source's, so every such refusal reads alike (SEC-020; D-IMPL-378"
        " repair 2.2 (a))"
    ),
    error_code=None,
)


#: The ONE refusal a question becomes when ruling P6 (a)'s probe call itself
#: ends in a held refusal (``D-IMPL-378`` OWED-RULINGS-3 item 4 (b), as repaired
#: by 2.3 (b); SDK-defined, CLAUDE.md §11; SEC-020 stays OPEN). Dave, 2026-10-09
#: 10:54 MST: *"Use (d) only if “unknown identifier” has a typed, stable cause.
#: Do not infer it from message text. Otherwise implement (b) with a recorded
#: constant SDK cause. Role and parameter refusals must retain their decision
#: records."* The condition for (d) was measured not met: a source's "I do not
#: hold that identifier" reaches the probe with no typed cause as a refusal
#: shell or an assembler's refusal, and the SDK declares the typed
#: ``nonexistent`` for a refusal that is not about the identifier.
#:
#: For a class that may withhold its subject and declares no early policy, a
#: refusal the subject-keyed phase raises when asked about
#: :data:`UNHELD_SUBJECT_PROBE` — the typed handoff carrying any refusal kind or
#: a refusal shell, recorded by its raiser or not, or a type the class or the
#: SDK declares at the seam — refuses the question before the phase is handed
#: its subject, and the question is answered and recorded as this value at the
#: ``acquisition`` seam, beside the caller's question: one kind, cause, code and
#: text for every subject, and nothing the source said. So a refusal the
#: question decided (a role, a parameter) keeps its decision record, and an
#: identifier nothing holds is refused as a withheld subject is (measured by
#: ``tests/products/test_sec020_held_refusal_at_the_probe_is_recorded.py``).
#: Its own value rather than :data:`EARLY_POLICY_ACQUISITION_REFUSAL`, whose
#: sentence says the class declares an early policy, which a class the probe
#: reads does not; no class takes both paths, so the two never meet in one
#: class's answers.
UNHELD_SUBJECT_PROBE_REFUSAL: Final[SubjectUnavailableRefusal] = SubjectUnavailableRefusal(
    cause="undisclosed",
    detail=(
        "the subject-keyed acquisition phase refused"
        f" {UNHELD_SUBJECT_PROBE!r}, an identifier that names nothing, so this"
        " class refuses the question before that phase is handed its subject;"
        " the SDK keeps no statement of the source's, so every such refusal"
        " reads alike (SEC-020; D-IMPL-378 OWED-RULINGS-3 item 4 (b), repair"
        " 2.3 (b))"
    ),
    error_code=None,
)


class PopulationReadInSubjectKeyedPhase(UnsupportedComposition):
    """The subject-keyed acquisition phase acquired something for an identifier that names nothing.

    ``D-IMPL-378`` ruling P6 (a) (SDK-defined, CLAUDE.md §11). Dave,
    2026-10-08 16:40 MST, a conditional implementation go: *"Do not declare
    closure based on this probe alone"*. SEC-020 stays OPEN.

    A class that may withhold its subject and declares no early policy
    withholds inside its projection, after acquisition; the withheld subject is
    then rendered over the fabric as it stood immediately before the
    subject-keyed phase (``D-IMPL-376`` (3), route A). That is the state an
    identifier that names nothing is rendered over only when the subject-keyed
    phase acquires nothing for such an identifier. A read that acquires the
    same content whatever is asked — a population read left in the
    subject-keyed phase instead of declared as the population phase (Q7) —
    gives a nonexistent subject that content, and the two answers differ. So,
    for such a class, :meth:`GovernedResolver.__call__` first asks the
    subject-keyed phase about :data:`UNHELD_SUBJECT_PROBE` — the question's
    effective request with that identifier in place of the subject — and reads
    the fabric again; if the read differs from the one taken before, this is
    raised, before the phase is asked about the question's subject. The
    decision reads nothing about the asked subject, so a withheld subject and
    an identifier nothing holds are refused alike. A held refusal from the
    probe refuses the question instead, answered and recorded as
    :data:`UNHELD_SUBJECT_PROBE_REFUSAL` (OWED-RULINGS-3 item 4 (b), as
    repaired by ``D-IMPL-378`` 2.3 (b)). Q10's *"each
    once"* is amended by the ruling to exactly this one extra call to the
    subject-keyed phase per question of such a class, and nothing more.

    What it relies on, stated: the phase treats :data:`UNHELD_SUBJECT_PROBE`
    as it treats any identifier its sources do not hold — the assumption Q8
    already makes of a declared stand-in. **A source that recognizes the probe**
    — its exact identifier, or its shape, outside the URI form the fabric's
    entity resolution mints — and answers nothing for it while it reads the
    population for any other identifier **is not detected**, and a withheld
    subject and a nonexistent one are then still told apart (measured, and
    kept visible: ``tests/products/test_sec020_p6_probe_recognizing_source_counterexample.py``,
    and the ``SEC-020 P6 PROBE LIMITATION`` block of SEC-020's closing test). It costs one
    more call to the subject-keyed phase and one more read of the fabric per
    question of such a class. A class with a declared early policy is not
    refused by this probe — its declared stand-in is verified instead, which
    asks the phase about :data:`UNHELD_SUBJECT_PROBE` as its baseline
    (:class:`UndisclosedSubjectSubstituteIsHeld`) — and a class affirming
    ``subject_withholding: never`` is not probed. To be
    served, declare the read as the population phase
    (``open_product(population=...)``,
    :attr:`GovernedResolver.population_acquisition`), declare an early policy
    (:class:`SubjectDisclosingPlanFactoryProtocol`), or affirm
    ``subject_withholding: never`` for a projection that never withholds.

    That the probe identifier names nothing is checked, not assumed
    (:class:`UnheldSubjectProbeIsHeld`): a fabric or a source that names it is
    refused by that name instead, before this decision is taken.
    """


class UnheldSubjectProbeIsHeld(UnsupportedComposition):
    """The identifier the P6 probe treats as naming nothing names something here.

    ``D-IMPL-378`` ruling P6 (a) (SDK-defined, CLAUDE.md §11). Dave,
    2026-10-08 16:40 MST: *"Verify that the fixed identifier is actually
    absent; do not assume it."* SEC-020 stays OPEN.

    :class:`PopulationReadInSubjectKeyedPhase` is decided by what the
    subject-keyed phase acquires for :data:`UNHELD_SUBJECT_PROBE`, which
    measures what it acquires for an identifier its sources do not hold only if
    the probe identifier names nothing. So it is read, by the reading the SDK
    seeds a walk from a subject with
    (:func:`~ccf.products.request.request_seeds`: the subject is the node whose
    entity URI it is), on both axes of a view — an entity whose URI is the
    identifier, or a relationship with it at either end. Raised by
    :meth:`GovernedResolver.__call__`, for a class the probe reads, when the
    fabric as read before the probe names it (then the phase is not asked
    about the probe at all), or when the fabric as read after the probe does
    (the phase's source holds the identifier, so what it acquired is not a
    population read's evidence) — before the phase is handed the question's
    subject, with one message whatever subject was asked. Fail closed.

    L2's ingest mints every node it writes as
    ``<entity_class>://<content hash>``, a form the probe identifier does not
    have, so on the paved road no write can name it; a node named by it reaches
    a fabric only through the admission path for an already-resolved claim
    (:meth:`~ccf.assembly.worker.AssemblyWorker.admit_entity_claim`, the path a
    replayed snapshot takes) or a store written outside this SDK. A paved
    source holding a record FOR the probe identifier therefore writes a node
    with another URI, and the question is refused as
    :class:`PopulationReadInSubjectKeyedPhase` — also fail closed.
    """


class UndisclosedSubjectSubstituteIsHeld(UnsupportedComposition):
    """The identifier a declared early policy asks in place of an undisclosed subject names something here.

    ``D-IMPL-378`` decision 4 (a) (SDK-defined, CLAUDE.md §11). Dave,
    2026-10-09 06:06 MST, confirmed at 06:21 MST: *"Verify the stand-in is
    absent before and after acquisition. A failed check refuses without
    exposing subject-dependent differences."* SEC-020 stays OPEN.

    Under a declared early policy (:class:`SubjectDisclosingPlanFactoryProtocol`,
    Q8) every subject-dependent step is asked about the policy's
    :attr:`~ccf.products.subject_disclosure.SubjectDisclosurePolicy.undisclosed_subject`
    in place of a subject the policy does not disclose, so a withheld subject's
    answer equals the answer for an identifier that names nothing only if the
    stand-in names nothing. That is checked, not assumed, for EVERY question of
    such a class, whatever the policy decides for the asked subject, by the
    mechanism :data:`UNHELD_SUBJECT_PROBE` is checked by
    (:class:`UnheldSubjectProbeIsHeld`) — a view names an identifier when an
    entity's URI is the identifier, or a relationship has it at either end:

    * **before acquisition** — the fabric as read before the subject-keyed
      phase (after a declared population phase) must not name it; and, where a
      subject-keyed phase is declared, the phase is asked about
      :data:`UNHELD_SUBJECT_PROBE` and then about the stand-in, the fabric read
      after each, and what it acquired for the stand-in must name nothing and
      add nothing to what it acquired for the probe identifier — compared as
      entities, relationships and claim values, with delivery lineage set
      aside (``D-IMPL-378`` repair 1.3, :func:`_held_content`). A source that
      holds the stand-in, under any URI, acquires for it what it does not
      acquire for an identifier that names nothing; a read that acquires the
      same content whatever is asked adds nothing, also when it gives each
      delivery its own envelope id or receipt instant (the components of a
      lineage entry a delivery mints), while evidence from another source or
      another passage adds something;
    * **after acquisition** — the fabric the plan reads must not name it.

    Raised by :meth:`GovernedResolver.__call__` with ONE message, whatever
    subject was asked and whichever check failed: before the subject-keyed
    phase is handed anything for the question (the checks before acquisition),
    or before anything is computed or recorded (the check after it). A broken
    composition, as every :class:`UnsupportedComposition` is: nothing is
    recorded, and a door answers with its opaque failure. Fail closed.

    What it costs: for a class with a declared early policy and a subject-keyed
    phase, two more calls to that phase and two more reads of the fabric per
    question — Q10's *"each once"*, amended by this decision as ruling P6 (a)
    amended it for the probe.

    What it does not detect, stated: a source that RECOGNIZES the stand-in — its
    identifier, or its shape — and answers nothing for it while it answers other
    identifiers it does not hold with content. A source that recognizes
    :data:`UNHELD_SUBJECT_PROBE` and answers the stand-in as it answers any
    other identifier is refused (fail closed). The check after acquisition reads
    what the question's own acquisition wrote, so a source that writes the
    stand-in for some asked subjects and not for others is refused for those
    questions only — such a source already answers its subjects differently,
    and the check refuses rather than answer over a fabric that names the
    stand-in. A composite's children are asked about the stand-in through their
    own deployments; what their sources hold for it is not read here.
    """


#: The components of a :class:`~ccf.contracts.claims.LineageEntry` that a DELIVERY
#: mints rather than the evidence carries (``D-IMPL-378`` repair 1.3): the
#: ``envelope_id`` of the envelope that delivered the claim, which the
#: acquisition seam leaves to the adapter, and the ``observed_at`` instant the
#: fabric received that delivery, which L2 takes from the envelope's
#: ``ingestion_timestamp`` (:meth:`~ccf.assembly.worker.AssemblyWorker._stitch`).
#: Every other component — the source's identity, the passage anchor, and any
#: component the entry declares later — is evidence, and is compared.
_DELIVERY_LINEAGE: Final[frozenset[str]] = frozenset({"envelope_id", "observed_at"})


def _held_content(view: GraphView) -> bytes:
    """``view``'s entities, relationships and claim values, with delivery lineage set aside, in canonical bytes.

    ``D-IMPL-378`` repair 1.3 (SDK-defined, CLAUDE.md §11). Dave, 2026-10-09
    10:54 MST: *"Compare entities, relationships and claim values, excluding
    delivery lineage. Preserve security-relevant differences and the existing
    held-stand-in controls."* SEC-020 stays OPEN.

    Two views hold the same content exactly when these bytes are equal (the
    SDK's one canonical form, :func:`~ccf.contracts.canonical.canonical_bytes`).
    Every member of the view, of each entity and relationship record and of
    each claim is kept, read off the declared fields, so a member added later is
    compared rather than skipped; a claim's lineage is kept as the set of its
    entries with the components in :data:`_DELIVERY_LINEAGE` removed. So a
    delivery that brings what the fabric already holds under its own envelope id
    or its own receipt instant adds nothing, while a new entity, a new
    relationship, a changed claim value, or evidence from another source or
    another passage still does. Pure over the view.
    """

    def entry(held: LineageEntry) -> str:
        return canonical_bytes(
            {name: getattr(held, name) for name in type(held).model_fields if name not in _DELIVERY_LINEAGE}
        ).decode("utf-8")

    def record(held: EntityRecord | RelationshipRecord) -> dict[str, object]:
        claim = held.claim
        return {
            **{name: getattr(held, name) for name in type(held).model_fields if name != "claim"},
            "claim": {
                **{name: getattr(claim, name) for name in type(claim).model_fields if name != "lineage"},
                "lineage": frozenset(entry(lineage) for lineage in claim.lineage),
            },
        }

    return canonical_bytes(
        {
            name: (
                tuple(record(held) for held in getattr(view, name))
                if name in ("entities", "relationships")
                else getattr(view, name)
            )
            for name in type(view).model_fields
        }
    )


def _names(view: GraphView, identifier: str) -> bool:
    """Whether ``view`` names ``identifier``: an entity whose URI it is, or a relationship with it at either end.

    The reading :func:`~ccf.products.request.request_seeds` seeds a walk from a
    subject with. Pure over the view; reads no clock and no store.
    """
    return any(record.claim.entity_uri == identifier for record in view.entities) or any(
        identifier in (record.claim.subject_uri, record.claim.object_uri)
        for record in view.relationships
    )


class CompositeNeedsAnEarlyPolicy(UnsupportedComposition):
    """A composite whose projection declares it withholds, without an early policy.

    Q8: *"Require early withholding for affected composites."* A composite asks
    its children about the subject before its plan runs, so a withhold decided
    inside the projection reaches them too late; an affected composite — one
    whose plan factory declares, through
    :class:`SubjectDisclosingPlanFactoryProtocol`, that it withholds — must
    declare the early policy, and one that declares withholding with no policy
    is refused when the resolver is constructed.
    """


class CompositeNeedsAWithholdingStance(UnsupportedComposition):
    """A composite that declares no withholding stance: no early policy, and no affirmation it never withholds.

    ``D-IMPL-378`` P2, option (c), ruled by Dave on 2026-10-08 at 12:29 MST
    (SDK-defined, CLAUDE.md §11); SEC-020 stays OPEN. Q8:
    *"Require early withholding for affected composites. Make it an enforced
    policy decision before subject-dependent fetches, child resolution or
    scoring. It cannot depend on learning whether the subject exists."* A
    composite asks its children about the subject before its plan runs, and
    nothing at construction says whether its projection will withhold; a
    refusal decided when the projection withholds (:class:`CompositeWithheldLate`)
    is decided for the withheld subject only, and is itself an answer a
    nonexistent subject's question does not get. So a composite — a class that
    declares ``requires`` — states its stance when its resolver is constructed:
    an early policy, through :class:`SubjectDisclosingPlanFactoryProtocol`, or
    its class's affirmation ``subject_withholding: never`` (Dave's Q12), which
    is built only over a plan factory positively declaring that it never
    withholds (:class:`NonWithholdingPlanFactoryProtocol`, Dave's E2 (ii) (d))
    and which :meth:`GovernedResolver.__call__` enforces when the projection
    withholds anyway. One that declares neither is refused here, before any
    question — the same refusal whatever subject would have been asked.
    """


class EarlyPolicyNeedsRequestAwareChildren(UnsupportedComposition):
    """Early withholding over a composite whose children are never handed the request.

    Q8. The early decision replaces the subject in every child question; a
    child resolver offering only the request-less legacy call cannot receive
    the replacement, so the composition is refused when the resolver is
    constructed rather than answered with children asked about the real
    subject.
    """


class UndisclosedSubjectAnswered(ProductNotResolvable):
    """The declared policy did not disclose the subject, and the projection answered it anyway.

    Q8. Every subject-dependent step was asked about the declared stand-in; the
    projection, built from the caller's question, must withhold the subject,
    or it would serve the subject's own answer over a fabric built for nobody.
    Raised after the plan runs and BEFORE this decision is gated, recorded or
    served (a composite's children, asked about the stand-in, may already have
    filed their own): a broken composition, not a governed "no".
    """


class CompositeWithheldLate(ProductNotResolvable):
    """A composite's projection withheld a subject its early policy did not withhold.

    Q8: *"Make it an enforced policy decision before subject-dependent
    fetches, child resolution or scoring."* By the time a composite's
    projection raises the withheld signal, its children were already asked
    about the subject; so a composite withholds only through the declared
    early policy, and a projection that withholds anything else is refused here
    — after the plan runs, BEFORE this decision is gated, recorded or served;
    what the children filed when they were asked stays filed. The
    SDK cannot see at construction whether a projection will withhold; a
    composite that declares it does is held to the early policy then
    (:class:`CompositeNeedsAnEarlyPolicy`). A composite whose class affirms
    ``subject_withholding: never`` is refused as
    :class:`NeverWithholdingContradicted` instead, which is checked first (Dave's
    CT-D (a), 2026-10-08 12:29 MST: diagnostic precedence only).
    """


class AcquiredFabricReused(ProductNotResolvable):
    """A fabric an acquisition phase was claimed for was asked another question.

    Q9, *"including concurrent use"*. The claim is taken under a lock
    immediately before the first acquisition phase, so of two questions on one
    fabric — one after the other or at the same time — exactly one acquires and
    the other is refused here, before anything is read or fetched for it. The
    claim reads nothing about the subject: any second question is refused the
    same way. A question refused before acquisition (its address, its request,
    its temporal bound) never claims the fabric. Held per fabric handle in this
    process; a fabric is fresh per question by its boot
    (:class:`AcquisitionNeedsAQuestionFabric`), so a second handle over the same
    store is not a question fabric to begin with.

    **Every governed call over a question fabric claims it** (SEC-020 P4 (a),
    ``D-IMPL-378``, ruled by Dave on 2026-10-08 at 12:29 MST), at the same
    point, with an acquisition phase or without one: a later call that declares no
    acquisition would otherwise answer from what the first question fetched. A
    second handle over the same store is refused by
    :class:`QuestionStoreReopened`.
    """


class QuestionStoreReopened(UnsupportedComposition):
    """A governed call over a question's store booted again, refused before the graph is read.

    SEC-020 P4 (a), ``D-IMPL-378`` (ruled by Dave on 2026-10-08 at 12:29 MST;
    Q9: *"Enforce a fresh fabric per question whenever acquisition exists"*). The
    store a question was answered from keeps what its acquisition fetched, and
    the paved road leaves it on disk. A boot for one question leaves a durable
    marker beside the store
    (:attr:`~ccf.deployment.manifest.BootedFabric.question_store`), so a later
    boot of it is a fabric to read, not to answer from: Decision Replay
    rebuilds a resolver over it and never calls it. A governed call over it
    that declares no acquisition phase — where Q9 alone never bound — is
    refused here, at the point a question fabric is claimed: after the
    question-level refusals (its address, its request, its temporal bound),
    which read no graph, and before the graph is read. One that declares an
    acquisition phase is refused at the same point by
    :class:`AcquisitionNeedsAQuestionFabric`. Either way the refusal is decided
    by the marker and the boot, never by the subject the question names or by
    what the store holds. The marker sits beside the store, not inside it: a
    copy of the store taken without it, or a store booted for a question
    before the marker existed, carries no marker at all, and is refused as
    unmarked instead (:class:`UnmarkedStoreNotPresumedFresh`).
    """


class UnmarkedStoreNotPresumedFresh(UnsupportedComposition):
    """A governed call over an existing store that carries no marker, refused before the graph is read.

    SEC-020 P4 (a) made strict, ``D-IMPL-378`` (Dave, 2026-10-08 12:29 MST:
    *"An unmarked existing store must not be presumed fresh. Require
    verifiable fresh creation or refuse acquisition-backed serving."*). Every
    store the deployment doors create at a path gets a marker beside it before
    it exists — the question marker on a boot for one question, the deployment
    marker on any other — so an existing store with neither
    (:attr:`~ccf.deployment.manifest.BootedFabric.store_creation` ``"unmarked"``)
    is one nothing shows was never a question's: a store booted for a question
    before the markers existed, a copy of a used store taken without its
    marker, a store created outside the doors. A later question answered from
    it would answer from what an earlier question's acquisition fetched, so a
    governed call over it is refused here, at the point a question fabric is
    claimed: after the question-level refusals (its address, its request, its
    temporal bound), which read no graph, and before the graph is read. A call
    that declares an acquisition phase is refused at the same point by
    :class:`AcquisitionNeedsAQuestionFabric`, as before. Decision Replay
    rebuilds a resolver over the store and never calls it, so it reads the
    store as before. Decided by the markers and the boot, never by the subject
    or by what the store holds. Remedy: boot a new store through a deployment
    door, which creates and marks it; a deployment's own kept store, created
    by a door, carries its marker and is not refused.
    """


#: SEC-020 Q9: every question fabric an acquisition phase has been claimed for
#: in this process. Weak, so a closed and released fabric leaves nothing
#: behind; guarded, so two threads cannot both claim one handle.
_CLAIMED_QUESTION_FABRICS: weakref.WeakSet[object] = weakref.WeakSet()
_CLAIMED_QUESTION_FABRICS_LOCK = threading.Lock()


def _claim_question_fabric(fabric: BootedFabric) -> None:
    """Claim ``fabric`` for the one question its acquisition phases may write for (Q9).

    Called by every governed call over a question fabric, and by every call
    that declares an acquisition phase (SEC-020 P4 (a)). Raises
    :class:`AcquisitionNeedsAQuestionFabric` when the fabric was not booted for
    a question, and :class:`AcquiredFabricReused` when it was already claimed.
    Reads nothing about the question.
    """
    if not fabric.for_question:
        raise AcquisitionNeedsAQuestionFabric(
            "an acquisition phase writes what one question's sources returned"
            " into the fabric the question is answered from, so the fabric must"
            " be booted for that question (load_and_boot or load_config_and_boot"
            " with for_question=True; the paved road does) — this one was not"
            " (SEC-020, Q9)"
        )
    handle = fabric.handle
    with _CLAIMED_QUESTION_FABRICS_LOCK:
        if handle in _CLAIMED_QUESTION_FABRICS:
            raise AcquiredFabricReused(
                "this question fabric was already claimed by a question whose"
                " acquisition writes into it; a fabric answers the one question"
                " it was booted for (SEC-020, Q9)"
            )
        _CLAIMED_QUESTION_FABRICS.add(handle)
class WithholdingClassListedReadable(ProductNotResolvable):
    """A tenant lists for owner read-back a class that may withhold its subject.

    Dave's Q12 (2026-10-07; ``D-IMPL-378``): *"Default-deny owner read-back,
    with an explicit tenant class allowlist. Reject withholding classes—including
    affected composites."* Raised by :class:`GovernedResolver` at construction
    — the deployment's boot — when the tenant's
    :class:`~ccf.products.entitlement.ProductEntitlementPolicy` lists its class
    in ``evidence_readable_classes`` while the class declaration does not
    affirm :data:`~ccf.products.contract.SUBJECT_WITHHOLDING_NEVER`. A record's
    dimension 1 is the real read, so a record of such a class can name a
    subject its answer hid. Every class may withhold until it says otherwise,
    composites included; a composite affirms ``"never"`` only if no answer of it
    withholds its own subject, which the resolver then enforces. The governed
    evidence read refuses such records whatever the policy says; this is the
    deployment's configuration error, named where an operator sees it.
    """


class NeverWithholdingContradicted(ProductNotResolvable):
    """A class affirmed that its answers never withhold their subject, and one did.

    Dave's Q12 (2026-10-07; ``D-IMPL-378``). Raised by
    :meth:`GovernedResolver.__call__` when the projection raises the withheld
    signal (:class:`~ccf.projection.plan.ProjectionOutput`'s ``withheld``) for a
    class whose declaration affirms
    :data:`~ccf.products.contract.SUBJECT_WITHHOLDING_NEVER` — before anything is
    rendered, recorded or served, and before Q8's :class:`CompositeWithheldLate`,
    so a composite affirming ``never`` is named by this refusal (Dave's CT-D (a),
    2026-10-08 12:29 MST, diagnostic precedence only). The affirmation is what lets the class's
    records be read back by their owners; a withheld answer under it would
    reopen the read-back of a subject the answer hid, so it is refused as the
    broken deployment it is. A deployment whose projection may withhold leaves
    its class at the default.

    **The defense, not the control** (Dave, 2026-10-08 12:29 MST, E2 (ii):
    *"retain the runtime check as defense"*). A plan factory that declares it
    withholds is refused where the resolver is built
    (:class:`NeverWithholdingProjectionCanWithhold`), and so is one that does
    not positively declare that it never withholds
    (:class:`NeverWithholdingNeedsAPositiveDeclaration`, Dave's option (d),
    16:40 MST); this check is what remains for a factory whose positive
    declaration is FALSE — trusted deployment code — and whose projection
    withholds anyway
    (``tests/products/test_sec020_never_capability.py::test_e2ii_the_serve_time_check_remains_the_defense_for_a_false_positive_declaration``).
    Raised for the withheld subject only, it still tells that subject from one
    nothing holds — measured, as an exception (an HTTP 500) against an answer,
    by
    ``tests/products/test_sec020_e2ii_trusted_declaration.py::test_e2ii_d_counterexample_a_false_positive_declaration_still_tells_the_withheld_subject_apart``
    and reported outside the closure gate on every run of
    ``tests/products/test_sec020_combined_proof.py::test_e2ii_limitation_the_false_declaration_cells_are_measured_not_gated``.
    SEC-020 is OPEN.
    """


class NeverWithholdingProjectionCanWithhold(UnsupportedComposition):
    """A class affirming its answers never withhold their subject, over a plan factory that declares it withholds.

    Dave, 2026-10-08 12:29 MST (``D-IMPL-378``, E2 (ii); SDK-defined, CLAUDE.md
    §11): *"Validate withholding capability against the class declaration at
    construction; retain the runtime check as defense."* Raised by
    :class:`GovernedResolver` at construction — on the paved road, which builds
    a resolver for each question, before anything is read for it — the same
    refusal whatever subject would have been asked — when the class declaration
    affirms :data:`~ccf.products.contract.SUBJECT_WITHHOLDING_NEVER` and its plan
    factory, through :class:`SubjectDisclosingPlanFactoryProtocol`, states a
    capability to withhold that the SDK can read without running a question:

    * **verified** — an early policy that does not disclose some subject to some
      principal or role: the resolver itself withholds that subject (Q8), so
      under the affirmation that subject's question could only end in a
      refusal raised for it alone, which a nonexistent subject's does not get;
    * **declared** — ``subject_disclosure()`` returning ``None``: the factory's
      own statement that its projection withholds late, inside itself.

    **What it cannot see.** Whether a projection withholds is otherwise
    decided inside the deployment's ``invoke()``, which sets the withheld signal
    on its own output; no operator and no declared plan step sets it. So a plan
    factory that states no capability must state the opposite: Dave's E2 (ii)
    option (d) (2026-10-08 16:40 MST) refuses one that does not positively
    declare that its projection never withholds
    (:class:`NeverWithholdingNeedsAPositiveDeclaration`, a subclass of this
    refusal, checked after it). A positive declaration is trusted deployment
    code; one that is false constructs, and a projection of it that withholds
    anyway meets the serve-time defense (:class:`NeverWithholdingContradicted`)
    — measured as still telling a withheld subject from a nonexistent one. An
    early policy that withholds nobody is no capability.
    """


class NeverWithholdingNeedsAPositiveDeclaration(NeverWithholdingProjectionCanWithhold):
    """A class affirming its answers never withhold their subject, over a plan factory that does not positively declare it.

    Dave, 2026-10-08 16:40 MST (``D-IMPL-378``, E2 (ii), option (d);
    SDK-defined, CLAUDE.md §11): *"Require a positive declaration, default
    silence to refusal, and explicitly limit the trusted-code assumption to
    deployment code callers cannot influence. Keep the false-declaration
    counterexample visible."* Raised by :class:`GovernedResolver` at
    construction — before anything is read for a question, the same refusal
    whatever subject would have been asked — when the class declaration
    affirms :data:`~ccf.products.contract.SUBJECT_WITHHOLDING_NEVER` and its
    plan factory does not implement :class:`NonWithholdingPlanFactoryProtocol`
    (silence), or its ``withholds_no_subject()`` returns anything but ``True``.

    Silence counts as able to withhold, so this is a
    :class:`NeverWithholdingProjectionCanWithhold`: what handles that refusal
    handles this one. A factory that declares it withholds is named by that
    refusal first, whatever else it declares. The remedy is in the deployment:
    declare ``withholds_no_subject()`` returning ``True`` only over a projection
    that never sets the withheld signal, or leave the class at the default.
    """


def _refuse_a_never_class_whose_projection_can_withhold(
    *, declaration: ProductClassDeclaration, disclosure: SubjectDisclosurePolicy | None
) -> None:
    """Refuse to construct a class affirming ``never`` whose plan factory declares it withholds (E2 (ii)).

    Called only for a plan factory implementing
    :class:`SubjectDisclosingPlanFactoryProtocol`, with what its
    ``subject_disclosure()`` returned — read ONCE, by the caller. Reads the
    declaration and the policy alone: no subject, no fabric, no clock.
    """
    if declaration.subject_withholding != SUBJECT_WITHHOLDING_NEVER:
        return
    if disclosure is None:
        raise NeverWithholdingProjectionCanWithhold(
            f"class {declaration.schema_name!r} affirms subject_withholding:"
            f" {SUBJECT_WITHHOLDING_NEVER!r}, and its plan factory declares that its"
            " projection withholds subjects late (subject_disclosure() returns None);"
            " a withheld answer under the affirmation is refused for the withheld"
            " subject only, which tells it from a subject nothing holds. Affirm"
            " 'never' only over a projection that never withholds (Dave's E2 (ii),"
            " D-IMPL-378)"
        )
    if any(disclosure.by_principal.values()) or any(disclosure.by_role.values()):
        raise NeverWithholdingProjectionCanWithhold(
            f"class {declaration.schema_name!r} affirms subject_withholding:"
            f" {SUBJECT_WITHHOLDING_NEVER!r}, and its plan factory declares an early"
            " policy that withholds subjects from some principal or role; the"
            " resolver withholds them, so the affirmation would be contradicted for"
            " those subjects only, which tells them from a subject nothing holds."
            " Affirm 'never' only over a projection that never withholds (Dave's"
            " E2 (ii), D-IMPL-378)"
        )


def _refuse_a_never_class_without_a_positive_declaration(
    *, declaration: ProductClassDeclaration, plan_factory: object
) -> None:
    """Refuse to construct a class affirming ``never`` whose plan factory does not positively declare it never withholds.

    Dave's E2 (ii), option (d) (``D-IMPL-378``, 2026-10-08 16:40 MST). Reads
    the declaration, and the factory's own statement
    (:meth:`NonWithholdingPlanFactoryProtocol.withholds_no_subject`), called
    ONCE with no argument: no subject, no request, no fabric, no clock. Anything
    but exactly ``True`` — silence included — is refused, with a message that
    names the class and never the subject.
    """
    if declaration.subject_withholding != SUBJECT_WITHHOLDING_NEVER:
        return
    if isinstance(plan_factory, NonWithholdingPlanFactoryProtocol):
        if plan_factory.withholds_no_subject() is True:
            return
        stated = "its withholds_no_subject() does not return True"
    else:
        stated = "it does not implement NonWithholdingPlanFactoryProtocol"
    raise NeverWithholdingNeedsAPositiveDeclaration(
        f"class {declaration.schema_name!r} affirms subject_withholding:"
        f" {SUBJECT_WITHHOLDING_NEVER!r}, and its plan factory does not positively"
        f" declare that its projection never withholds ({stated}); silence counts"
        " as able to withhold, and a withheld answer under the affirmation would"
        " be refused for the withheld subject only, which tells it from a subject"
        " nothing holds. Declare withholds_no_subject() returning True only over a"
        " projection that never withholds (Dave's E2 (ii) (d), D-IMPL-378)"
    )


def _refuse_a_listed_class_that_may_withhold(
    *, control_plane: ControlPlaneProtocol, tenant: str, declaration: ProductClassDeclaration
) -> None:
    """Refuse to boot when the tenant lists this class for read-back and it may withhold.

    Dave's Q12 (``D-IMPL-378``). Reads the tenant's entitlement policy as it
    stands at construction; with none registered there is nothing listed. A
    policy registered later is held by the governed evidence read, which reads
    every record's own affirmation, and by the next resolver this composition
    builds — the paved road builds one per question.
    """
    if declaration.subject_withholding == SUBJECT_WITHHOLDING_NEVER:
        return
    key = product_entitlement_key(tenant_id=tenant)
    try:
        _version, resolved = control_plane.resolve_latest(key)
    except LookupError:
        return
    if not isinstance(resolved, ProductEntitlementPolicy):
        return
    if declaration.schema_name in resolved.evidence_readable_classes:
        raise WithholdingClassListedReadable(
            f"tenant {tenant!r} lists class {declaration.schema_name!r} in"
            " evidence_readable_classes, and its declaration does not affirm"
            f" subject_withholding: {SUBJECT_WITHHOLDING_NEVER!r}; a record's"
            " dimension 1 is the real read, so the record behind an answer that"
            " withheld its subject would be read back by its owner. Affirm"
            " 'never' only for a class whose answers never withhold their"
            " subject (the resolver enforces it), or remove the class from the"
            " list (Dave's Q12, D-IMPL-378)"
        )


@runtime_checkable
class PackagingTraceProtocol(Protocol):
    """How a Mode 2 deployment reports what its packaging stage actually did.

    **SDK-defined** (CLAUDE.md §11). Whitepaper §7.10.4 makes Assembly Mode 2
    pin four rendering primitives — model version, temperature, prompt
    template and output hash — so that an examiner reads the packaging off
    replay dimension 3 without dereferencing anything.

    **Why a seam and not a derivation.** The SDK cannot compute any of these:
    which model ran, at what temperature, against which prompt artifact, and
    what bytes it produced are facts of the deployment's packaging stage. The
    SDK could *re-read* them from the served payload, and that is exactly what
    this seam exists to avoid — a record re-derived from the payload reports
    what the payload says, which makes ``output_hash`` and
    ``product_content_address`` agree by construction and destroys the one
    question §7.10.4 asks them to answer together: whether the packaging moved
    the conclusion.

    **Mode 1 supplies nothing**, and the no-packaging sentinel is then the
    true claim rather than a gap. A Mode 2 deployment that supplies nothing is
    a defect this Protocol makes visible instead of silent: it was measured
    on `dr-02`, whose payload carried real pins while dimension 3 read
    ``no-packaging`` on every field (`PKG-F-08`).
    """

    def __call__(self, *, product: ContextProductContract) -> PackagingTrace:
        """The trace for one served product, as the packaging stage knows it.

        Args:
            product: The product about to be served, so a deployment can hash
                its own packaged output. Passed rather than left implicit
                because ``output_hash`` is per-serve while the other four pins
                are usually per-deployment.

        Returns:
            The five pinned values. A deployment that ran no packaging returns
            :data:`~ccf.replay.record.NO_PACKAGING_TRACE` rather than raising.
        """
        ...


#: SEC-020 Q7, ``D-IMPL-378`` decision 3 (a) (Dave, 2026-10-09, 06:06 MST,
#: confirmed as "3a" at 06:21 MST: *"(a). Extend the shared-state guard, with a
#: bounded walk and an explicit statement of what it cannot detect."*;
#: SDK-defined, CLAUDE.md §11). How far the shared-owner walk looks from a
#: phase, in steps. One step is one reference followed: to the object a method
#: is bound to or the function behind it, to a closure cell's contents, a
#: default argument, an attribute's or a declared slot's value, or a
#: container's member. An object more steps than this from each phase is not
#: seen (:class:`PopulationPhaseSharesAnOwner` states what else is not). Chosen
#: from a measurement of every pair of phases the SDK's own tests compose (lane
#: ``378i-q7owner``, 2026-10-09): everything they hold was read within 10 steps.
SHARED_OWNER_WALK_DEPTH: Final[int] = 12

#: SEC-020 Q7, ``D-IMPL-378`` decision 3 (a) (as :data:`SHARED_OWNER_WALK_DEPTH`).
#: The most references the shared-owner walk reads from one phase, an object
#: counted once for every reference to it that the walk reads. The walk stops
#: when they are spent, nearest first, so its cost has this ceiling whatever a
#: phase holds; what it would have reached after that is not seen. Chosen from
#: the same measurement: the most any of those phases holds is 3,989 references.
SHARED_OWNER_WALK_OBJECTS: Final[int] = 5_000

#: The identities of the types whose instances refer to no other object: the
#: walk compares such an object's identity and reads nothing from it. Compared
#: by identity, so no metaclass's ``__hash__`` or ``__eq__`` runs.
_NO_REFERENCES: Final[frozenset[int]] = frozenset(
    id(kind) for kind in (str, bytes, bytearray, int, float, complex, bool, type(None))
)
#: ``type``'s own descriptors for a class's method resolution order and its
#: namespace, used directly so that nothing a metaclass defines is consulted.
_CLASS_MRO: Final[Any] = type.__dict__["__mro__"]
_CLASS_NAMESPACE: Final[Any] = type.__dict__["__dict__"]


def _bound_object(phase: object) -> object | None:
    """The object a method or a built-in method is bound to; ``None`` for any other callable.

    Read off the method types themselves, so nothing the phase defines — a
    ``__getattr__``, a property named ``__self__`` — is called (SEC-020 Q7).
    """
    if type(phase) is MethodType:
        return phase.__self__
    if type(phase) is BuiltinFunctionType or type(phase) is MethodWrapperType:
        return phase.__self__
    return None


def _owners(phase: object) -> frozenset[int]:
    """The identities a phase's state lives on: the callable, and the object it is bound to (Q7)."""
    bound = _bound_object(phase)
    return frozenset({id(phase)} if bound is None else {id(phase), id(bound)})


def _is_the_standard_instance_dict(descriptor: object, klass: type) -> bool:
    """Whether ``descriptor``, found under ``__dict__`` in ``klass``'s namespace, is the standard one.

    A class that replaces ``__dict__`` with a property or another descriptor is
    not read: reading its instances' dictionary would call that descriptor.
    """
    if type(descriptor) is GetSetDescriptorType:
        return descriptor.__name__ == "__dict__" and descriptor.__objclass__ is klass
    return type(descriptor) is MemberDescriptorType and descriptor.__name__ == "__dict__"


def _attribute_values(held: object, kind: type, limit: int) -> list[object]:
    """The values of ``held``'s declared slots and instance attributes, at most ``limit`` of them (Q7).

    The classes are read through ``type``'s own descriptors; the slots the
    Python classes declare (``__slots__``) through their member descriptors;
    the instance dictionary only through the standard ``__dict__`` descriptor.
    No property, other descriptor, ``__getattr__`` or ``__getattribute__`` is
    called.
    """
    values: list[object] = []
    reads_the_instance_dict: bool | None = None
    for klass in _CLASS_MRO.__get__(kind):
        namespace = _CLASS_NAMESPACE.__get__(klass)
        if reads_the_instance_dict is None and "__dict__" in namespace:
            reads_the_instance_dict = _is_the_standard_instance_dict(namespace["__dict__"], klass)
        if "__slots__" in namespace:
            for descriptor in tuple(namespace.values()):
                if type(descriptor) is MemberDescriptorType:
                    try:
                        values.append(descriptor.__get__(held, klass))
                    except AttributeError:  # a slot never assigned
                        continue
    if reads_the_instance_dict:
        try:
            attributes = object.__getattribute__(held, "__dict__")
        except AttributeError:
            attributes = None
        if type(attributes) is dict:
            values.extend(islice(dict.values(attributes), limit))
    return values[:limit]


def _references(held: object, limit: int) -> list[object]:
    """What ``held`` stores, read without calling anything it defines: at most ``limit`` references (Q7).

    A bound method: the object it is bound to, and its function. A built-in
    method: the object it is bound to. A function: its closure cells'
    contents, its default arguments and its attributes. Any other object: the
    members of a ``list``, ``tuple``, ``set`` or ``frozenset`` and the keys
    and values of a ``dict`` (subclasses included, iterated by the base type),
    then its declared slots and instance attributes. A class, a module, and
    the fields a C-extension object keeps outside those yield nothing.
    """
    kind = type(held)
    if id(kind) in _NO_REFERENCES or issubclass(kind, (type, ModuleType)):
        return []
    if type(held) is MethodType:
        return [held.__self__, held.__func__][:limit]
    if type(held) is BuiltinFunctionType or type(held) is MethodWrapperType:
        bound: object = held.__self__
        return [] if bound is None else [bound][:limit]
    if type(held) is FunctionType:
        found: list[object] = []
        for cell in held.__closure__ or ():
            try:
                found.append(cell.cell_contents)
            except ValueError:  # an empty cell
                continue
        found.extend(held.__defaults__ or ())
        found.extend(dict.values(held.__kwdefaults__ or {}))
        found.extend(islice(dict.values(held.__dict__), limit))
        return found[:limit]
    # Each container is copied by one call into C before its members are read.
    members: list[object] = []
    if issubclass(kind, dict):
        for key, value in tuple(islice(dict.items(cast("dict[object, object]", held)), limit)):
            members.extend((key, value))
    elif issubclass(kind, list):
        members.extend(tuple(islice(list.__iter__(cast("list[object]", held)), limit)))
    elif issubclass(kind, tuple):
        members.extend(tuple(islice(tuple.__iter__(cast("tuple[object, ...]", held)), limit)))
    elif issubclass(kind, frozenset):
        members.extend(tuple(islice(frozenset.__iter__(cast("frozenset[object]", held)), limit)))
    elif issubclass(kind, set):
        members.extend(tuple(islice(set.__iter__(cast("set[object]", held)), limit)))
    if len(members) < limit:
        members.extend(_attribute_values(held, kind, limit - len(members)))
    return members[:limit]


def _walk_incomplete(walked: str, cause: str, *, step: int, read: int) -> str:
    """The message of :class:`SharedOwnerWalkIncomplete`: the phase, the cause, the step and the counts (Q7).

    Built from the walk's own labels and counts alone, so it carries nothing
    any object the walk reached holds.
    """
    return (
        f"the shared-owner walk from the {walked} phase {cause} at step {step} of at most"
        f" {SHARED_OWNER_WALK_DEPTH} (SHARED_OWNER_WALK_DEPTH), having read {read} of at most"
        f" {SHARED_OWNER_WALK_OBJECTS} references (SHARED_OWNER_WALK_OBJECTS), so it cannot show"
        " that the population phase and the subject-keyed phase hold nothing of each other;"
        " refused rather than admitted (SEC-020, Q7; D-IMPL-378)"
    )


def _reaches(phase: object, owners: frozenset[int], *, walked: str) -> bool:
    """Whether ``phase`` holds an object whose identity is in ``owners``, within the walk's bounds (Q7).

    Breadth first, so the nearest references are read first. Every object the
    walk reaches is compared by identity with ``owners``; each one not seen
    before is read in turn at the next step, up to
    :data:`SHARED_OWNER_WALK_DEPTH` steps and until
    :data:`SHARED_OWNER_WALK_OBJECTS` references are spent. An object is read
    once however many references reach it, which also ends a cycle, and every
    object reached is held until the walk returns, so no identity it compares
    can pass to a new object meanwhile. ``walked`` names the phase the walk
    starts from, for a refusal's message.

    Raises:
        SharedOwnerWalkIncomplete: reading what an object the walk reached
            holds raised, other than reading a declared slot never assigned
            or an empty closure cell, each of which holds nothing, so the
            walk cannot complete (``D-IMPL-378`` repair 1.8); never the raw
            error.
    """
    if id(phase) in owners:
        return True
    seen: set[int] = {id(phase)}
    reached: list[object] = [phase]
    frontier: list[object] = [phase]
    budget = SHARED_OWNER_WALK_OBJECTS
    for step in range(1, SHARED_OWNER_WALK_DEPTH + 1):
        following: list[object] = []
        for holder in frontier:
            try:
                references = _references(holder, budget)
            except Exception as error:  # noqa: BLE001 — refused by name, never admitted or raised raw (repair 1.8)
                cause = f"could not read what an object it reached holds (the read raised {type(error).__name__})"
                raise SharedOwnerWalkIncomplete(
                    _walk_incomplete(walked, cause, step=step, read=SHARED_OWNER_WALK_OBJECTS - budget)
                ) from None
            for held in references:
                budget -= 1
                if id(held) in owners:
                    return True
                if id(type(held)) not in _NO_REFERENCES and id(held) not in seen:
                    seen.add(id(held))
                    reached.append(held)
                    following.append(held)
                if not budget:
                    return False
        if not following:
            return False
        frontier = following
    return False


def _refuse_shared_owner(population: object, subject_keyed: object) -> None:
    """Raise :class:`PopulationPhaseSharesAnOwner` when either phase reaches the other's owner (Q7).

    An owner is the phase itself or the object it is bound to
    (:func:`_owners`); the reach is :func:`_reaches`, from each phase in turn,
    within :data:`SHARED_OWNER_WALK_DEPTH` and :data:`SHARED_OWNER_WALK_OBJECTS`.
    An object both phases hold that is neither phase nor bound by either is not
    an owner, and holding it is not refused; :class:`PopulationPhaseSharesAnOwner`
    states that and the rest of what the walk does not see. A walk that cannot
    read what an object it reached holds raises
    :class:`SharedOwnerWalkIncomplete` (``D-IMPL-378`` repair 1.8).
    """
    if _reaches(population, _owners(subject_keyed), walked="population") or _reaches(
        subject_keyed, _owners(population), walked="subject-keyed"
    ):
        raise PopulationPhaseSharesAnOwner(
            "the population phase and the subject-keyed phase share an owner: one"
            " is, is bound to or holds the other or the object it is bound to, so"
            " state the subject-keyed phase was handed — the asked subject — can"
            " reach a later question's population phase; declare them on separate"
            " objects that hold nothing of each other (SEC-020, Q7)"
        )


@runtime_checkable
class ServedProductResolverProtocol(Protocol):
    """What a deployment plugs into an in-process delivery surface.

    A Protocol rather than a base class (CLAUDE.md §11), for the reason
    :class:`~ccf.agents.assembler.ContextAssemblerProtocol` gives for its own
    case: a deployment substitutes its own resolver by **conforming**, and the
    SDK's reference implementation carries no privileged status.
    :class:`GovernedResolver` is something a deployment instantiates and
    supplies — never something the SDK invokes on its own authority.

    ``@runtime_checkable`` so a delivery surface can assert conformance at the
    boundary it is handed one, rather than discovering a shape mismatch inside
    a call it has already accepted. The check is structural and covers the
    presence of ``__call__``, not its signature; the signature is mypy's job,
    and this module is inside ``[tool.mypy] files``.

    **Two refusals a resolver must call, and no door will call for it.** This
    obligation is inherited verbatim from the two ``runtime/`` seams, whose
    docstrings argue it at length, and it is restated rather than referenced
    because a resolver author reading *this* Protocol is the person it falls
    on:

    - A resolver that does not call
      :func:`~ccf.products.request.refuse_request` **serves against an
      unchecked request** — the question is answered without ever being
      compared to the surface its product class declared.
    - A resolver that does not call
      :func:`~ccf.products.bind.refuse_bound_payload` **serves an unvalidated
      payload against a schema its own class declared**, which from a
      consumer's seat is indistinguishable from there being no schema at all.

    **Why a delivery surface cannot make either call for the resolver.** Both
    comparisons take the :class:`~ccf.products.contract.RegisteredProductClass`
    as their second operand, and a surface holding a tenant, a class name, a
    version, a perspective and a request holds no such thing — the registered
    class is resolved *behind* this seam. The SDK cannot call a comparison
    whose second operand it does not have, and reaching for it at the surface
    would put an SDK-owned verdict on the serve path that ``D-IMPL-102`` limb 3
    declined. :class:`GovernedResolver` discharges the obligation; a deployment
    writing its own discharges it itself.
    """

    def __call__(
        self,
        *,
        tenant: str,
        product_class: str,
        version: str,
        perspective: Perspective,
        request: ProductRequest | None,
    ) -> ResolverOutcome:
        """Return the gate-admitted product at that address, or the refusal.

        Keyword-only, so a signature of same-typed strings cannot be called
        with the tenant and the class transposed.

        Args:
            tenant: The tenant the product is addressed under. Established by
                the calling surface, never claimed by the caller's body.
            product_class: The Context Product class being requested.
            version: The class's own semver lane (INV-CH7-49). Lanes are per
                class and are never compared across classes.
            perspective: The Π role-conditioning the surface resolved and the
                deployment's entitlement policy authorized. Required and
                non-nullable, and deliberately not defaulted: a resolver
                quietly constructing its own perspective is indistinguishable
                from one honouring the surface's, and a parameter defaulting to
                ``None`` would recreate exactly that ambiguity one layer down.
            request: The typed question the caller asked, or ``None`` when
                **the surface carries no way to ask**. Required with no
                default; ``None`` is a positive assertion rather than a missing
                value, and it is spelled that way because the ``ccf-product://``
                template has three segments and no query surface among them.
                A surface that does have one passes a request whenever a caller
                supplies one.

        Returns:
            A :class:`~ccf.replay.serve.ServedProduct` — the vessel paired with
            the reference of the replay record whose successful append
            authorized its delivery — or a
            :class:`~ccf.products.refusal.RefusalEnvelope` carrying the
            governed "no" with its kind intact.

        Raises:
            ProductNotResolvable: no product at that address.
        """
        ...


@runtime_checkable
class ProjectionPlanFactoryProtocol(Protocol):
    """How a deployment builds its Π for one question.

    A factory rather than a plan, because a plan that is going to interpret a
    caller's parameters has to *see* them: the whole distinction between an
    aggregated product and an assembled one is that the question reaches the
    interpretation. Handing a resolver one long-lived plan would either freeze
    the parameters at wiring time — the *configurable rather than callable*
    defect :mod:`ccf.products.request` was written to correct — or force every
    plan to be mutable, which replay cannot tolerate.

    The SDK ships no implementation of this, and could not: which operator
    outputs mean what, and what the payload of an answer looks like, is the
    deployment's whole contribution.

    **That is now a ruling rather than an assumption.** CLAUDE.md §11 asks for a
    reference implementation beside every Protocol, so the absence was put to
    Dave and measured:
    ``docs/superpowers/specs/2026-08-16-reference-plan-factory-and-debt-scorer.md``
    **Amendment A.2** records that
    :class:`~ccf.projection.plan.ProjectionPlan` is itself a Protocol — code,
    not data — that no declarative plan artifact exists in the tree, and that a
    reference factory would therefore have to *invent* the mapping from a
    :class:`~ccf.graph.protocols.GraphView` of entities onto a payload schema's
    declared fields. A "pass-through" reference plan was proposed and withdrawn
    for doing the same invention less visibly. The ruling, in substance: *§11
    does not require the impossible; it requires a reference implementation
    when one can be pure mechanism, and here it cannot.* A declarative plan
    surface is named there as future work, and it is what would close this.

    The sibling seam :class:`AssemblyDebtScorerProtocol` was measured the other
    way in the same amendment and **does** carry a shipped reference; the two
    Protocols look symmetrical and are not.
    """

    def __call__(
        self, *, required: tuple[str, ...], request: ProductRequest
    ) -> ProjectionPlan:
        """Build the plan that answers ``request``.

        Args:
            required: The operator keys the product class's own document
                declares. Passed in rather than read by the plan, so a
                deployment authoring one operator set cannot accidentally
                author a second one for Gate 2 to diverge from.
            request: The question, carrying the parameters the interpretation
                applies and the instant it is asked as of.
        """
        ...


@runtime_checkable
class SubjectDisclosingPlanFactoryProtocol(Protocol):
    """A plan factory declaring that its projection withholds subjects, and how early.

    SEC-020, ``D-IMPL-378`` (Q8; SDK-defined, CLAUDE.md §11). An **optional
    companion** to :class:`ProjectionPlanFactoryProtocol`, on the
    :class:`CompositePlanFactoryProtocol` precedent: declared structurally,
    never inferred. :meth:`subject_disclosure` returns the declared
    :class:`~ccf.products.subject_disclosure.SubjectDisclosurePolicy` — read
    ONCE, when the resolver is constructed, so it is a declaration rather than
    a per-question computation — or ``None``, the statement that this
    projection withholds only inside itself, after its plan has run (a late
    withhold), which a composite may not do
    (:class:`CompositeNeedsAnEarlyPolicy`).

    Under a policy, :meth:`GovernedResolver.__call__` decides before anything
    in the question is fetched, any child is asked or anything is scored —
    from the asked identifier, the resolved perspective and the declaration
    alone — and, for a subject the policy does not disclose, asks the
    acquisition phases and the child questions about the declared undisclosed
    subject IN PLACE OF it, seeds the plan's walk with it, and computes the
    product ONCE along that path; the plan is still built from, and the record
    still keeps, the caller's question. The factory's projection must withhold
    exactly what the policy does not disclose
    (:class:`UndisclosedSubjectAnswered`).

    A class affirming ``subject_withholding: never`` is not built over a factory
    whose declaration withholds — ``None``, or a policy that does not disclose
    some subject — (:class:`NeverWithholdingProjectionCanWithhold`, Dave's E2
    (ii), ``D-IMPL-378``).
    """

    def subject_disclosure(self) -> SubjectDisclosurePolicy | None:
        """The declared early policy, or ``None`` for a projection that withholds only late."""
        ...


@runtime_checkable
class NonWithholdingPlanFactoryProtocol(Protocol):
    """A plan factory's positive declaration that no projection it builds withholds its subject.

    Dave, 2026-10-08 16:40 MST (``D-IMPL-378``, E2 (ii), option (d);
    SDK-defined, CLAUDE.md §11): *"Require a positive declaration, default
    silence to refusal, and explicitly limit the trusted-code assumption to
    deployment code callers cannot influence. Keep the false-declaration
    counterexample visible."* An **optional companion** to
    :class:`ProjectionPlanFactoryProtocol`, on the
    :class:`SubjectDisclosingPlanFactoryProtocol` precedent: declared
    structurally, never inferred, and read ONCE, when the resolver is
    constructed. A class affirming ``subject_withholding: never`` is built only
    over a factory implementing it whose :meth:`withholds_no_subject` returns
    exactly ``True``; a factory that does not implement it (silence), or that
    returns anything else, counts as able to withhold and is refused
    (:class:`NeverWithholdingNeedsAPositiveDeclaration`). Classes at the
    default never read it.

    **Trusted deployment code, and only that.** The SDK cannot see inside a
    projection's ``invoke()`` before running it, so it cannot verify the
    statement; it trusts it as deployment code, and the assumption is limited
    to code no caller can influence. The resolver calls
    :meth:`withholds_no_subject` with no argument, at construction, on the
    factory the deployment composed it with; no request, parameter, door
    payload, harness or agent input, or caller-supplied document reaches that
    call or selects the factory it is made on (measured, statically and at the
    in-process, HTTP and MCP doors, by
    ``tests/products/test_sec020_e2ii_trusted_declaration.py::test_e2ii_d_no_caller_input_supplies_selects_or_alters_the_positive_declaration``).
    A deployment's factory that reads caller input into its own declaration is
    outside the assumption.

    **The residual, kept visible.** A FALSE declaration — ``True`` over a
    projection that withholds — constructs, and the serve-time defense
    (:class:`NeverWithholdingContradicted`) refuses the withheld subject's
    question alone, which still tells it from a subject nothing holds
    (``tests/products/test_sec020_e2ii_trusted_declaration.py::test_e2ii_d_counterexample_a_false_positive_declaration_still_tells_the_withheld_subject_apart``);
    every run of the closing test reports it outside its gate
    (``tests/products/test_sec020_combined_proof.py::test_e2ii_limitation_the_false_declaration_cells_are_measured_not_gated``).
    SEC-020 is OPEN.
    """

    def withholds_no_subject(self) -> bool:
        """``True`` only if no projection this factory builds sets the withheld signal, for any subject or principal."""
        ...


@runtime_checkable
class CompositePlanFactoryProtocol(Protocol):
    """A plan factory that can build the parent's Π over its children's contracts.

    `D-IMPL-339`. An **optional companion** to
    :class:`ProjectionPlanFactoryProtocol`, on the
    :class:`~ccf.products.debt_scorer.EvidenceAwareFactorScorer` precedent —
    two seams rather than one widened seam. Adding a defaulted parameter to
    the base Protocol would not make any existing factory accept it, so a
    factory that can read the admitted children declares so by implementing
    this method, and the resolver decides which call to make **structurally**
    — never by probing a signature and retrying without the keyword.

    A factory implementing only ``__call__`` keeps working unchanged: a
    composite whose factory does not implement this is served exactly as it
    was, with the children contributing governance only.
    """

    def build_with_children(
        self,
        *,
        required: tuple[str, ...],
        request: ProductRequest,
        children: ChildContractView,
    ) -> ProjectionPlan:
        """Build the plan that answers ``request`` over ``children``.

        Args:
            required: As for :class:`ProjectionPlanFactoryProtocol`.
            request: As for :class:`ProjectionPlanFactoryProtocol`.
            children: The admitted children's contracts, keyed by the
                declared requirement's ``product_class``. Read-only. Every
                value came through :class:`~ccf.products.composite.CompositeAdmissionGate`
                and was re-bound to this composition before the view existed.
        """
        ...


@runtime_checkable
class ChildAwareDebtScorerProtocol(Protocol):
    """A debt scorer that can read the admitted children's contracts.

    `D-IMPL-339`. The companion to :class:`AssemblyDebtScorerProtocol` on the
    same precedent as :class:`CompositePlanFactoryProtocol` above: a parent
    whose own ``C`` or ``S`` depends on what its children reported — how many
    required legs carried positive data, say — needs those contracts at
    assessment time, per request, and this is the one path by which they
    arrive. A scorer implementing only ``__call__`` is asked exactly as before.
    """

    def score_with_children(
        self,
        *,
        view: GraphView,
        evidence: ExecutionEvidence | None,
        children: ChildContractView,
    ) -> DebtAssessment:
        """Assess ``D_c`` over ``view``, with the children's contracts in hand."""
        ...


@runtime_checkable
class AssemblyDebtScorerProtocol(Protocol):
    """How a deployment measures ``D_c`` over what one question assembled.

    Whitepaper §7.7. A Protocol and not a computation this module performs,
    because the SDK ships the *machinery* for debt and never the *values* — and
    the choice this seam hides is bigger than a threshold: measuring freshness
    over the rows a question **read** rather than over the rows that **survived
    being read** gives a different number, and which one is right depends on
    what the product means.

    **That reasoning stands; the conclusion this docstring used to draw from it
    does not.** It previously asserted that the SDK ships no implementation and
    that scoring debt here would be *"choosing for every deployment, which is
    CLAUDE.md §6.4 firing."* The ruling of record is
    ``docs/superpowers/specs/2026-08-16-reference-plan-factory-and-debt-scorer.md``
    **Amendment A.1** (Dave, 2026-08-16): that **overstates the objection**. A
    documented, overridable default is not a choice imposed on every
    deployment; it is what a reference implementation *is*, and CLAUDE.md §11 —
    *"Reference implementations ship alongside Protocols"* — requires a default
    here rather than an absence. Shipping none did not spare any deployment the
    choice; it made every deployment write the adapter *and* make the choice,
    unstated, in its own tree.

    **The shipped reference is**
    :class:`~ccf.products.debt_scorer.AssemblyDebtScorer`, and it makes the
    choice explicitly rather than avoiding it: it measures over **the rows that
    survived being read** — exactly the entity records of the view it is handed,
    which under :class:`GovernedResolver` is the composed post-operator view —
    because the seam carries one view and recovering the rows the question
    *read* would need a second graph consultation at a second boundary, which
    the Decision Replay record does not describe. Its own docstring carries the
    statement in full, with the observable consequence and the override path.

    **The Protocol's real point is unchanged.** A deployment whose product
    means something different — one measuring how fresh the *consulted source
    data* was, or one counting edges as observations — supplies its own
    conforming callable, and the SDK invokes the reference one never.

    It takes the *view* rather than the payload because debt is measured
    against the assembly, not declared beside it.

    **``evidence`` joined the seam at ``24.6-05``** (``24.6-L-06``,
    ``D-IMPL-255`` (2)). ``D_c`` may not be derived from how many rows came
    back — *"Cardinality never determines Context Debt. Evidence determines
    Context Debt."* — so a conforming scorer is handed what the execution
    observed about its own search: queries issued, operators invoked and
    returned empty, source attestation, snapshot pin. It is keyword-only with
    a ``None`` default, which is *no evidence was supplied*; a scorer is free
    to ignore it, and the shipped reference passes it on to the deployment's
    ``C``/``S`` scorers that declare themselves able to read it
    (:class:`~ccf.products.debt_scorer.EvidenceAwareFactorScorer`).
    **A deployment scorer written before ``24.6-05`` must accept the keyword**
    — the governed resolver always passes it, because a resolver that decided
    per-scorer whether to tell the truth about the search would be two seams
    wearing one name.
    """

    def __call__(
        self,
        *,
        view: GraphView,
        evidence: ExecutionEvidence | None = None,
    ) -> DebtAssessment:
        """Assess ``D_c`` over the graph state this question assembled."""
        ...


@runtime_checkable
class ProductGateProtocol(Protocol):
    """How a deployment holds a product to its class's OWN declared invariant.

    **SDK-defined** (CLAUDE.md §11). The ruling of record is ``D-IMPL-282``
    ``R-11`` option 1a (Dave, 2026-09-08): *"Use a Protocol-typed callable
    supplied to* ``build_governed_resolver``, *analogous to* ``debt_scorer``.
    *The gate identity/version remain declared in the Control Plane;
    implementation is deployment-supplied."* And the boundary on it, from the
    same sitting: *"the runtime gate is not a new universal policy vocabulary.
    It is a declared product invariant with a governed identity, whose
    implementation is supplied by the deployment."*

    **What ``R-11`` supersedes, exactly.** ``D-IMPL-225`` amendment 3 said of
    ``D-IMPL-224``'s declared gates: *"There is no ``ProductGate`` Protocol, no
    serve path for them, and the SDK's universal gates stay the only serve-time
    gates."* ``R-11`` supersedes **the first two limbs and no more** — this
    Protocol exists and there is a path on which it runs. **The third limb
    stands**: a conforming callable is not a member of
    :func:`~ccf.products.gates.run_gates`' sequence, joins no token to the gate
    roster, and :data:`~ccf.products.gates.GATE_DECLARED_OBLIGATIONS` with its
    one-member ``Literal`` is untouched. The supersession is recorded here and
    on :class:`~ccf.products.gates.ProductInvariantRefusal` rather than only in
    a plan file, because a supersession that lives in a plan is one the next
    reader of these modules will not find.

    **Two halves, and they stay apart.** The Control Plane owns the gate's
    IDENTITY —
    :attr:`~ccf.controlplane.artifacts.ProductClassDeclaration.declared_product_gate`
    — and the deployment owns the PREDICATE. That is why a conforming callable
    returns a *detail string* and never an identity: the resolver stamps
    ``gate`` and ``gate_version`` from the declaration, so a deployment's gate
    cannot claim to be a different gate than the one its class declared, and
    ``D-14``'s *"which gate produced the refusal"* is a fact an examiner can
    trust rather than a claim the failing code made about itself.

    **Where it runs**, and it is ruled rather than convenient
    (``D-IMPL-282``, ``D-12``): *"after candidate construction and before
    fitness/fulfillment"* — in
    :meth:`GovernedResolver.__call__`, between :func:`run_gates` returning a
    :class:`~ccf.products.gates.ServableProduct` and
    :func:`~ccf.products.gates.refuse_over_tolerance` withholding one. So it
    never runs on a candidate the universal gates refused (there is no product
    to hold an invariant against) and it runs before an applicable tolerance
    can withhold fulfillment, because whether the answer is RIGHT is a
    different question from whether it is FIT.

    **No expression language, no rule DSL, no gate registry** (``D-11``,
    ``D-13``). The invariant is Python the deployment already writes, in the
    deployment's own tree, exactly as ``plan_factory`` and ``debt_scorer`` are.
    The SDK never parses it and never authors one.

    **A deployment gate that raises or hangs is the deployment's own
    latency and failure budget**, on the same footing as the other two
    deployment-supplied seams. Wrapping this call in a timeout would be the
    SDK choosing a deployment's budget for it, which is what CLAUDE.md §11
    refuses.
    """

    def __call__(
        self,
        *,
        candidate: ContextProductContract,
        evidence: ExecutionEvidence | None = None,
    ) -> str | None:
        """Hold ``candidate`` to the class's declared invariant.

        Args:
            candidate: The product the deployment is about to serve. The
                invariant is a property of the answer, so the answer is what
                is handed over — not the view, which is what
                :class:`AssemblyDebtScorerProtocol` takes, because debt is a
                property of the assembly and this is not.
            evidence: What the execution observed about its own search,
                keyword-only with a ``None`` default for the reason the debt
                scorer's carries one: a gate is free to ignore it, and the
                resolver always passes it, because a resolver that decided
                per-gate whether to tell the truth about the search would be
                two seams wearing one name.

        Returns:
            ``None`` to admit, or a non-empty string describing the violation
            in the deployment's own words. The SDK carries that string into
            :attr:`~ccf.products.gates.GateRefusal.detail` and never parses it:
            an invariant's failure mode is the product's to describe. An empty
            string admits — it is not a violation nobody worded, and a gate
            that means to refuse says why.
        """
        ...


@runtime_checkable
class AcquisitionSeamProtocol(Protocol):
    """The declared acquisition boundary on the governed call (`D-IMPL-343` R-4).

    **SDK-defined** (CLAUDE.md §11); the rulings of record are ``D-IMPL-279``
    ``R-09`` — *"it should accept an acquisition result / prepared context
    input produced through a declared acquisition interface"* — and Dave's
    ``D-IMPL-343`` ruling R-4, verbatim: *"Effective-request derivation runs
    once, on the governed call, and acquisition consumes that outcome. A
    preview API that re-runs constraint resolution is a second derivation and
    fails D-IMPL-289."*

    **What the seam is.** One callable a deployment (or the paved road's
    facade on its behalf) hands :class:`GovernedResolver`, invoked by
    :meth:`GovernedResolver.__call__` exactly once per question for the
    question's subject (and, as below, once more for the P6 probe, or twice
    more to verify a declared early policy's stand-in),
    **after** the effective request has been resolved — defaults applied, the constraints
    in force folded, the technical capabilities held, the intent judged — and
    **before** the graph is read at the question's boundary. A declared
    :class:`PopulationAcquisitionSeamProtocol` is the second declared phase,
    also invoked exactly once per question, immediately BEFORE this one and
    without the subject (SEC-020, ``D-IMPL-378`` Q7 and Q10: *"Two declared
    acquisition phases are permitted, each once."*): the effective request is
    still derived once, and each phase consumes that one outcome. **Q10 as
    amended by ruling P6 (a)** (Dave, 2026-10-08 16:40 MST: *"Amend Q10 to
    permit the probe."*): for a class that may withhold its subject and
    declares no early policy, this seam is called ONCE MORE per question, and
    for nothing else — with the effective request carrying
    :data:`UNHELD_SUBJECT_PROBE` in place of the subject, immediately before its
    call for the question's subject — and the question is refused if that call
    changed the fabric (:class:`PopulationReadInSubjectKeyedPhase`), or
    answered and recorded as :data:`UNHELD_SUBJECT_PROBE_REFUSAL` if it ended in
    a held refusal. **Q10 as
    amended by decision 4 (a)** (Dave, 2026-10-09 06:06 MST, confirmed 06:21:
    *"Verify the stand-in is absent before and after acquisition."*): for a
    class with a declared early policy, this seam is called TWICE MORE per
    question, and for nothing else — with :data:`UNHELD_SUBJECT_PROBE` and then
    with the policy's declared stand-in in place of the subject, immediately
    before its call for the question — and the question is refused if the
    stand-in acquired anything the probe identifier did not
    (:class:`UndisclosedSubjectSubstituteIsHeld`). It receives the
    EFFECTIVE request, so what a deployment reads its sources at is the value
    governance resolved, never a second derivation of it: the seven copies of
    ``ReferencePolicyConstraintResolver`` the canonical trees carried to guess
    that value are what this seam deletes (``D-IMPL-289``: deleted, not
    relocated).

    **What the seam is not.** It is not the resolver acquiring. The callable
    is the deployment's composition root — the paved road's
    :class:`~ccf.products.product.OpenedProduct`, or a hand-composed spine —
    and it is that root that reads a source and ingests through L2's one
    writer. :class:`GovernedResolver` holds no writer, hands no envelope to
    one, and cannot: what its docstring says about that boundary is unchanged
    by this Protocol, which adds a call and no capability. A refused question
    never reaches the seam, so a refused request acquires nothing — by the
    ordering rather than by a check the deployment remembers to write.

    ``perspective`` travels because which principal asks changes WHICH
    ENTITIES a source read may expand (a jurisdiction grant, say), and the
    deployment's acquisition is where that expansion legitimately happens.
    """

    def __call__(self, *, request: ProductRequest, perspective: Perspective) -> None:
        """Acquire and ingest whatever answering ``request`` needs; return nothing."""
        ...


class PopulationQuestion(CCFContract):
    """What the population phase is asked: the effective request WITHOUT its subject.

    SEC-020, ``D-IMPL-378`` (Dave, 2026-10-07, Q7: *"Approve an explicit
    population-fetch mode. Subject-independent acquisition must not receive
    the requested subject indirectly through context or closures."*;
    SDK-defined, CLAUDE.md §11). A source whose answer does not depend on who
    is asked about acquires, for an identifier that names nothing, exactly what
    it acquires for any other subject, and a withheld subject is rendered over
    the fabric after it. This type has no ``subject`` member, so nothing the
    population phase is handed carries the asked identifier — by construction,
    not by trust. It keeps the subject out, not every identifier: a declared
    parameter that itself names an entity is still a parameter, and reaches the
    population phase.
    """

    schema_name: str
    schema_version: str
    intent: str
    freshness: str
    asked_at: datetime
    parameters: Mapping[str, Any]

    @classmethod
    def of(cls, request: ProductRequest) -> PopulationQuestion:
        """The subject-free half of ``request``: every member but the subject and its overrides."""
        return cls(
            schema_name=request.schema_name,
            schema_version=request.schema_version,
            intent=request.intent,
            freshness=request.freshness,
            asked_at=request.asked_at,
            parameters=dict(request.parameters),
        )


@runtime_checkable
class PopulationAcquisitionSeamProtocol(Protocol):
    """The population phase: the declared, subject-independent half of a question's acquisition.

    SEC-020, ``D-IMPL-378`` (Q7, Q10: *"Two declared acquisition phases are
    permitted, each once."*; SDK-defined, CLAUDE.md §11). Declared on its own
    (:attr:`GovernedResolver.population_acquisition`), never as a method of the
    subject-keyed seam — a shared owner is refused at construction
    (:class:`PopulationPhaseSharesAnOwner`). :meth:`GovernedResolver.__call__`
    invokes it exactly once per question, FIRST — after the fabric is claimed
    for the question and before anything in the question is fetched for the
    subject — with a :class:`PopulationQuestion`; it then reads the fabric, the
    state a subject Π withholds is rendered over, and invokes the subject-keyed
    seam, also once for the question's subject. The subject-keyed phase's
    obligation — it acquires nothing for an identifier its source does not hold
    — is checked for a class that may withhold and declares no early policy, by
    one extra call with :data:`UNHELD_SUBJECT_PROBE` before that one
    (:class:`PopulationReadInSubjectKeyedPhase`; ``D-IMPL-378`` ruling P6 (a),
    which amends Q10 to exactly that call). For a class with a declared early
    policy, what the phase acquires for the policy's stand-in is compared with
    what it acquires for :data:`UNHELD_SUBJECT_PROBE`, two extra calls before
    that one (:class:`UndisclosedSubjectSubstituteIsHeld`; ``D-IMPL-378`` decision
    4 (a)). Neither check detects a source that recognizes the identifier it is
    asked about, so for that source, and for any other class, the obligation
    stays a trusted statement (the security how-to, section 4.12). SEC-020
    stays OPEN.
    """

    def __call__(self, *, question: PopulationQuestion, perspective: Perspective) -> None:
        """Acquire and ingest the part of the answer that does not depend on the subject."""
        ...


@runtime_checkable
class InstantAwareDebtScorerProtocol(Protocol):
    """A debt scorer that is handed the DECISION INSTANT (`D-IMPL-343` R-3c).

    The second structural companion to :class:`AssemblyDebtScorerProtocol`,
    on exactly :class:`ChildAwareDebtScorerProtocol`'s precedent
    (`D-IMPL-339`): a scorer declares that it can read the instant the answer
    is produced as of — and, for a composite, the admitted children — by
    implementing this method, and the resolver decides which call to make
    **structurally**, never by probing a signature.

    **Why the instant has to arrive, rather than be closed over.** A scorer
    that measures freshness needs *now*, and before this seam every canonical
    tree wrote a closure over ``asked_at`` — which is the graph boundary, not
    the decision instant, and the two differ for any class declaring
    :attr:`~ccf.controlplane.artifacts.ProductClassDeclaration.decision_instant_parameter`
    (``24.10-F-09``, ``D-IMPL-308``). ``decided_at`` here IS the resolver's
    own :meth:`GovernedResolver._decision_instant` — the same value the
    product's expiry runs from and the record's ``recorded_at`` carries — so
    a deployment's freshness reading and the SDK's expiry can no longer
    disagree about when the answer was produced.

    A scorer implementing only ``__call__`` is asked exactly as before, and a
    child-aware scorer keeps its own call; this Protocol is checked first
    because it is the widest, and a scorer implementing more than one is
    asked through the widest one it declares.
    """

    def score_at(
        self,
        *,
        view: GraphView,
        evidence: ExecutionEvidence | None,
        decided_at: datetime,
        children: ChildContractView | None,
    ) -> DebtAssessment:
        """Assess ``D_c`` over ``view`` as of ``decided_at``, children in hand."""
        ...


@runtime_checkable
class RefusalRecorderProtocol(Protocol):
    """The ONE seam through which a governed refusal reaches the replay writer.

    **SDK-defined** (CLAUDE.md §11); the rulings of record are ``D-IMPL-253``
    Q13 (*"Refusal is itself a decision and deserves the same five-dimensional
    replay model. Do not create second-class replay."*) and ``D-IMPL-256``,
    whose invariant this seam exists to make structural rather than
    conventional:

        *"Every governed determination that crosses a CCF delivery boundary —
        fulfilled or refused, tool or resource, authorized or denied — must
        reach the replay writer before the response is released. A delivery
        boundary unable to satisfy that invariant is unavailable, not partially
        governed."*

    **Why a seam and not a function.** Four callers mint through it and they do
    not share a caller's shape: this module's own three refusal branches, the
    governed delivery-boundary step every entitling door calls
    (``runtime/ccf_runtime/authz/delivery_boundary.py``), and an assembler's
    own wrappers. A Protocol is what lets all four hold *one* recorder — one
    :class:`~ccf.replay.serve.ReplayWriter`, over one artifact store — while a
    deployment that files records elsewhere substitutes its own by conforming.

    **What must NOT happen here, stated because it is the failure this seam
    prevents.** ``D-IMPL-256`` again, in Dave's words: *"make sure the
    architecture does not accidentally make the transport responsible for
    minting replay. The sequence should conceptually remain: request →
    identity/policy → determination → replay → disclosure shaping → transport
    encoding, not: request → determination → HTTP/MCP → transport notices
    refusal → writes replay. Replay belongs to the governed determination, not
    to HTTP or MCP."* No module under ``runtime/ccf_runtime/http_api/`` or
    ``runtime/ccf_runtime/mcp/`` calls this seam; the governed step does, and
    the transports encode what it returns.

    ``@runtime_checkable`` so a delivery boundary can assert conformance at the
    point it is handed one rather than discovering a shape mismatch inside a
    determination it has already made. The check is structural and covers the
    presence of ``record``, not its signature; the signature is mypy's job —
    with one exception, read at construction: every path that accepts a
    recorder refuses one whose ``record`` cannot be passed
    ``subject_withholding=``, the keyword the governed resolver passes on every
    refusal (Dave's E2 (iii), ``D-IMPL-378``;
    :func:`refuse_incompatible_refusal_recorder`).
    """

    def record(
        self,
        envelope: RefusalEnvelope,
        *,
        perspective: Perspective,
        recorded_at: datetime,
        served_at: datetime | None,
        request: ProductRequest | None = None,
        execution: ExecutionResult | None = None,
        policy_bindings: tuple[PolicyBinding, ...] = (),
        assembler_id: str | None = None,
        assembler_version: str | None = None,
        resolution: EffectiveRequest | ResolutionNotApplicable,
        child_resolutions: tuple[ChildResolution, ...] = (),
        refusal_seam: str = NO_REFUSAL_SEAM,
        subject_withholding: str | None = None,
        agent_conditioning: PerspectiveConditioning | None = None,
    ) -> RefusalEnvelope:
        """Append ``envelope``'s decision record, then return it with its address.

        The ordering is the whole mechanism and it is not negotiable: the
        record is appended **first**, and the shell the caller gets back is the
        one the append produced an address for. A caller that received a shell
        has, by construction, a recorded decision behind it.

        Args:
            envelope: The governed "no", as the determination produced it. Its
                :attr:`~ccf.products.refusal.RefusalEnvelope.replay_reference`
                is expected to be the sentinel; whatever it carries, the
                **recorded** shell carries the sentinel, because a record whose
                content address covered a reference to itself could not be
                content-addressed at all.
            perspective: Whose viewpoint the determination was reached under,
                **already resolved** — dimension 4, recorded verbatim.

                It is a :class:`~ccf.projection.plan.Perspective` rather than a
                ``principal_id`` and a ``role``, and that is a structural
                requirement rather than a convenience: ``15.5-RESEARCH.md``
                Pitfall 3 forbids a ``principal_id`` **parameter** anywhere
                under ``ccf/products``, ``ccf/projection`` or ``ccf/replay``,
                and ``tests/invariants/test_mcp_role_separation.py`` walks the
                three trees for one. Entitlement is decided at the door and
                everything below receives an already-resolved perspective; a
                seam that took the two halves apart would be assembling
                identity one layer too low.

                A delivery boundary that denies before any Π role is resolved
                passes :data:`~ccf.replay.record.NO_ROLE_RESOLVED` as the role
                — a positive claim the **door** makes, rather than a ``None``
                this seam would have to interpret on the door's behalf.
            recorded_at: The determination's own instant. For a resolver
                refusal that is the question's ``asked_at``; for a
                delivery-boundary denial it is the deployment's declared
                entitlement clock, and it is the **same** instant the
                envelope's
                :attr:`~ccf.products.refusal.ResourceRequestIdentity.determined_at`
                carries — the shell and its record cannot disagree about when
                the fabric decided.
            request: The typed question, when there was one. ``None`` for a
                standing-resource denial, which is a governed request in a
                different request form (``D-IMPL-256`` (1)).
            execution: The execution behind the refusal, when the graph was
                read. ``None`` makes dimension 1 the positive *unread* claim.
            policy_bindings: Control Plane pins in force, beyond whatever the
                recorder was constructed with.
            assembler_id: The assembler in force, and ``assembler_version`` its
                lane — dimension 4 (``D-IMPL-253`` Q16).
            resolution: The resolution state — dimension 2 (``D-IMPL-253``
                Q1/Q6; ``D-IMPL-264`` D-10). REQUIRED, with no default, as of
                24.7-04: the
                :class:`~ccf.products.provenance.EffectiveRequest` the
                Authority layer produced — complete, or the partial record it
                established before refusing (D-07) — or a
                :class:`~ccf.replay.record.ResolutionNotApplicable` marker
                stating, with its reason, that no resolution applies (D-09).
                A caller that ran no resolver says so; this seam never says
                it on the caller's behalf. ``D-IMPL-264`` amendment 1 (F-3 a), Dave verbatim: *"Any API that
        constructs or delegates construction of a replay record must require
        an explicit resolution state: effective/partial resolution or explicit
        not-applicable marker. No intermediate layer may manufacture the
        marker from omission."*
            subject_withholding: What the deciding class's declaration affirms
                about withholding its subject (Dave's Q12; ``D-IMPL-378``),
                recorded in dimension 5 so the governed evidence read can hold
                owner read-back to it. ``None`` records the unstated sentinel,
                which the read treats as a class that may withhold. The governed
                resolver passes it on every refusal it records.

        Returns:
            The same envelope with its
            :attr:`~ccf.products.refusal.RefusalEnvelope.replay_reference` set
            to where the record landed.

        Raises:
            Exception: whatever the artifact store raises, deliberately
                uncaught. A failure to record is a failure to respond.
        """
        ...


class IncompatibleRefusalRecorder(TypeError):
    """A refusal recorder whose ``record`` cannot be passed ``subject_withholding=``, refused where it is built.

    Dave's E2 (iii) (``D-IMPL-378``, 2026-10-08 12:29 MST), verbatim: *"Approve
    the recorder keyword change. Detect incompatible recorders at construction,
    rather than on the first refusal."* (SDK-defined, CLAUDE.md §11.)
    :meth:`RefusalRecorderProtocol.record` takes ``subject_withholding=`` (Dave's
    Q12), and :class:`GovernedResolver` passes it on every refusal it records. A
    recorder written to the earlier signature — the keyword neither named nor
    absorbed by ``**kwargs`` — used to build cleanly and raise ``TypeError`` at
    the first refusal: a failure that waited for a question to be refused. It is
    raised instead where a resolver or an entitling door is built
    (:func:`refuse_incompatible_refusal_recorder`), before anything is minted,
    registered or answered. A ``TypeError``: the recorder's ``record`` has the
    wrong signature for the seam.
    """


def refuse_incompatible_refusal_recorder(
    recorder: object, *, builder: str, keyword: str = "subject_withholding"
) -> None:
    """Refuse, where it is built, a recorder whose ``record`` cannot be passed ``subject_withholding=``.

    Dave's E2 (iii) (``D-IMPL-378``; :class:`IncompatibleRefusalRecorder`).
    Called by :class:`GovernedResolver` at construction and by every entitling
    door's builder (``runtime/ccf_runtime/authz/delivery_boundary.py::recorded_boundary``
    and ``runtime/ccf_runtime/mcp/artifact_server.py::build_artifact_server``).
    Read off ``record``'s signature, never by calling it: a call would append a
    record describing no decision. A ``record`` that names
    ``subject_withholding`` as a parameter it can be passed by keyword, or that
    takes ``**kwargs``, is compatible.

    Args:
        recorder: What the builder was handed.
        builder: The builder's own name, so the message names where to fix it.
        keyword: The keyword ``record`` must accept; ``subject_withholding`` by
            default, ``agent_conditioning`` for a resolver composed over an
            agent-conditioned child resolver (`D-IMPL-385`).

    Raises:
        IncompatibleRefusalRecorder: ``recorder`` has no callable ``record``,
            its signature cannot be read, or it cannot be passed
            ``subject_withholding=``.
    """
    record = getattr(recorder, "record", None)
    where = f"{builder} was handed a refusal_recorder of type {type(recorder).__name__} whose `record`"
    if not callable(record):
        raise IncompatibleRefusalRecorder(
            f"{where} is missing or not callable; it cannot be passed"
            " subject_withholding=, which the governed resolver passes on every"
            " refusal it records (Dave's E2 (iii), D-IMPL-378)"
        )
    try:
        parameters = inspect.signature(record).parameters
    except (TypeError, ValueError) as unreadable:
        raise IncompatibleRefusalRecorder(
            f"{where} has a signature that cannot be read, so it cannot be shown"
            " to accept subject_withholding=, which the governed resolver passes"
            " on every refusal it records (Dave's E2 (iii), D-IMPL-378)"
        ) from unreadable
    if any(parameter.kind is inspect.Parameter.VAR_KEYWORD for parameter in parameters.values()):
        return
    named = parameters.get(keyword)
    if named is None or named.kind not in (
        inspect.Parameter.KEYWORD_ONLY,
        inspect.Parameter.POSITIONAL_OR_KEYWORD,
    ):
        if keyword != "subject_withholding":
            raise IncompatibleRefusalRecorder(
                f"{where} cannot be passed {keyword}=: the governed resolver passes"
                " it on every refusal its composing agent's decisions record. Add"
                f" `{keyword}: PerspectiveConditioning | None = None` to `record`"
                " (RefusalRecorderProtocol), or take **kwargs (D-IMPL-385)"
            )
        raise IncompatibleRefusalRecorder(
            f"{where} cannot be passed subject_withholding=: the governed"
            " resolver passes it on every refusal it records, so this recorder"
            " would raise TypeError at the first one. Add `subject_withholding:"
            " str | None = None` to `record` (RefusalRecorderProtocol), or take"
            " **kwargs (Dave's E2 (iii), D-IMPL-378)"
        )


def _disclosure_reader(
    control_plane: ControlPlaneProtocol,
) -> Callable[..., tuple[DisclosureLevel, ProvenanceSource | None]]:
    """A :attr:`ReplayRefusalRecorder.disclosure_level_for` over one registry.

    ``24.6-L-16``; ``D-IMPL-253`` Q17. Resolves the tenant's
    :class:`~ccf.products.entitlement.ProductEntitlementPolicy` under
    :func:`~ccf.products.entitlement.product_entitlement_key`, reads the
    principal's own override when the grant declares one, and falls back to the
    tenant's level. **No registered policy is
    :data:`~ccf.products.disclosure.DISCLOSURE_MINIMAL` with a ``None``
    source** — the safe default, and the ``None`` says positively that no
    policy set it rather than leaving a reader to guess.

    Read **per call**, with no cache and no TTL, on
    :class:`~ccf_runtime.authz.product_entitlement.ControlPlaneProductEntitlementSource`'s
    own reasoning (D-07): a posture tightened in the Control Plane must govern
    the next determination.

    A near-miss is refused rather than interpreted, in that source's shape too:
    an artifact under the key that is not a policy, or one whose own
    ``tenant_id`` is not the tenant it was found under, raises. Disclosing
    under a policy that names another tenant is exactly the elevation
    ``T-24.6-29`` describes.

    The returned closure is keyword-permissive for the reason
    :func:`_minimal_disclosure` is: naming ``principal_id`` as a parameter
    under ``ccf/products`` is what ``15.5-RESEARCH.md`` Pitfall 3 forbids.
    """

    def read(**asked: object) -> tuple[DisclosureLevel, ProvenanceSource | None]:
        tenant = str(asked["tenant"])
        principal = str(asked["principal_id"])
        key = product_entitlement_key(tenant_id=tenant)
        try:
            version, resolved = control_plane.resolve_latest(key)
        except LookupError:
            # Deny-by-default in the disclosure dimension: a tenant with no
            # registered entitlement policy discloses minimally. The exception
            # type is the registry's (`ControlPlaneMissing`, a `LookupError`),
            # and catching it structurally rather than by name keeps this
            # module free of a second import of the registry's error
            # vocabulary. ONLY the lookup failure is "no policy": a registry
            # that failed for any other reason propagates, because answering
            # `(minimal, None)` for it would record *no policy is registered*
            # as the disclosure's provenance when the truth is that the policy
            # could not be read — a false claim in replay dimension 5, found by
            # the Phase 24.6 close panel.
            return DISCLOSURE_MINIMAL, None
        if not isinstance(resolved, ProductEntitlementPolicy):
            raise TypeError(
                f"artifact under {key!r} is not a ProductEntitlementPolicy"
                f" (got {type(resolved).__name__}); the disclosure level is"
                " read from the tenant's own entitlement policy and a"
                " near-miss is refused, never interpreted"
            )
        if resolved.tenant_id != tenant:
            raise ValueError(
                f"policy under {key!r} declares tenant {resolved.tenant_id!r},"
                f" not {tenant!r}; disclosing under another tenant's policy is"
                " the elevation the tenant-scoped key exists to prevent"
            )
        source = ProvenanceSource(kind="artifact", identity=key, version=version)
        grant = resolved.principals.get(principal)
        if grant is not None and grant.disclosure_level is not None:
            return grant.disclosure_level, source
        return resolved.disclosure_level, source

    return read


def _minimal_disclosure(
    **_read: object,
) -> tuple[DisclosureLevel, ProvenanceSource | None]:
    """The posture a recorder with nothing to ask can honestly report.

    ``D-IMPL-253`` Q17: *"Suppression silence should be policy-controlled, with
    minimal disclosure as the safe default."* A recorder constructed without a
    Control Plane reader cannot resolve any tenant's policy, so
    :data:`~ccf.products.disclosure.DISCLOSURE_MINIMAL` is not a fallback here —
    it is the only true answer, and the ``None`` source says positively that no
    policy set it.

    Keyword-permissive so it satisfies the seam's shape without naming the two
    keywords: a default that declared ``principal_id`` would put that parameter
    under ``ccf/products``, which ``15.5-RESEARCH.md`` Pitfall 3 forbids and
    ``tests/invariants/test_mcp_role_separation.py`` fails on.
    """
    return DISCLOSURE_MINIMAL, None


# --- the composition recipe (D-IMPL-354) --------------------------------------
#
# This module is a composition root — `COMPOSITION_MINT_SITES` names it — and
# these three functions are the whole of how the resolver's own writes obtain
# authority: the decision is recorded on the Control Plane's own audit log as a
# `composition` event, and the capability carries that event's content address
# as its `decision_id`. `ReplayMint` on one evidence class for one tenant;
# `Register` on one Control Plane key whose tenant is the key's own segment,
# derived as the registry derives it. Nothing here is a wildcard.


def _composition_decision(
    control_plane: ControlPlaneProtocol, *, key: str, action_id: str
) -> str:
    event = control_plane.audit_log.append(
        action="composition",
        key=key,
        version=action_id,
        resolved=True,
        occurred_at=_utc_now(),
        actor=COMPOSITION_PRINCIPAL,
    )
    return content_hash(event)


def _mint_replay_at_composition(
    control_plane: ControlPlaneProtocol, *, tenant: str, artifact_class: str
) -> Authorized[ReplayMint]:
    """``Authorized[ReplayMint]`` for ``artifact_class`` under ``tenant``, audited."""
    return mint_at_composition(
        ReplayMint,
        tenant=tenant,
        principal=COMPOSITION_PRINCIPAL,
        resource=artifact_class,
        decision_id=_composition_decision(
            control_plane, key=artifact_class, action_id=ReplayMint.action_id
        ),
    )


def _mint_register_at_composition(
    control_plane: ControlPlaneProtocol, *, key: str
) -> Authorized[CompositionRegister]:
    """``Authorized[CompositionRegister]`` for exactly ``key``, for the key's own tenant, audited."""
    tenant, separator, _ = key.partition("/")
    if not separator or not tenant:
        raise CrossTenantKeyRefused(
            f"Control Plane key {key!r} has no tenant segment; a composition"
            " root mints Register for `{tenant}/{class}/{name}` and a key that"
            " names no tenant belongs to nobody (D-IMPL-353 §1.3; D-IMPL-354)"
        )
    return mint_at_composition(
        CompositionRegister,
        tenant=tenant,
        principal=COMPOSITION_PRINCIPAL,
        resource=key,
        decision_id=_composition_decision(
            control_plane, key=key, action_id=CompositionRegister.action_id
        ),
    )


@dataclass(frozen=True, kw_only=True)
class _ComposedAuthorities:
    """What a :class:`GovernedResolver`'s composition minted for its own writes (D-IMPL-354).

    One value, built once in :meth:`GovernedResolver.__post_init__` and held for
    the resolver's life. Every member is required and typed for the one kind
    and one resource it opens; nothing here has a default, because a
    composition that minted four of five would be a resolver that fails at
    its first write instead of at boot.
    """

    replay: Authorized[ReplayMint]
    query_pin: Authorized[ReplayMint]
    admitted_child: Authorized[ReplayMint]
    max_ttl: Authorized[CompositionRegister]
    request_contract: Authorized[CompositionRegister]


class UndeclaredMechanismClass(TypeError):
    """The store handed to a resolver does not declare a class the resolver writes under ``ReplayMint``.

    D-IMPL-353 §1.2: which kind a write requires is looked up per artifact
    class from the :class:`~ccf.artifacts.protocol.WriteKinds` declaration
    bound to the store at composition. A resolver writes its replay records,
    its query pins and its admitted child contracts under the composition-
    minted ``ReplayMint``; a store whose declaration does not name one of
    those classes under that kind would refuse the resolver's own writer at
    the first serve — wrong kind, loudly. This refusal moves that failure to
    **construction**: fail closed at boot, never at the first write. A store
    that exposes no declaration at all cannot show it declares them, and is
    refused the same way — *don't know* is not *pass*.
    """


@runtime_checkable
class _DeclaresWriteKinds(Protocol):
    @property
    def write_kinds(self) -> WriteKinds: ...


def _require_declared(store: ArtifactStoreProtocol, classes: tuple[str, ...]) -> None:
    if not isinstance(store, _DeclaresWriteKinds):
        raise UndeclaredMechanismClass(
            f"the artifact store ({type(store).__name__}) exposes no `write_kinds`"
            " declaration, so it cannot be shown to admit the resolver's own"
            f" writes under ReplayMint for {list(classes)!r}; both shipped"
            " stores take `write_kinds=` at construction (D-IMPL-353 §1.2)"
        )
    declared = store.write_kinds
    for artifact_class in classes:
        if not any(kind is ReplayMint for kind in declared.for_class(artifact_class)):
            raise UndeclaredMechanismClass(
                f"the artifact store does not declare class {artifact_class!r}"
                " mechanism-written under ReplayMint; the resolver files that"
                " class under its composition-minted capability and would be"
                " refused at the first serve — declare it at composition:"
                f" WriteKinds.declare({{{artifact_class!r}: (ReplayMint,), ...}})"
                " (D-IMPL-353 §1.2; D-IMPL-354)"
            )


@dataclass(frozen=True, kw_only=True)
class ReplayRefusalRecorder:
    """The SDK's reference :class:`RefusalRecorderProtocol` — one writer, one store.

    **SDK-defined** (CLAUDE.md §11), and the reference implementation CLAUDE.md
    §11 requires beside every Protocol. It composes exactly two shipped things
    and invents nothing: :func:`~ccf.replay.record.build_replay_record` with
    the refusal as its outcome, and :func:`~ccf.replay.serve.record_refusal`
    over a :class:`~ccf.replay.serve.ReplayWriter` — the **same** writer class
    the served path uses, over the store the deployment already handed its
    resolver. That sameness is the substance of *"do not create second-class
    replay"*: a second writer, or a second record shape, would be exactly that.

    It is also why the ArtifactStore never becomes a second writer to the graph
    (CLAUDE.md §7.4, §10): this type holds a store and no graph handle, and
    nothing below reaches one.

    Attributes:
        authorized: The composition-minted ``ReplayMint`` capability for the
            record class this recorder files (D-IMPL-353 §2 P3; D-IMPL-354).
            Handed by the deployment at composition — the same object its
            :class:`~ccf.replay.serve.ReplayWriter` is built over — and
            verified here at construction. The tenant and the record class are
            READ off it (:attr:`tenant_id`, :attr:`replay_record_class`);
            there is no second source for either (§1.2, §1.3).
        artifact_store: Where the record lands. A substrate reached *through*
            mechanism. Must declare the capability's class under ``ReplayMint``
            (:class:`UndeclaredMechanismClass` otherwise, at construction).
        assembly_mode: The mode dimension 3 records.
            :func:`~ccf.replay.record.build_replay_record` takes it with no
            default, so it is held here rather than defaulted into existence.
        policy_bundle_pin: The bundle in force, prepended to every record's
            bindings. ``None`` — the default — means the record's bindings are
            **exactly** the caller's tuple, which is the honest posture for a
            recorder wired by a delivery boundary that holds no bundle key.
        disclosure_level_for: How this recorder reads the posture in force
            (``24.6-L-16``; ``D-IMPL-253`` Q17). Called as
            ``(tenant=..., principal_id=...)`` and returning the level with the
            Control Plane source that set it.

            **Keyed by principal, not by**
            :class:`~ccf.projection.plan.Perspective`: a delivery-boundary
            denial has a principal and no resolved role at all
            (``NO_ROLE_RESOLVED``), and it must disclose under the same reader
            a resolver refusal for that principal would. A signature that
            needed a role would have made the two paths disclose differently,
            which is the observational difference ``D-IMPL-253`` amendment 2
            (4) forbids.

            **Keyed by the determination's tenant together with the
            principal** (Dave, 2026-10-07; ``D-IMPL-378``): a delivery-boundary
            determination's own resource identity names the tenant its door
            established for the caller, and that tenant is the one asked; this
            recorder's own tenant is asked only for a determination that names
            none — a resolver's own refusal, decided under the tenant this
            recorder files for. Asked under this recorder's tenant alone, a
            door serving several tenants through one recorder disclosed another
            tenant's caller at whatever level this tenant declares for a
            colliding principal id.

            The default is :func:`_minimal_disclosure`, which reads nothing and
            answers ``(DISCLOSURE_MINIMAL, None)``. A recorder wired with no
            Control Plane to ask cannot resolve a policy, and the safe default
            is the only coherent answer — asserted here rather than left to a
            caller to remember. :func:`build_governed_resolver` supplies a
            reader over the deployment's own registry.
    """

    authorized: Authorized[ReplayMint]
    artifact_store: ArtifactStoreProtocol
    assembly_mode: AssemblyMode
    policy_bundle_pin: PolicyBinding | None = None
    # A `default_factory` rather than a bare `default`, and the reason is a
    # measurement rather than a style: a function object's `repr` carries its
    # memory address, and `docs/surface/v0.2-surface.json` renders this
    # dataclass's `__init__` signature — so a plain default would put
    # `<function _minimal_disclosure at 0x…>` in a committed manifest, which is
    # a different document on every run. `dataclasses` renders a factory's
    # default as the stable `<factory>` sentinel.
    # (`tests/test_surface_shape_capture.py::test_the_serialized_manifest_carries_no_memory_addresses`.)
    disclosure_level_for: Callable[
        ..., tuple[DisclosureLevel, ProvenanceSource | None]
    ] = field(default_factory=lambda: _minimal_disclosure)

    def __post_init__(self) -> None:
        # Verified where it is handed over (§1.5c, g): a fabricated,
        # retargeted or wrong-kind capability dies at composition, not at the
        # first denial a bank would rather have had recorded.
        verify(
            self.authorized,
            kind=ReplayMint,
            resource=getattr(self.authorized, "resource", ""),
        )
        # And the store must declare the class, or the first denial would be
        # refused as a wrong-kind write instead of recorded (fail closed at boot).
        _require_declared(self.artifact_store, (self.authorized.resource,))

    @property
    def replay_record_class(self) -> str:
        """The artifact class replay records are filed under — the capability's resource."""
        return self.authorized.resource

    @property
    def tenant_id(self) -> str:
        """The tenant every determination this recorder writes was made under — the capability's."""
        return self.authorized.tenant

    def record(
        self,
        envelope: RefusalEnvelope,
        *,
        perspective: Perspective,
        recorded_at: datetime,
        served_at: datetime | None,
        request: ProductRequest | None = None,
        execution: ExecutionResult | None = None,
        policy_bindings: tuple[PolicyBinding, ...] = (),
        assembler_id: str | None = None,
        assembler_version: str | None = None,
        resolution: EffectiveRequest | ResolutionNotApplicable,
        child_resolutions: tuple[ChildResolution, ...] = (),
        refusal_seam: str = NO_REFUSAL_SEAM,
        subject_withholding: str | None = None,
        agent_conditioning: PerspectiveConditioning | None = None,
    ) -> RefusalEnvelope:
        """Disclose, append the INTERNAL truth, then hand back the shell.

        See :meth:`RefusalRecorderProtocol.record` for the argument contract.
        ``resolution`` is passed through to the builder exactly as received
        and is required here for the reason it is required there
        (24.7-04; ``D-IMPL-264`` amendment 1 (F-3 a), Dave verbatim: *"Any API that
        constructs or delegates construction of a replay record must require
        an explicit resolution state: effective/partial resolution or explicit
        not-applicable marker. No intermediate layer may manufacture the
        marker from omission."*).

        **The order is the architecture** (``D-IMPL-254``). The record is built
        from the **internal** envelope — the determination as the fabric
        reached it, whole — together with the
        :class:`~ccf.products.disclosure.DisclosureDecision` that produced the
        shell; what is returned is the **disclosed** envelope with its address
        attached. So replay reconstructs both *what was determined* and *why
        the consumer saw the particular response it saw*, which is the pair
        ``D-IMPL-254`` requires and which recording only the shell would lose.

        Dave, ``D-IMPL-253`` Q27: *"Don't destroy audit truth merely to achieve
        external suppression silence."* Recording the disclosed form would be
        exactly that.

        There is **one** entry to this seam and there is deliberately no
        disclose-without-recording entry beside it: ``D-IMPL-256`` (1) makes
        every delivery-boundary denial hold an instant, so a caller that wanted
        a disclosed shell without a record would be asking for the replay hole
        the ruling closed. The name that shape would have carried is spelled
        nowhere in ``src/``, so the grep that proves its absence is a clean
        zero (the ``24.6-04`` precedent for a retired identifier). **No caller of this seam calls**
        :func:`~ccf.products.disclosure.disclose` **itself** — the resolver's
        own branches, the governed delivery-boundary step and an assembler's
        wrappers all reach disclosure only through here, so one determination
        cannot be disclosed twice by two readings of the policy.
        """
        # The tenant the determination was made under, with the principal it
        # was made for: a delivery-boundary determination names it on its
        # resource identity; a resolver's own refusal names none and was made
        # under this recorder's tenant (Dave, 2026-10-07; `D-IMPL-378`).
        level, disclosure_policy = self.disclosure_level_for(
            tenant=(
                envelope.resource.tenant_id
                if envelope.resource is not None
                else self.tenant_id
            ),
            principal_id=perspective.principal_id,
        )
        disclosed, decision = disclose(
            envelope, level=level, policy=disclosure_policy
        )
        record = build_replay_record(
            execution=execution,
            product=None,
            refusal=envelope,
            # `D-IMPL-358` step 5. Threaded from the caller and NEVER recomputed
            # here: the recorder reads no clock, so every refusal from one
            # governed invocation carries the one instant that invocation read.
            served_at=served_at,
            # Recorded verbatim: identity is resolved at the door and this seam
            # constructs none of it (Pitfall 3).
            perspective=perspective,
            policy_bindings=(
                *(
                    (self.policy_bundle_pin,)
                    if self.policy_bundle_pin is not None
                    else ()
                ),
                *policy_bindings,
            ),
            assembly_mode=self.assembly_mode,
            recorded_at=recorded_at,
            tenant_id=self.tenant_id,
            assembler_id=assembler_id,
            assembler_version=assembler_version,
            # `CMP-R-01`. One row per DECLARED requirement, refused or not, so
            # a refused composite's record names the children it tried. `()`
            # for every non-composite refusal, which is the true claim rather
            # than a filler — and it is hash-transparent, so no existing
            # record's content address moves.
            child_resolutions=child_resolutions,
            refusal_seam=refusal_seam,
            # Dimension 5's own record of the Disclosure layer, pre-serialized
            # in the SDK's one canonical form — the `hitl_actions` and
            # `workflow_step_sequence` discipline: a block the layer that made
            # the decision produced, recorded verbatim rather than rebuilt here.
            disclosure=canonical_bytes(decision).decode("utf-8"),
            resolution=resolution,
            request=request,
            # Dave's Q11 (`D-IMPL-378`): a refusal that answers a product
            # QUESTION is issued to its caller under a fresh identifier, so its
            # record — and the `replay_reference` the shell carries — is unique
            # per answer and reflects nothing the determination read. A
            # determination with no question (an evidence read, a door-level
            # entitlement denial, an erasure, an absence) read no subject; its
            # record keeps the sentinel and is still named by its own content
            # address, unique per content.
            issuance=new_issuance() if request is not None else None,
            # Dave's Q12 (`D-IMPL-378`): what the deciding class affirms.
            subject_withholding=subject_withholding,
            # `D-IMPL-385`: the composing agent and its in-force skill-set, as
            # the resolver's child resolver serialized them; `None` keeps the
            # no-agent claims, which is the true claim for every decision no
            # agent composed.
            agent_conditioning=agent_conditioning,
        )
        reference = record_refusal(
            record=record,
            replay_writer=ReplayWriter(
                authorized=self.authorized, store=self.artifact_store
            ),
        )
        return disclosed.model_copy(update={"replay_reference": reference.uri})


def _artifact_on(
    fabric: BootedFabric, *, key: str, expected: type[_Artifact]
) -> _Artifact:
    """One parsed artifact off ``fabric``, or a wiring refusal naming both sides.

    The narrowing is not ceremony. A manifest key is a string, and a resolver
    handed the wrong one would otherwise fail somewhere further down with a
    message about a field, at which point the actual defect — this key names
    that artifact — is two layers away from what is reported.

    Module-level rather than a method because
    :func:`build_governed_resolver` needs the identical check *before* a
    resolver exists, and the manifest read staying in **one** place is what
    ``17-11`` deferred to this plan.

    Raises:
        ProductNotResolvable: the key names no artifact, or names one of
            another class. A broken deployment, so an exception rather than a
            governed "no" — the distinction :class:`ProductNotResolvable` draws
            for itself.
    """
    try:
        artifact = fabric.artifacts[key]
    except KeyError as absent:
        raise ProductNotResolvable(
            f"manifest key {key!r} names no artifact on the booted fabric;"
            f" the manifest declares {sorted(fabric.artifacts)}"
        ) from absent
    if not isinstance(artifact, expected):
        raise ProductNotResolvable(
            f"manifest key {key!r} holds {type(artifact).__name__}, and this"
            f" resolver reads it as {expected.__name__}"
        )
    return artifact


def _refuse_unbindable_request_parameter(
    *,
    parameters: Mapping[str, OperatorParametersArtifact],
    declared: ProductRequestContract | None,
    request_contract_key: str,
) -> None:
    """Raise unless every request-bound operator parameter names a declared argument.

    ``24.11-04`` / ``D-IMPL-295``, in
    :func:`~ccf.products.request.refuse_undeclared_class_default`'s shape and
    for its reason: a binding naming a parameter the request contract does not
    expose is a **malformed declaration**, and it should fail where the two
    documents disagree rather than three frames down on the first call that
    happens to exercise it.

    **Existence only, and the narrowness is deliberate.** This asks whether the
    contract declares the name; it says nothing about the value's type. Judging
    the type here would mean comparing a JSON-Schema ``type`` against a Python
    field annotation — a second type system, kept in step with the first by
    hand, disagreeing with it the first time either moves. The artifact's own
    validation already settles the type when the value arrives
    (:meth:`GovernedResolver._bind_declared_request_values` revalidates), so
    there is exactly one authority on the question and it is the field itself.

    A deployment naming no request contract is not checked: it has no
    declaration for a binding to disagree with, and the resolution path refuses
    the binding when the value fails to arrive.

    Raises:
        ProductNotResolvable: a binding names an argument the contract does not
            declare, naming the operator key, the field, the parameter and the
            arguments the contract does expose.
    """
    if declared is None:
        return
    exposed = set(declared.arguments.properties)
    for key, artifact in sorted(parameters.items()):
        for name, value in artifact:
            if not isinstance(value, RequestBoundParameter):
                continue
            if value.parameter not in exposed:
                raise ProductNotResolvable(
                    f"operator parameters {key!r} bind {name!r} to request"
                    f" parameter {value.parameter!r}, which the request"
                    f" contract {request_contract_key!r} does not declare;"
                    f" it exposes {sorted(exposed)}. A binding and the contract"
                    " it binds to are one declaration in two documents, and"
                    " they disagree (D-IMPL-295)"
                )


def _request_contract_on(
    fabric: BootedFabric, *, key: str
) -> ProductRequestContract:
    """One request contract off ``fabric``, however the manifest authored it.

    Module-level for :func:`_artifact_on`'s reason, which
    :func:`build_governed_resolver` now needs a second time: the
    ``D-IMPL-258`` (5) check runs at boot, *before* a resolver exists, and it
    must read the contract exactly as :meth:`GovernedResolver._request_contract`
    will read it at request time. Two transcriptions of one manifest key are
    two chances to disagree about what a class's request surface is, and the
    check whose whole subject is that surface is the worst place to disagree.

    Raises:
        ProductNotResolvable: the key names no artifact, or names one that is
            neither a declared artifact nor a request contract.
    """
    artifact = fabric.artifacts.get(key)
    if isinstance(artifact, DeclaredArtifact):
        return ProductRequestContract.from_declared(artifact)
    return _artifact_on(fabric, key=key, expected=ProductRequestContract)


def _capabilities_of(fabric: BootedFabric) -> tuple[TechnicalCapability, ...]:
    """The technical limits the booted fabric can be asked for, if any.

    ``D-IMPL-253`` Q21. Structural, on the
    :class:`~ccf.graph.protocols.SnapshotPinnable` idiom: whatever the boot
    handed back is *asked* whether it reports a traversal ceiling, and a
    substrate that reports none contributes nothing — no flag, no stub, and no
    number invented on its behalf.

    **What this reaches today, measured rather than assumed.**
    :class:`~ccf.boot.FabricHandle` exposes a *reader*, and the two ceilinged
    backends declare their bound on the *store*, which the handle deliberately
    does not carry. So for every shipped boot path this derives the empty tuple
    — the honest answer, since nothing the resolver is handed can report a
    ceiling — and a deployment that holds its store passes ``capabilities``
    explicitly to :func:`build_governed_resolver` or to
    :class:`GovernedResolver`. The walk is written over both objects so that a
    handle or reader which later reports one is picked up with no edit here.

    Duplicate identities are collapsed, so a handle and its reader that are the
    same object — or two objects reporting one substrate — contribute one bound
    rather than two identical ones.
    """
    found: dict[tuple[str, str], TechnicalCapability] = {}
    for candidate in (fabric.handle, getattr(fabric.handle, "reader", None)):
        if not isinstance(candidate, TraversalDepthCapability):
            continue
        capability = TechnicalCapability(
            capability=CAPABILITY_TRAVERSAL_DEPTH,
            maximum=Decimal(candidate.max_traversal_depth),
            identity=candidate.capability_identity,
        )
        found.setdefault(
            (capability.capability, capability.identity), capability
        )
    return tuple(found[key] for key in sorted(found))



def _utc_now() -> datetime:
    """The process's UTC clock.

    The default for :func:`build_governed_resolver`'s ``admission_clock``
    (`D-IMPL-336` **O3**), and the same one-line shape
    :mod:`ccf.controlplane.registry` already uses for the same reason: the
    machinery takes a clock so a test can pin an instant, and exactly one
    place names the real one.
    """
    return datetime.now(UTC)


@dataclass(frozen=True, kw_only=True)
class GovernedResolver:
    """The SDK's reference composition: assemble → gate → record → serve.

    **A reference implementation a deployment instantiates and supplies, never
    a resolver the SDK invokes on its own authority.** It carries exactly the
    privileged status :class:`~ccf.agents.assembler.DeterministicAssembler`
    carries against its own Protocol, which is none: conformance is structural,
    the SDK calls nothing here by itself, and a deployment substituting its own
    resolver loses no capability.

    **Every value this composition needs that the SDK cannot know arrives from
    outside it, and nothing has a default.** That is the constraint Amendment 1
    §B attaches to the ruling and the reason this module is allowed to exist at
    all: the composition is *mechanism* — an ordering, and the gate and replay
    obligations along it — while every threshold, class name, policy key, TTL
    figure, operator parameter set and artifact-class token stays a Control
    Plane artifact or a constructor argument the deployment authored. A
    defaulted TTL, a defaulted product class or a defaulted threshold here
    would be a defect of the same severity as a half-life table in library
    code (CLAUDE.md §6.4).

    ``kw_only=True`` for the reason the Protocol is keyword-only: several
    arguments are same-typed strings, and a transposition would resolve a
    different artifact without failing.

    **What arrives as a manifest key rather than as an object.** Five — the
    product class, the request contract, the operator parameter sets, the
    policy bundle and the debt profile — are named by *key* and read off
    :attr:`~ccf.deployment.BootedFabric.artifacts`. That is
    :func:`~ccf.deployment.load_and_boot`'s own recommended idiom, and it buys
    a governance property a passed object cannot: the declaration this resolver
    serves is provably the one the manifest put in force, rather than one a
    caller assembled beside it. A key holding the wrong artifact class is a
    wiring defect and is refused on the first call, naming both sides.

    **What deliberately stays a constructor argument.** The projection factory
    and the debt scorer are behavior rather than declaration and have no
    artifact form — so they are *supplied*, and neither is defaulted here; a
    deployment that wants the SDK to choose its scorer calls
    :func:`build_governed_resolver`, which is where the choosing lives. The
    two differ in what a deployment can supply: the SDK ships
    :class:`~ccf.products.debt_scorer.AssemblyDebtScorer` for the second and
    ships nothing for the first, because Amendment A.1 of the 2026-08-16 spec
    ruled a reference plan factory impossible as scoped — a
    :class:`~ccf.projection.plan.ProjectionPlan` is itself a Protocol, no
    declarative plan artifact exists, and mapping operator outputs onto a
    declared payload shape is invention rather than mapping. The
    artifact store is a substrate, not Control Plane state. The two
    artifact-class tokens are deployment vocabulary, exactly as
    :class:`~ccf.replay.serve.ReplayWriter` already treats its own. And the two
    TTL figures **stay two**: the class's ceiling is registered here to mint
    its pin, and the product's own lifetime is authored separately, because a
    single figure serving as both would have Gate 3 compare a ceiling against
    itself — the failure :func:`~ccf.deployment.load_and_boot` warns about in
    its own docstring.

    **What this composition does not do, and will not learn to.** It hands no
    envelope to the L1 writer, creates no store, mints no schema and boots
    nothing: the deployment it is handed is already booted and already
    populated. A resolver that provisioned would make a client call a
    producer-side act, which is the boundary the client design draws in its §7,
    and it would need a write handle to the graph — which this type is
    constructed without and cannot obtain (single-writer, CLAUDE.md §10). The
    absence is structural rather than described: nothing below reaches
    ``fabric.handle.worker``.

    **What it cannot serve yet, measured against the SDK's own worked example**
    (``24.10-04`` / ``R-03``; ``D-IMPL-282``). That ruling opened
    ``examples/s1-01-hello-context-product/spine.py`` so that *"can an author
    reach this composition?"* could be answered by trying rather than by
    asserting. It was tried, against a live substrate, and **it could not**.
    Four seams were absent; each carries an executable test in
    ``tests/examples/test_s1_01_governed_resolver_adoption.py``, and none of
    them is a defect in the example. **Two — ``24.10-F-06`` and ``24.10-F-07``
    — are closed as of ``24.11-02b``; two remain.** The closed ones are kept in
    this roster rather than deleted from it, because what a composition *used
    to* get wrong is what says why the line that fixes it is load-bearing:

    ``24.10-F-06`` — **CLOSED in two parts, ``24.11-02`` then ``24.11-02b``**
        A product class whose operator set included the **Similarity**
        category — one of whitepaper §7.4's four — could not be served at all.
        :func:`~ccf.deployment.build_operator_registry` was called below with
        no ``similarity_index_version``, which that builder then required
        exactly when a similarity artifact was present (``D-IMPL-38``, and
        rightly: an unversioned index is one replay cannot be held against).
        There was no field here and no argument on
        :func:`build_governed_resolver`, and the registry is built inside
        :meth:`__call__` — so a deployment had nowhere to supply it, and every
        such call died three frames below a composition it had no way to
        configure.

        ``24.11-02`` fixed the propagation by giving this class a
        deployment-owned ``similarity_index_version`` field. **That closed the
        runtime seam and left the architecture open**, and Dave ruled it
        insufficient (``D-IMPL-292``): *"the deployment still has to tell the
        resolver something that materially affects operator behavior and
        reproducibility … it must not remain an ungoverned deployment-supplied
        semantic value."* A workaround relocated from test code into caller
        code is still a workaround (``D-IMPL-289``).

        **``24.11-02b`` moved the authority to the declaration**, and there is
        consequently *nothing here* to see: the field is gone, the argument on
        :func:`build_governed_resolver` is gone, and this class passes no
        version to the builder. The value is declared on
        :class:`~ccf.controlplane.artifacts.SimilaritySelectParametersArtifact`
        — an artifact this resolver already loads by manifest key, already
        hands the builder, and whose content hash is already in the pin set —
        so the corpus identity a determination ranked against is now visible in
        replay dimension 2 where it previously appeared nowhere. Dave's
        authority model, verbatim: *"declaration owns the version → resolver
        consumes it → deployment supplies the implementation, not an alternate
        semantic version."* One site, not a precedence order. Regressed
        directly at ``tests/products/test_resolver_seam.py::
        test_the_declared_index_version_is_the_only_authority``.
    ``24.10-F-07`` — **CLOSED, ``24.11-01``**
        :meth:`__call__` executed Π with **no seeds**, while
        :mod:`ccf.replay.engine` replays with
        ``seeds=``:func:`~ccf.products.request.request_seeds`. Two questions
        about two different subjects therefore compiled to the same graph query
        and pinned identically — ``DI-15.5-07``, which ``D-IMPL-111`` limb (a)
        closed on the hand-built path — and a served product whose plan walks
        was replay-divergent by construction. :meth:`__call__` now passes
        ``seeds=request_seeds(request)``, derived from the **caller's**
        request: the same object it hands
        :func:`~ccf.replay.record.build_replay_record`, which dimension 5
        carries verbatim and :mod:`ccf.replay.engine` reads back — so the two
        paths are one reading of one object rather than two derivations that
        could drift. Regressed directly at ``tests/products/
        test_resolver_seam.py::
        test_two_subjects_cannot_collapse_to_one_question_to_the_graph``.
    ``24.10-F-08`` — **obligation limb CLOSED at** ``24.11-03``
        The candidate below set none of ``obligation_in_force``,
        ``source_refresh_recency`` or ``debt_evidence``. All three are inside
        the product's content address, so none is an omission a deployment can
        repair afterwards. ``24.11-03`` closed the first: the candidate now
        composes :meth:`_obligation_in_force`, which reads the profile named by
        :attr:`debt_profile_key` and asks it what it binds to the state the
        assessment landed in. Two changes carried it, and the second was the
        one the probe found — :func:`build_governed_resolver` had treated the
        profile key as scorer material *only*, so a deployment supplying its
        own scorer could not declare its bands at all and could never carry an
        obligation. Regressed at ``tests/products/test_resolver_seam.py::
        test_the_served_product_carries_the_obligation_the_profile_bound``
        with its negative control beside it, and the ``s1-01`` adoption test
        that carried this finding is un-quarantined and passing unchanged.

        **The other two limbs stay open, and neither is a dropped join.**
        Measured at ``24.11-03``: nothing in ``src/`` or ``runtime/``
        constructs a :class:`~ccf.halflife.assessment.SourceRefreshWindow` or a
        :class:`~ccf.halflife.assessment.DebtEvidencePointer`, and no SDK
        artifact declares either — so composing them is not a join the resolver
        drops but an authority the SDK does not have. For source-refresh
        recency that absence is *ruled* (``D-IMPL-124``: the SDK ships no
        reducer, because one would decide which of a deployment's sources count
        toward the window). For evidence pointers it is a standing prohibition
        (``D-IMPL-119`` limb 4) whose named precondition — a perspective-scoped
        view in the assembly path — this path still does not meet. Giving
        either a declaration home is an architecture question and is not this
        row's.
    ``24.10-F-09``
        ``expires_at``, the gate instant and ``recorded_at`` all derive from
        ``request.asked_at``, so a class declaring a **decision instant**
        distinct from the graph boundary finds nothing reads it.

    What remains is recorded here rather than fixed here. ``D-IMPL-282``:
    *"No broader API redesign is authorized up front"* — the escalation it
    earns is Dave's ruling to make, and the tests are what go loudly red when a
    seam lands without its finding being closed. ``F-07``, ``F-06`` and
    ``F-08``'s obligation limb are the three that have had that ruling
    (``D-IMPL-290``, ``D-IMPL-291``, ``D-IMPL-292``), and each was taken
    **alone**: one repair per row, so that what a row moved stays attributable
    to what a row changed.

    Attributes:
        fabric: The booted deployment, exactly as
            :func:`~ccf.deployment.load_and_boot` returned it — so an adopter
            hands back what they were given rather than unpacking it. Supplies
            the L3 **reader** (never a writer: single-writer holds across this
            seam by construction, CLAUDE.md §10), the resolved pins, the tenant
            and the parsed artifacts.
        control_plane: The Control Plane the fabric booted against. A caller
            argument and never constructed here, on
            :func:`~ccf.deployment.load_and_boot`'s own reasoning: a registry
            built behind the adopter's back would split the audit sequence in
            two, and the Control Plane is the audit plane, singular.
        product_class_key: Manifest key of the
            :class:`~ccf.controlplane.artifacts.ProductClassDeclaration` this
            resolver serves.
        request_contract_key: Manifest key of the request surface that class
            declares. Read as a :class:`~ccf.products.request.ProductRequestContract`,
            or through :meth:`~ccf.products.request.ProductRequestContract.from_declared`
            when the manifest authored it in an adopter namespace — which is the
            ordinary case, and the transcription ``D-IMPL-126`` exists to spare
            every adopter.
        operator_parameter_keys: Manifest keys of the operator-parameters
            artifacts this deployment declared — **however many**. One yields a
            one-operator registry; this resolver holds no fixed set of four
            keys and never counts them (``D-IMPL-132``).

            **A similarity artifact named here carries its own corpus version
            identity** and needs no companion field (``24.11-02b`` /
            ``D-IMPL-292``; see ``24.10-F-06`` above). This class holds no
            ``similarity_index_version``: the artifact these keys resolve to is
            handed to :func:`~ccf.deployment.build_operator_registry`, and the
            builder reads
            :attr:`~ccf.controlplane.artifacts.SimilaritySelectParametersArtifact.index_version`
            off it. A field here would be a second site for one semantic value,
            and a deployment able to state a version other than the one it
            declared is a deployment able to make its own determination
            irreproducible.
        policy_bundle_key: The key whose pinned version becomes the admitted
            bundle version and the product's policy binding.
        debt_profile_key: Manifest key of this deployment's ``D_c`` bands, whose
            ``signal_obligations`` bind the obligation the served product
            carries (``24.11-03``, ``24.10-F-08``). ``None`` is admissible and
            is the positive claim that this deployment declares no bands — never
            a default, for every other field's reason. **Independent of**
            ``debt_scorer``: a deployment that scores for itself may still
            declare its bands, because ``D-IMPL-118`` gave the obligation its
            own identity on the vessel rather than making it a rider on debt.
        plan_factory: How this deployment builds Π for one question.
        constraint_resolver: How this deployment resolves a question's
            parameters against every authority that bounds them — the class's
            declared defaults, the caller's values, the Control Plane's policy
            constraints in force at ``asked_at``, and the substrate's technical
            capabilities (``D-IMPL-253`` Q8). No default here for the reason
            ``debt_scorer`` has none: this class is the auditable, defaultless
            composition, and :func:`build_governed_resolver` is where the SDK's
            own :class:`~ccf.products.constraints.ReferencePolicyConstraintResolver`
            is chosen.
        capabilities: The technical limits in force, read off the substrate by
            whoever wired this resolver. Supplied rather than discovered here,
            because the fabric hands back a *reader* and the ceiling is a
            property of the *store* — and because a resolver that went looking
            for capabilities would be deciding, on its own authority, which
            substrate facts govern a question. The empty tuple is the positive
            statement that no technical bound applies, which is every
            deployment on a store that declares none.
        debt_scorer: How this deployment measures ``D_c`` over an assembly.
            :class:`~ccf.products.debt_scorer.AssemblyDebtScorer` is the shipped
            reference, and **it is what** :func:`build_governed_resolver`
            **selects when no scorer is passed** — a deployment reaching the
            fabric through that helper never names it and never has to know the
            Protocol exists. Supplying it *here* is the deployment's act, never
            this class's, which is why the field has no default: this class is
            the auditable, defaultless composition, and the helper is where the
            SDK's own reference is chosen. See the module docstring for the
            measurement that split them.
        product_gate: The deployment's own implementation of the invariant its
            product class DECLARES, or ``None`` when the class declares none
            (``24.10-02`` / ``R-11``; ``D-IMPL-282`` option 1a). Written in
            ``debt_scorer``'s voice and for its reason: the SDK ships the
            machinery and never the values, and here the value is the invariant
            itself. What it may say is bounded — a violation string or
            ``None`` — because the gate's IDENTITY is the Control Plane's
            (:attr:`~ccf.controlplane.artifacts.ProductClassDeclaration.declared_product_gate`)
            and this class stamps it onto the refusal rather than accepting it
            from the callable.

            **The two halves must agree, and** :func:`build_governed_resolver`
            **refuses at build time when they do not**: a callable against a
            class declaring no gate is a check nothing governs, and a declared
            gate with no callable is *"a default that nothing exercises*, which
            *is a check that stops checking without going red."* No default
            here, for ``debt_scorer``'s reason — ``None`` is a value the
            deployment states, not one this class assumes.
        refusal_recorder: The ONE seam through which every governed refusal
            this composition produces reaches the replay writer
            (``24.6-07``; ``D-IMPL-253`` Q13, ``D-IMPL-256``). No default here
            for ``debt_scorer``'s reason — this class is the auditable,
            defaultless composition, and :func:`build_governed_resolver` is
            where the SDK's own :class:`ReplayRefusalRecorder` is chosen over
            the store and tenant this resolver was already handed.

            It is a **field** and not a method because three other callers mint
            through it: the governed delivery-boundary step every entitling
            door calls, and an assembler's own wrappers. One resolver, one
            recorder, one writer, one store — which is what makes *"no second
            writer"* a fact about the wiring rather than a rule people follow.
        artifact_store: Where the replay record and the executed queries' bytes
            land. A substrate reached *through* this mechanism, never a second
            writer to the graph (CLAUDE.md §7.4).
        replay_record_class: The artifact class replay records are filed under.
        query_pin_class: The artifact class executed queries' bytes are filed
            under.
        max_ttl_seconds: The class's TTL **ceiling**. Registering it is what
            mints ``max_ttl_version``, which is why the class document cannot
            declare it.
        product_ttl_seconds: How long a product this resolver serves stays
            servable. Independent of the ceiling by construction; Gate 3
            compares the two.
    """

    fabric: BootedFabric
    control_plane: ControlPlaneProtocol
    product_class_key: str
    request_contract_key: str
    operator_parameter_keys: tuple[str, ...]
    policy_bundle_key: str
    debt_profile_key: str | None
    plan_factory: ProjectionPlanFactoryProtocol
    debt_scorer: AssemblyDebtScorerProtocol
    product_gate: ProductGateProtocol | None
    constraint_resolver: PolicyConstraintResolver
    capabilities: tuple[TechnicalCapability, ...]
    refusal_recorder: RefusalRecorderProtocol
    artifact_store: ArtifactStoreProtocol
    replay_record_class: str
    query_pin_class: str
    max_ttl_seconds: int
    product_ttl_seconds: int
    #: D-IMPL-354 — the capabilities THIS composition minted for its own
    #: writes, at construction (:meth:`__post_init__`), and holds for its
    #: life. Not constructor arguments, deliberately: the resolver's
    #: constructor and factories ARE the resolver's composition (this module
    #: is a `COMPOSITION_MINT_SITES` root), so every existing construction
    #: site keeps working with no new parameter, and no caller of a resolver
    #: becomes a minter. The alternative — authorities as constructor
    #: parameters — was rejected for exactly that reason. Three `ReplayMint`,
    #: one per evidence class the resolver files (records, query pins,
    #: admitted child contracts), and two `Register`, one per Control Plane
    #: key `_register` opens (the class's MAX_TTL and its request contract).
    #: `init=False`: not a parameter of any signature, so nothing can omit it
    #: or pass a substitute; set exactly once below.
    _authorities: _ComposedAuthorities = field(init=False, repr=False, compare=False)
    #: SEC-020 Q8 (`D-IMPL-378`): the early policy the plan factory declared,
    #: read once at construction (:meth:`__post_init__`); ``None`` when it
    #: declared none. `init=False`, set exactly once below.
    _disclosure: SubjectDisclosurePolicy | None = field(init=False, repr=False, compare=False)
    #: §7.10.4's Mode 2 footprint — how this deployment reports what its
    #: packaging stage did. ``None`` for every Mode 1 deployment, which is
    #: every one shipped before `dr-02`, and the no-packaging sentinel is then
    #: dimension 3's true claim rather than a gap.
    #:
    #: **No default**, like every other argument here: a deployment states
    #: what it supplies, including when it supplies nothing. A default would
    #: make "this deployment does no packaging" and "nobody thought about
    #: packaging" the same construction, and `PKG-F-08` is what that costs —
    #: a Mode 2 product filed `no-packaging` on every pin for a whole rung.
    packaging_trace: PackagingTraceProtocol | None
    #: `D-IMPL-336` Amendment 3, F0 — how this deployment resolves, invokes,
    #: delivers and admits the children a composite class declares. ``None``
    #: for every non-composite deployment, which is every one shipped before
    #: this surface; a class that declares ``requires`` against a resolver
    #: with no child resolver is REFUSED rather than served without them.
    #:
    #: The SDK ships the Protocol **and** a reference implementation —
    #: :class:`~ccf.products.child_resolver.GrantBoundChildResolver` — under
    #: CLAUDE.md §11. This comment said the opposite until close panel 2; the
    #: correction is `D-IMPL-336` Amendment 5, which ruled that resolving a
    #: grant and dispatching it once is not an agent loop. What stays out of
    #: `src/` is the scheduler, the swarm loop and any new identity axis.
    composite_children: (
        CompositeChildResolverProtocol | RequestAwareChildResolverProtocol | None
    )

    #: `D-IMPL-336` **O3** — the trusted runtime clock a child admission is
    #: judged against.
    #:
    #: Admission time is **not** the decision instant. `D-IMPL-308` lets a
    #: class declare its decision instant from the request, which is right for
    #: expiry — a reconstruction of a historical decision expires from when
    #: that decision was produced. It is wrong for eligibility: `F7`'s
    #: evidence-age bound asks *how old is this evidence NOW*, and answering it
    #: with a declared historical instant lets a request move the window its
    #: own evidence is checked in. The earlier behavior was conservative in
    #: practice — the skew check refused rather than admitted — but a check
    #: whose safety depends on which way the caller's declared instant happens
    #: to fall is not a check.
    #:
    #: Injected rather than read from the wall clock here, so the boundary is
    #: testable exactly; the default lives in
    #: :func:`build_governed_resolver`, never on this class, which permits no
    #: constructor defaults at all.
    admission_clock: Callable[[], datetime]

    #: The request-contract argument that carries this class's DECISION
    #: INSTANT, or ``None`` when the class declares none — `24.10-F-09`,
    #: `D-IMPL-308`.
    #:
    #: **The graph boundary and the decision instant are two different facts**
    #: and this resolver used to have only one. ``request.asked_at`` is *when
    #: the graph is observed*; the decision instant is *when the answer is
    #: produced*, and a class may legitimately declare them apart — `s1-01`
    #: declares a boundary of ``00:00``, a decision instant of ``00:05`` and an
    #: expiry of ``00:15``, and proves by that spread that nothing in the path
    #: reads a clock.
    #:
    #: **Coincidence is allowed; collapse is not** (`D-IMPL-308`). A class
    #: declaring no such parameter leaves this ``None`` and every instant
    #: continues to derive from ``asked_at``, which is what
    #: `s1-00-companies-over-revenue` legitimately does. What this forbids is
    #: substituting one for the other when the class says they differ.
    decision_instant_parameter: str | None

    #: When this deployment's sources last published — `24.10-F-08`,
    #: `D-IMPL-308`.
    #:
    #: **Declaration-owned evidence, and it is inside the content address.** A
    #: refresh window is a fact about the world upstream of the fabric: the
    #: deployment knows it and no operator can observe it, which is why it
    #: arrives here as a declared value rather than being derived from the
    #: view. The candidate below used to set nothing, so a deployment that
    #: declared a window watched the canonical path drop it silently — and
    #: because the field is sealed, that is not an omission a deployment can
    #: repair afterwards.
    source_refresh_recency: SourceRefreshRecency

    #: `D-IMPL-343` R-4 — the declared acquisition boundary, or ``None`` for a
    #: deployment whose fabric is populated before this resolver is reached
    #: (every deployment shipped before the seam existed, and every hw1-shaped
    #: long-lived fabric). When present it is called ONCE per question for the
    #: question's subject, with the EFFECTIVE request, between resolution and
    #: the graph read — and, for a class that may withhold and declares no early
    #: policy, once more immediately before that, for the P6 probe only
    #: (:data:`UNHELD_SUBJECT_PROBE`; Q10 as amended by ruling P6 (a)); for a
    #: class with a declared early policy, twice more immediately before that,
    #: with :data:`UNHELD_SUBJECT_PROBE` and then the declared stand-in (Q10 as
    #: amended by decision 4 (a), :class:`UndisclosedSubjectSubstituteIsHeld`) — see
    #: :class:`AcquisitionSeamProtocol` for what it is and is not. No default
    #: here for the class's own reason; :func:`build_governed_resolver`
    #: defaults it to ``None``.
    acquisition: AcquisitionSeamProtocol | None
    #: SEC-020 Q7 (`D-IMPL-378`): the declared population phase — the
    #: subject-independent half of the question's acquisition, invoked once per
    #: question before the subject-keyed ``acquisition`` and handed no subject
    #: (:class:`PopulationAcquisitionSeamProtocol`). ``None`` is admissible and
    #: POSITIVE — this deployment declares no population phase — but never a
    #: default, on ``acquisition``'s own terms.
    population_acquisition: PopulationAcquisitionSeamProtocol | None
    # `D-IMPL-341`: the manifest key of this deployment's λ_c table, when it
    # has one. Read at the mint to derive an evidence-anchored expiry from the
    # same observations the freshness factor scores, and pinned on the record
    # for such a serve so replay re-derives the anchor under the same table.
    # ``None`` for a resolver wired without a table — an evidence-anchored
    # class then refuses by name at gate 3 rather than anchoring on anything.
    half_life_key: str | None

    def __post_init__(self) -> None:
        """Compose: refuse an undeclared store, then mint this resolver's own authorities (D-IMPL-354).

        Order is the order of refusals a deployment should meet at boot rather
        than at its first question: the store's :class:`~ccf.artifacts.protocol.WriteKinds`
        must name the three classes this resolver files under ``ReplayMint``
        (:class:`UndeclaredMechanismClass` otherwise — fail closed at boot,
        never at the first write); then five capabilities are minted through
        the composition recipe, each audited on the Control Plane's own log,
        for exactly the class or key each will open; then the request contract
        is registered under the capability minted for its key (``D-IMPL-378``
        R-A), so a process that builds this resolver can replay the records
        that pin it before it answers anything. The clock those audit
        events carry is the process clock at composition — never
        ``admission_clock``, which the serve path reads exactly once per
        admission and which nothing at construction may consume.
        """
        _require_declared(
            self.artifact_store,
            (self.replay_record_class, self.query_pin_class, ADMITTED_CHILD_CONTRACT_CLASS),
        )
        # Dave's E2 (iii) (`D-IMPL-378`): a recorder `_record_refusal` could not
        # pass `subject_withholding=` is refused here, not at the first refusal.
        refuse_incompatible_refusal_recorder(self.refusal_recorder, builder="GovernedResolver")
        # `D-IMPL-385`: a recorder that cannot be passed the composing agent's
        # conditioning is refused here when the child resolver can supply one,
        # rather than raising at the first refusal an agent composed.
        children: object = self.composite_children
        if isinstance(children, AgentConditionedChildResolverProtocol):
            refuse_incompatible_refusal_recorder(
                self.refusal_recorder, builder="GovernedResolver", keyword="agent_conditioning"
            )
        # SEC-020 Q7 (`D-IMPL-378`): an unsupported combination of the two
        # declared acquisition phases is refused here, at construction.
        if self.population_acquisition is not None and self.acquisition is not None:
            _refuse_shared_owner(self.population_acquisition, self.acquisition)
        # SEC-020 P4 (a) made strict (`D-IMPL-378`): an acquisition phase over a
        # store with no path, which no boot can make a question fabric, is
        # refused here, before any question runs.
        if (
            self.acquisition is not None or self.population_acquisition is not None
        ) and self.fabric.store_creation == "unverifiable":
            raise AcquisitionOverUnverifiableStore(
                "this resolver declares an acquisition phase over a fabric whose"
                " store the SDK cannot verify fresh — its adapter's connection"
                " names no path, so no boot can make it a question fabric, and"
                " every question would be refused; compose this store without an"
                " acquisition phase, or acquire into a file-backed question"
                " fabric (SEC-020, P4)"
            )
        tenant = self.fabric.tenant_id
        declaration = self._declaration()
        # SEC-020 Q8 (`D-IMPL-378`): the early policy, read ONCE here, and the
        # composite combinations it cannot support, refused here.
        disclosure: SubjectDisclosurePolicy | None = None
        discloses = False
        if isinstance(self.plan_factory, SubjectDisclosingPlanFactoryProtocol):
            discloses = True
            disclosure = self.plan_factory.subject_disclosure()
            if disclosure is not None and not isinstance(disclosure, SubjectDisclosurePolicy):
                raise TypeError(
                    "a plan factory's subject_disclosure() returns a"
                    " SubjectDisclosurePolicy or None (SEC-020, Q8); got"
                    f" {type(disclosure).__name__}"
                )
            # Dave's E2 (ii) (`D-IMPL-378`, 2026-10-08 12:29 MST): a class
            # affirming `never` over a factory that declares it withholds is
            # refused here, before Q8's composite rules name anything else.
            _refuse_a_never_class_whose_projection_can_withhold(
                declaration=declaration, disclosure=disclosure
            )
        # Dave's E2 (ii), option (d) (`D-IMPL-378`, 2026-10-08 16:40 MST): a
        # class affirming `never` over a factory that does not positively
        # declare it never withholds — silence included — is refused here, after
        # a declared capability is named and before Q8's composite rules.
        _refuse_a_never_class_without_a_positive_declaration(
            declaration=declaration, plan_factory=self.plan_factory
        )
        if discloses:
            if declaration.requires and disclosure is None:
                raise CompositeNeedsAnEarlyPolicy(
                    f"class {declaration.schema_name!r} composes children and its"
                    " plan factory declares it withholds subjects with no early"
                    " policy; a composite asks its children before its plan runs,"
                    " so it withholds only through a declared early policy"
                    " (SEC-020, Q8)"
                )
            if (
                declaration.requires
                and disclosure is not None
                and not isinstance(self.composite_children, RequestAwareChildResolverProtocol)
            ):
                raise EarlyPolicyNeedsRequestAwareChildren(
                    f"class {declaration.schema_name!r} withholds early, and its"
                    " child resolver is never handed the request, so its children"
                    " could not be asked about the undisclosed subject in place of"
                    " the withheld one (SEC-020, Q8)"
                )
        object.__setattr__(self, "_disclosure", disclosure)
        # Dave's Q12 (`D-IMPL-378`): a tenant may list for owner read-back only a
        # class that affirms its answers never withhold their subject.
        _refuse_a_listed_class_that_may_withhold(
            control_plane=self.control_plane, tenant=tenant, declaration=declaration
        )
        # `D-IMPL-378` P2 (c), ruled 2026-10-08 12:29 MST: a composite
        # states its withholding stance here — an early policy, or its class's
        # affirmation that it never withholds — or it is refused, before any
        # question, so the refusal cannot depend on a subject.
        if (
            declaration.requires
            and disclosure is None
            and declaration.subject_withholding != SUBJECT_WITHHOLDING_NEVER
        ):
            raise CompositeNeedsAWithholdingStance(
                f"class {declaration.schema_name!r} composes children and declares no"
                " withholding stance: neither an early policy (its plan factory's"
                " subject_disclosure(), SubjectDisclosingPlanFactoryProtocol) nor"
                f" subject_withholding: {SUBJECT_WITHHOLDING_NEVER!r} on the class; a"
                " composite asks its children before its plan runs, so a withhold"
                " decided inside its projection would be decided too late and for the"
                " withheld subject only (SEC-020; D-IMPL-378 P2 (c))"
            )
        minted = _ComposedAuthorities(
            replay=_mint_replay_at_composition(
                self.control_plane, tenant=tenant, artifact_class=self.replay_record_class
            ),
            query_pin=_mint_replay_at_composition(
                self.control_plane, tenant=tenant, artifact_class=self.query_pin_class
            ),
            admitted_child=_mint_replay_at_composition(
                self.control_plane, tenant=tenant, artifact_class=ADMITTED_CHILD_CONTRACT_CLASS
            ),
            max_ttl=_mint_register_at_composition(
                self.control_plane, key=declaration.max_ttl_key
            ),
            request_contract=_mint_register_at_composition(
                self.control_plane, key=self.request_contract_key
            ),
        )
        # Frozen dataclass: the one sanctioned way to set a field from
        # `__post_init__`; the field is `init=False` and exists for nothing
        # but this.
        object.__setattr__(self, "_authorities", minted)
        # `D-IMPL-378` R-A (b) (Dave, 2026-10-08): THE REQUEST SURFACE IS
        # REGISTERED WHEN THE RESOLVER IS BUILT, so any process that builds
        # this deployment's resolver — a transport's boot, a replay
        # environment — can replay the deployment's earlier records, served or
        # refused, before it has answered a question. The Control Plane is
        # in-process: a new process holds only what it registered itself, and
        # a boot registers no typed request contract. Content-addressed and
        # idempotent: the version minted is the content address of the
        # contract this fabric holds, which is the version every record decided
        # under that contract pins (`D-IMPL-310`); a changed contract mints a
        # different version, and a record pinning the old one still fails
        # replay by name. `__call__` registers it again before the resolution
        # that pins it (`CP17-F-09`).
        self.control_plane.register(
            minted.request_contract, self._request_contract(declaration)
        )

    def _decision_instant(
        self, request: ProductRequest, effective_request: ProductRequest
    ) -> datetime:
        """When the answer is produced, as the class declares it.

        Read off the EFFECTIVE request, so a decision instant supplied by a
        default or narrowed by policy is the one that governs — the same
        authority chain every other argument travels.

        Falls back to ``request.asked_at`` when the class declares no such
        parameter, which keeps every existing deployment on the behavior it
        already had. The parse is the SDK's for `D-IMPL-302`'s reason: the
        party holding the declaration is the party that converts it.
        """
        if self.decision_instant_parameter is None:
            return request.asked_at
        declared = effective_request.parameters.get(self.decision_instant_parameter)
        if declared is None:
            return request.asked_at
        if isinstance(declared, datetime):
            return declared
        return datetime.fromisoformat(str(declared).replace("Z", "+00:00"))

    def __call__(
        self,
        *,
        tenant: str,
        product_class: str,
        version: str,
        perspective: Perspective,
        request: ProductRequest | None,
    ) -> ResolverOutcome:
        """Answer one question end to end, or return the refusal that stands.

        The ordering is the mechanism, and each step is where it is for a
        reason the composition would lose if it moved:

        1. **The address is checked first.** A call for a tenant or a class
           this resolver was never wired to serve is a mis-wiring, and it
           raises rather than being reported as a governed "no".
        2. **The question is RESOLVED before the graph is touched, and the
           resolution is what is checked.** The class's declared defaults are
           applied, the caller's values overlaid, the policy constraints in
           force at ``asked_at`` resolved with their provenance, the technical
           capabilities held against them — and only then is the *effective*
           request checked against the declared surface. The order is ruled
           (``D-IMPL-253`` Q8; ``D-IMPL-254`` — this is the **Authority**
           layer's place in Determination → Authority → Disclosure →
           Delivery), and it is the whole reason a default can mean something:
           a parameter the caller omitted reaches the closed-world comparison
           as the value the class declared, rather than as an omission. A
           question this class does not answer still costs nothing and still
           comes back with a reason rather than an approximation. The request
           surface, registered when this resolver was built (``D-IMPL-378``
           R-A), is **registered again** before the resolution, at the version
           the resolution pins (``CP17-F-09``), so every record that pins it
           resolves against this Control Plane at replay — a refusal asked
           first of a fresh Control Plane included.
        3. **The graph is read at the boundary the question named.** The
           instant is ``request.asked_at`` — supplied by a caller at serve time
           and by replay at replay time, through this same code path, which is
           the entire reason **the graph boundary** needs no clock. A clock IS
           read, once, at entry (`D-IMPL-358` step 4): ``served_at``, when the
           answer was handed over, which is a different instant answering a
           different question and reaches no graph read. This sentence
           previously claimed nothing here read a clock, which was already
           untrue of the composite branch before the hoist made it material.
        4. **The operator registry is built from whatever the deployment
           declared**, then Π runs at L5.
        5. **The class registers**, minting the pin Gate 3 resolves against;
           the request surface, registered at composition and at step 2, is
           registered again here with identical content, which is idempotent.
        6. **The candidate claims its lineage from the declaration, never from
           the execution.** A claim copied out of the execution record is not a
           claim, it is a transcript — and Gate 2 then has two independently
           authored sets to hold to strict equality.
        7. **The gates run**, and their refusal is returned as a value. An
           ADMITTED product is then held to the applicable tolerance —
           default, caller or policy — and withheld by name if it is exceeded
           (:func:`~ccf.products.gates.refuse_over_tolerance`, ``24.6-L-05``).
           That step is deliberately after the gates and deliberately not one
           of them: a gate decides whether a product may exist, and this
           decides whether a product that does exist is delivered.
        8. **The record is built, then persisted, and only a completed append
           yields a delivery.** No branch here reaches a served product without
           a recorded decision, because :func:`~ccf.replay.serve.serve` has
           none to offer.
        9. **And every refusal is recorded the same way, first** (``24.6-07``;
           ``D-IMPL-253`` Q13). All three refusal branches — the resolution
           verdict, the gate refusal, the withheld fulfillment — go through
           :meth:`_record_refusal` into the one
           :class:`RefusalRecorderProtocol`, which appends through the **same**
           :class:`~ccf.replay.serve.ReplayWriter` over the same store and then
           hands back the shell with its own address on it. A shell that left
           this method has a recorded decision behind it, by construction and
           not by review: the append happens before the return, and a store
           failure propagates out of it with no branch reaching a returned
           shell.

        Registration is content-addressed, so a second call registers identical
        content to an identical version; the audit log carries both attempts,
        which is the Control Plane being the audit plane rather than a leak.

        Raises:
            ProductNotResolvable: the address names a tenant or a class this
                resolver does not serve, or the call carried no request.
            ccf.controlplane.registry.ControlPlaneMissing: a pin has
                disappeared since registration — a broken deployment, which
                this seam reports differently from a bad question.
            Exception: whatever the artifact store raises, deliberately
                uncaught. A failure to record is a failure to serve — and as of
                ``24.6-07`` a failure to *refuse*, on the same posture: a
                governed "no" released without its record is a determination
                with no audit, and ``D-IMPL-256`` refuses to make auditability
                contingent on the outcome.
        """
        declaration = self._declaration()
        if tenant != self.fabric.tenant_id:
            raise ProductNotResolvable(
                f"this resolver serves tenant {self.fabric.tenant_id!r} and was"
                f" called for {tenant!r}; the tenant is established by the"
                " calling surface and a resolver bound to a booted fabric"
                " cannot answer for another one"
            )
        if (product_class, version) != (
            declaration.schema_name,
            declaration.schema_version,
        ):
            raise ProductNotResolvable(
                f"this resolver serves {declaration.schema_name!r} at lane"
                f" {declaration.schema_version!r} and was called for"
                f" {product_class!r} at lane {version!r}; the declaration comes"
                f" from manifest key {self.product_class_key!r}"
            )
        if request is None:
            raise ProductNotResolvable(
                f"this resolver validates a question against"
                f" {declaration.schema_name!r}'s declared request surface and"
                " derives the decision instant from it, so a call carrying no"
                " request has nothing to validate and no instant to read; the"
                " seam admits `None` because a surface with no query segment"
                " must be able to say so, and such a surface needs a resolver"
                " that answers without one"
            )

        # `D-IMPL-358` step 4 — ONE READ, HERE. The fabric-controlled clock is
        # read exactly once per call, at the entry to the governed path: after
        # the three address checks above, which RAISE on a mis-wiring and so
        # reach no governed decision at all, and before everything that does.
        #
        # Hoisted out of the composite branch below, where it was read only
        # `if registered.requires:` — so before this, a NON-COMPOSITE serve read
        # no clock and had no instant to say when it answered. `admitted_at` is
        # now this same value, so the composite window is unchanged and the
        # read-once-per-composition control still measures what it measured.
        #
        # A refusal path reads it too and, at THIS step, records nothing with
        # it: threading `served_at` into refusal records is step 5. That is the
        # ruled placement rather than an oversight — moving the read later and
        # then moving it again would make step 5 redo step 4.
        served_at = self.admission_clock()

        identity = RequestIdentity(
            product_id=product_class,
            product_version=version,
            parameters=request.parameters,
            temporal_boundary=request.asked_at,
        )

        # 24.7-07: is this class registered to serve the intent the request is
        # addressed with? An ADDRESSING verdict, and it precedes resolution for
        # the reason `_refuse_address` states for the lane check: judging the
        # parameters of a request for a class that does not serve its intent
        # is a confident verdict about the wrong question. Judged HERE, where
        # the declaration that carries `discovery` is in scope, and not inside
        # `refuse_request`, which never sees it — so direct validators that
        # hold no declaration never judge intent (D-09). Three states
        # (`D-IMPL-264` D-01 as amended, F-1 a): no declaration
        # (`NOT_DISCOVERABLE`) → unjudged, every existing deployment serves
        # as it did; declared and a member → serves; declared and not a member
        # — including a declared EMPTY set — → refused as data.
        violation = refuse_intent(request=request, discovery=declaration.discovery)
        if violation is not None:
            # No resolution ran, and the record says so positively rather than
            # by omission (D-09/D-10, P-2). What DID decide this outcome is the
            # class's declared intent set, so the deciding declaration IS
            # pinned — minted the way `class_source` mints it below, so the pin
            # resolves to the exact bytes that declared the set (`D-IMPL-264`
            # amendment 3 B-3 a, Dave: *"The refusal was decided by the class's
            # declared intent set, so replay should preserve the declaration
            # that actually governed the outcome"*). No request contract and no
            # constraint is pinned, because none was resolved against — which
            # is what lets replay read *request-contract pin + applicable
            # constraint pins* as the evidence that resolution ran, and never
            # a class-declaration pin (D-11 as narrowed by the same amendment).
            return self._record_refusal(
                envelope=envelope_for(violation, request=identity),
                execution=None,
                request=request,
                perspective=perspective,
                policy_bindings=(
                    PolicyBinding(
                        key=self.product_class_key, version=content_hash(declaration)
                    ),
                ),
                resolution=ResolutionNotApplicable(reason="refused-before-resolution"),
                served_at=served_at,
            )

        # THE DOOR, and this composition is the resolver standing at it. The
        # comparison the two shipped doors cannot make, because neither holds
        # the registered class it compares against (`D-IMPL-121`) — and, as of
        # `24.6-03`, the Control Plane read no door could make either.
        declared = self._request_contract(declaration)

        # D-IMPL-357 C2: the mechanism floor, judged HERE — after the
        # addressing verdicts (lane, intent) and BEFORE the overridable
        # `constraint_resolver` seam and before any acquisition — so that no
        # `PolicyConstraintResolver` override can remove its judgment of what
        # it DOES judge. The declaration is already in hand (`declared`,
        # above); the floor walks it and the effective request has not been
        # derived yet, so this judges the CALLER's own `request.subject` and
        # every DECLARED `string` parameter at every DECLARED depth, never a
        # value the resolution stage could have substituted for them.
        #
        # TWO floors, TWO roles, one call (item 7, ruled 2026-09-27, option
        # (a)): `request.subject` is an ADDRESS and is judged by
        # `SUBJECT_FLOOR_V1`, which forbids a space because its documented
        # safe position is a SPARQL IRI `<...>`. Every DECLARED `string`
        # PARAMETER is a VALUE and is judged by `PARAMETER_VALUE_FLOOR_V1`,
        # the same class PLUS an ordinary INTERIOR space (leading, trailing
        # and doubled space are refused), so an ordinary banking label such
        # as `Term Loan` is admissible as a parameter and still inadmissible
        # as an address. Whichever floor decides, its version name rides in
        # the refusal `detail`, which is what pins the deciding grammar on
        # the record.
        #
        # NOT covered — out-of-grammar text at any of these CAN still reach
        # the acquisition seam through this call site alone (`refuse_floor`'s
        # own docstring carries the same list): `request.intent` when the
        # class declares no discovery set; `request.freshness` (judged
        # nowhere in this fabric); every member of
        # `request.policy_overrides` (a flat `tuple[str, ...]` — that tuple
        # is the whole extent of the carrier, since the field cannot hold a
        # mapping or any nested shape); any value the resolution stage
        # supplies rather than the caller (a contract `defaults` string, a
        # relative default, a policy-narrowed value); a string under an
        # UNDECLARED parameter key; any other presented string at a position
        # the declaration does not type as `string`; and any string nested
        # inside a declared member whose type is `object` (an opaque
        # container the floor does not open).
        #
        # **The coverage question is RULED, not open** (item 4, ruled
        # 2026-09-27, correcting this comment's earlier wording): the floor
        # stays on DECLARED positions only. `request.intent`,
        # `request.freshness`, `request.policy_overrides` and any
        # presented-but-undeclared position are deliberately NOT judged here
        # and are ledgered residuals rather than folded in by widening this
        # call. Registration-time validation of a contract's own `defaults`
        # string is 1.0.3.
        floor = refuse_floor(request=request, declared=declared)
        if floor is not None:
            # D-IMPL-357 C2: a mechanism floor, judged before the overridable
            # seam and before any acquisition; the deciding declaration is the
            # class (pinned as for intent) and the floor's version rides in
            # `detail`, which is what pins the floor on the record.
            return self._record_refusal(
                envelope=envelope_for(floor, request=identity),
                execution=None,
                request=request,
                perspective=perspective,
                policy_bindings=(
                    PolicyBinding(key=self.product_class_key, version=content_hash(declaration)),
                ),
                resolution=ResolutionNotApplicable(reason="refused-before-resolution"),
                served_at=served_at,
            )

        # `CP17-F-09` / `ATM-F-11` (`D-IMPL-378`, lane 378d-replayfix): THE
        # REQUEST SURFACE IS REGISTERED HERE, before the resolution that first
        # pins it — again, since `__post_init__` registered it when this
        # resolver was built (`D-IMPL-378` R-A), and kept beside the step that
        # first records the pin. Every refusal from this line on — a resolution-stage
        # refusal, the naive-instant and temporal-bound refusals, a refusal held
        # at either acquisition seam — records the resolution on dimension 2,
        # and with it this contract at `content_hash(declared)` (`D-IMPL-310`:
        # the pin belongs there). `_register` below registers the same content,
        # but only the served path reaches it, so a refusal asked first of a
        # fresh Control Plane left a record whose pin nothing had registered,
        # and `replay_refusal` refused it as a configuration that was gone.
        # Registration is content-addressed and idempotent: the version minted
        # is the version the record pins, so no record's bytes or address
        # change, and the audit log carries the attempt.
        self.control_plane.register(self._authorities.request_contract, declared)

        outcome = self.constraint_resolver.resolve(
            # `D-IMPL-358` step 5 ruling B: effectivity at the TRUSTED serve
            # instant — the one this invocation read once at entry. The graph is
            # still read at `request.asked_at` below, which keeps the two axes
            # separate: a question about last quarter stays about last quarter
            # while the policy governing the answer is today's.
            served_at=served_at,
            product_class=product_class,
            request=request,
            declared=declared,
            declared_source=ProvenanceSource(
                kind="artifact",
                identity=self.request_contract_key,
                # The version the registry assigns this content, minted the way
                # `ControlPlaneRegistry.register` mints it — a content address
                # (`D-IMPL-26`). So the pin this resolution records and the pin
                # registered just above (and again by `_register` on the served
                # path) are the same pin by construction, rather than two reads
                # that could disagree.
                version=content_hash(declared),
            ),
            perspective=perspective,
            intent=request.intent,
            tenant=self.fabric.tenant_id,
            capabilities=self.capabilities,
            # 24.6-04: the product class's own declared characteristic reaches
            # the resolution as a DEFAULT and never as a ceiling (`D-IMPL-251`
            # C1=A). The key is omitted when the class declares nothing, so a
            # class with no opinion contributes no authority — rather than an
            # authority whose value happens to be `None`.
            class_defaults=self._class_defaults(declaration),
            class_source=ProvenanceSource(
                kind="artifact",
                identity=self.product_class_key,
                # The declaration's content address, minted the way
                # `ControlPlaneRegistry.register` mints one (`D-IMPL-26`), so
                # the pin recorded beside a defaulted value resolves to the
                # exact bytes that declared it.
                version=content_hash(declaration),
            ),
        )
        if outcome.refusal is not None:
            # No lineage: every one of these is reached while the effective
            # request is still being built, which is strictly before the graph
            # is touched. `envelope_for` refuses a lineage here, which is what
            # makes the assembly-boundary split structural.
            #
            # 24.6-07: and no execution, so dimension 1 says positively that
            # nothing was read. The bundle pin is the recorder's. What DID
            # govern this is the resolution that ran up to the refusal —
            # defaults applied, the constraints in force folded, capabilities
            # consulted — and that partial work is governed truth. It rides on
            # dimension 2 with the pins it was resolved from, exactly as a
            # completed resolution does on the two post-assembly branches
            # below (`D-IMPL-264` D-07, Dave: *"'It failed before producing
            # an effective request' must not erase what resolution already
            # established."*). The shell carries the same partial record as
            # its `provenance`, so the record and the shell cannot disagree.
            return self._record_refusal(
                envelope=envelope_for(
                    outcome.refusal,
                    request=identity,
                    policy_bindings=outcome.evidence.applied,
                    provenance=outcome.evidence,
                ),
                execution=None,
                request=request,
                perspective=perspective,
                policy_bindings=self._applied_bindings(outcome.evidence),
                resolution=outcome.evidence,
                served_at=served_at,
            )
        effective = outcome.evidence
        # The engine answers the EFFECTIVE question — defaults applied, policy
        # bounds in force. It is a SIBLING of the caller's request and never a
        # replacement: `identity.parameters` and the request that lands in
        # replay dimension 5 both keep what the caller supplied, so a refusal
        # can still say "you asked for X and policy P bounds you to Y", and the
        # resolution that turned one into the other is dimension 2's
        # (`D-IMPL-253` Q1 — *"do not collapse authority after resolution"*).
        effective_request = request.model_copy(
            update={"parameters": dict(effective.values())}
        )

        # `D-IMPL-358` step 5 ruling C — THE DECISION INSTANT, DERIVED ONCE, HERE.
        # Hoisted from below the graph read, where it used to be computed, because
        # the temporal bound must judge it and the bound must be judged before
        # anything is acquired. It is a pure function of `request` and
        # `effective_request`, both final at this line and neither reassigned
        # afterwards — so this is the same value the later stages used, computed
        # once rather than twice. Two computations are two chances to disagree.
        decided_at = self._decision_instant(request, effective_request)

        # `D-IMPL-358` step 5 section C1: THE INSTANT MUST BE AWARE, judged here
        # because this is the line after which the fabric does arithmetic with it.
        # A declared instant is caller-supplied data and may arrive with no UTC
        # offset. There is no implicit UTC in this fabric: assuming one answers
        # for an hour the caller never named, silently, with every gate green —
        # so this refuses by name rather than repairing with `.replace(tzinfo=…)`.
        # Refusing here also keeps the bound below from raising `TypeError` on a
        # naive-minus-aware subtraction, which would be an ungoverned 500 for what
        # is a malformed value.
        if decided_at.tzinfo is None or decided_at.tzinfo.utcoffset(decided_at) is None:
            parameter = self.decision_instant_parameter
            assert parameter is not None, (
                "a naive instant can only come from a declared parameter; "
                "`request.asked_at` is aware by contract"
            )
            return self._record_refusal(
                envelope=envelope_for(
                    ProductRequestViolation(
                        reason="malformed-value",
                        key=parameter,
                        declared_type="an aware datetime (one carrying a UTC offset)",
                        presented_type=type(decided_at).__name__,
                        declared_keys=frozenset(effective_request.parameters),
                        presented_keys=frozenset(
                            request.parameters if request is not None else ()
                        ),
                        detail=(
                            f"{parameter}: the declared decision instant carries no UTC"
                            " offset, so the fabric cannot say which moment it names."
                            " Refused by name and never repaired: there is no implicit"
                            " UTC here, and assuming one would answer for an hour the"
                            " caller never stated (`D-IMPL-358` step 5 section C1)"
                        ),
                    ),
                    request=identity,
                    policy_bindings=effective.applied,
                    provenance=effective,
                ),
                execution=None,
                request=request,
                perspective=perspective,
                served_at=served_at,
                policy_bindings=self._applied_bindings(effective),
                resolution=effective,
            )

        # THE TEMPORAL BOUND, JUDGED HERE AND BEFORE ACQUISITION. The effective
        # request exists (policy has narrowed what it can), the decision instant is
        # derived, and nothing has been read or ingested — which is the point: an
        # out-of-window question must cost nothing.
        temporal = resolve_temporal_boundary(
            registry=self.control_plane, tenant_id=self.fabric.tenant_id
        )
        temporal_pins = (
            (temporal.binding,) if isinstance(temporal, PinnedTemporalBoundary) else ()
        )
        out_of_window = refuse_temporal_bound(
            pinned=temporal,
            served_at=served_at,
            asked_at=request.asked_at,
            decision_instant=decided_at,
        )
        if out_of_window is not None:
            # A typed refusal BEFORE any write, through the same `_record_refusal`
            # seam every other governed refusal uses — no fabricated record, no
            # restamping. `temporal_pins` is EMPTY when the policy was undeclared
            # (ruling 11 forbids minting a binding for a policy that does not
            # exist) and carries the exact resolved binding when the policy itself
            # is what refused.
            return self._record_refusal(
                envelope=envelope_for(
                    out_of_window,
                    request=identity,
                    policy_bindings=effective.applied,
                    provenance=effective,
                ),
                execution=None,
                request=request,
                perspective=perspective,
                served_at=served_at,
                policy_bindings=(*self._applied_bindings(effective), *temporal_pins),
                resolution=effective,
            )

        # SEC-020 Q8 / Q10 (`D-IMPL-378`): THE EARLY DECISION. Taken here —
        # after every refusal that precedes acquisition, before anything in
        # the question is fetched, any child is asked or anything is scored —
        # from the asked identifier, the resolved perspective and the policy
        # the plan factory declared at construction, and from nothing else: no
        # fabric, no source, no store, so it is the same for a subject the
        # source holds and one it does not. A subject the policy does not
        # disclose is replaced, for every subject-dependent step below, by the
        # declared undisclosed subject (`asked`); the plan is still built from,
        # and the record still keeps, the caller's question.
        disclosure = self._disclosure
        undisclosed = disclosure is not None and not disclosure.discloses(
            subject=request.subject, perspective=perspective
        )
        asked = (
            effective_request.model_copy(update={"subject": disclosure.undisclosed_subject})
            if undisclosed and disclosure is not None
            else effective_request
        )

        # `D-IMPL-343` R-4: THE DECLARED ACQUISITION SEAM, HERE AND ONLY HERE.
        # The question is resolved (above) and the graph is not yet read
        # (below), so what the deployment reads its sources at is the value
        # governance resolved — the one derivation — and a refused request
        # never reaches this line. The seam is the composition root's: it
        # reads and it ingests through L2's one writer; this resolver hands
        # it a request and holds no handle to anything it writes.
        #
        # SEC-020, `D-IMPL-376` (3) route A: THE FABRIC BEFORE THIS REQUEST'S
        # ACQUISITION, read once, immediately before the seam — after every
        # refusal above, so a refused question still costs nothing, and before
        # the seam, so nothing this request acquires is in it. A subject that
        # names nothing has nothing acquired for it by a source keyed on the
        # subject, so this is the state its walk reads; a subject Π withholds
        # is rendered from it below. (An acquisition that ingests the same
        # content whatever the subject gives a nonexistent subject that content
        # too, which this state lacks: measured, and disclosed in the security
        # how-to, section 4.12; for a class whose projection may withhold late,
        # such an acquisition is refused below, before the seam is handed the
        # subject — `D-IMPL-378` ruling P6 (a).) Read only when a seam is
        # declared: with none, nothing is acquired, and the state the plan
        # reads below is this one.
        before_acquisition: GraphView | None = None
        acquires = self.acquisition is not None or self.population_acquisition is not None
        if acquires or self.fabric.for_question:
            # SEC-020 Q9 (`D-IMPL-378`): a fabric booted for this question, and
            # claimed for it — before anything is read or fetched, and decided
            # by nothing about the subject. P4 (a) (`D-IMPL-378`, ruled
            # 2026-10-08 12:29 MST): a question fabric is claimed by every
            # governed call over it, so a later call with no acquisition phase
            # does not answer from what the first one fetched.
            _claim_question_fabric(self.fabric)
        elif self.fabric.question_store:
            # SEC-020 P4 (a): a question's store booted again, read with no
            # acquisition phase — where Q9 alone never bound. Refused here,
            # before the graph is read, by the boot's marker and never by the
            # question; a call that acquires over it was refused just above
            # (not booted for its question). Replay builds a resolver over it
            # and never calls it.
            raise QuestionStoreReopened(
                "this fabric reads a store that was booted for one question,"
                " booted again; it keeps what that question's acquisition"
                " fetched, so it answers no later question (boot a new store"
                " for each question; SEC-020, Q9)"
            )
        elif self.fabric.store_creation == "unmarked":
            # SEC-020 P4 (a) made strict (Dave, 2026-10-08 12:29 MST: *"An
            # unmarked existing store must not be presumed fresh"*): a store
            # that existed at boot with no marker beside it may be a question's
            # store from before the markers, or a copy taken without one.
            # Refused here, before the graph is read, by the boot's reading of
            # the markers and never by the question; replay builds a resolver
            # over it and never calls it.
            raise UnmarkedStoreNotPresumedFresh(
                "this fabric reads a store that existed before its boot and"
                " carries no marker a deployment door left when it created it;"
                " nothing shows that no earlier question's acquisition wrote"
                " into it, so it is not presumed fresh and answers no question"
                " (boot a new store through a deployment door; SEC-020, P4)"
            )
        if acquires:
            # SEC-020 Q7 / Q10: THE POPULATION PHASE FIRST, once, handed no
            # subject — so what it acquires is what any identifier's question
            # acquires, and it is in the state read below.
            if self.population_acquisition is not None:
                population_phase = self.population_acquisition
                population = PopulationQuestion.of(effective_request)
                refused = self._invoke_acquisition(
                    lambda: population_phase(question=population, perspective=perspective),
                    request=request, identity=identity, perspective=perspective,
                    effective=effective, served_at=served_at,
                )
                if refused is not None:
                    return refused
            before_acquisition = self.fabric.handle.reader.as_of(
                tenant_id=self.fabric.tenant_id, at=request.asked_at
            )
            # `D-IMPL-378` ruling P6 (a) (Dave, 2026-10-08 16:40 MST; SEC-020
            # stays OPEN). The read above is what route A renders a
            # late-withheld subject over, and it equals what an identifier
            # that names nothing is rendered over only if the subject-keyed
            # phase acquires nothing for such an identifier. For a class whose
            # projection may withhold late — it may withhold, and it declares
            # no early policy — the phase is asked about `UNHELD_SUBJECT_PROBE`
            # HERE, before it is ever handed the question's subject, and the
            # question is refused if that changed the fabric; decided by
            # nothing about the asked subject. Q10 is amended to exactly this
            # one extra call.
            if (
                self.acquisition is not None
                and disclosure is None
                and declaration.subject_withholding != SUBJECT_WITHHOLDING_NEVER
            ):
                held_at_the_probe = self._refuse_a_population_read_in_the_subject_keyed_phase(
                    asked, perspective=perspective, before=before_acquisition,
                    at=request.asked_at,
                )
                if held_at_the_probe is not None:
                    # OWED-RULINGS-3 item 4 (b), as repaired by 2.3 (b): the
                    # probe's held refusal answers the question as a RECORDED
                    # refusal, the SDK's one constant, the same for every subject.
                    return self._refuse_raised_at_seam(
                        held_at_the_probe, seam="acquisition", request=request,
                        identity=identity, perspective=perspective, effective=effective,
                        served_at=served_at,
                    )
            # `D-IMPL-378` decision 4 (a) (Dave, 2026-10-09 06:06 MST, confirmed
            # 06:21; SEC-020 stays OPEN). Under a declared early policy the
            # stand-in is what every subject-dependent step is asked about in
            # place of an undisclosed subject, so it must name nothing: verified
            # HERE, for every question of the class whatever its policy decides,
            # before the subject-keyed phase is handed anything for the question
            # — the fabric read above must not name it, and the phase must
            # acquire nothing for it that it does not acquire for
            # `UNHELD_SUBJECT_PROBE`. Decided by nothing about the asked subject.
            if disclosure is not None:
                self._refuse_a_stand_in_that_names_something(
                    disclosure.undisclosed_subject, effective_request,
                    perspective=perspective, before=before_acquisition,
                    at=request.asked_at,
                )
        if self.acquisition is not None:
            try:
                self.acquisition(request=asked, perspective=perspective)
            except GovernedRefusalRaised as raised:
                # `D-IMPL-304`: a governed determination the seam HELD and could
                # not return — recorded through this composition's ONE minting
                # seam with the resolution THIS resolver established, and
                # returned as data. Only this type; any other exception the
                # seam raises propagates exactly as before. `D-IMPL-378` repair
                # 2.2 (a): under a declared early policy it is served and
                # recorded as the SDK's one constant refusal instead.
                return self._refuse_raised_at_seam(
                    raised if disclosure is None else self._under_the_early_policy(raised),
                    seam="acquisition", request=request, identity=identity,
                    perspective=perspective, effective=effective,
                    served_at=served_at,
                )
            except Exception as error:  # noqa: BLE001 — re-raised unless DECLARED
                # `D-IMPL-347` B2: only a type THIS class declared converts.
                # Everything else re-raises unchanged, which is what keeps a
                # defect a defect.
                binding = self._declared_seam_refusal(error)
                if binding is None:
                    raise
                if disclosure is not None:
                    # `D-IMPL-378` repair 2.2 (a): the declared cause, code and
                    # the exception's own text give way to the one constant.
                    return self._refuse_raised_at_seam(
                        self._under_the_early_policy(None), seam="acquisition",
                        request=request, identity=identity, perspective=perspective,
                        effective=effective, served_at=served_at,
                    )
                return self._refuse_declared_at_seam(
                    error, binding, seam="acquisition", request=request,
                    identity=identity, perspective=perspective, effective=effective,
                    served_at=served_at,
                )

        view = self.fabric.handle.reader.as_of(
            tenant_id=self.fabric.tenant_id, at=request.asked_at
        )
        # `D-IMPL-378` decision 4 (a), AFTER acquisition: the fabric the plan
        # reads must not name the declared stand-in — checked for every
        # question of an early-policy class, before anything is computed or
        # recorded, with the one message the checks before acquisition carry.
        if disclosure is not None and _names(view, disclosure.undisclosed_subject):
            raise UndisclosedSubjectSubstituteIsHeld(self._stand_in_is_held())
        operators = build_operator_registry(
            parameters=self.operator_parameters(effective_request),
            view=view,
            pins=self.fabric.pins,
            policy_bundle_key=self.policy_bundle_key,
            # `24.11-02b` / `24.10-F-06` (`D-IMPL-292`). No index version
            # travels here, and its ABSENCE is the repair rather than an
            # omission. `24.11-02` passed one from a field on this class,
            # which fixed the propagation and left a decision-affecting
            # semantic value in ungoverned deployment hands. It is now
            # declared on the similarity artifact — one of the very artifacts
            # `operator_parameters()` returns on the line above — so the
            # builder reads the corpus identity off the same declaration it
            # already reads the corpus map off, and this composition states
            # no opinion about a value it does not own.
        )
        required = tuple(declaration.required_operator_keys)
        registered = self._register(declaration)
        policy_version = self.fabric.pins.version_for(self.policy_bundle_key)
        own_lineage = ProductLineage(
            operators_invoked=frozenset(required),
            policy_bundle_versions=frozenset({policy_version}),
            graph_snapshot_at=request.asked_at,
        )
        # --- `D-IMPL-339`: ACQUIRE AND ADMIT CHILDREN ONCE, BEFORE THE PLAN ----
        #
        # The approved order: child-independent request / policy / declaration
        # checks (all above) -> acquire and admit children once -> the
        # read-only child-contract view -> the parent's plan -> the parent's
        # own assessment -> compose using the SAME acquired outcomes -> the
        # existing gates, tolerance, delivery / refusal and replay. Only the
        # acquisition half moves here; `compose_children` runs below, after
        # the assessment it needs, over exactly these `outcomes`.
        #
        # `registered`, `policy_version` and `own_lineage` moved up with it:
        # none reads the projection. What stays below is what does —
        # `assessed`, `decided_at` and the composition laws.
        composed: CompositionOutcome | None = None
        outcomes: Mapping[str, object] | None = None
        # Round 5 SDK lane A (CP08-R3-F-01): the rows the per-requirement walk
        # produced, bound for the ONE exit between that walk and the composition
        # — the evidence-after-decision refusal at scoring — so it keeps the
        # child evidence `D-GATE-338` requires of every exit after acquisition.
        # `()` for a non-composite: no child was asked anything.
        walk_child_rows: tuple[ChildResolution, ...] = ()
        children: ChildContractView | None = None
        invocation = ""
        if registered.requires:
            # One governed question, one invocation identity — derived from the
            # request so it is stable under replay and cannot be chosen per
            # child (F8: invocation-bound, and the binding is to THIS one).
            invocation = f"composition://{content_hash(request)}"
            # Read ONCE per composition — and now once per CALL, which is
            # strictly stronger. Two children admitted against two readings of a
            # clock would be judged in two windows, and the rows would disagree
            # about when the composition admitted them. `D-IMPL-358` step 4:
            # `admitted_at := served_at`, the value read at entry, so the
            # composite window is exactly the window it was and the instant the
            # answer was served is the instant its children were admitted.
            admitted_at = served_at
            if self.composite_children is None:
                composed = CompositionOutcome(
                    factors=None,
                    resolutions=(),
                    refusal=ChildAdmissionRefusal(
                        gate=GATE_CHILD_ADMISSION,
                        detail=(
                            f"class {registered.schema_name!r} declares"
                            f" {len(registered.requires)} child requirement(s)"
                            " and this deployment wired no composite child"
                            " resolver, so they could not be satisfied."
                            " Refused rather than served without them: a"
                            " declared requirement execution ignores is the"
                            " defect this block exists to close"
                        ),
                        product_class=registered.schema_name,
                        reason="no-producing-skill",
                    ),
                )
            else:
                # `D-IMPL-340`. A resolver that declares it takes the composite's
                # EFFECTIVE request — defaults applied, policy narrowed, the same
                # authority chain every argument travels — receives it; every other
                # resolver takes the call it always took. Structural `isinstance` on
                # a capability Protocol, on the `CompositePlanFactoryProtocol`
                # precedent: no defaulted keyword, no `TypeError` probing.
                # `D-IMPL-347` A2 / `CLD-F-06`: a refusal the FACTORY raises is
                # a COMPOSITE refusal (Dave, 2026-09-23) — an envelope check, a
                # policy bound, a "do not dispatch". There is no child outcome
                # to attach it to, and treating it as one is the mix-up cp-20's
                # workaround was avoiding. A child DOOR's own governed refusal
                # is a different path entirely: it arrives as an outcome row
                # below, where the slot rules decide (`D-IMPL-336` F1).
                try:
                    if isinstance(
                        self.composite_children, RequestAwareChildResolverProtocol
                    ):
                        outcomes = self.composite_children.resolve_for(
                            requirements=registered.requires,
                            asked_at=request.asked_at,
                            # `O3`: the trusted runtime clock, NOT `decided_at`.
                            admitted_at=admitted_at,
                            composition_invocation=invocation,
                            # `D-IMPL-336` Amendment 5: peering admission extends the
                            # consumer's lineage by set-union.
                            consumer_lineage=own_lineage,
                            # SEC-020 Q8: the request the subject-dependent
                            # steps are asked about — an undisclosed subject's
                            # children are asked about the declared stand-in.
                            request=asked,
                        )
                    else:
                        outcomes = self.composite_children(
                            requirements=registered.requires,
                            asked_at=request.asked_at,
                            # `O3`: the trusted runtime clock, NOT `decided_at`.
                            admitted_at=admitted_at,
                            composition_invocation=invocation,
                            # `D-IMPL-336` Amendment 5: peering admission
                            # extends the consumer's lineage by set-union.
                            consumer_lineage=own_lineage,
                        )
                except GovernedRefusalRaised as raised:
                    return self._refuse_raised_at_seam(
                        raised, seam="build_children", request=request,
                        identity=identity, perspective=perspective,
                        effective=effective,
                        served_at=served_at,
                    )
                except Exception as error:  # noqa: BLE001 — re-raised unless DECLARED
                    binding = self._declared_seam_refusal(error)
                    if binding is None:
                        raise
                    return self._refuse_declared_at_seam(
                        error, binding, seam="build_children", request=request,
                        identity=identity, perspective=perspective,
                        effective=effective,
                        served_at=served_at,
                    )
                # The per-requirement walk — provenance, slot / instant /
                # invocation re-binding, the refusal branches — runs HERE,
                # before any child-dependent computation, and the view is
                # derived only from what passed it (`D-IMPL-339` Q1, Q2).
                resolved = resolve_child_outcomes(
                    requirements=registered.requires,
                    outcomes=outcomes,
                    asked_at=request.asked_at,
                    composition_invocation=invocation,
                )
                # `D-IMPL-344`: RETENTION FOLLOWS ADMISSION, NOT COMPOSITION
                # SUCCESS. Every contract this walk admitted is filed by content
                # address HERE — before the blocking split — so a partially
                # admitted set (one child admitted, a required sibling refused
                # or unreachable, the parent's plan never run) keeps the bytes
                # its refusal record's row names. Read off `resolved.admitted`
                # directly: the view below refuses a blocked resolution by
                # design (`D-IMPL-339` Q2), and a view over a set known not to
                # compose was never the prerequisite for keeping what WAS
                # admitted. Replay rebuilds from what was consumed — never from
                # a provider call, a latest-version lookup or a live closure —
                # on every exit, not only the served one. A store that cannot
                # file raises here, before any record is minted (§3 of the
                # design): a determination whose evidence was not kept is not
                # recorded as though it had been.
                self._retain_child_contracts(
                    child.contract for child in resolved.admitted
                )
                walk_child_rows = tuple(resolved.rows)
                if resolved.blocking:
                    composed = CompositionOutcome(
                        factors=None,
                        resolutions=resolved.rows,
                        refusal=resolved.refusal,
                    )
                else:
                    children = child_contract_view(resolved)
            if composed is not None and composed.refusal is not None:
                # A KNOWN BLOCKING OUTCOME BEFORE PROJECTION (`D-IMPL-339` Q2):
                # a required child absent, an invoked child refused or rejected
                # at admission, or no resolver wired. Child-dependent
                # computation does not run. Recorded through the same seam a
                # pre-assembly refusal takes — no execution, no lineage, and
                # dimension 1 says positively that nothing was read — with
                # every child row the walk produced (`D-IMPL-338`).
                return self._record_refusal(
                    envelope=envelope_for(
                        composed.refusal,
                        request=identity,
                        policy_bindings=effective.applied,
                        provenance=effective,
                    ),
                    execution=None,
                    request=request,
                    perspective=perspective,
                    policy_bindings=self._applied_bindings(effective),
                    resolution=effective,
                    child_resolutions=composed.resolutions,
                    served_at=served_at,
                )

        # `D-IMPL-300`: the plan is a NAMED LOCAL so the binder has somewhere to
        # stand. `D-IMPL-86`'s correction of 2026-08-05 puts the check between
        # plan construction and `execute`, and on this path that moment exists
        # ONLY here — `plan_factory` is invoked by the resolver, so no adopter
        # code sits between the two. Found by cp-05's canonical adoption: its
        # hand-composed spine called the binder, and the migrated program had
        # nowhere legitimate to.
        # `D-IMPL-339`: a composite-capable factory receives the admitted
        # children's contracts; every other factory is called EXACTLY as it
        # always was. The capability is declared structurally, never inferred
        # from a signature, and never probed with a TypeError-and-retry.
        # `D-IMPL-347` A2: the plan factory is a deployment seam, so a refusal
        # it raises is data. Wrapped individually rather than as part of a
        # broader block — the refusal must be attributable to THIS seam.
        try:
            if children is not None and isinstance(
                self.plan_factory, CompositePlanFactoryProtocol
            ):
                plan = self.plan_factory.build_with_children(
                    required=required, request=effective_request, children=children
                )
            else:
                plan = self.plan_factory(required=required, request=effective_request)
        except GovernedRefusalRaised as raised:
            return self._refuse_raised_at_seam(
                raised, seam="plan_factory", request=request, identity=identity,
                perspective=perspective, effective=effective,
                served_at=served_at,
            )
        except Exception as error:  # noqa: BLE001 — re-raised unless DECLARED
            binding = self._declared_seam_refusal(error)
            if binding is None:
                raise
            return self._refuse_declared_at_seam(
                error, binding, seam="plan_factory", request=request,
                identity=identity, perspective=perspective, effective=effective,
                served_at=served_at,
            )
        # The product class's `required_operator_keys` and the plan's own
        # `required_operators()` are two separately authored documents (design
        # E2). Gate 2 below compares the declaration against what the engine
        # RESOLVED, which is a different and later invariant: it catches the
        # divergence after a product has already been assembled from a set the
        # deployment's own claim contradicts. Refusing here is what keeps that
        # assembly from happening at all.
        refuse_operator_set_divergence(declared=declaration, plan=plan)
        engine = ProjectionEngine(
            reader=self.fabric.handle.reader, registry=operators
        )
        execution = engine.execute(
            plan=plan,
            perspective=perspective,
            tenant_id=self.fabric.tenant_id,
            temporal_boundary=request.asked_at,
            # `24.11-01` / `24.10-F-07` (`D-IMPL-111` limb (a), Dave,
            # 2026-08-11): *the request seeds the traversal*. Absent this
            # argument the canonical path executed with `seeds=None` while
            # `ccf.replay.engine` replayed with
            # `seeds=request_seeds(path.request)`, so two questions about two
            # different subjects compiled to the SAME graph query and pinned
            # identically in dimension 5 — `DI-15.5-07` exactly, reproduced on
            # the canonical path after limb (a) had already closed it on the
            # hand-built one.
            #
            # **`request`, not `effective_request`, and the reason is the
            # invariant rather than a preference.** `build_replay_record` below
            # is handed `request=request`, which `ccf.replay.record` writes
            # verbatim to `ContentGenerationPath.request`, which
            # `ccf.replay.engine` reads back as `request_seeds(path.request)`.
            # Seeding from the CALLER's request is therefore the SAME function
            # applied to the SAME object on both paths — the "one reading, used
            # on both paths" `request_seeds` exists to be. `effective_request`
            # is a sibling that today carries an identical `subject` (it differs
            # only in `parameters`), so it would agree by coincidence and not by
            # construction: it is a SECOND derivation, and a second derivation
            # is precisely the drift that would replay a different question
            # under this decision's identifier.
            #
            # SEC-020 Q10 (`D-IMPL-378`): under the early decision the walk is
            # seeded with the declared undisclosed subject, IN PLACE OF the
            # caller's — exactly the walk a question about an identifier that
            # names nothing takes — and this is the ONE computation of the
            # product; the seed is recorded beside the caller's question
            # (`ContentGenerationPath.executed_seeds`) and replay re-executes
            # from it.
            seeds=request_seeds(asked if undisclosed else request),
        )
        # Dave's Q12 (`D-IMPL-378`): a class that affirmed its answers never
        # withhold their subject may have its records read back by their
        # owners; a withheld answer under that affirmation is a broken
        # deployment, refused before anything is rendered, recorded or served.
        # Checked FIRST, before Q8's composite refusal below: Dave's CT-D (a),
        # 2026-10-08 12:29 MST, "for diagnostic precedence; this does not
        # resolve E2(ii)'s oracle" — a composite affirming `never` that
        # withholds late is named by its own contradiction. Both refuse before
        # anything is recorded.
        if (
            execution.projection.withheld
            and self._declaration().subject_withholding == SUBJECT_WITHHOLDING_NEVER
        ):
            raise NeverWithholdingContradicted(
                f"class {self._declaration().schema_name!r} affirms"
                f" subject_withholding: {SUBJECT_WITHHOLDING_NEVER!r} and its"
                " projection withheld the subject; a record of the class may be"
                " read back by its owner, so a withheld answer under the"
                " affirmation is refused (Dave's Q12, D-IMPL-378)"
            )
        if execution.projection.withheld and not undisclosed and registered.requires:
            # SEC-020 Q8 (`D-IMPL-378`): a composite withholds only through the
            # declared early policy; its children were already asked about this
            # subject, so a withhold decided inside the projection is refused,
            # before this decision is gated, recorded or served.
            raise CompositeWithheldLate(
                f"class {registered.schema_name!r} composes children and its"
                " projection withheld a subject its early policy did not; a"
                " composite asks its children before its plan runs, so it"
                " withholds only through a declared early policy (SEC-020, Q8)"
            )
        if undisclosed and not execution.projection.withheld:
            # SEC-020 Q8: the policy did not disclose the subject and the
            # projection answered it. Serving that payload would hand over the
            # subject's own answer; refusing it as data would be a governed
            # "no" nobody declared.
            raise UndisclosedSubjectAnswered(
                "the declared early policy does not disclose this subject to this"
                " principal, and the projection answered without raising the"
                " withheld signal (SEC-020, Q8)"
            )

        # --- SEC-020: A WITHHELD SUBJECT'S EVIDENCE, FROM AN UNSEEDED RE-RUN ----
        # `D-IMPL-370` Q12 (a), constant-fill, as finally ruled at `D-IMPL-371`
        # (SDK-defined, CLAUDE.md §11). SEC-020 is OPEN: what this branch makes
        # equal to a nonexistent subject's answer, and what still tells the two
        # apart, is in the security how-to, section 4.12. A projection
        # conditioned on the perspective may withhold the subject from this
        # principal; it says so with the typed signal on
        # `src/ccf/projection/plan.py::ProjectionOutput`, and the signal is the
        # ONLY key into this branch — an empty payload without it is a
        # legitimately empty answer and keeps what its real view earned
        # (`D-IMPL-242` amendment 1).
        #
        # THE BASELINE IS THE WALK A SUBJECT THAT NAMES NOTHING GETS. Walk
        # starts are the union of the plan's seed classes and the request seed
        # (`GQ-11`); for an identifier that names nothing the request seed
        # matches no record, so its walk starts at the class seeds alone. The
        # plan is therefore RE-EXECUTED WITHOUT THE REQUEST SEED
        # (`src/ccf/projection/engine.py::ProjectionEngine.execute_without_request_seed`)
        # and the debt, the empty finding, the TTL anchor, the touched set the
        # staleness gate reads and the evidence a declared product gate is shown
        # are computed from that run. That is not everything a caller can tell
        # the two answers apart by, each measured (section 4.12): a composite's
        # children are resolved for the ASKED subject above, and the
        # composition below replaces the debt and supplies the expiry and the
        # lineage, none of it re-rendered (review finding I-1); and the
        # answer's replay reference is named by dimension 1, which keeps the
        # real read (review finding C-1). (Review finding I-2, a similarity
        # operator scoring the re-run against text acquisition wrote, is the
        # registry note below.) The
        # withheld subject's own records stay in the re-run's view if and only
        # if a class seed reaches them, exactly as for the nonexistent
        # identifier. Measured history: an EMPTY view (round 1) created a
        # serve-versus-refuse oracle on a class-seeded fabric; MASKING the
        # subject's records (round 2) left a residual whenever the subject's
        # evidence was fresher or staler than its siblings', because the
        # nonexistent identifier's walk reads those records.
        #
        # AND THE FABRIC IT WALKS IS THE ONE BEFORE THIS REQUEST'S ACQUISITION
        # (`D-IMPL-376` (3), route A). An identifier that names nothing has
        # nothing acquired for it from a source keyed on the subject (the scope
        # the security how-to, section 4.12, discloses); the withheld subject's
        # own question did acquire, through the declared seam above, BEFORE the
        # plan ran — so re-executing over the fabric as it now stands walked the
        # evidence acquisition had just ingested for the asked subject (measured
        # by the `D-IMPL-371` close review on the paved road: `computed_empty`
        # under `from_decision`, the refusal kind under `from_entity_freshness`).
        # `before_acquisition` is the state read immediately before that seam;
        # with no seam declared it is `None` and the store is read as it is.
        #
        # `execution` itself is NOT replaced. The replay record is the audit
        # plane (whitepaper §7.8.2) and keeps what was actually read, so a
        # re-execution pins the same reads; the recorded debt and finding are
        # `rendered`'s, carried in dimension 5, which is what replay rehydrates.
        #
        # AND ITS OPERATORS ARE BUILT FROM THE SAME READ IT WALKS (SEC-020
        # channel 5, review finding I-2; `D-IMPL-378`). `operators` was built
        # from `view`, read AFTER acquisition, and an index-backed operator
        # holds a corpus read out of the view its registry was built from: a
        # similarity operator in it scored the unseeded walk over the records
        # before acquisition against the text acquisition had just written for
        # the asked subject (measured: `computed_empty`, `debt.debt`,
        # `debt.factors.freshness` and `debt.scorers` moved). So when a seam ran,
        # the re-execution's registry is built from `before_acquisition`, with
        # the same parameters (the same effective request over the same pinned
        # artifacts), on an engine over the same reader. Only on this branch:
        # the served path keeps `operators`, so a subject Π does not withhold is
        # still scored against the text its own acquisition wrote. With no seam,
        # `view` is the state before acquisition and `operators` is already
        # built from it. Like the walk, this is exact only for an acquisition
        # keyed on the subject: under a population read a nonexistent subject's
        # question is scored against text the read wrote (measured; section 4.12).
        rendered = (
            (
                engine
                if before_acquisition is None
                else ProjectionEngine(
                    reader=self.fabric.handle.reader,
                    registry=build_operator_registry(
                        parameters=self.operator_parameters(effective_request),
                        view=before_acquisition,
                        pins=self.fabric.pins,
                        policy_bundle_key=self.policy_bundle_key,
                    ),
                )
            ).execute_without_request_seed(
                executed=execution,
                plan=plan,
                perspective=perspective,
                tenant_id=self.fabric.tenant_id,
                temporal_boundary=request.asked_at,
                before_acquisition=before_acquisition,
            )
            # SEC-020 Q10 (`D-IMPL-378`): ONLY a late withhold (inside the
            # projection) on a non-composite product is re-executed — the
            # re-execution `D-IMPL-371`/`376` authorized, not widened. Under the
            # early decision the one computation above already took the path a
            # nonexistent subject's question takes.
            if execution.projection.withheld and not undisclosed
            else execution
        )

        # `24.10-F-09` / `D-IMPL-308`. `decided_at` is bound ONCE — far above,
        # beside the temporal bound that judges it — and read FIVE times: the
        # product's expiry, the gate instant, the record's `recorded_at`, the
        # instant an instant-aware scorer measures freshness as of (`D-IMPL-343`
        # R-3c), and now the temporal bound itself. Five statements about the same
        # moment, and deriving them separately is how they drift apart.
        #
        # It used to be bound HERE, and the superseded reasoning is kept because
        # it names the constraint the move had to satisfy: *"hoisted above the
        # scorer call for that fourth reader; it reads only the two requests, so
        # nothing about the value moved."* That is still why moving it is safe —
        # it is a pure function of `request` and `effective_request`, and neither
        # is reassigned between the new binding site and this line. `D-IMPL-358`
        # step 5 ruling C moved it because the bound must judge the decision
        # instant BEFORE anything is acquired, and a second derivation here would
        # be a second chance to disagree with the instant that was judged.

        # `24.11-03` / `24.10-F-08`: hoisted out of the constructor because two
        # members are now derived from it — the assessment itself and the
        # obligation bound to the state it landed in — and scoring twice could
        # put a product's debt and its obligation on different sides of a band.
        # `D-IMPL-343` R-3c: an instant-aware scorer is asked FIRST and is
        # handed the decision instant and the admitted children (None for a
        # non-composite) — the widest seam, so a scorer declaring it is asked
        # through it. `D-IMPL-339`: a child-aware scorer receives the same view
        # the plan did, so the parent's own child-dependent `C` / `S` reach its
        # assessment per request; every other scorer is asked as before.
        #
        # ROUND 5 SDK LANE A (Dave 2026-10-11 20:19 MST ruling 1; CP08-R3-F-01):
        # evidence dated after the decision instant is a GOVERNED REFUSAL, never
        # an escaped exception. The decay module raises `TemporalOrderError`
        # rather than score the future as fresh, and that verdict stands — it is
        # recorded here, post-projection, with this execution's evidence and no
        # debt (none could be assessed). Exactly that error and nothing broader:
        # any other scorer failure is a wiring fault and still raises.
        try:
            if isinstance(self.debt_scorer, InstantAwareDebtScorerProtocol):
                assessed = self.debt_scorer.score_at(
                    view=rendered.view,
                    evidence=ExecutionEvidence.of(rendered),
                    decided_at=decided_at,
                    children=children,
                )
            elif children is not None and isinstance(self.debt_scorer, ChildAwareDebtScorerProtocol):
                assessed = self.debt_scorer.score_with_children(
                    view=rendered.view,
                    evidence=ExecutionEvidence.of(rendered),
                    children=children,
                )
            else:
                assessed = self.debt_scorer(
                    view=rendered.view, evidence=ExecutionEvidence.of(rendered)
                )
        except TemporalOrderError as future_dated:
            return self._record_refusal(
                envelope=envelope_for(
                    EvidenceAfterDecisionRefusal(
                        reason="evidence-after-decision",
                        detail=(
                            "the Context Debt cannot be assessed at the decision"
                            f" instant {decided_at.isoformat()}: {future_dated}"
                            " (CP08-R3-F-01; the evidence is neither excluded nor"
                            " scored as fresh)"
                        ),
                        decided_at=decided_at,
                    ),
                    request=identity,
                    pre_assembly_lineage=own_lineage,
                    policy_bindings=effective.applied,
                    evidence=RefusalEvidence(
                        operators_invoked=execution.operators_invoked,
                        plan_id=execution.plan_id,
                        debt=None,
                        computed_empty=ComputedEmptyFinding.of(
                            rendered,
                            emptiness=emptiness_of(ExecutionEvidence.of(rendered)),
                        ),
                    ),
                    provenance=effective,
                ),
                execution=execution,
                request=request,
                perspective=perspective,
                policy_bindings=self._applied_bindings(effective),
                resolution=effective,
                child_resolutions=walk_child_rows,
                served_at=served_at,
            )

        # --- composite assembly (`D-IMPL-336` Amendment 3, F0) -------------
        #
        # THE DECLARATION IS READ FROM THE REGISTERED CLASS. Until this block
        # existed the whole composite surface had no caller: a class could
        # declare `requires` and be served with no composition, no admission
        # and no replay rows — `D-IMPL-324`'s "declaration is not a door",
        # applied to an entire feature.
        #
        # `composed` stays None for every non-composite product, which is
        # every product shipped before this, and everything below is inert.
        #
        # `D-IMPL-339` split where a composition refusal is recorded. A KNOWN
        # BLOCKING outcome — a required child absent, an invoked child refused
        # or rejected at admission, no resolver wired — returned ABOVE, before
        # the plan, through the pre-assembly seam. What can still refuse HERE
        # is the composition of an admitted set — the mixing law — and that
        # refusal is carried, as before, to the same post-gate path a gate
        # refusal takes, so it and a TTL refusal are recorded by one mechanism.
        # --- `D-IMPL-339`: COMPOSE USING THE SAME ACQUIRED OUTCOMES ------------
        # `outcomes` is the one acquisition above; content (the view the plan
        # received) and governance (the laws applied here) refer to the same
        # admitted products. Nothing is re-acquired, looked up or rebuilt.
        # --- `D-IMPL-341`: THE TTL ANCHOR, RESOLVED ONCE FOR BOTH BRANCHES ----
        # The decision instant for a `from_decision` class; for a
        # `from_entity_freshness` class the freshest `valid-from` leading edge
        # over the SAME observations the freshness factor just scored — the
        # deployment's declared decay clock, read once more. Nothing here is
        # minted, read off a payload, or defaulted: a set with no usable
        # instant is gate 3's own refusal (R-3), recorded below with the
        # child rows a composite already resolved.
        anchor = resolve_ttl_anchor(
            ttl_anchor=registered.ttl_anchor,
            view=rendered.view,
            table=self._half_life_table(),
            decided_at=decided_at,
            product_class=registered.schema_name,
        )
        anchored_at = (
            anchor.anchor_at if isinstance(anchor, TTLAnchorResolution) else decided_at
        )
        if outcomes is not None:
            composed = compose_children(
                own_factors=assessed.factors,
                requirements=registered.requires,
                outcomes=outcomes,
                asked_at=request.asked_at,
                composition_invocation=invocation,
                own_lineage=own_lineage,
                max_ttl=MaxTTL(seconds=self.product_ttl_seconds),
                # `R6` — THE TTL ANCHOR IS `decided_at`, NOT `asked_at`.
                # The first version passed the reconstruction instant here
                # while the non-composite branch below anchored at the
                # decision instant, silently reverting `D-IMPL-308` for
                # composites only. Measured consequence: a class with a
                # declared decision instant served a SHORTER window as a
                # composite than as a plain product, and the two landed on
                # the same content address — two governed answers, one
                # identity. The anchor is the same instant on both
                # branches now, which is what `D-IMPL-308` says it is:
                # the TTL runs from when the answer was PRODUCED.
                ttl_anchor_at=anchored_at,
                # AND THE INSTANT THE COMPOSITION IS EVALUATED AT, for the
                # mixing law alone: how much validity a child has LEFT is a fact
                # about now, not about the parent's evidence (`D-IMPL-341`
                # review). `D-IMPL-358` step 5 section I made "now" literal —
                # this is `served_at`, the instant the answer is handed over,
                # and the parameter was renamed with the value so no variable
                # named `decided_at` carries it.
                evaluated_at=served_at,
                validity_floors=registered.constituent_validity_floors,
            )
            if composed is not None and composed.factors is not None:
                # `24.11-03`'s hazard, respected: the composed factors replace
                # the parent's own BEFORE `obligation_in_force` is derived
                # below, so a composite's reported debt and its obligation
                # cannot land on different sides of a routing band.
                #
                # `R2` — AND THE SIGNAL IS RE-DERIVED, not carried forward.
                # The first version of this block kept `signal=assessed.signal`
                # while replacing the debt and the factors, so a composite
                # whose composed D_c crossed fail-closed was served with
                # `signal=ok` and the routine obligation. The signal is the
                # thing the band is read from, so carrying the parent's own
                # made the comment above it false: re-deriving it from the
                # COMPOSED factors under the same profile is what makes the
                # claim true.
                assessed = self._reassess(composed.factors, fallback=assessed)

        # `D-IMPL-338`. THE CHILD EVIDENCE IS BOUND ONCE, HERE, AND READ BY
        # EVERY EXIT BELOW — the served record and all four post-acquisition
        # refusals. `CMP-R-01` widened the recorder seam and threaded the rows
        # through the served path and the COMPOSITION refusal only; the three
        # refusals that can follow a successful composition (universal gate,
        # declared product gate, tolerance) each called `_record_refusal`
        # without them, so a composite refused for excess INHERITED debt wrote
        # a record that did not say which children it inherited it from.
        # Enumerated rather than patched at the first omission found: every
        # refusal exit below this line passes `child_rows`,
        # and the two refusals ABOVE the composite block pass nothing — no
        # child was considered there, and `()` is the true claim rather than
        # an invented outcome.
        child_rows: tuple[ChildResolution, ...] = (
            composed.resolutions if composed is not None else ()
        )
        if isinstance(anchor, TTLAnchorRefusal):
            # A POST-PROJECTION REFUSAL, and recorded as one: the plan ran, the
            # projection produced the payload the anchor was read over, and
            # the debt was assessed on it. The record carries that execution's
            # evidence and the product's own lineage exactly as a gate refusal
            # does, so `replay_refusal` can re-execute the recorded path and
            # hold the refusal to it (`D-IMPL-344`). Measured 2026-09-18: the
            # first candidate recorded this refusal with neither, and the
            # reconstruction path refused the record as contradicting itself
            # — a plan named, no evidence of it.
            return self._record_refusal(
                envelope=envelope_for(
                    anchor,
                    request=identity,
                    pre_assembly_lineage=own_lineage,
                    policy_bindings=effective.applied,
                    evidence=RefusalEvidence(
                        operators_invoked=execution.operators_invoked,
                        plan_id=execution.plan_id,
                        debt=assessed,
                        computed_empty=ComputedEmptyFinding.of(
                            rendered,
                            emptiness=emptiness_of(ExecutionEvidence.of(rendered)),
                        ),
                    ),
                    provenance=effective,
                ),
                execution=execution,
                request=request,
                perspective=perspective,
                policy_bindings=self._applied_bindings(effective),
                resolution=effective,
                child_resolutions=child_rows,
                served_at=served_at,
            )

        candidate = ContextProductContract(
            schema_name=registered.schema_name,
            schema_version=registered.schema_version,
            plan_id=execution.plan_id,
            tenant_id=self.fabric.tenant_id,
            # THE BOUNDARY STAYS `asked_at` AND THE EXPIRY DOES NOT.
            # `temporal_boundary` is when the graph was observed; the TTL runs
            # from when the answer was PRODUCED (`24.10-F-09`, `D-IMPL-308`).
            # They are equal whenever a class declares no decision instant.
            temporal_boundary=request.asked_at,
            # `D-IMPL-336` F14: a composite's expiry is FLOORED by its
            # stalest admitted constituent, so it can never be labelled
            # fresher than the child it depends on. Non-composites keep the
            # declared window exactly as before.
            expires_at=(
                composed.expires_at
                if composed is not None and composed.expires_at is not None
                else anchored_at + timedelta(seconds=self.product_ttl_seconds)
            ),
            ttl_anchor=registered.ttl_anchor,
            # `D-IMPL-341` R-2: every new product states the instant its
            # anchor resolved to, on every class.
            ttl_anchor_at=anchor.anchor_at,
            # `D-IMPL-336` F14: and its lineage is the N-way set-union over
            # every admitted child's, so each constituent's provenance stays
            # resolvable from the composite.
            #
            # `D-IMPL-309`: the engine's store head is NOT sealed here. It is
            # execution provenance and it is recorded in replay dimension 1
            # from `execution.store_snapshot_pin`, so an ambient ledger
            # advancing between two runs of one governed question cannot mint
            # a second product identity (`MOD-05`).
            lineage=(
                composed.lineage
                if composed is not None and composed.lineage is not None
                else own_lineage
            ),
            payload=execution.projection.payload,
            # `24.10-F-08` / `D-IMPL-308`: the window this deployment DECLARED,
            # carried rather than dropped. Inside the content address, so a
            # deployment cannot add it afterwards.
            source_refresh_recency=self.source_refresh_recency,
            # 24.6-05 (`24.6-L-06`, `D-IMPL-255` (2)): the scorer is told what
            # the execution observed about its own search, so that D_c is
            # derived from evidence rather than from how many rows came back.
            debt=assessed,
            # `24.11-03` / `24.10-F-08`: the obligation this deployment's own
            # profile binds to the state `assessed` landed in. Derived from
            # THAT assessment rather than from a second scoring call — the
            # product must not be able to carry an obligation bound to a
            # routing state other than the one it reports.
            obligation_in_force=self._obligation_in_force(assessed.signal),
            # 24.6-05 (`D-IMPL-242` amendment 1, `D-IMPL-253` Q11/Q12): an
            # operator that RAN and returned nothing computed something, so
            # its emptiness is served as a finding rather than refused on
            # cardinality. `None` when no operator returned empty — the claim
            # every product made before this field existed.
            computed_empty=ComputedEmptyFinding.of(
                rendered,
                emptiness=emptiness_of(ExecutionEvidence.of(rendered)),
            ),
        )

        # `R4`, the other half. Widening Gate 2's operand for composites opens
        # a hole unless the parent's OWN declaration is held to its OWN
        # execution first: if the engine ran operator X while the class
        # declared only Y, and a child happens to invoke X, then X is on both
        # sides of the widened comparison and the parent's drift is masked.
        #
        # So the two halves are checked separately and both strictly. This one
        # is the pre-composition question — "did THIS fabric run what THIS
        # class declared" — and it is exactly what Gate 2 asked before
        # composites existed, which is why the refusal is the same type with
        # the same gate identifier and reaches the caller identically.
        #
        # Proven by sabotage: `test_r4_the_union_CANNOT_mask_the_parents_own_
        # declaration_drifting` perturbs the engine's set and gives the child
        # precisely the drifted operator.
        own_declared = frozenset(required)
        drifted: GateRefusal | None = (
            LineageMismatchRefusal(
                gate=GATE_LINEAGE_EQUALITY,
                detail=(
                    f"composite {registered.schema_name!r} declares operators "
                    f"{sorted(own_declared)} but its own engine resolved "
                    f"{sorted(execution.operators_invoked)}; a composite's "
                    "admitted children widen what the composition resolved, "
                    "never what the parent itself declared, so this half stays "
                    "strict in both directions (INV-CH7-47, D-IMPL-336 R4)"
                ),
                declared=own_declared,
                resolved=execution.operators_invoked,
            )
            if composed is not None and own_declared != execution.operators_invoked
            else None
        )

        gated: ServableProduct | GateRefusal
        if drifted is not None:
            gated = drifted
        else:
            gated = run_gates(
                candidate,
                # `R4` — THE COMPOSITE'S ENGINE-RESOLVED SET INCLUDES ITS ADMITTED
                # CHILDREN'S OPERATORS. **PROPOSED reading of INV-CH7-47, pending
                # Dave's ruling at `D-IMPL-336` checkpoint 1.**
                #
                # Gate 2 compares the candidate's declared operators against what
                # the engine resolved, by strict equality in both directions. A
                # composite's lineage is the `D-IMPL-31` N-way union, which
                # includes every admitted child's operators — and this fabric's
                # engine never ran those, because the child did. So before this
                # line a composite could serve only while every child invoked a
                # SUBSET of the parent's own operators, which a real child of a
                # different class never does: it exists to answer a different
                # question. Measured, with the control, at
                # `test_r4_a_composite_serves_with_a_child_that_ran_ITS_OWN_operators`.
                #
                # The two obvious alternatives each break a standing ruling — a
                # subset check abandons INV-CH7-47's strictness, and declaring
                # only the parent's own operators abandons `D-IMPL-31`'s union —
                # so the operand widens instead, and Gate 2 itself is untouched.
                # Each child's set is engine-resolved evidence: it passed that
                # child's own Gate 2 at its own delivery.
                #
                # Strictly additive for every non-composite: `composed` is None,
                # the union is with `frozenset()`, and the operand is the value it
                # has always been.
                engine_resolved=execution.operators_invoked
                | (composed.admitted_operators if composed is not None else frozenset()),
                # `D-IMPL-358` step 5 section H: GATE 3 ASKS ABOUT THE MOMENT OF
                # SERVICE. The comparand was `decided_at`, on the reasoning that
                # the expiry RUNS FROM the decision instant (`D-IMPL-308`) — which
                # is true of how `expires_at` is COMPUTED and is a different
                # question from the one the gate ASKS.
                #
                # The gate holds `now < expires_at <= now + MAX_TTL`, and the
                # inequality stays two-sided. Both bounds are statements about the
                # CONSUMER's moment, not the fabric's:
                #
                #   * lower — a product whose expiry already passed between being
                #     decided and being handed over must not be served. Judged at
                #     `decided_at` this was blind to exactly the gap `served_at`
                #     exists to name;
                #   * upper — a product may not promise more than MAX_TTL of life
                #     measured from when the consumer receives it. Judged at
                #     `decided_at` a child answering a question a DAY out fit a
                #     ceiling drawn from its own future decision.
                #
                # `served_at` on a refusal RECORD is not this: the record says when
                # the determination happened; this is the instant the bound is
                # applied at. Both were needed and only the first had landed.
                now=served_at,
                registry=self.control_plane,
                product_class=registered,
                source_attestation=execution.source_attestation,
                # `D-IMPL-334`: the entities this execution actually read — the same
                # value replay dimension 1 records. The gate asks whether any of
                # them moved after the snapshot this product was built at.
                touched_entities=rendered.touched_entities(),
            )
        # 24.6-03/24.6-07: every source the resolution consulted, by exact
        # `(key, version)`. Derived ONCE and shared by the served record and
        # every refusal record below — two derivations would let a refused
        # decision and a fulfilled one disagree about what governed them.
        applied = self._applied_bindings(effective)
        # 24.6-07: what the fabric is PERMITTED to show of the search behind a
        # post-assembly refusal. The candidate's own facts, read off the same
        # execution the served product would have been recorded from — never
        # re-derived, so a refusal shell cannot describe a different search
        # from the one that ran.
        evidence = RefusalEvidence(
            operators_invoked=execution.operators_invoked,
            plan_id=execution.plan_id,
            debt=candidate.debt,
            computed_empty=candidate.computed_empty,
        )
        # `D-IMPL-336` Amendment 3, F0: a composition refusal is recorded by
        # the SAME mechanism a gate refusal is, and BEFORE the universal gates
        # report on a candidate whose children never arrived. Placed here
        # rather than at the composition itself so one refusal path serves
        # both, and so the refusal travels with the candidate's own lineage
        # and evidence exactly as a TTL refusal does.
        if composed is not None and composed.refusal is not None:
            return self._record_refusal(
                # `CMP-R-01` CLOSED. `compose_children` builds a row for every
                # requirement and this path used to drop them, because the
                # recorder is a public seam that had no parameter for them —
                # so the one case where a reader most needs to know WHICH child
                # failed was the case the record did not say. The seam was
                # widened under Amendment 5 §5, with the surface recorded
                # first; the rows travel now.
                envelope=envelope_for(
                    composed.refusal,
                    request=identity,
                    pre_assembly_lineage=candidate.lineage,
                    policy_bindings=effective.applied,
                    evidence=evidence,
                    provenance=effective,
                ),
                execution=execution,
                request=request,
                perspective=perspective,
                policy_bindings=applied,
                resolution=effective,
                child_resolutions=child_rows,
                served_at=served_at,
            )

        if not isinstance(gated, ServableProduct):
            # A refusal is a value, and it travels with the lineage the
            # candidate claimed — a gate refusal has a candidate behind it, so
            # saying it has no lineage would be a different and false claim.
            return self._record_refusal(
                envelope=envelope_for(
                    gated,
                    request=identity,
                    pre_assembly_lineage=candidate.lineage,
                    policy_bindings=effective.applied,
                    evidence=evidence,
                    provenance=effective,
                ),
                execution=execution,
                request=request,
                perspective=perspective,
                policy_bindings=applied,
                resolution=effective,
                # `D-IMPL-338`: the children this candidate was composed from.
                child_resolutions=child_rows,
                served_at=served_at,
            )

        # `24.10-02` / `R-11` (`D-IMPL-282` option 1a), and the placement is
        # the ruling: *"It executes after candidate construction and before
        # fitness/fulfillment."* The universal gates have ADMITTED this
        # product, so there is something to hold an invariant against; the
        # tolerance comparison below has not run, so a product that is WRONG
        # is reported as wrong rather than as unfit. Two different questions,
        # and the order between them is what keeps them two.
        #
        # The identity is read from the Control Plane and stamped here. The
        # deployment's callable returns a detail string and nothing else, so a
        # gate cannot claim to be a different gate than the one its class
        # declared — which is what makes `D-14`'s "which gate produced the
        # refusal" a fact rather than a claim the failing code made about
        # itself.
        if self.product_gate is not None:
            # `D-IMPL-347` A2: the gate is a deployment seam. A gate that
            # RETURNS a violation string already refuses through the branch
            # below; this catches the gate that RAISES a governed refusal —
            # previously a traceback, now data attributable to `product_gate`.
            try:
                gate_violation = self.product_gate(
                    candidate=gated.product, evidence=ExecutionEvidence.of(rendered)
                )
            except GovernedRefusalRaised as raised:
                return self._refuse_raised_at_seam(
                    raised, seam="product_gate", request=request,
                    identity=identity, perspective=perspective,
                    effective=effective,
                    served_at=served_at,
                )
            except Exception as error:  # noqa: BLE001 — re-raised unless DECLARED
                binding = self._declared_seam_refusal(error)
                if binding is None:
                    raise
                return self._refuse_declared_at_seam(
                    error, binding, seam="product_gate", request=request,
                    identity=identity, perspective=perspective,
                    effective=effective,
                    served_at=served_at,
                )
            if gate_violation:
                declared_gate = self._declaration().declared_product_gate
                return self._record_refusal(
                    # `evidence`, `applied` and `effective` are the values
                    # derived ONCE above the gate branch and shared by every
                    # post-assembly refusal. Deriving them again here would let
                    # a refused determination and a fulfilled one disagree
                    # about what governed them, which is the comment already
                    # standing at that site.
                    envelope=envelope_for(
                        ProductInvariantRefusal(
                            gate=declared_gate.gate_id,
                            gate_version=declared_gate.gate_version,
                            detail=gate_violation,
                        ),
                        request=identity,
                        pre_assembly_lineage=candidate.lineage,
                        policy_bindings=effective.applied,
                        evidence=evidence,
                        provenance=effective,
                    ),
                    execution=execution,
                    request=request,
                    perspective=perspective,
                    policy_bindings=applied,
                    resolution=effective,
                    # `D-IMPL-338`: the children this candidate was composed from.
                    child_resolutions=child_rows,
                    served_at=served_at,
                )

        # 24.6-04, the delivery boundary: the gates ADMITTED this product, and
        # only now is it held to the one applicable tolerance — the class's
        # default, the caller's own value or a policy's, folded exactly once
        # upstream by the Authority layer with the authority that set it
        # recorded (`D-IMPL-254`). Nothing is folded here, because a second
        # fold is the scalar collapse this phase removed and the place a class
        # preference could re-acquire the power `D-IMPL-251` C1 took from it.
        # The product was constructible; what is withheld is fulfillment.
        # Nothing about the principal or the perspective reaches this
        # comparison (`D-IMPL-105`): D_c is entitlement-neutral, as assessed.
        #
        # SEC-019 (`D-IMPL-356` D11): the step is also handed the POLICY bound
        # the Authority layer reported on the tolerance, read off the record.
        # A completed resolution never leaves a policy-bounded tolerance
        # absent — it refused that as `required-absent` before anything was
        # read — so for an absent tolerance the bound is `None` here by
        # construction, and the step's own refusal of that case (a
        # pre-assembly kind) is never handed to the recorder below.
        resolved_tolerance = effective.parameter(DEBT_TOLERANCE_PARAMETER)
        withheld = refuse_over_tolerance(
            gated,
            tolerance=resolved_tolerance,
            policy_bound=(
                resolved_tolerance.bound
                if resolved_tolerance is not None
                and resolved_tolerance.bound is not None
                and resolved_tolerance.bound.authority == "policy"
                else None
            ),
        )
        if withheld is not None:
            return self._record_refusal(
                envelope=envelope_for(
                    withheld,
                    request=identity,
                    pre_assembly_lineage=candidate.lineage,
                    policy_bindings=effective.applied,
                    evidence=evidence,
                    provenance=effective,
                ),
                execution=execution,
                request=request,
                perspective=perspective,
                policy_bindings=applied,
                resolution=effective,
                # `D-IMPL-338`: a tolerance refusal is the case that most needs
                # its children named — the debt it refused on is inherited.
                child_resolutions=child_rows,
                served_at=served_at,
            )

        record = build_replay_record(
            execution=execution,
            product=gated.product,
            perspective=perspective,
            policy_bindings=(
                PolicyBinding(key=self.policy_bundle_key, version=policy_version),
                *applied,
                # `D-IMPL-341` R-5: an evidence-anchored serve pins the λ_c
                # table it anchored under, so replay re-derives the anchor
                # under the same declarations, never today's.
                *self._ttl_anchor_pins(anchor),
                # `D-IMPL-358` step 5 area 8: the temporal policy that governed
                # this serve, pinned by its EXACT resolved version. `.binding` and
                # never a `PolicyBinding(key, version)` rebuilt here — rebuilding
                # is how a reconstructed version gets in, which is the step-3
                # defect this pin exists to make load-bearing.
                *temporal_pins,
                # `D-IMPL-378` C1: the declared demonstration serve instant this
                # decision was served at, by its exact version — empty on every
                # serve on a real clock, so those records are byte-identical to
                # the ones written before the declaration existed.
                *self._demonstration_pins(),
            ),
            assembly_mode=registered.assembly_mode,
            # WHEN THE DECISION WAS TAKEN, not when the graph was read
            # (`D-IMPL-308`). Dimension 5 already carries `asked_at` on the
            # request it holds, so the record says both rather than one twice.
            recorded_at=decided_at,
            # `D-IMPL-358` step 4. A THIRD instant, and the record now says all
            # three rather than one of them twice: `request.asked_at` is what the
            # question asks as of, `recorded_at` is when the decision was taken,
            # and this is when the answer was handed over. `recorded_at` is
            # deliberately untouched.
            served_at=served_at,
            request=request,
            # 24.6-07: the assembler in force, on the served path and on every
            # refusal path alike (`D-IMPL-253` Q16). This resolver holds no
            # `ContextAssemblerProtocol` — it composes assemble → gate → serve
            # itself — so it passes `None` and lets dimension 4's
            # `NO_ASSEMBLER` sentinel say exactly that, rather than inventing
            # an identity for a collaborator that does not exist. A resolver
            # that DOES hold one wires its own id and version here.
            assembler_id=self._assembler_id(),
            assembler_version=self._assembler_version(),
            # `D-IMPL-336` Amendment 3, F0 — the per-child rows, GENERATED
            # FROM EXECUTION. Empty for every non-composite decision, which is
            # what keeps those records byte-identical to the ones written
            # before this surface existed.
            child_resolutions=child_rows,
            # `D-IMPL-385`: dimension 4 names the composing agent and the
            # skill-set it held; `None` (the no-agent claims) for a decision no
            # agent composed.
            agent_conditioning=self._agent_conditioning(perspective),
            # 24.6-03: what was resolved, and on whose authority — dimension 2,
            # beside the versions it was resolved from (`D-IMPL-254`).
            resolution=effective,
            # §7.10.4's Mode 2 pins, from the deployment that did the
            # packaging. `None` for Mode 1, and `build_replay_record` then
            # keeps the no-packaging sentinel.
            packaging_trace=(
                self.packaging_trace(product=gated.product)
                if self.packaging_trace is not None
                else None
            ),
            # Dave's Q11 (`D-IMPL-378`): the answer is issued under a fresh
            # identifier, so its record is unique per answer and the
            # `replay_ref` every door hands out reflects nothing it read.
            issuance=new_issuance(),
            # Dave's Q12: what the class affirms, which the governed evidence
            # read requires before the owner reads this record back.
            subject_withholding=self._declaration().subject_withholding,
        )
        return serve(
            product=gated,
            record=record,
            replay_writer=ReplayWriter(
                authorized=self._authorities.replay, store=self.artifact_store
            ),
            query_pin_writer=QueryPinWriter(
                authorized=self._authorities.query_pin, store=self.artifact_store
            ),
            executed_queries=execution.executed_queries,
        )

    def _retain_child_contracts(
        self, contracts: Iterable[ContextProductContract]
    ) -> None:
        """File each admitted child's contract by content address (`D-IMPL-339`).

        Nothing else retains a served product's bytes — the writer files the
        record and the query pins, never the product — so the parent's
        child-contract view would be unrebuildable after the fact. Filed under
        :data:`~ccf.products.composite.ADMITTED_CHILD_CONTRACT_CLASS` on this
        fabric's own store, idempotently: the address IS the identity, and a
        second composition consuming the same child files nothing twice.

        Takes the admitted **contracts** and not a
        :class:`~ccf.products.composite.ChildContractView` (`D-IMPL-344`): the
        view exists only for a composition that reached no refusal, while
        retention follows admission on every exit. The caller hands over
        exactly what :func:`~ccf.products.composite.resolve_child_outcomes`
        admitted, so nothing that was refused, rejected, absent or unreachable
        can arrive here.

        The store's address for the bytes must equal
        :func:`~ccf.contracts.canonical.content_hash` of the contract — the
        same address the child row records — or replay could not resolve the
        row to the bytes. A store that hashed differently is refused here,
        loudly, rather than discovered at replay.

        **The store is handed a deep copy of each contract, taken before**
        ``put`` (``D-IMPL-380``, third round, ruling 2 (a), 2026-10-10 09:18
        MST), and the resolver keeps its own: the contracts in
        ``resolved.admitted``, from which ``child_contract_view(resolved)`` —
        the parent's view — is built. ``ContextProductContract.payload``
        validates to a live ``dict``, so a store that wrote into the mapping it
        was handed and answered the right address would otherwise have its
        alteration reach the parent under a child row that names the address
        as admitted. The content-address check (the paragraph above) is
        unchanged. The saved-bytes limit stands: such a store files altered
        bytes under the original's address, and nothing here re-reads what it
        filed; replay, which re-hashes what it fetches, finds the difference.
        """
        for contract in contracts:
            address = content_hash(contract)
            if self.artifact_store.exists(content_address=address):
                continue
            # A derived write under the composition-minted capability
            # (D-IMPL-353 §1.2): the class is the SDK's, the name is the
            # contract's own address, the tenant is the capability's.
            filed = self.artifact_store.put(
                self._authorities.admitted_child,
                DerivedWrite(
                    artifact_class=ADMITTED_CHILD_CONTRACT_CLASS,
                    name=address,
                    # A deep copy taken now, before the save; the resolver keeps
                    # its own contract (`D-IMPL-380`, third round, ruling 2 (a);
                    # Dave, 2026-10-10 09:23 MST: *"The parent is built from
                    # contracts the store never held."*).
                    artifact=contract.model_copy(deep=True),
                ),
            )
            if filed.content_address != address:
                raise RuntimeError(
                    "the artifact store filed an admitted child contract at"
                    f" {filed.content_address!r} but its content address is"
                    f" {address!r}; replay resolves child rows by content"
                    " address and this store would break that (D-IMPL-339)"
                )

    # --- the one minting seam ----------------------------------------------

    def _invoke_acquisition(
        self,
        invoke: Callable[[], None],
        *,
        request: ProductRequest,
        identity: RequestIdentity,
        perspective: Perspective,
        effective: EffectiveRequest,
        served_at: datetime,
    ) -> RefusalEnvelope | None:
        """Run the population phase; a held refusal comes back as data (SEC-020 Q7).

        The conversion the subject-keyed phase gets inline in :meth:`__call__`:
        `D-IMPL-304`'s held determination is recorded through this
        composition's ONE minting seam and returned as data, `D-IMPL-347` B2's
        declared types convert, and any other exception re-raises unchanged.
        Recorded at the one ``acquisition`` seam: the two phases are two
        declared halves of one seam.
        """
        try:
            invoke()
        except GovernedRefusalRaised as raised:
            return self._refuse_raised_at_seam(
                raised, seam="acquisition", request=request, identity=identity,
                perspective=perspective, effective=effective, served_at=served_at,
            )
        except Exception as error:  # noqa: BLE001 — re-raised unless DECLARED
            binding = self._declared_seam_refusal(error)
            if binding is None:
                raise
            return self._refuse_declared_at_seam(
                error, binding, seam="acquisition", request=request,
                identity=identity, perspective=perspective, effective=effective,
                served_at=served_at,
            )
        return None

    def _refuse_a_population_read_in_the_subject_keyed_phase(
        self,
        asked: ProductRequest,
        *,
        perspective: Perspective,
        before: GraphView,
        at: datetime,
    ) -> GovernedRefusalRaised | None:
        """Ask the subject-keyed phase about :data:`UNHELD_SUBJECT_PROBE`; refuse if the fabric then reads otherwise.

        ``D-IMPL-378`` ruling P6 (a) (:class:`PopulationReadInSubjectKeyedPhase`).
        Called by :meth:`__call__` after the read route A renders over and
        BEFORE the phase is handed the question's subject. The probe is
        ``asked`` with :data:`UNHELD_SUBJECT_PROBE` in place of its subject —
        every parameter and the instant as the question carries them, under the
        same perspective — so what the phase acquires for it is what it acquires
        for an identifier its sources do not hold. A held refusal
        (``GovernedRefusalRaised``, or a type the class or the SDK declares at
        this seam) refuses the question (OWED-RULINGS-3 item 4 (b)): such a
        source refuses an identifier nothing holds where a subject withheld
        inside the projection is answered. What is returned then is the SDK's
        one constant, :data:`UNHELD_SUBJECT_PROBE_REFUSAL`, which :meth:`__call__`
        records at the ``acquisition`` seam and answers with — so a refusal the
        question decided keeps its decision record, and nothing the source said
        is kept (``D-IMPL-378`` repair 2.3 (b)); ``None`` when the probe passes.
        Any other exception propagates, as the phase's own would. Nothing here
        reads the asked subject.

        Dave's condition, *"Verify that the fixed identifier is actually
        absent; do not assume it"*: a fabric that names the probe identifier
        before the call is refused before the phase is asked anything, and one
        that names it after the call — the phase's source holds the identifier,
        so what it acquired is not a population read's evidence — is refused
        before the comparison is read; both as :class:`UnheldSubjectProbeIsHeld`.
        """
        assert self.acquisition is not None  # the caller tested it
        if _names(before, UNHELD_SUBJECT_PROBE):
            raise UnheldSubjectProbeIsHeld(self._probe_identifier_is_held("before the probe"))
        probe = asked.model_copy(update={"subject": UNHELD_SUBJECT_PROBE})
        try:
            self.acquisition(request=probe, perspective=perspective)
        except GovernedRefusalRaised as raised:
            # OWED-RULINGS-3 item 4 (b) (Dave, 2026-10-09 06:21 MST), as repaired
            # by 2.3 (b) (10:54 MST): a held refusal from the probe call itself
            # refuses the question, RECORDED as the SDK's one constant.
            return self._refused_at_the_probe(raised)
        except Exception as error:  # noqa: BLE001 — re-raised unless DECLARED
            if self._declared_seam_refusal(error) is None:
                raise
            return self._refused_at_the_probe(None)
        after = self.fabric.handle.reader.as_of(tenant_id=self.fabric.tenant_id, at=at)
        if _names(after, UNHELD_SUBJECT_PROBE):
            raise UnheldSubjectProbeIsHeld(self._probe_identifier_is_held("after the probe"))
        if after != before:
            raise PopulationReadInSubjectKeyedPhase(
                "the subject-keyed acquisition phase acquired content when asked"
                f" about {UNHELD_SUBJECT_PROBE!r}, an identifier that names"
                " nothing, so a subject withheld inside the projection would be"
                " rendered over a fabric a nonexistent subject's question is not"
                " answered over; declare that read as the population phase"
                " (open_product(population=...), or"
                " GovernedResolver(population_acquisition=...)), declare an early"
                " policy, or affirm subject_withholding:"
                f" {SUBJECT_WITHHOLDING_NEVER!r} (SEC-020; D-IMPL-378 ruling P6 (a))"
            )
        return None

    def _refuse_a_stand_in_that_names_something(
        self,
        stand_in: str,
        effective_request: ProductRequest,
        *,
        perspective: Perspective,
        before: GraphView,
        at: datetime,
    ) -> None:
        """Verify the declared stand-in names nothing before acquisition; refuse if it does.

        ``D-IMPL-378`` decision 4 (a) (:class:`UndisclosedSubjectSubstituteIsHeld`).
        Called by :meth:`__call__` for EVERY question of a class with a declared
        early policy, whatever the policy decides for the asked subject, after
        the read route A takes and BEFORE the subject-keyed phase is handed
        anything for the question. Nothing here reads the asked subject: every
        request it hands the phase is the question's effective request with an
        identifier the SDK chose in place of the subject, under the same
        perspective, so whether it refuses — and its one message — is the same
        for every subject.

        1. The fabric as read before (``before``) must not name the stand-in.
        2. The phase is asked about :data:`UNHELD_SUBJECT_PROBE` and the fabric
           is read again (``baseline``): what the phase acquires for an
           identifier that names nothing — nothing, for a source keyed on the
           subject; the same content as for any identifier, for a read that
           does not depend on what is asked.
        3. The phase is asked about the stand-in and the fabric is read again
           (``after``): neither read may name it, and ``after`` must hold what
           ``baseline`` holds — the phase acquired nothing for the stand-in that
           it did not acquire for an identifier that names nothing. Held as
           entities, relationships and claim values with delivery lineage set
           aside (:func:`_held_content`; ``D-IMPL-378`` repair 1.3), so a
           delivery that only re-delivers under its own envelope id or receipt
           instant is not a difference, and every other one is.

        A held refusal from either call (``GovernedRefusalRaised``, or a type
        the class or the SDK declares at this seam) acquires nothing, which is
        how a source may answer an identifier it does not hold; under an early
        policy the withheld subject's own question is asked as the stand-in, so
        such a source refuses it as it refuses any unheld identifier. Any other
        exception propagates, as the phase's own would.
        """
        if _names(before, stand_in):
            raise UndisclosedSubjectSubstituteIsHeld(self._stand_in_is_held())
        if self.acquisition is None:
            return
        baseline = self._acquired_for(effective_request, UNHELD_SUBJECT_PROBE, perspective=perspective, at=at)
        after = self._acquired_for(effective_request, stand_in, perspective=perspective, at=at)
        if (
            _names(baseline, stand_in)
            or _names(after, stand_in)
            or _held_content(after) != _held_content(baseline)
        ):
            raise UndisclosedSubjectSubstituteIsHeld(self._stand_in_is_held())

    def _acquired_for(
        self, effective_request: ProductRequest, identifier: str, *, perspective: Perspective, at: datetime
    ) -> GraphView:
        """Ask the subject-keyed phase about ``identifier`` in place of the subject; the fabric as read after.

        ``D-IMPL-378`` decision 4 (a)'s one call to the phase and its one read.
        A held refusal acquires nothing; any other exception propagates.
        """
        assert self.acquisition is not None  # the caller tested it
        try:
            self.acquisition(
                request=effective_request.model_copy(update={"subject": identifier}),
                perspective=perspective,
            )
        except GovernedRefusalRaised:
            pass
        except Exception as error:  # noqa: BLE001 — re-raised unless DECLARED
            if self._declared_seam_refusal(error) is None:
                raise
        return self.fabric.handle.reader.as_of(tenant_id=self.fabric.tenant_id, at=at)

    @staticmethod
    def _under_the_early_policy(raised: GovernedRefusalRaised | None) -> GovernedRefusalRaised:
        """What the subject-keyed phase's refusal becomes under a declared early policy: :data:`EARLY_POLICY_ACQUISITION_REFUSAL`.

        ``D-IMPL-378`` repair 2.2 (a). Whatever the phase raised — its kind,
        cause, code, text, an envelope its raiser recorded — is replaced by the
        SDK's one constant refusal, which this resolver records as it records
        any refusal raised at the seam. A raiser that states
        :class:`~ccf.replay.record.ResolutionNotApplicable` is kept, so
        :meth:`_refuse_raised_at_seam` refuses that programming error by its own
        message as it does under every other policy.
        """
        if raised is not None and isinstance(raised.resolution, ResolutionNotApplicable):
            return raised
        return GovernedRefusalRaised(EARLY_POLICY_ACQUISITION_REFUSAL, resolution=RESOLVED_BY_THE_RESOLVER)

    @staticmethod
    def _stand_in_is_held() -> str:
        """The one message :class:`UndisclosedSubjectSubstituteIsHeld` carries, whatever was asked and whichever check failed."""
        return (
            "the identifier this class's early policy asks in place of a subject it"
            " does not disclose names something here: the fabric names it, or the"
            " subject-keyed acquisition phase acquires for it what it does not"
            f" acquire for {UNHELD_SUBJECT_PROBE!r}, an identifier that names"
            " nothing; declare a stand-in that no source, child or fabric of this"
            " deployment holds (SEC-020; D-IMPL-378 decision 4 (a))"
        )

    @staticmethod
    def _refused_at_the_probe(raised: GovernedRefusalRaised | None) -> GovernedRefusalRaised:
        """What a held refusal at the P6 probe becomes: :data:`UNHELD_SUBJECT_PROBE_REFUSAL`, for :meth:`__call__` to record.

        ``D-IMPL-378`` OWED-RULINGS-3 item 4 (b), as repaired by 2.3 (b).
        Whatever the phase raised for the probe identifier — its kind, cause,
        code, text, an envelope its raiser recorded — is replaced by the SDK's
        one constant. A raiser that states
        :class:`~ccf.replay.record.ResolutionNotApplicable` is kept, so
        :meth:`_refuse_raised_at_seam` refuses that programming error by its own
        message, as it does at every other seam.
        """
        if raised is not None and isinstance(raised.resolution, ResolutionNotApplicable):
            return raised
        return GovernedRefusalRaised(UNHELD_SUBJECT_PROBE_REFUSAL, resolution=RESOLVED_BY_THE_RESOLVER)

    @staticmethod
    def _probe_identifier_is_held(when: str) -> str:
        """The one message :class:`UnheldSubjectProbeIsHeld` carries, naming only WHEN the fabric named it."""
        return (
            f"the fabric as read {when} names {UNHELD_SUBJECT_PROBE!r}, the"
            " identifier the subject-keyed acquisition phase is asked about as one"
            " that names nothing, so its answer cannot show what the phase acquires"
            " for an identifier its sources do not hold; nothing in this deployment"
            " may be named by it (SEC-020; D-IMPL-378 ruling P6 (a))"
        )

    def _declared_seam_refusal(
        self,
        error: BaseException,
        *,
        _sdk_seam_refusals: Mapping[str, SeamRefusalBinding] = SDK_SEAM_REFUSALS,
    ) -> SeamRefusalBinding | None:
        """The binding for ``error``'s type, or ``None`` to re-raise.

        `D-IMPL-347` B2, amended by `D-IMPL-357` B3. **Matched, never imported**:
        the raised value's own ``module.QualName`` is compared against the
        declared string, so a declaration cannot cause an import and a misspelled
        one never matches rather than executing something.

        **Exact type, never a subclass walk.** A subclass of a declared type is
        a DIFFERENT failure the product has not spoken about, and silently
        inheriting a parent's cause is how a narrow declaration becomes a wide
        one without anybody widening it. The deployment declares what it means.
        That holds for the mechanism map below too: it is consulted by exact
        name, so a subclass of an SDK seam class is not converted either.

        :data:`SDK_SEAM_REFUSALS` is consulted **first**, because the SDK owns
        the meaning of the exceptions the SDK raises — that is the whole of B3's
        amendment. Read that constant for what its narrowness is and is not: it
        is not a trust boundary, and the honest statement of its three real
        mechanisms is there. A class that declares a binding for one of those
        types does not override it: the SDK's cause and code are minted, and the
        class's restatement is not reachable.

        **The map is bound at DEFINITION time, not read at call time.** The
        private ``_sdk_seam_refusals`` parameter is never passed by any caller;
        its default captures the mapping object once, when this method is
        defined, so rebinding ``ccf.products.resolver.SDK_SEAM_REFUSALS`` after
        import cannot change what this dispatch consults. That closes the one
        widening route a module global has and costs nothing — the matching
        semantics are unchanged, and it is deliberately NOT presented as a trust
        boundary: code inside this process can still reach the bound object
        itself, and the constant's own comment says so. A control pins the
        rebind.
        """
        raised = f"{type(error).__module__}.{type(error).__qualname__}"
        if (mechanism := _sdk_seam_refusals.get(raised)) is not None:
            return mechanism
        for binding in self._declaration().seam_refusals:
            if binding.exception == raised:
                return binding
        return None

    def _refuse_declared_at_seam(
        self,
        error: BaseException,
        binding: SeamRefusalBinding,
        *,
        seam: str,
        request: ProductRequest,
        identity: RequestIdentity,
        perspective: Perspective,
        effective: EffectiveRequest,
        served_at: datetime,
    ) -> RefusalEnvelope:
        """Mint the refusal the class declared for ``error``, at ``seam``.

        The cause and the code are the PRODUCT's statement; the detail is the
        exception's own message, unedited — the SDK does not paraphrase a
        failure it did not diagnose. A ``source-unavailable`` cause mints a
        :class:`~ccf.products.refusal.SourceUnavailableRefusal`, which says
        nothing about the subject; any other cause, a
        :class:`~ccf.products.refusal.SubjectUnavailableRefusal` (`CP06C-F-06`).
        """
        detail = str(error) or type(error).__name__
        refusal: SourceUnavailableRefusal | SubjectUnavailableRefusal
        if binding.cause == "source-unavailable":
            refusal = SourceUnavailableRefusal(detail=detail, error_code=binding.error_code)
        else:
            refusal = SubjectUnavailableRefusal(
                cause=binding.cause, detail=detail, error_code=binding.error_code
            )
        return self._refuse_raised_at_seam(
            GovernedRefusalRaised(refusal, resolution=RESOLVED_BY_THE_RESOLVER),
            seam=seam,
            request=request,
            identity=identity,
            perspective=perspective,
            effective=effective,
            served_at=served_at,
        )

    def _refuse_raised_at_seam(
        self,
        raised: GovernedRefusalRaised,
        *,
        seam: str,
        request: ProductRequest,
        identity: RequestIdentity,
        perspective: Perspective,
        effective: EffectiveRequest,
        served_at: datetime,
    ) -> RefusalEnvelope:
        """The typed handoff caught at a DEPLOYMENT-SUPPLIED seam.

        `D-IMPL-304` opened this for ``acquisition``; `D-IMPL-347` A2 (Dave,
        2026-09-23) widened it to the other three seams a deployment supplies —
        ``build_children``, ``plan_factory`` and ``product_gate`` — because the
        narrow scope was itself the defect: `CLD-F-06` measured the RIGHT
        exception raised from the WRONG seam escaping as a traceback, and
        cp-20 worked around it by moving an envelope check into ``acquire``.

        **Each seam is wrapped individually and NEVER the whole resolve.** A
        blanket ``try`` would convert a ``GovernedRefusalRaised`` escaping from
        deep inside the SDK into a plausible-looking governed "no" — an SDK
        defect wearing a refusal's clothes. These four are exactly the
        callables the deployment supplies, which is the whole reason their
        refusals are data rather than defects.

        ``seam`` is recorded on dimension 5 and is one of
        :data:`~ccf.replay.record.REFUSAL_SEAMS`. Without it the four wraps
        collapse into one undifferentiated "no" and A2 is un-auditable.

        The resolution completed before the seam ran — that is the seam's
        contract — so dimension 2 carries THIS resolver's evidence, which is
        the truth about what governance resolved, and the raiser's stated
        state is held to it: :data:`~ccf.products.refusal.RESOLVED_BY_THE_RESOLVER`
        or the same evidence are consistent; an explicit not-applicable marker
        is a contradiction (resolution DID run) and is refused as the
        programming error it is rather than recorded as a false statement.
        An envelope the raiser had already recorded passes through; a bare
        refusal is enveloped with the request identity and the resolution
        provenance exactly as the resolver's own pre-view refusals are.
        """
        if isinstance(raised.resolution, ResolutionNotApplicable):
            raise TypeError(
                f"a GovernedRefusalRaised at the {seam} seam states"
                " ResolutionNotApplicable, but this resolver resolved the effective"
                " request before calling the seam; state RESOLVED_BY_THE_RESOLVER"
                " or the resolver's own evidence (D-IMPL-304)"
            ) from raised
        if isinstance(raised.refusal, RefusalEnvelope):
            if raised.refusal.replay_reference != NO_REPLAY_REFERENCE:
                return raised.refusal
            envelope = raised.refusal
        else:
            envelope = envelope_for(
                raised.refusal,
                request=identity,
                policy_bindings=effective.applied,
                provenance=effective,
            )
        return self._record_refusal(
            envelope=envelope,
            execution=None,
            request=request,
            perspective=perspective,
            policy_bindings=self._applied_bindings(effective),
            resolution=effective,
            refusal_seam=seam,
            served_at=served_at,
        )

    def _record_refusal(
        self,
        *,
        envelope: RefusalEnvelope,
        execution: ExecutionResult | None,
        request: ProductRequest,
        perspective: Perspective,
        served_at: datetime,
        policy_bindings: tuple[PolicyBinding, ...] = (),
        resolution: EffectiveRequest | ResolutionNotApplicable,
        child_resolutions: tuple[ChildResolution, ...] = (),
        refusal_seam: str = NO_REFUSAL_SEAM,
    ) -> RefusalEnvelope:
        """Mint this refusal's decision record, then return the addressed shell.

        ``24.6-07``; ``D-IMPL-253`` Q13. A **thin** call into
        :attr:`refusal_recorder` and nothing else — every governed refusal this
        composition produces goes through here, and nothing in ``src/`` calls
        :func:`~ccf.replay.serve.record_refusal` except the recorder itself.

        **Two instants, and they are not synonyms** (`D-IMPL-358` step 5).
        ``recorded_at`` is ``request.asked_at`` — the QUESTION's instant, which
        keeps a refusal's dimension-1 boundary on what was asked rather than on
        when the refusal happened, and which the caller supplies at serve time
        and replay supplies at replay time through this same path. ``served_at``
        is the LIVE instant this invocation determined the refusal at, read once
        at `GovernedResolver.__call__` entry and threaded here.

        This docstring previously said *"nothing in this module reads a clock"*.
        That became untrue at step 4 and is corrected rather than deleted: the
        module reads exactly one clock, once, at entry, and never here.

        ``resolution`` is required with no default (24.7-04): every branch
        that reaches here ran the resolution step and passes what it
        established — complete or partial (D-07) — and this thin layer
        never substitutes a marker for what a branch did not say. ``D-IMPL-264`` amendment 1 (F-3 a), Dave verbatim: *"Any API that
        constructs or delegates construction of a replay record must require
        an explicit resolution state: effective/partial resolution or explicit
        not-applicable marker. No intermediate layer may manufacture the
        marker from omission."*

        Raises:
            Exception: whatever the artifact store raises, deliberately
                uncaught. *A failure to record is a failure to serve* — and
                24.6-07 extends that sentence to a governed "no": a refusal
                released without its record is a determination with no audit,
                which is the repudiation `D-IMPL-256` refuses to make
                contingent on the outcome.
        """
        return self.refusal_recorder.record(
            envelope,
            perspective=perspective,
            recorded_at=request.asked_at,
            # The live instant beside the question's, never instead of it.
            served_at=served_at,
            request=request,
            execution=execution,
            # `D-IMPL-378` C1: a refusal determined on a DECLARED demonstration
            # instant pins that declaration, exactly as a served decision does.
            policy_bindings=(*policy_bindings, *self._demonstration_pins()),
            assembler_id=self._assembler_id(),
            assembler_version=self._assembler_version(),
            resolution=resolution,
            # `CMP-R-01`: what the composition tried, on the refused branch
            # too. `()` for every non-composite, which is what they mean.
            child_resolutions=child_resolutions,
            # `D-IMPL-347` A2: WHICH deployment seam held this refusal. The
            # sentinel for the resolver's own refusals, which is what they are.
            refusal_seam=refusal_seam,
            # Dave's Q12 (`D-IMPL-378`): passed on every refusal, so a recorder
            # that cannot take it fails on every refusal alike, never only on
            # one about a withheld subject.
            subject_withholding=self._declaration().subject_withholding,
            # `D-IMPL-385`: passed only when an agent composed this decision, so
            # a recorder written before the keyword existed is unaffected on
            # every decision no agent composed (it is refused at construction
            # when composed over an agent-conditioned child resolver).
            **self._agent_conditioning_keyword(perspective),
        )

    def _agent_conditioning_keyword(self, perspective: Perspective) -> dict[str, PerspectiveConditioning]:
        """``{"agent_conditioning": ...}`` when an agent composed this decision, else ``{}`` (`D-IMPL-385`).

        Asked of the child resolver when it declares
        :class:`~ccf.products.composite.AgentConditionedChildResolverProtocol`,
        at the moment the decision's record is written: the ledger's grant set
        is read then, so a grant or revocation between two questions shows in
        the second record and never rewrites the first.
        """
        conditioning = self._agent_conditioning(perspective)
        return {} if conditioning is None else {"agent_conditioning": conditioning}

    def _agent_conditioning(self, perspective: Perspective) -> PerspectiveConditioning | None:
        """The composing agent's dimension-4 conditioning, or ``None`` (`D-IMPL-385`).

        Read off the child resolver when it declares
        :class:`~ccf.products.composite.AgentConditionedChildResolverProtocol`;
        ``None`` for every resolver that does not, and every decision no agent
        composed.
        """
        # Typed as `object`: the field's declared Protocols do not name this
        # capability, which a resolver declares structurally, beside them.
        children: object = self.composite_children
        if not isinstance(children, AgentConditionedChildResolverProtocol):
            return None
        return children.agent_conditioning(perspective=perspective)

    def _demonstration_pins(self) -> tuple[PolicyBinding, ...]:
        """The declared demonstration serve instant's pin, or nothing (`D-IMPL-378` C1).

        **SDK-defined** (CLAUDE.md §11). Audit by construction: a resolver whose
        serve clock is a :class:`~ccf.products.demonstration_clock.DeclaredServeClock`
        — composed only by
        :func:`~ccf.products.demonstration_clock.compose_serve_clock` from the
        tenant's Control Plane declaration — writes that declaration's exact
        ``(key, version)`` into dimension 2 of every record, served or refused,
        so an examiner can tell a demonstration record from a real one without
        reading code. A resolver on any other clock pins nothing here.
        """
        clock = self.admission_clock
        return (clock.binding,) if isinstance(clock, DeclaredServeClock) else ()

    def _applied_bindings(
        self, effective: EffectiveRequest
    ) -> tuple[PolicyBinding, ...]:
        """Every source the resolution consulted, by exact ``(key, version)``.

        ``24.6-03``: the constraint artifacts in force at ``asked_at``, the
        request contract's own pin, and the entitlement policy when an override
        was verified against it.

        Sources with no version lane (the request's own identity, a backend
        capability) are **not** bindings: :class:`PolicyBinding` is a Control
        Plane pin, and minting a lane for a capability is the fake artifact
        ``D-IMPL-253`` amendment 2 (1) forbids. They travel whole inside
        ``request_resolution``.

        Derived once and shared by the served record and every refusal record,
        because two derivations would let a refused decision and a fulfilled
        one disagree about what governed them (``24.6-07``).
        """
        return (
            *(
                PolicyBinding(key=source.identity, version=source.version)
                for source in effective.applied
                if source.kind == "artifact" and source.version is not None
            ),
            *(
                PolicyBinding(
                    key=override.grant_source.identity,
                    version=override.grant_source.version,
                )
                for override in effective.overrides
                if override.grant_source is not None
                and override.grant_source.version is not None
            ),
        )

    def _assembler_id(self) -> str | None:
        """The assembler in force, for replay dimension 4 — ``None`` here.

        ``D-IMPL-253`` Q16 with ``D-IMPL-245`` amendment 1. This composition
        holds no :class:`~ccf.agents.assembler.ContextAssemblerProtocol`: it
        *is* the assembly, composing engine → gates → serve itself. So it
        passes ``None`` and the record's :data:`~ccf.replay.record.NO_ASSEMBLER`
        sentinel makes that a positive claim rather than a silence.

        A method rather than an inline ``None`` so the two call sites — served
        and refused — read the same answer from one place, and so a resolver
        that later does hold an assembler has one line to change rather than
        two that could drift.
        """
        return None

    def _assembler_version(self) -> str | None:
        """The assembler's lane. ``None`` here; see :meth:`_assembler_id`."""
        return None

    # --- reading what the manifest put in force ----------------------------

    def _half_life_table(self) -> HalfLifeTable | None:
        """The deployment's λ_c table, when the resolver was wired with one (`D-IMPL-341`)."""
        if self.half_life_key is None:
            return None
        return self._artifact(self.half_life_key, HalfLifeTable)

    def _ttl_anchor_pins(self, anchor: TTLAnchorResolution) -> tuple[PolicyBinding, ...]:
        """The λ_c table pin an evidence-anchored serve records (`D-IMPL-341` R-5).

        Only for ``from_entity_freshness``: a decision-anchored record needs
        no table to re-derive its anchor, and pinning one would move the bytes
        of every record for nothing.
        """
        if anchor.basis != FROM_ENTITY_FRESHNESS or self.half_life_key is None:
            return ()
        return (
            PolicyBinding(
                key=self.half_life_key,
                version=self.fabric.pins.version_for(self.half_life_key),
            ),
        )

    def _artifact(self, key: str, expected: type[_Artifact]) -> _Artifact:
        """One parsed artifact, or a wiring refusal naming both sides.

        Delegates to :func:`_artifact_on` rather than repeating it, so the
        narrowing a resolver performs at call time and the one
        :func:`build_governed_resolver` performs at construction time are the
        same check with the same message. Two copies would drift, and the
        adopter would be told two different things about one mistake.
        """
        return _artifact_on(self.fabric, key=key, expected=expected)

    def _declaration(self) -> ProductClassDeclaration:
        """The Control Plane claim: what this product says produced it."""
        return self._artifact(self.product_class_key, ProductClassDeclaration)

    def _class_defaults(
        self, declaration: ProductClassDeclaration
    ) -> Mapping[str, object]:
        """What the product CLASS declares about omission — today one name.

        ``24.6-L-04``, ``D-IMPL-251`` C1=A. The class's
        :attr:`~ccf.products.contract.ServeObligations.default_debt_tolerance`
        is a declared *characteristic*, so it reaches the Authority layer as a
        default under the SDK's own parameter name
        (:data:`~ccf.products.gates.DEBT_TOLERANCE_PARAMETER`) — never as a
        ceiling this layer folds.

        The key is **omitted** when the class declares nothing, rather than
        present at ``None``. A mapping carrying ``{"debt_tolerance": None}``
        would record an authority that established a non-value, and the
        resolution's own comparisons would then have to ask whether a resolved
        value means anything. Absence is what "this class has no opinion"
        looks like.
        """
        tolerance = declaration.serve_obligations.default_debt_tolerance
        if tolerance is None:
            return {}
        return {DEBT_TOLERANCE_PARAMETER: tolerance}

    def _request_contract(
        self, declaration: ProductClassDeclaration
    ) -> ProductRequestContract:
        """The request surface, however the manifest authored it.

        A request contract is ordinarily declared in an **adopter** namespace,
        so a manifest resolves it to a
        :class:`~ccf.controlplane.artifacts.DeclaredArtifact` and the four
        fields have to be read out of its declaration. ``D-IMPL-126`` shipped
        the named constructor for exactly that, and calling it here is the SDK
        doing the transcription once instead of every adopter doing it. A
        deployment that already holds a typed contract passes straight through.

        Delegates to :func:`_request_contract_on` for :meth:`_artifact`'s
        reason: the read this resolver performs at request time and the one
        :func:`build_governed_resolver` performs at boot are the same read.
        """
        return _request_contract_on(self.fabric, key=self.request_contract_key)

    def operator_parameters(
        self, effective_request: ProductRequest
    ) -> dict[str, OperatorParametersArtifact]:
        """The adopter-side idiom: name your own keys, no type filtering.

        ``24.11-04`` / ``24.10-F-11`` (``D-IMPL-295``): the EFFECTIVE request is
        a parameter here, and it is the last link of the authority chain —
        Control Plane envelope -> :func:`~ccf.products.constraints.
        resolve_effective_request` -> declared binding -> operator. Before it,
        this method took no request at all, so an operator parameter whose value
        is knowable only per request could not be declared, and the one
        deployment that needed one substituted a value into its own resolved
        artifact at runtime.

        **The effective request and never the caller's.** Binding from
        ``request`` would take the raw value and bypass class defaults, policy
        bounds and technical capabilities at the exact final step those exist to
        govern — the substitution this closes, wearing a different hat.
        Regressed by ``test_the_call_site_binds_from_the_effective_request_not_
        the_callers``, which exists because swapping this one argument left the
        whole tree green.
        """
        return {
            key: self._bind_declared_request_values(
                self._artifact(key, OperatorParametersArtifact),
                key=key,
                effective_request=effective_request,
            )
            for key in self.operator_parameter_keys
        }

    def _bind_declared_request_values(
        self,
        artifact: OperatorParametersArtifact,
        *,
        key: str,
        effective_request: ProductRequest,
    ) -> OperatorParametersArtifact:
        """One artifact with every request-bound field replaced by its value.

        ``24.11-04`` / ``D-IMPL-295``. Returns the artifact unchanged when it
        declares no binding, which is every artifact shipped before this row.

        **Revalidated rather than copied.** :meth:`pydantic.BaseModel.
        model_copy` does not validate, so a bound value of the wrong type would
        reach the operator wearing the declared field's name. Reconstruction
        puts the effective value through the field's own declared type, so the
        compatibility this binding promises is enforced by the same machinery
        that enforces it for a literal — one type system rather than a second
        one written here to compare against it.

        Raises:
            ProductNotResolvable: the binding names a parameter the effective
                request does not carry, or carries a value the target field
                refuses. Both are wiring defects rather than governed "no"s —
                the deployment declared a binding its own request contract does
                not support, which no caller can fix.
        """
        bound = {
            name: value
            for name, value in artifact
            if isinstance(value, RequestBoundParameter)
        }
        if not bound:
            return artifact
        supplied = dict(effective_request.parameters)
        replacements: dict[str, object] = {}
        for name, binding in bound.items():
            if binding.parameter not in supplied:
                raise ProductNotResolvable(
                    f"operator parameters {key!r} bind {name!r} to request"
                    f" parameter {binding.parameter!r}, which the effective"
                    f" request does not carry; it offers {sorted(supplied)}."
                    " The binding is declared against a request contract that"
                    " does not declare the parameter"
                )
            replacements[name] = supplied[binding.parameter]
        document = artifact.model_dump()
        document.update(replacements)
        try:
            return type(artifact).model_validate(document)
        except ValidationError as mismatch:
            raise ProductNotResolvable(
                f"operator parameters {key!r} bind {sorted(replacements)} from"
                f" the effective request, and the value(s) do not satisfy the"
                f" declared field type(s): {mismatch}. A binding supplies a"
                " value; it never converts one (D-IMPL-295)"
            ) from mismatch

    def _reassess(
        self, factors: DebtFactors, *, fallback: DebtAssessment
    ) -> DebtAssessment:
        """Re-derive the routing signal from COMPOSED factors (`R2`).

        Read through the same manifest key `_obligation_in_force` uses, for the
        same reason: the profile that routes a composite is provably the one
        the manifest put in force, not one assembled beside it.

        A deployment that declares no bands keeps the scorer's own signal —
        there is nothing to re-route against, and inventing a band here would
        be the SDK holding a value (`D-IMPL-38`).
        """
        debt = context_debt(factors)
        if self.debt_profile_key is None:
            return DebtAssessment(
                debt=debt,
                signal=fallback.signal,
                factors=factors,
                scorers=fallback.scorers,
            )
        profile = self._artifact(self.debt_profile_key, DebtProfile)
        assessed = assess_debt(factors, profile=profile)
        return DebtAssessment(
            debt=assessed.debt,
            signal=assessed.signal,
            factors=factors,
            scorers=fallback.scorers,
        )

    def _obligation_in_force(self, signal: DebtSignal) -> str:
        """What this deployment's profile binds to the state debt landed in.

        ``24.11-03`` closes ``24.10-F-08``'s obligation limb. ``D-IMPL-117``
        says the SDK owes *"the structure and the API to populate and extract"*
        a signal-to-obligation binding, and **owes no obligation vocabulary**:
        :meth:`~ccf.controlplane.artifacts.DebtProfile.obligation_for` is the
        extract half — *"and the whole of it"*, in its own words — and this is
        the populate half on the governed path. Nothing here judges what a
        reference means; the binding is read off the deployment's declaration
        and carried verbatim.

        **Read by manifest key, never from a passed object**, for the reason
        this class's docstring gives for every other key: the profile served is
        provably the one the manifest put in force rather than one a caller
        assembled beside it. ``obligation_for`` states the same constraint from
        its side — nothing reaches the Control Plane for a *"latest"*, because
        the resolved value travels **inside the product's content address**
        (``D-IMPL-26``, ``D-IMPL-118``) and a substituted one would replay as
        though it had been in force.

        Returns :data:`~ccf.halflife.assessment.NO_OBLIGATION_IN_FORCE` when
        this deployment names no profile. That is the **positive claim that
        nothing was bound**, not a silent default: a deployment supplying its
        own scorer and declaring no bands has declared no obligation, which is
        exactly how ``obligation_for`` resolves an unbound state within a
        profile. A partly-bound estate is the ordinary case rather than a
        defect.
        """
        if self.debt_profile_key is None:
            return NO_OBLIGATION_IN_FORCE
        profile = self._artifact(self.debt_profile_key, DebtProfile)
        return profile.obligation_for(signal)

    def _register(
        self, declaration: ProductClassDeclaration
    ) -> RegisteredProductClass:
        """Register the class, forwarding every governance field it declares.

        The two registrations that must happen here rather than at boot: the
        ``MAX_TTL`` value, because registering it is what mints the pin Gate 3
        resolves; and the request contract, so its pin is re-resolvable years
        later against the surface a question was actually validated against.
        The request contract is registered first when the resolver is built
        (``D-IMPL-378`` R-A) and again in :meth:`__call__` before the
        resolution that pins it (``CP17-F-09``): a refusal never reaches this
        method and its record pins the same version, so registering it here
        once more is idempotent.

        Every remaining governance field is forwarded off the declaration
        rather than left to :func:`~ccf.products.contract.register_product_class`'s
        defaults. The defaults are shipped and governed, but a deployment that
        *declared* accepted lineage modes and then had them silently replaced
        by a default would have written a policy the fabric never enforced.
        """
        # D-IMPL-354: both registrations run under the `Register` capability
        # this composition minted for exactly that key. The registry takes the
        # key FROM the capability; the comparison below is what keeps a
        # declaration handed in later from silently landing under the key the
        # composition minted for.
        if declaration.max_ttl_key != self._authorities.max_ttl.resource:
            raise TypeError(
                f"the declaration names max_ttl_key {declaration.max_ttl_key!r}"
                " and this resolver's composition minted Register for"
                f" {self._authorities.max_ttl.resource!r}; one resolver registers"
                " one class's ceiling (D-IMPL-354)"
            )
        max_ttl_version = self.control_plane.register(
            self._authorities.max_ttl, MaxTTL(seconds=self.max_ttl_seconds)
        )
        request_contract_version = self.control_plane.register(
            self._authorities.request_contract,
            self._request_contract(declaration),
        )
        return register_product_class(
            registry=self.control_plane,
            schema_name=declaration.schema_name,
            schema_version=declaration.schema_version,
            ttl_anchor=declaration.ttl_anchor,
            assembly_mode=declaration.assembly_mode,
            max_ttl_key=declaration.max_ttl_key,
            max_ttl_version=max_ttl_version,
            accepted_policy_binding_modes=declaration.accepted_policy_binding_modes,
            accepted_lineage_modes=declaration.accepted_lineage_modes,
            freshness_sla=declaration.freshness_sla,
            discovery=declaration.discovery,
            addressability=declaration.addressability,
            constituent_validity_floors=declaration.constituent_validity_floors,
            request_contract_key=self.request_contract_key,
            requires=declaration.requires,
            request_contract_version=request_contract_version,
            # 24.5-L-14 / L-26: the declared obligations reach the gate off
            # the registered value, exactly as the accepted modes do.
            serve_obligations=declaration.serve_obligations,
        )


def _replay_binding_on(fabric: BootedFabric) -> ReplayBinding | None:
    """The one :class:`ReplayBinding` a booted fabric declares, or ``None``.

    **SDK-defined** (CLAUDE.md §11); the ruling of record is ``D-IMPL-282``
    ``R-12`` (Dave, 2026-09-08). The read half of the Control Plane's replay
    binding: :func:`build_governed_resolver` asks the fabric what this
    deployment declared, and uses it only for the members its caller did not
    supply.

    ``None`` is a **statement**, not a failure — a deployment that declares no
    binding is the ordinary case for every `ccf_config.yaml` written before the
    section existed, and the caller's refusal (which names both sources) is
    what speaks about it.

    **More than one is refused rather than resolved**, in
    :func:`~ccf.deployment.config._refuse_operator_set_divergence`'s voice and
    for its reason: two declarations that cannot both be what their author
    meant, compared before anything is wired, refused rather than reconciled.
    Picking the first would be a rule that silently changes behavior the day a
    second binding is registered, and only the deployment's author knows which
    was meant. Every key holding one is named, so the fix does not need a
    search.

    Raises:
        TypeError: the fabric declares more than one binding. An
            argument-shape mistake — the deployment was wired ambiguously —
            so the exception Python reserves for one, and never a governed
            refusal, because nobody asked a question yet.
    """
    declared = sorted(
        key
        for key, artifact in fabric.artifacts.items()
        if isinstance(artifact, ReplayBinding)
    )
    if not declared:
        return None
    if len(declared) > 1:
        raise TypeError(
            "this deployment declares more than one replay binding —"
            f" {', '.join(repr(key) for key in declared)} — and this call"
            " omits at least one of `artifact_store`, `replay_record_class`"
            " and `query_pin_class`, so which binding was meant is a question"
            " only the deployment's author can answer. Refusing beats picking"
            " (`D-IMPL-282` `R-12`): register one binding, or pass the three"
            " arguments explicitly"
        )
    binding = fabric.artifacts[declared[0]]
    assert isinstance(binding, ReplayBinding)  # narrowed by the filter above
    return binding


def _declared_member(
    binding: ReplayBinding | None, *, member: str, argument: str
) -> str:
    """One member of the declared binding, or the neither-source refusal.

    ``D-IMPL-282`` ``R-12``, Dave: *"Do not silently invent a replay backend
    when neither source provides one."* So there is no default here and no
    warning — a resolver that could not reach a replay writer would be a
    resolver whose only remaining move is to serve an unrecorded decision, and
    ``D-IMPL-256``'s invariant is that such a boundary is *unavailable*, not
    partially governed.

    Both places the value could have come from are named, because a caller
    reading this should not have to work out whether the fix is an argument or
    a section.

    Raises:
        TypeError: neither the call nor the Control Plane supplies ``member``.
    """
    if binding is None:
        raise TypeError(
            f"this call omits `{argument}` and this deployment's Control Plane"
            f" declares no replay binding, so nothing supplies it. State"
            f" `{argument}` on the call, or declare a `replay:` section naming"
            f" `{member}` in the deployment's ccf_config.yaml — the SDK does"
            " not invent a replay backend when neither source provides one"
            " (`D-IMPL-282` `R-12`)"
        )
    value = getattr(binding, member)
    assert isinstance(value, str)  # ReplayBinding declares all three as str
    return value


def _ttl_binding_on(fabric: BootedFabric) -> TtlBinding | None:
    """The one :class:`~ccf.controlplane.artifacts.TtlBinding` a fabric declares, or ``None``.

    `D-IMPL-343` R-3a, on :func:`_replay_binding_on`'s shape and for its
    reason: ``None`` is a statement (every config written before the `ttl:`
    section existed declares none, and the two builder keywords still supply
    the figures), and more than one is refused rather than resolved.

    Raises:
        TypeError: the fabric declares more than one TTL binding.
    """
    declared = sorted(
        key for key, artifact in fabric.artifacts.items() if isinstance(artifact, TtlBinding)
    )
    if not declared:
        return None
    if len(declared) > 1:
        raise TypeError(
            "this deployment declares more than one TTL binding —"
            f" {', '.join(repr(key) for key in declared)} — so which window"
            " was meant is a question only the deployment's author can"
            " answer (D-IMPL-343 R-3a): declare one `ttl:` section"
        )
    binding = fabric.artifacts[declared[0]]
    assert isinstance(binding, TtlBinding)  # narrowed by the filter above
    return binding


def _resolve_ttl(
    fabric: BootedFabric, *, max_ttl_seconds: int | None, product_ttl_seconds: int | None
) -> tuple[int, int]:
    """The class ceiling and the product lifetime — one authority, two readers.

    `D-IMPL-343` R-3a, `D-IMPL-292` applied to the two TTL figures. Per
    figure: the call's value when the declaration has none; the declaration's
    when the call is silent; **both, held equal**, when both speak — and a
    disagreement is refused with both values named rather than resolved by
    precedence, because a builder keyword that could silently override a
    declared window is exactly the second authority the ruling deletes. When
    neither source supplies a figure the refusal names both places it could
    have come from, on `_declared_member`'s posture: the SDK invents no TTL.

    Raises:
        TypeError: a figure is supplied by neither source, or by both with
            different values.
    """
    binding = _ttl_binding_on(fabric)
    resolved: list[int] = []
    for argument, member, supplied in (
        ("max_ttl_seconds", "max_ttl_seconds", max_ttl_seconds),
        ("product_ttl_seconds", "product_ttl_seconds", product_ttl_seconds),
    ):
        declared = None if binding is None else int(getattr(binding, member))
        if supplied is None and declared is None:
            raise TypeError(
                f"this call omits `{argument}` and this deployment's Control"
                " Plane declares no `ttl:` binding, so nothing supplies it."
                f" State `{argument}` on the call, or declare a `ttl:` section"
                f" naming `{member}` in the deployment's ccf_config.yaml — the"
                " SDK does not invent a TTL when neither source provides one"
                " (D-IMPL-343 R-3a; D-IMPL-292)"
            )
        if supplied is not None and declared is not None and supplied != declared:
            raise TypeError(
                f"this call states `{argument}={supplied}` and this"
                f" deployment's `ttl:` binding declares `{member}: {declared}`;"
                " a declared value has one authority, and a call that could"
                " override it silently would be a second one (D-IMPL-343 R-3a;"
                " D-IMPL-292) — drop the argument, or correct the declaration"
            )
        resolved.append(int(supplied if supplied is not None else declared))  # type: ignore[arg-type]
    return resolved[0], resolved[1]


def declared_refusal_recorder(
    *,
    control_plane: ControlPlaneProtocol,
    artifact_store: ArtifactStoreProtocol,
    replay_record_class: str,
    tenant_id: str,
    assembly_mode: AssemblyMode,
    policy_bundle_pin: PolicyBinding,
) -> ReplayRefusalRecorder:
    """ONE :class:`ReplayRefusalRecorder` for a deployment, built once, shared everywhere.

    `D-IMPL-343` (design §5.3, §5.4). The recorder :func:`build_governed_resolver`
    builds for itself is bound to the store, class, tenant, mode and bundle pin
    the call supplied — and before this function a door that needed the same
    recorder could not reach it, because the canonical trees built their
    resolver per question inside a function that returned only the outcome.
    So every one of those doors built a SECOND recorder over a SECOND store,
    and served and refused decisions were filed in two places under a class
    each module restated (`CP03C-F-07`'s neighborhood). This is the same
    construction the builder performs, exposed so a composition root can build
    the recorder ONCE — from the declared `replay:` binding and the bundle's
    content address — and hand the same object to the resolver (through
    ``refusal_recorder=``) and to
    :func:`~ccf_runtime.mcp.egress.build_egress_server`.

    ``policy_bundle_pin.version`` is the bundle's content address, which is
    what the registry mints for it (`D-IMPL-26`), so a caller holding the
    parsed bundle can build this before anything is booted and the pin it
    records is the pin the boot will mint.
    """
    return ReplayRefusalRecorder(
        # D-IMPL-354: this function is the recorder's composition; it mints
        # the ONE `ReplayMint` the recorder writes under, audited on the
        # Control Plane it was handed.
        authorized=_mint_replay_at_composition(
            control_plane, tenant=tenant_id, artifact_class=replay_record_class
        ),
        artifact_store=artifact_store,
        assembly_mode=assembly_mode,
        policy_bundle_pin=policy_bundle_pin,
        disclosure_level_for=_disclosure_reader(control_plane),
    )


def build_governed_resolver(
    *,
    fabric: BootedFabric,
    control_plane: ControlPlaneProtocol,
    product_class_key: str,
    request_contract_key: str,
    operator_parameter_keys: tuple[str, ...],
    policy_bundle_key: str,
    plan_factory: ProjectionPlanFactoryProtocol,
    #: SEC-009 (`D-IMPL-374` (4), fix round 1 C1): the deployment's durable
    #: erasure index. REQUIRED, no default — the resolver's store, supplied or
    #: default, is composed with the erasure consult over it, scoped to the
    #: fabric's tenant, and a composition without a declared index refuses.
    erasure_index: ErasureIndexProtocol,
    #: SEC-009 (`D-IMPL-374` (4), fix round 5, R1, R2, R4): the deployment's
    #: erasure trust root, per tenant — the HITL policy key each tenant's
    #: transport is bound to, its erasure workflow's content hash and the
    #: erasure door's public key — which the composed store verifies every
    #: erasure against. REQUIRED, no default.
    erasure_trust: ErasureTrust,
    #: `D-IMPL-343` R-3a (`D-IMPL-292` applied): optional, and read from the
    #: deployment's declared `ttl:` binding when omitted. A call stating a
    #: value that DIFFERS from the declaration is refused with both named —
    #: an argument for a declared value is one more place to be wrong.
    max_ttl_seconds: int | None = None,
    product_ttl_seconds: int | None = None,
    decision_instant_parameter: str | None = None,
    source_refresh_recency: SourceRefreshRecency = NO_SOURCE_REFRESH_RECENCY,
    #: `D-IMPL-336` Amendment 3, F0. Defaulted HERE and required on the
    #: resolver itself: the dataclass forbids defaults so every deployment
    #: states its posture explicitly, while this factory — which most
    #: deployments call — keeps the non-composite default that every product
    #: shipped before this surface had.
    composite_children: (
        CompositeChildResolverProtocol | RequestAwareChildResolverProtocol | None
    ) = None,
    #: `D-IMPL-336` **O3** — the clock a child admission is judged against.
    #: Defaults to the process's UTC clock, which is the right value for a
    #: deployment; tests inject a fixed instant so the evidence-age and skew
    #: boundaries can be asserted exactly rather than approached.
    #: `D-IMPL-378` C1: a tenant that DECLARES a demonstration serve instant is
    #: served at that instant instead, and only while this argument is left at
    #: its default — a clock supplied beside a declaration is refused by name
    #: (`ccf.products.demonstration_clock.compose_serve_clock`).
    admission_clock: Callable[[], datetime] = _utc_now,
    artifact_store: ArtifactStoreProtocol | None = None,
    replay_record_class: str | None = None,
    query_pin_class: str | None = None,
    artifact_store_root: Path | None = None,
    half_life_key: str | None = None,
    debt_profile_key: str | None = None,
    declared_completeness: Decimal | None = None,
    evidence_clock_key: str | None = None,
    declared_semantic_consistency: Decimal | None = None,
    debt_scorer: AssemblyDebtScorerProtocol | None = None,
    product_gate: ProductGateProtocol | None = None,
    constraint_resolver: PolicyConstraintResolver | None = None,
    capabilities: tuple[TechnicalCapability, ...] | None = None,
    #: `D-IMPL-343`: the ONE recorder a deployment may hand in so its door and
    #: its resolver share a writer (see :func:`declared_refusal_recorder`);
    #: ``None`` selects the SDK's own over the store this call chose, exactly
    #: as before. And the declared acquisition seam (R-4), ``None`` for every
    #: deployment whose fabric is populated before the resolver is reached.
    refusal_recorder: RefusalRecorderProtocol | None = None,
    acquisition: AcquisitionSeamProtocol | None = None,
    #: §7.10.4's Mode 2 footprint. ``None`` for every Mode 1 deployment.
    packaging_trace: PackagingTraceProtocol | None = None,
    #: SEC-020 Q7 (`D-IMPL-378`): the declared population phase, ``None`` for
    #: every deployment that declares none.
    population_acquisition: PopulationAcquisitionSeamProtocol | None = None,
) -> GovernedResolver:
    """Build a :class:`GovernedResolver`, selecting the SDK's reference scorer.

    **SDK-defined** (CLAUDE.md §11); the ruling of record is
    ``docs/superpowers/specs/2026-08-16-reference-plan-factory-and-debt-scorer.md``
    §6 and **Amendment A.3** (Dave, 2026-08-16). This is the *"thin*
    ``build_governed_resolver(...)`` *helper"* §6 names, and the module
    docstring records the two measurements that put the default here rather
    than on the class.

    What this helper is for
    -----------------------
    **A deployment that provides only data never has to know
    :class:`AssemblyDebtScorerProtocol` exists.** Everything below is plain
    data plus the three fabric objects plus the single permitted projection
    reference (Amendment A.3) — and the debt scorer arrives from the SDK. A
    deployment reaching the fabric through this seam imports no scorer, writes
    no ``GraphView`` → :class:`~ccf.halflife.assessment.DebtFactors` adapter,
    and makes no row-selection choice in its own tree.

    How far that reaches, measured rather than claimed
    ---------------------------------------------------
    ``24.10-04`` / ``R-03`` (``D-IMPL-282``) tried this seam from the SDK's own
    worked example, ``examples/s1-01-hello-context-product/spine.py``, against
    a live substrate. **The example could not adopt it**, and four absent seams
    were why — of which ``24.10-F-06`` and ``24.10-F-07`` are closed as of
    ``24.11-02b``, leaving two. Read
    :class:`GovernedResolver`'s own docstring for ``24.10-F-06`` through
    ``24.10-F-09`` and ``tests/examples/
    test_s1_01_governed_resolver_adoption.py`` for the executable roster. One
    of the two bears directly on the arguments below and is worth knowing
    before wiring rather than after:

    * A ``debt_scorer`` supplied here measures ``D_c`` at the *graph boundary*,
      because that is the only instant the resolver has; a deployment whose
      class declares a distinct decision instant will find it unread
      (``24.10-F-09``).

    It is recorded, and not fixed here: ``D-IMPL-282`` authorizes *"no
    broader API redesign … up front"*, so what it earns is a ruling.

    The one that *looked* like an argument problem turned out not to be one.
    ``24.11-02`` added a ``similarity_index_version`` argument here, and Dave
    ruled that insufficient (``D-IMPL-292``): a corpus's version identity is
    *decision-affecting operator configuration*, and an argument makes it an
    ungoverned value the deployment restates in code. **There is no such
    argument below, and its absence is the repair.** A deployment declaring a
    **similarity** operator-parameters artifact among
    ``operator_parameter_keys`` declares
    :attr:`~ccf.controlplane.artifacts.SimilaritySelectParametersArtifact.index_version`
    *on that artifact*, and :func:`~ccf.deployment.build_operator_registry`
    reads it there. That is the difference between a value in the pin set and a
    value in a call — and it is why this argument is not offered even as an
    optional convenience: an optional second site is still a site at which a
    deployment can contradict its own declaration.

    What "the default" can and cannot mean here
    --------------------------------------------
    It means the **machinery**, and it can never mean the **values**. The
    reference scorer needs four inputs (:data:`DEBT_SCORER_INPUTS`), and none of
    the four is something the SDK may invent:

    * ``half_life_key`` / ``debt_profile_key`` name **Control Plane artifacts**.
      They are keys rather than discovered artifacts because §6 rules out *"new
      discovery or registration machinery in this change"* — a fabric holding
      two ``λ_c`` tables has no SDK-knowable right answer, and picking the only
      one present would be a rule that silently changes behaviour the day a
      second is registered.
    * ``declared_completeness`` / ``declared_semantic_consistency`` are the two
      factors with **no SDK measurement at all**.
      :class:`~ccf.halflife.assessment.DebtFactors` states that position in its
      own docstring, and ``17-11`` rejected each candidate default in turn
      (``C = 1`` is a number the SDK chose inside a delivered product's content
      address; ``C = 0`` fail-closes every deployment; deriving ``C`` from the
      table's breadth couples completeness to how many observation types a
      deployment happens to calibrate). They travel through
      :class:`~ccf.products.debt_scorer.DeclaredFactor`, so each lands in the
      Decision Replay record under its own :class:`~ccf.halflife.assessment.ScorerPin`
      (``D-IMPL-47``) and an examiner can tell an assertion from a measurement.

    So this helper defaults the *adapter*, the *decay computation* and the
    *pinning* — the parts that were mechanism the SDK declined to ship — and
    defaults nothing a deployment is entitled to decide.

    **The replay binding defaults the WIRING and never a replay semantic**
    (`R-12`; ``D-IMPL-282``, Dave, 2026-09-08). Three arguments —
    ``artifact_store``, ``replay_record_class``, ``query_pin_class`` — may now
    be omitted, and the deployment's own `ccf.replay-binding` supplies what the
    call left out, **per member**: a call naming ``replay_record_class`` and
    omitting the other two takes the explicit record class and the declared
    query-pin class and store. The precedence, in Dave's own order, is
    *explicit builder argument > Control Plane replay binding > no
    binding/refusal according to existing availability semantics*, and the
    third step is a refusal rather than a fallback because *"Do not silently
    invent a replay backend when neither source provides one."*

    What forced the argument, recorded here because a helper that grew one
    without saying why is how this seam accumulates arguments nobody can
    account for: cp-05 measured that a deployment's replay binding had nowhere
    declared to live — `examples/cp-05-credit-exposure-rollup/artifacts
    /replay.yaml` — so the three strings lived either as module constants in a
    deployment's own Python or as an adopter-namespaced artifact beside the
    config, and neither is the Control Plane. What the binding may carry is
    bounded by the same ruling: *"No product-specific replay semantics in the
    Control Plane—only deployment binding/configuration."* It says where
    records go, never what a record means.

    The two argument shapes, and why supplying neither or both is refused
    ---------------------------------------------------------------------
    Exactly one of these is a valid call:

    * **the data-only path** — the four :data:`DEBT_SCORER_INPUTS`, no
      ``debt_scorer``. The SDK builds
      :class:`~ccf.products.debt_scorer.AssemblyDebtScorer`.
    * **the override path** — ``debt_scorer``, none of the four. A deployment
      whose product means something the reference does not measure supplies its
      own conforming callable, exactly as the Protocol intends.

    Neither is refused rather than defaulted, because a resolver built with no
    scorer and no material would be a resolver with **no way to measure debt**,
    and the only thing left for it to do is serve an unscored product — the
    failure Risk 3 of the spec names: *"a default that nothing exercises is a
    check that stops checking without going red."* Both are refused because
    silently ignoring four supplied arguments is how a deployment comes to
    believe a ``λ_c`` key is in force when it is not.

    Args:
        fabric: The booted deployment, as :func:`~ccf.deployment.load_and_boot`
            returned it.
        control_plane: The Control Plane the fabric booted against.
        product_class_key: Manifest key of the served class declaration.
        request_contract_key: Manifest key of its request surface.
        operator_parameter_keys: Manifest keys of the operator parameters —
            however many (``D-IMPL-132``).
        policy_bundle_key: Manifest key of the policy regime in force.
        plan_factory: The deployment's Π factory. The **one** thing measurement
            said cannot be data (Amendment A.2), and therefore the one thing
            this helper cannot default.
        erasure_index: The deployment's durable erasure index (SEC-009;
            `D-IMPL-374` (4), C1). Required: the selected store is composed with
            the erasure consult over it, scoped to the fabric's tenant.
        erasure_trust: The deployment's per-tenant erasure authorities
            (SEC-009; `D-IMPL-374` (4), fix round 5). Required: the composed
            store verifies the door's record signature and every approval
            against the authority of the record's tenant.
        artifact_store: Where replay records and executed-query bytes land. A
            substrate reached *through* mechanism, never a second writer
            (CLAUDE.md §7.4). Taken as an object rather than a path so this
            seam stays substrate-agnostic. **Optional since `R-12`**: when it
            is omitted the deployment's declared binding supplies a
            file-backed store rooted at ``artifact_store_root /
            <declared store_dirname>``; when both sources are silent the build
            refuses.
        replay_record_class: Artifact class replay records are filed under.
            **Optional since `R-12`** — the declared binding's
            ``record_class`` when the call omits it.
        query_pin_class: Artifact class executed-query bytes are filed under.
            **Optional since `R-12`** — the declared binding's
            ``query_pin_class`` when the call omits it.
        artifact_store_root: The directory the declared ``store_dirname`` is
            joined onto. Required only when the *binding* is what supplies the
            store, and refused-when-absent rather than defaulted: a root taken
            from the process's working directory would put a deployment's
            decision records wherever it happened to be started from. Ignored
            when ``artifact_store`` is passed, because an object needs no root.
        max_ttl_seconds: The class's TTL ceiling.
        product_ttl_seconds: A served product's own lifetime. Two figures, and
            they stay two.
        half_life_key: Manifest key of this deployment's ``λ_c`` table.
        evidence_clock_key: The SAME manifest key, supplied when the deployment
            hands in its own ``debt_scorer`` (`D-IMPL-341`). A scorer and the
            reference scorer's material are alternatives, but the resolver
            still needs the table for something the scorer does not do: the
            instant an evidence-anchored window runs from, and the pin that
            instant is re-derivable under at replay. Naming it here is how a
            supplied-scorer deployment says which table that is; the paved road
            passes it from ``build_arguments``. Give this or ``half_life_key``,
            never two different keys — and for a class declaring
            ``ttl_anchor: from_entity_freshness`` at least one of them, or the
            call is refused (R-3's first row).
        debt_profile_key: Manifest key of its ``D_c`` bands. **The one input
            here that is not only scorer material** (``24.11-03``,
            ``24.10-F-08``): the same profile binds the obligation the served
            product carries, so this may accompany an explicit ``debt_scorer``
            where the other three may not — the exclusion below is about
            *scoring*, never about the *declaration*.
        declared_completeness: The ``C`` this deployment asserts, in ``[0, 1]``.
        declared_semantic_consistency: The ``S`` it asserts, in ``[0, 1]``.
        debt_scorer: A conforming scorer that **overrides** the reference.
        product_gate: The deployment's implementation of the invariant its
            product class declares (``24.10-02`` / ``R-11``; ``D-IMPL-282``
            option 1a). Unlike ``debt_scorer`` this has **no reference
            implementation and cannot have one**: the SDK ships the machinery
            for every seam it defines (CLAUDE.md §11), and the machinery here
            is the identity, the execution point and the refusal — the
            predicate is the product's own meaning, which no SDK could supply.
            So the pairing is not default-versus-override but declared-versus-
            supplied, and **both mismatches are refused** rather than
            defaulted: see the ``Raises`` note below.
        constraint_resolver: A conforming resolver that **overrides** the
            reference. When omitted, the SDK selects
            :class:`~ccf.products.constraints.ReferencePolicyConstraintResolver`
            over the same Control Plane this fabric booted against, keyed to
            this tenant's entitlement policy through
            :func:`~ccf.products.entitlement.product_entitlement_key` — so a
            deployment that registered one gets its overrides verified without
            naming anything, and a deployment that registered none entitles no
            override, which is deny-by-default rather than an error. Unlike the
            debt scorer this default needs **no material**: the resolver reads
            what the deployment already registered, so there is no pair of
            argument shapes here and none is refused (``24.6-03``).
        capabilities: The technical limits in force. When omitted they are
            derived structurally from what the boot handed back
            (:func:`_capabilities_of`), which is the empty tuple for every
            shipped boot path — the handle carries a reader and the ceiling is
            the store's. Pass them explicitly to bound a parameter by a
            substrate limit; the binding that says *which* parameter is the
            request contract's (``capability_bindings``).

    **The refusal recorder is selected here too, and it takes no argument**
    (``24.6-07``; ``D-IMPL-253`` Q13). :class:`ReplayRefusalRecorder` needs the
    store, the artifact class and the tenant — all three already arguments —
    plus the assembly mode and the bundle pin, both read off what the manifest
    put in force. So unlike the debt scorer there is no pair of argument shapes
    here and none is refused: a deployment reaching the fabric through this
    seam gets a governed refusal path without naming anything, and the
    ``D-IMPL-256`` invariant *"a delivery boundary unable to reach the replay
    writer is unavailable, not partially governed"* holds by wiring.

    A deployment that files its refusal records elsewhere constructs
    :class:`GovernedResolver` directly with its own
    :class:`RefusalRecorderProtocol`.

    Returns:
        The composed resolver, ready to be handed to a delivery surface.

    Raises:
        TypeError: a ``product_gate`` was supplied against a class declaring
            none, or a class declaring one was built with no callable. The
            second is the one that matters: a declared gate nothing executes is
            *"a default that nothing exercises*, which *is a check that stops
            checking without going red"* — an audit would report an invariant
            in force that had never run. The first is refused rather than
            ignored because a deployment silently running an ungoverned
            predicate inside the determination path would have no identity to
            record it under. Also raised when both a scorer and the material to
            build one were supplied, or neither was. An argument-shape mistake, so the exception Python
            already reserves for one — and never a governed refusal, because
            nobody asked a question yet. Also raised when a replay member is
            supplied by neither the call nor a declared binding, when the
            binding is what supplies the store and no ``artifact_store_root``
            was given, and when the fabric declares more than one binding —
            see :func:`_replay_binding_on` and :func:`_declared_member`.
        TTLAnchorUndeclared: the class declares ``ttl_anchor:
            from_entity_freshness`` and the clock it would need cannot exist —
            either no λ_c table was named at all, or the named table declares
            no ``decay_basis: valid-from`` row. Both are configuration
            failures and both are refused here, before any question
            (`D-IMPL-341` R-3, first row, widened by Dave's ruling of
            2026-09-18).
        ProductNotResolvable: ``half_life_key`` or ``debt_profile_key`` names no
            artifact on the booted fabric, or names one of another class; or
            ``product_class_key`` / ``request_contract_key`` does.
        ProductClassRegistrationError: the product class declares a default for
            a parameter its request contract does not declare as an argument —
            an internally inconsistent declaration, refused at boot under
            ``D-IMPL-258`` (5) rather than in front of a caller. Also raised
            when the class declares a ``seam_refusals`` binding for an exception
            in :data:`SDK_SEAM_REFUSALS`, whose meaning the SDK owns and
            consults first, so the declaration could never be minted
            (:func:`_refuse_sdk_owned_seam_refusal`).
        ValueError: a declared factor lies outside ``[0, 1]``. Raised by
            :class:`~ccf.products.debt_scorer.DeclaredFactor`, where the value
            was authored, rather than three frames later.
    """
    # `D-IMPL-258` (5), FIRST, before any other wiring decision: a product class
    # whose declared default names a parameter its own request contract does not
    # expose is an internally inconsistent declaration, and Dave ruled that it
    # *"should fail registration/configuration/boot validation, not produce a
    # shell to a caller."* This is the boot half; registration's half is in
    # `ccf.products.contract.register_product_class`. It runs first because a
    # deployment that cannot answer coherently should not get as far as choosing
    # a debt scorer, and because a failure here names the two documents that
    # disagree rather than whatever fell over later.
    boot_declaration = _artifact_on(
        fabric, key=product_class_key, expected=ProductClassDeclaration
    )
    # `D-IMPL-341`: the λ_c table the resolver anchors an evidence-anchored
    # expiry on and pins on the record. It is `half_life_key` when this call
    # lets the helper build the reference scorer, and `evidence_clock_key` —
    # the same manifest key, stated once more — when a supplied scorer already
    # reads the table (the paved road), because the scorer and the resolver
    # read it for two different things: `F`, and the instant the window runs
    # from. Neither is a value; both name the deployment's one table.
    if half_life_key is not None and evidence_clock_key is not None and half_life_key != evidence_clock_key:
        raise TypeError(
            f"this call names `half_life_key={half_life_key!r}` and"
            f" `evidence_clock_key={evidence_clock_key!r}`; a deployment has one"
            " λ_c table, so the two keys must agree or only one be given"
            " (D-IMPL-341)"
        )
    resolver_table_key = half_life_key if half_life_key is not None else evidence_clock_key
    # `D-IMPL-341` R-3 (first row), for a resolver wired by hand: the same
    # registration-time refusal the config derivation makes, over the table
    # this builder is about to anchor with.
    #
    # NO TABLE AT ALL IS A CONFIGURATION FAILURE, AND IT FAILS HERE (Dave's
    # ruling of 2026-09-18, closing the review's open question). A class
    # declaring an evidence anchor over a resolver wired with no λ_c table can
    # never resolve one: every question it is asked would be refused at serve
    # time for a reason that was already true at registration, and a serve-time
    # refusal is for a class whose CONFIGURATION is sound and whose OBSERVATIONS
    # supply no instant. The two are different failures and keep different
    # boundaries.
    if resolver_table_key is None and boot_declaration.ttl_anchor == FROM_ENTITY_FRESHNESS:
        raise TTLAnchorUndeclared(
            f"product class {boot_declaration.schema_name!r} declares"
            " `ttl_anchor: from_entity_freshness` and this resolver is wired"
            " with no λ_c table: neither `half_life_key` nor"
            " `evidence_clock_key` was given, so no observation can ever supply"
            " an evidence instant. Name the deployment's table, or declare"
            " `ttl_anchor: from_decision` (D-IMPL-341 R-3, first row)"
        )
    if resolver_table_key is not None:
        refuse_undeclared_ttl_anchor(
            ttl_anchor=boot_declaration.ttl_anchor,
            entries=_artifact_on(fabric, key=resolver_table_key, expected=HalfLifeTable).entries,
            product_class=boot_declaration.schema_name,
        )
        # AND THE TABLE MUST BE PINNABLE, for the same reason and at the same
        # moment (`D-IMPL-341` review, 2026-09-18). An evidence-anchored serve
        # pins its λ_c table on dimension 2 so replay can re-derive the anchor
        # under the declarations that were in force; a table the manifest
        # declares `role: load` is parsed and returned but never registered
        # (`D-IMPL-80`), so `version_for` raises for it. Read only here, that
        # raise landed AFTER the question was admitted, the anchor resolved and
        # the gates passed — an exception where a governed refusal belongs, and
        # a record that could never be written. Asking at registration turns a
        # deployment that cannot record what it anchors on into a boot failure.
        if boot_declaration.ttl_anchor == FROM_ENTITY_FRESHNESS:
            fabric.pins.version_for(resolver_table_key)
    refuse_undeclared_class_default(
        schema_name=boot_declaration.schema_name,
        schema_version=boot_declaration.schema_version,
        serve_obligations=boot_declaration.serve_obligations,
        declared=_request_contract_on(fabric, key=request_contract_key),
    )
    # `D-IMPL-357` B3 round 3, in the same breath and for the same reason: a
    # class declaring a seam refusal for one of the SDK's OWN seam exceptions
    # has authored a control that can never fire, because the SDK's map is
    # consulted first. Refused HERE — where both documents are in hand, and
    # before the acquisition seam, the plan, the gates or any delivery — rather
    # than at the seam, which would turn a governance mistake into the very
    # runtime failure B3 removed.
    #
    # "Before any question" is true of the in-process adapter and the replay
    # environment, which build while opening. It is NOT true of the paved road,
    # which boots per question and builds inside `answer()`: there this is the
    # FIRST QUESTION's refusal, with the answering call already in flight. See
    # `_refuse_sdk_owned_seam_refusal` for why that is still the right site.
    _refuse_sdk_owned_seam_refusal(boot_declaration)

    # `24.11-04` / `D-IMPL-295`, immediately after and for the same reason: a
    # request-bound operator parameter naming an argument the contract does not
    # declare is two documents disagreeing, and boot is where they are both in
    # hand. Existence only — the artifact's own validation owns the type.
    _refuse_unbindable_request_parameter(
        parameters={
            key: _artifact_on(fabric, key=key, expected=OperatorParametersArtifact)
            for key in operator_parameter_keys
        },
        declared=_request_contract_on(fabric, key=request_contract_key),
        request_contract_key=request_contract_key,
    )

    # `R-11` (`D-IMPL-282` option 1a), immediately after: the class's declared
    # gate and the supplied callable must agree, and BOTH mismatches are
    # refused. Read off the declaration already parsed above rather than a
    # second read, so what the check sees is what the resolver will stamp.
    declared_gate = boot_declaration.declared_product_gate
    if declared_gate.gate_id and product_gate is None:
        raise TypeError(
            f"the product class {product_class_key!r} declares the runtime"
            f" gate {declared_gate.gate_id!r} at version"
            f" {declared_gate.gate_version!r}, and this call supplies no"
            " `product_gate` to run it. A declared check that nothing executes"
            " is a check that stops checking without going red, and an audit"
            " would read the declaration as an invariant in force. Pass the"
            " deployment's callable, or remove `declared_product_gate` from"
            " the class document (`D-IMPL-282` `R-11`)"
        )
    if product_gate is not None and not declared_gate.gate_id:
        raise TypeError(
            "this call supplies a `product_gate` and the product class"
            f" {product_class_key!r} declares none, so the SDK has no identity"
            " to stamp on a refusal it produced and replay could not say which"
            " gate refused. Declare `declared_product_gate` on the class"
            " document with the gate's id and version, or drop the argument"
            " (`D-IMPL-282` `R-11`; the identity is the Control Plane's half"
            " and the implementation is the deployment's)"
        )

    # `R-12` (`D-IMPL-282`), SECOND — before the constraint-resolver branch and
    # before any scorer material is read, so a wiring mistake is reported
    # before anything else is chosen. Per member, in Dave's ruled order:
    # explicit argument, then the deployment's declared binding, then a
    # refusal that names both places the value could have come from.
    # Asked only when something is actually missing, and that is what makes
    # the ambiguity refusal below a statement about this CALL rather than about
    # this deployment: a fabric declaring two bindings and a call naming all
    # three arguments has asked nothing ambiguous, and refusing it would break
    # a deployment that had already resolved its own ambiguity.
    binding = (
        _replay_binding_on(fabric)
        if artifact_store is None
        or replay_record_class is None
        or query_pin_class is None
        else None
    )
    record_class = (
        replay_record_class
        if replay_record_class is not None
        else _declared_member(
            binding, member="record_class", argument="replay_record_class"
        )
    )
    pin_class = (
        query_pin_class
        if query_pin_class is not None
        else _declared_member(
            binding, member="query_pin_class", argument="query_pin_class"
        )
    )
    if artifact_store is not None:
        store: ArtifactStoreProtocol = artifact_store
    else:
        dirname = _declared_member(
            binding, member="store_dirname", argument="artifact_store"
        )
        if artifact_store_root is None:
            raise TypeError(
                "this call omits `artifact_store` and this deployment declares"
                f" store_dirname {dirname!r}, which is half a location: a"
                " dirname is relative to a root, and the other half is the"
                " caller's. Pass `artifact_store_root`, or pass"
                " `artifact_store` — the SDK does not root a deployment's"
                " decision records at whichever directory the process happened"
                " to start in (`D-IMPL-282` `R-12`)"
            )
        # The file-backed reference store is what a dirname can select; a
        # deployment on the MCP-backed store passes `artifact_store` and wins
        # under the precedence above. See `ReplayBinding`'s own docstring,
        # where the limitation is recorded rather than left to be discovered.
        # The deployment's declaration of what its own mechanism writes and
        # under which kind (D-IMPL-353 §1.2): the two replay classes the
        # binding names and the SDK's admitted-child class, all `ReplayMint`.
        store = FileArtifactStore(
            root=Path(artifact_store_root) / dirname,
            write_kinds=WriteKinds.declare(
                {
                    record_class: (ReplayMint,),
                    pin_class: (ReplayMint,),
                    ADMITTED_CHILD_CONTRACT_CLASS: (ReplayMint,),
                }
            ),
        )

    # SEC-009 (`D-IMPL-374` (4), ruling 2): the erasure consult is composed
    # around whichever store was selected — supplied or default — over this
    # call's Control Plane, so every read the resolver and its recorder make
    # refuses erased content.
    # Fix round 4, ruling 5: the consult verifies through THIS Control Plane,
    # which must offer the pinned-read surface; refused by name otherwise.
    if not isinstance(control_plane, PinnedPolicySource):
        raise ErasureCompositionRefused(
            f"{type(control_plane).__name__} offers no pinned-read surface"
            " (resolve, versions, peek, artifact_class_of, keys_of_class,"
            " audit_events), so the erasure consult cannot verify an approval"
            " through it (SEC-009; D-IMPL-374 (4), fix round 4, ruling 5)"
        )
    # `D-IMPL-378` C1 (SDK-defined, CLAUDE.md §11): THE SERVE CLOCK, composed ONCE.
    # A tenant that declares a demonstration serve instant is served at that
    # instant — resolved here, from the Control Plane, at composition, and never
    # again, so nothing a question carries and nothing registered later moves it.
    # A clock this call was handed beside a declaration is refused by name, and
    # outside the SDK's own approved development backends the declaration itself
    # is refused (option (b), ruled by Dave 2026-10-08 10:50 MST; narrowed to the
    # SDK's own by decision 6 (b), 2026-10-09). Checked against
    # `store` as SELECTED, before the erasure consult wraps it.
    #
    # CONFINED: only the resolver's serve clock (`served_at`) is replaced. The
    # erasure consult below keeps `admission_clock`, the clock this call was
    # composed with, so an audit stamp on the Control Plane log never carries a
    # declared instant.
    serve_clock = compose_serve_clock(
        control_plane=control_plane,
        fabric=fabric,
        artifact_store=store,
        admission_clock=admission_clock,
        sdk_clock=_utc_now,
    )
    store = compose_erasure_consult(
        store,
        index=erasure_index,
        audit_log=control_plane.audit_log,
        clock=admission_clock,
        # Fix rounds 4 and 5: approvals and the door's record signatures
        # verify here, against the deployment's per-tenant trust root.
        control_plane=control_plane,
        erasure_trust=erasure_trust,
        tenant_id=fabric.tenant_id,
    )

    # `D-IMPL-343` R-3a, THIRD: the two TTL figures, from the call or from the
    # declared `ttl:` binding, held EQUAL when both speak and refused when
    # neither does. Before the R-12 scorer material for the R-12 reason.
    ceiling, lifetime = _resolve_ttl(
        fabric, max_ttl_seconds=max_ttl_seconds, product_ttl_seconds=product_ttl_seconds
    )
    # `D-IMPL-343` R-3b, the same shape for the decision instant: the class
    # DECLARES which request parameter carries it, this call may restate it,
    # and the two are held equal — a keyword that could name a different
    # parameter than the declaration would be the ungoverned second authority
    # `24.10-F-09` recorded and `D-IMPL-292` refuses.
    declared_instant = boot_declaration.decision_instant_parameter
    if decision_instant_parameter is None:
        decision_instant_parameter = declared_instant
    elif declared_instant is not None and declared_instant != decision_instant_parameter:
        raise TypeError(
            f"this call states `decision_instant_parameter={decision_instant_parameter!r}`"
            f" and the product class {product_class_key!r} declares"
            f" `decision_instant_parameter: {declared_instant}`; the class's"
            " declaration is the one authority for which argument carries the"
            " decision instant (D-IMPL-343 R-3b; D-IMPL-292) — drop the"
            " argument, or correct the declaration"
        )

    # Keyed by name rather than zipped against :data:`DEBT_SCORER_INPUTS`
    # positionally: a positional pairing goes on running after somebody reorders
    # the constant, and reports the wrong argument in both refusals below.
    # `tests/products/test_resolver_defaults.py::test_the_named_inputs_are_this_helper_s_own_optional_parameters`
    # holds the constant and this signature to each other in both directions.
    resolution_seam: PolicyConstraintResolver
    if constraint_resolver is not None:
        resolution_seam = constraint_resolver
    elif isinstance(control_plane, _ConstraintSource):
        resolution_seam = ReferencePolicyConstraintResolver(
            control_plane=control_plane,
            entitlement_key=product_entitlement_key(tenant_id=fabric.tenant_id),
        )
    else:
        # Structural, and checked rather than assumed: the reference resolver
        # needs a read surface `ControlPlaneProtocol` does not promise —
        # `keys_of_class`, `versions` and `peek`, which are how "what is in
        # force at this instant" is answered without reaching for the latest
        # version. The shipped `ControlPlaneRegistry` has all three. A plane
        # that does not is a wiring fact the caller can fix two ways, and both
        # are named.
        raise TypeError(
            "this call supplies no `constraint_resolver`, and the Control"
            f" Plane it was given ({type(control_plane).__name__}) does not"
            " offer the read surface the SDK's reference resolver needs:"
            " `keys_of_class`, `versions`, `peek` and `resolve`. Pass a"
            " conforming `PolicyConstraintResolver`, or a Control Plane that"
            " can be asked which constraints are in force"
        )
    technical = (
        _capabilities_of(fabric) if capabilities is None else capabilities
    )

    # 24.6-07: the SDK's own refusal recorder, over the store and tenant this
    # call already supplies. It is selected here for `debt_scorer`'s reason —
    # `GovernedResolver` is the auditable, defaultless composition and this
    # helper is where the SDK chooses its own reference — and it needs no
    # material a deployment is entitled to decide: the store, the artifact
    # class and the tenant are already arguments, and the assembly mode and
    # bundle pin are read off what the manifest put in force.
    #
    # Both are read HERE rather than per call, deliberately: a recorder is
    # bound to a deployment exactly as its resolver is, and a mode or a pin
    # re-read at each refusal could describe a deployment that had changed
    # since the determination it is recording.
    #
    # `D-IMPL-343`: a recorder the deployment already holds wins — the paved
    # road builds ONE over the declared binding and hands the same object to
    # this resolver and to its door, so a served and a refused decision cannot
    # land in two stores or under two classes. Nothing about the recorder the
    # SDK builds when none is handed in has changed.
    recorder: RefusalRecorderProtocol = refusal_recorder if refusal_recorder is not None else ReplayRefusalRecorder(
        authorized=_mint_replay_at_composition(
            control_plane, tenant=fabric.tenant_id, artifact_class=record_class
        ),
        artifact_store=store,
        assembly_mode=_artifact_on(
            fabric, key=product_class_key, expected=ProductClassDeclaration
        ).assembly_mode,
        policy_bundle_pin=PolicyBinding(
            key=policy_bundle_key,
            version=fabric.pins.version_for(policy_bundle_key),
        ),
        # 24.6-08: the posture in force, read from the deployment's own
        # registry per call for `ControlPlaneProductEntitlementSource`'s reason
        # (no cache, no TTL — a level changed in the Control Plane governs the
        # next determination, not the one after a process restart).
        disclosure_level_for=_disclosure_reader(control_plane),
    )

    declared: dict[str, object | None] = {
        "half_life_key": half_life_key,
        "debt_profile_key": debt_profile_key,
        "declared_completeness": declared_completeness,
        "declared_semantic_consistency": declared_semantic_consistency,
    }
    supplied = tuple(
        name for name in _SCORER_ONLY_INPUTS if declared[name] is not None
    )

    if debt_scorer is not None:
        if supplied:
            raise TypeError(
                "this call supplies both `debt_scorer` and"
                f" {', '.join(repr(name) for name in supplied)}, and the two are"
                " alternatives rather than layers: an explicit scorer replaces"
                " the SDK's reference entirely, so the material for building the"
                " reference would be read by nothing. Pass the scorer, or pass"
                f" {', '.join(repr(name) for name in DEBT_SCORER_INPUTS)} and let"
                " this helper select"
                " `ccf.products.debt_scorer.AssemblyDebtScorer`"
            )
        return GovernedResolver(
            fabric=fabric,
            control_plane=control_plane,
            product_class_key=product_class_key,
            request_contract_key=request_contract_key,
            operator_parameter_keys=operator_parameter_keys,
            policy_bundle_key=policy_bundle_key,
            # `24.11-03` / `24.10-F-08`: passed through on BOTH legs. A
            # deployment supplying its own scorer may still declare bands,
            # and the obligation it binds is not the scorer's to carry.
            debt_profile_key=debt_profile_key,
            plan_factory=plan_factory,
            debt_scorer=debt_scorer,
            product_gate=product_gate,
            constraint_resolver=resolution_seam,
            capabilities=technical,
            refusal_recorder=recorder,
            artifact_store=store,
            replay_record_class=record_class,
            query_pin_class=pin_class,
            max_ttl_seconds=ceiling,
            product_ttl_seconds=lifetime,
            decision_instant_parameter=decision_instant_parameter,
            source_refresh_recency=source_refresh_recency,
            composite_children=composite_children,
            admission_clock=serve_clock,
            acquisition=acquisition,
            population_acquisition=population_acquisition,
            packaging_trace=packaging_trace,
            half_life_key=resolver_table_key,
        )

    if (
        half_life_key is None
        or debt_profile_key is None
        or declared_completeness is None
        or declared_semantic_consistency is None
    ):
        missing = tuple(
            name for name in DEBT_SCORER_INPUTS if name not in supplied
        )
        raise TypeError(
            "this call supplies no `debt_scorer` and omits"
            f" {', '.join(repr(name) for name in missing)}, so there is nothing"
            " to measure `D_c` with. The SDK's reference scorer is the default"
            " and it is a construction rather than a value: it needs the two"
            " Control Plane keys naming this deployment's λ_c table and D_c"
            " bands, and the two factors the SDK has no measurement for. A"
            " resolver built without them could only serve an unscored product,"
            " which is why this is refused rather than defaulted"
        )

    return GovernedResolver(
        fabric=fabric,
        control_plane=control_plane,
        product_class_key=product_class_key,
        request_contract_key=request_contract_key,
        operator_parameter_keys=operator_parameter_keys,
        policy_bundle_key=policy_bundle_key,
        debt_profile_key=debt_profile_key,
        plan_factory=plan_factory,
        debt_scorer=AssemblyDebtScorer(
            table=_artifact_on(fabric, key=half_life_key, expected=HalfLifeTable),
            profile=_artifact_on(
                fabric, key=debt_profile_key, expected=DebtProfile
            ),
            completeness=DeclaredFactor(value=declared_completeness),
            semantic_consistency=DeclaredFactor(
                value=declared_semantic_consistency
            ),
        ),
        product_gate=product_gate,
        constraint_resolver=resolution_seam,
        capabilities=technical,
        refusal_recorder=recorder,
        artifact_store=store,
        replay_record_class=record_class,
        query_pin_class=pin_class,
        max_ttl_seconds=ceiling,
        product_ttl_seconds=lifetime,
        decision_instant_parameter=decision_instant_parameter,
        source_refresh_recency=source_refresh_recency,
        composite_children=composite_children,
        admission_clock=serve_clock,
        acquisition=acquisition,
        population_acquisition=population_acquisition,
        packaging_trace=packaging_trace,
        half_life_key=resolver_table_key,
    )
