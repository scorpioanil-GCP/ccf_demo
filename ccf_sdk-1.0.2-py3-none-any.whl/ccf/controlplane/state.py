# Copyright (c) 2026 David Castillo. All rights reserved.
# Use, copying, modification, and distribution of the covered material
# are governed by the CCF SDK Interim Software and Patent License
# in the repository-root LICENSE.md and any controlling signed agreement.
# Rights under that interim license begin only upon its execution
# and are limited to its stated scope and term.
"""Mutable-until-terminal Control Plane state, behind one pluggable seam.

DESIGN.md §7; CLAUDE.md §10. D-IMPL-27 splits persistence **by mutability**:
immutable, versioned, replay-relevant artifacts route through the
ArtifactStore, while hot mutable state stays on native Protocols. This module
is that native surface for Control Plane state records — the state a governed
process mutates as it runs, and stops mutating when it reaches a terminal
outcome, at which point what is durable about it is the audit trail and the
replay record, never this store.

D-IMPL-18 named the substrate for suspended workflow execution state as "the
Control Plane's storage seam — pluggable there, no separate workflow-store
Protocol." This is that seam, declared once so every mutable-state consumer
shares it rather than minting a store apiece.

**What belongs here.** State that is mutable until terminal and whose
transitions are already audited: skill-grant state (``requested`` →
``pending-approval`` → ``effective`` / ``refused``, plus ``revoked``);
suspended workflow execution state. What does not: the artifacts themselves.
A grant *artifact* is immutable and registers append-only into the versioned
registry; only the grant's *state* lives here. Confusing the two is the
mutability rule failing (D-IMPL-27).

**Records are opaque.** The store keys and returns them without interpreting
them, so the state shapes belong to their consumers and this module holds no
vocabulary of its own — no grant states, no workflow states, no record schema
(CLAUDE.md §11, CINV-01). A consumer that needs a typed record defines it
next to the machine that transitions it.

**Why a seam rather than instance attributes.** State cached on the consuming
object diverges from every other consumer over the same Control Plane: two
:class:`~ccf.skills.grants.GrantLedger` instances over one registry
disagreed about which grants were effective, so a replay-facing
``grant_set_hash`` computed on a fresh ledger did not reproduce the skill-set
the decision was actually made under (WR-05; CLAUDE.md §6.2). Reading state
from the Control Plane instead of from the reader makes the disagreement
unrepresentable.

**Durability is the implementation's business, not the caller's.** The
reference implementation is in-process, matching the v0 Control Plane
posture (CLAUDE.md §13: an in-process versioned registry with an extension
point for remote control planes). A deployment needing state to survive a
restart supplies a conforming store; no consumer changes.

**Writes carry two proofs, and they are different facts.**

* **Audited by construction — D-22-scoped (07-02; D-20 closure).** ``put``
  requires a :class:`StateWriteToken` that only this module mints, and the
  only supported minting path is :class:`AuditedStateWriter`, which appends
  the caller's domain :class:`~ccf.controlplane.audit.AuditEvent` to the one
  existing :class:`~ccf.controlplane.audit.AuditLog` on every write
  (INV-CH7-71: one audit plane, one event per write). An unaudited state
  write is therefore unrepresentable **through the public write surface**.
* **Authorized by construction — D-IMPL-353 §1.2, the derived-writes rule.**
  ``put`` also requires an :class:`~ccf.authz.capability.Authorized` of one
  of :data:`STATE_WRITE_KINDS` — the capability that authorized the action
  this write is a *consequence* of: the ``Execute`` / ``Resume`` that started
  or resumed the run whose state this is, the ``SkillGrant`` / ``SkillRevoke``
  whose transition this records. The store takes the **tenant** from that
  capability and from nothing else (§1.3): the key is derived by
  :func:`state_key` from ``authorized.tenant`` and the record's own identity
  within the tenant (``record_id`` — an execution id, a grant hash — which
  the writing mechanism generated *after* the decision and which the decision
  therefore could not name). A caller cannot supply the tenant, so a write
  under another tenant is not refused; it is inexpressible.

  The capability is verified before the dict is touched, by
  :func:`~ccf.authz.capability.verify` — mint, retargeting and kind by
  identity (§1.5c, g). Its resource axis is bound to the capability's own
  resource: for a derived write the target did not exist when the decision
  was made, so there is nothing else to bind it to, and the design records
  that *"a mismatch is unreachable on the served path"* (§1.2). The tenant is
  where the authority bites, and it bites structurally.

Bypass via reflection or private construction (reaching for this module's
private sentinel, skipping ``__init__`` machinery) is not denied; it is out
of the claim's scope by design and is lint- and CI-covered instead (D-08,
D-22; D-IMPL-353 §5 — the same limit single-writer has).

**Reads remain unaudited and uncapabilitied, by scope of the same rulings.**
``get`` and ``items`` carry no token and append nothing: the closure governs
*writes*. A reader can enumerate state through ``items``; what it cannot do
is change state without leaving a record, or under a tenant it was not
authorized for.

Algorithmic module (CINV-03).
"""

from __future__ import annotations

import re
import secrets
import threading
from typing import TYPE_CHECKING, Final, Protocol, TypeAlias, runtime_checkable

from ccf.authz.capability import (
    verify_any,
    ActionKind,
    Authorized,
    Execute,
    Resume,
    DeclaredSkillGrant,
    SkillGrant,
    SkillRevoke,
    verify,
)
from ccf.controlplane.audit import AuditEvent, AuditLog

if TYPE_CHECKING:
    from ccf.graph.protocols import WriterLease

__ccf_mode__ = "algorithmic"

__all__ = [
    "STATE_KEY_SEPARATOR",
    "STATE_STORE_IDENTITY_PATTERN",
    "STATE_WRITE_KINDS",
    "AuditedStateWriter",
    "ConditionalStateStore",
    "ControlPlaneStateStore",
    "InMemoryStateStore",
    "StateConflict",
    "StateKeyError",
    "StateStoreIdentityMissing",
    "StateTenantMismatch",
    "StateWriteAuthority",
    "StateWriteBypassError",
    "StateWriteToken",
    "split_state_key",
    "state_key",
    "state_store_identity_of",
    "verify_any",
]


class StateWriteBypassError(TypeError):
    """A state write was attempted outside the audited write path.

    The same discipline as
    :class:`~ccf.peering.admission.AdmissionBypassError`: the token type is
    constructible only inside this module, so holding one *is* the evidence
    the audited path ran (D-08; D-22-scoped — public write surface only).
    """


class StateKeyError(ValueError):
    """A state key could not be derived unambiguously (D-IMPL-353 §1.3).

    The key is ``{tenant}{sep}{record_id}`` and must split back to exactly
    the pair that built it, or two tenants could share a key. A tenant that
    is empty, untrimmed, or carries the separator is refused at derivation —
    a misconfiguration surfaced where the operator sees it, never a decision
    about any caller.
    """


class StateTenantMismatch(PermissionError):
    """A record claims a tenant other than the capability's (D-IMPL-353 §1.3).

    Records are opaque to the store, with one exception the design requires:
    a record that *declares* a ``tenant`` must declare the capability's. The
    store files under ``authorized.tenant`` and nothing else may name one, so
    a record carrying another tenant would be filed under a tenant it does not
    describe — broken wiring, refused before the dict is touched.
    """


class StateConflict(RuntimeError):
    """A conditional state write found the record moved since its writer read it.

    SDK-defined (``D-IMPL-378``; Dave's ruling on the conditional state write,
    2026-10-07). :meth:`ConditionalStateStore.put_if` writes only when the key
    is still at the version its writer read; otherwise it writes nothing and
    raises this. The workflow engine reads it as "another writer moved this
    execution first" and refuses, so two passages past one suspension, or two
    starts of one execution id, cannot both commit, whichever process or
    state-store object each runs in. Measured by
    ``tests/workflow/test_approval_gate_limits.py`` and
    ``tests/conformance/test_gate_closure_and_conditional_write.py``.
    """


_STATE_WRITE_TOKEN = object()


class StateWriteToken:
    """Evidence that a state write travels the audited path (D-20 closure).

    Not constructible outside this module: the constructor demands the
    module-private sentinel, and :meth:`InMemoryStateStore.put` verifies the
    mint rather than trusting the type alone — a subclass that skips this
    ``__init__`` is refused at the write. The only supported producer is
    :class:`AuditedStateWriter`.

    D-22 scope: this makes an unaudited write unrepresentable through the
    *public write surface*; reflection and private-construction bypasses are
    lint- and CI-covered, never claimed impossible.
    """

    __slots__ = ("_minted",)

    def __init__(self, token: object) -> None:
        if token is not _STATE_WRITE_TOKEN:
            raise StateWriteBypassError(
                "StateWriteToken is minted only by"
                " ccf.controlplane.state.AuditedStateWriter; the audited"
                " write surface is the only path by which Control Plane"
                " state changes, so the write and its audit event are one"
                " action (INV-CH7-71; D-08; D-20 closure, 07-02)"
            )
        self._minted = _STATE_WRITE_TOKEN


def _verify(token: StateWriteToken) -> None:
    """Refuse a token this module did not mint (subclass/forgery guard)."""
    if getattr(token, "_minted", None) is not _STATE_WRITE_TOKEN:
        raise StateWriteBypassError(
            "the supplied token was not minted by"
            " ccf.controlplane.state.AuditedStateWriter; write Control Plane"
            " state through the audited surface (D-08; D-20 closure, 07-02)"
        )


# --- the capability half (D-IMPL-353) ---------------------------------------

#: The kinds whose handles write Control Plane state as a consequence of the
#: action they perform (§1.2, the derived-writes rule): the workflow engine
#: under the ``Execute`` / ``Resume`` that authorized the run, the grant
#: ledger under the ``SkillGrant`` / ``SkillRevoke`` whose transition it
#: records. A tuple, not a set: the order is the order a diagnostic names
#: them in. SDK action kinds are mechanism, not domain values (CINV-01).
STATE_WRITE_KINDS: Final[tuple[type[ActionKind], ...]] = (
    Execute,
    Resume,
    SkillGrant,
    SkillRevoke,
    # Ruling 4 (Dave, 2026-10-11): the composition root's declared grant writes the
    # same grant state records, under its own distinct kind.
    DeclaredSkillGrant,
)

#: The static type of ``put``'s first parameter — the union of the four, so a
#: handler holding any other kind is a ``mypy --strict`` error at the call.
StateWriteAuthority: TypeAlias = (
    Authorized[Execute]
    | Authorized[Resume]
    | Authorized[SkillGrant]
    | Authorized[SkillRevoke]
    | Authorized[DeclaredSkillGrant]
)


#: The one character between the tenant and the record id in a state key.
#: The engine keyed ``{tenant}/{execution_id}`` before the derivation moved
#: here; keeping the character keeps every recorded key readable.
STATE_KEY_SEPARATOR: Final[str] = "/"


def state_key(*, tenant: str, record_id: str) -> str:
    """The key a state record lives under: ``{tenant}/{record_id}`` (§1.3).

    Derived, never spelled by a caller. Injective: the tenant may not carry
    the separator (nor be empty or untrimmed), so splitting at the *first*
    separator recovers exactly the pair — a record id is free to contain it.

    Raises:
        StateKeyError: the tenant or record id cannot make an unambiguous key.
    """
    if not tenant or tenant != tenant.strip() or STATE_KEY_SEPARATOR in tenant:
        raise StateKeyError(
            f"tenant {tenant!r} cannot form a state key: a tenant must be a"
            f" non-empty, trimmed string without {STATE_KEY_SEPARATOR!r}, or"
            " two tenants could share one key (D-IMPL-353 §1.3)"
        )
    if not record_id:
        raise StateKeyError(
            "a state record needs an identity within its tenant; an empty"
            " record id names nothing (D-IMPL-353 §1.2)"
        )
    return f"{tenant}{STATE_KEY_SEPARATOR}{record_id}"


def split_state_key(key: str) -> tuple[str, str]:
    """The ``(tenant, record_id)`` a :func:`state_key` was built from.

    Raises:
        StateKeyError: ``key`` carries no tenant segment.
    """
    tenant, separator, record_id = key.partition(STATE_KEY_SEPARATOR)
    if not separator or not tenant or not record_id:
        raise StateKeyError(
            f"{key!r} is not a state key: expected"
            f" '{{tenant}}{STATE_KEY_SEPARATOR}{{record_id}}' (D-IMPL-353 §1.3)"
        )
    return tenant, record_id


@runtime_checkable
class ControlPlaneStateStore(Protocol):
    """The mutable-state surface a Control Plane must offer (D-IMPL-18/27).

    Records are addressed by ``(record_class, key)``. ``record_class``
    partitions the namespace so unrelated machines never collide on a shared
    key; it is an opaque identifier owned by the consuming module, exactly as
    :class:`~ccf.controlplane.artifacts.ArtifactClass` is for artifacts. The
    key is :func:`state_key` of the writing capability's tenant and the
    record's own id; readers derive the same key the same way.

    Deliberately not append-only, unlike the registry: these records are
    mutable by definition, and their history lives in the audit log rather
    than in accumulated versions here. A store that versioned records would
    be answering a question D-IMPL-18 left to the durable implementation.
    """

    def get(self, record_class: str, key: str) -> object | None:
        """Return the record under ``key``, or ``None`` if there is none."""
        ...

    def put(
        self,
        authorized: StateWriteAuthority,
        record_class: str,
        record: object,
        *,
        record_id: str,
        token: StateWriteToken,
    ) -> None:
        """Write ``record`` under ``state_key(authorized.tenant, record_id)``, replacing any prior record.

        ``authorized`` is the D-IMPL-353 proof: the capability for the action
        this write is a consequence of (:data:`STATE_WRITE_KINDS`), verified
        before anything is touched, and the only source of the tenant.
        ``token`` is the D-20 closure: only the audited write path
        (:class:`AuditedStateWriter`) mints one. An implementation that
        honours this signature cannot be written to unaudited, nor under a
        tenant nobody authorized, through the public write surface.
        """
        ...

    def items(self, record_class: str) -> tuple[tuple[str, object], ...]:
        """Every ``(key, record)`` pair in one class, key-sorted.

        Sorted so callers that fold over the class — computing a set
        identity, listing what is in force — get an arrival-order-independent
        traversal, and a replay of the same state produces the same walk.
        """
        ...


#: The shape a state store's identity must have (``D-IMPL-391``, design 1.4):
#: 256 bits written as 64 lowercase hex characters. Mechanism, not a domain
#: value. The engine can check the shape; it cannot check that the value is
#: unique or persisted, which is what the conformance suite
#: (``tests/conformance/test_gate_closure_and_conditional_write.py``) checks.
STATE_STORE_IDENTITY_PATTERN: Final[re.Pattern[str]] = re.compile(r"[0-9a-f]{64}")


class StateStoreIdentityMissing(TypeError):
    """A state store declares no well-formed :attr:`ConditionalStateStore.identity`.

    SDK-defined (``D-IMPL-391``; ``D-IMPL-378`` decision 2 (b): *"Unsupported
    implementations refuse construction."*). Without a stable identity an
    approval cannot be bound to the store that suspended the run.
    """


def state_store_identity_of(store: object) -> str:
    """Return ``store``'s identity, or refuse a missing or malformed one by name.

    Checks the SHAPE only (:data:`STATE_STORE_IDENTITY_PATTERN`); uniqueness and
    persistence are the conformance suite's to check. The value must be a plain
    ``str``, not a subclass: a subclass can override comparison and make every
    record look like this store's own.

    Raises:
        StateStoreIdentityMissing: ``identity`` is absent, not exactly a ``str``,
            or not 64 lowercase hex characters.
    """
    identity = getattr(store, "identity", None)
    if type(identity) is not str or STATE_STORE_IDENTITY_PATTERN.fullmatch(identity) is None:
        raise StateStoreIdentityMissing(
            f"the Control Plane state store {type(store).__name__} declares no stable"
            " identity: `identity` must be 64 lowercase hex characters, minted once per"
            " substrate from a CSPRNG and persisted with its records, so an approval"
            " can be bound to the store that suspended the run (SEC-001; D-IMPL-391,"
            " D-IMPL-378 decision 2 (b))"
        )
    return identity


@runtime_checkable
class ConditionalStateStore(ControlPlaneStateStore, Protocol):
    """The conditional write a store offers, so no write overwrites a record it never saw.

    SDK-defined (``D-IMPL-378``; Dave's ruling of 2026-10-07 approved the
    conditional state write). Every successful write of a key — conditional or
    not — increments that key's version; version ``0`` means absent.
    :meth:`put_if` runs every proof :meth:`put` runs and then writes only if the
    key's current version equals ``expected_version``, atomically against every
    other write of the same key by every client of the same durable store: an
    optimistic version column in a database, or a row lock in one transaction.
    ``expected_version=0`` creates only if absent.

    ``scope`` declares who shares the records: ``"process"`` for a store no
    other process can reach, ``"shared"`` for a durable store several reach.
    The workflow engine refuses, at construction and by name, a state store
    that is not a ``ConditionalStateStore`` or declares no known scope, and a
    ``"shared"`` store paired with a HITL transport that is not ``"shared"``
    (Dave: *"Unsupported third-party implementations must fail at
    construction."*). The reference store's behavior under concurrent writers
    is pinned by ``tests/conformance/test_gate_closure_and_conditional_write.py``;
    a deployment runs that suite against its own store.

    **``identity`` names the substrate** (``D-IMPL-391``, design 1.4; SEC-001;
    ``D-IMPL-378`` decision 2 (b): *"Bind approval events and closures to the
    suspending state store's stable identity. It must survive restart and
    distinguish independent stores."*). The workflow engine stamps it on every
    record it writes, so the suspension hash every approval request, verdict,
    gate closure and passage names carries the store, and an approval counts only
    in the store that paused the run. The contract:

    * 256 bits from a CSPRNG, written as 64 lowercase hex characters
      (:data:`STATE_STORE_IDENTITY_PATTERN`), **minted once per substrate** — the
      records' durable home — when the substrate is created; never configured,
      and never derived from a hostname, a path, a deployment name or any other
      value an operator types;
    * **persisted with the records**, at the same durability, and never
      rewritten;
    * **the same for every client object** of one substrate, in every process
      and across restarts;
    * **different for an independent substrate**;
    * a store **whose records do not survive a restart mints it per
      construction**: its records are gone, so a new object is a new store
      (:class:`InMemoryStateStore`).

    **A copied store MUST refuse to open** (Dave, 2026-10-09 10:54 MST: *"A
    copied store must refuse, not 'should.'"*). A durable store records, beside
    its identity, where its substrate lives (for a file or a directory, its
    device and inode), and refuses to open anywhere else until an operator
    deliberately re-mints the identity. A re-mint STRANDS every run in flight in
    the store: their records name the old identity, so the engine refuses them as
    another store's (``rebind_legacy_suspension`` re-pauses only records with no
    identity), and an operator reconciles them outside the fabric. A
    store that cannot detect a copy (a network service, a VM snapshot) does not
    conform. Reference recipes: a file or SQLite store creates a one-row table or
    file in the same transaction as its schema and reads it at open; PostgreSQL
    creates a one-row table with the schema (``INSERT ... ON CONFLICT DO
    NOTHING``, then ``SELECT``); a network service mints the identity at
    provisioning and serves it, and its client reads it at construction and
    raises if it cannot.

    **A path-backed store declaring ``scope = "process"`` MUST hold an exclusive
    SEC-013 lease on its substrate from open to close** (``D-IMPL-391``, Dave's
    ruling 2(a) of 2026-10-17: *"Stores labeled single-process get the graph
    store's lock. A second process is refused by name."*). It takes the lease
    (``src/ccf/graph/leases.py::LockFileWriterLease``, on a lock file inside the
    substrate's directory, or keyed on device and inode in a declared directory
    as the graph's SQLite store does) when it is OPENED, before it reads a
    record, so a second process can neither submit a verdict nor read in-flight
    state; refuses to open while another holder has it, raising
    :class:`~ccf.graph.protocols.WriterLeaseHeld` naming the lock and this rule,
    and logging one record that says so in the refused process only (a refused
    process writes nothing into the store it was refused); and releases it on
    close and when the object is collected (``weakref.finalize``: a
    ``LockFileWriterLease`` never releases itself). It offers the held lease as
    ``writer_lease()``; a path-backed subclass of :class:`InMemoryStateStore`
    MUST override the in-memory declaration it would otherwise inherit. That
    method is NOT a member of this Protocol — a
    ``"shared"`` store, multi-process by declaration, takes no lease — but
    :class:`~ccf_runtime.workflow.engine.WorkflowEngine` refuses, by name, a
    ``"process"`` store that offers none. The engine can see that the lease is
    offered, never that it was taken at open; that is this MUST, and the
    conformance suite's.
    """

    @property
    def scope(self) -> str:
        """``"process"`` or ``"shared"``."""
        ...

    @property
    def identity(self) -> str:
        """The substrate's stable identity: 64 lowercase hex characters (see above)."""
        ...

    def get_versioned(self, record_class: str, key: str) -> tuple[object | None, int]:
        """The record under ``key`` and its version; ``(None, 0)`` when absent."""
        ...

    def put_if(
        self,
        authorized: StateWriteAuthority,
        record_class: str,
        record: object,
        *,
        record_id: str,
        token: StateWriteToken,
        expected_version: int,
    ) -> int:
        """Write only if the key is still at ``expected_version``; return the new version.

        Raises:
            StateConflict: the key's version is not ``expected_version``;
                nothing was written.
        """
        ...


class InMemoryStateStore:
    """In-process reference implementation of :class:`ControlPlaneStateStore`.

    Ships alongside the Protocol per CLAUDE.md §11, and is the v0 default:
    the Control Plane is itself in-process (CLAUDE.md §13), so state held here
    is exactly as durable as the registry and audit log beside it. It is the
    development and single-process implementation, not a placeholder for one —
    a durable store is an alternative implementation of the same Protocol,
    added without touching a consumer.

    It is a :class:`ConditionalStateStore` of scope ``"process"``
    (``D-IMPL-378``): every write increments the key's version under one lock,
    and :meth:`put_if` compares and writes inside that same lock. Its
    :attr:`identity` is minted when the object is constructed and dies with it
    (``D-IMPL-391``): its records live in this object only, so a new object is
    a new store, and an approval taken against a store that no longer exists
    counts in none.
    """

    #: No other process can reach these records (``D-IMPL-378``).
    scope = "process"

    def __init__(self) -> None:
        self._identity = secrets.token_hex(32)
        self._records: dict[tuple[str, str], object] = {}
        self._versions: dict[tuple[str, str], int] = {}
        self._write_lock = threading.Lock()

    @property
    def identity(self) -> str:
        """Minted per construction (``D-IMPL-391``; see the class docstring)."""
        return self._identity

    def writer_lease(self) -> WriterLease:
        """The ``"process"`` declaration: exact, because no other process can reach this memory.

        ``D-IMPL-391`` (ruling 2(a)). A disclosure, not a lock: there is no
        substrate a second process could open.
        """
        from ccf.graph.protocols import ProcessScopedWriterLease

        return ProcessScopedWriterLease(substrate="in-memory Control Plane state store")

    def get(self, record_class: str, key: str) -> object | None:
        """Return the record under ``key``, or ``None`` if there is none."""
        return self._records.get((record_class, key))

    def get_versioned(self, record_class: str, key: str) -> tuple[object | None, int]:
        """The record under ``key`` and its version; ``(None, 0)`` when absent (``D-IMPL-378``).

        The version is read BEFORE the record, without the write lock, so a
        torn read can only pair a newer record with an older version — which
        makes the reader's later :meth:`put_if` conflict, never succeed wrongly.
        """
        version = self._versions.get((record_class, key), 0)
        return self._records.get((record_class, key)), version

    def put(
        self,
        authorized: StateWriteAuthority,
        record_class: str,
        record: object,
        *,
        record_id: str,
        token: StateWriteToken,
    ) -> None:
        """Write ``record`` under the derived key, replacing any prior record.

        Order is the order of proofs: the capability first (D-IMPL-353
        §1.5 — fabricated, retargeted or wrong-kind dies here, before the
        token is even read), then the token's mint (D-22), then the key is
        derived from the capability's tenant and the dict is touched. A
        refusal at either proof leaves the store byte-for-byte as it was.
        """
        verify_any(
            authorized,
            kinds=STATE_WRITE_KINDS,
            resource=getattr(authorized, "resource", ""),
        )
        _verify(token)
        claimed = getattr(record, "tenant", authorized.tenant)
        if claimed != authorized.tenant:
            raise StateTenantMismatch(
                f"the record declares tenant {claimed!r} but the capability is"
                f" for {authorized.tenant!r}; state is filed under the"
                " capability's tenant and a record may not name another"
                " (D-IMPL-353 §1.3)"
            )
        key = state_key(tenant=authorized.tenant, record_id=record_id)
        with self._write_lock:
            self._records[(record_class, key)] = record
            self._versions[(record_class, key)] = (
                self._versions.get((record_class, key), 0) + 1
            )

    def put_if(
        self,
        authorized: StateWriteAuthority,
        record_class: str,
        record: object,
        *,
        record_id: str,
        token: StateWriteToken,
        expected_version: int,
    ) -> int:
        """Write only if the key is still at ``expected_version`` (``D-IMPL-378``).

        The same proofs as :meth:`put`, in the same order, then one locked
        compare-and-write; returns the new version. ``expected_version=0``
        creates only if absent.

        Raises:
            StateConflict: the key is at another version; nothing was written.
        """
        verify_any(
            authorized,
            kinds=STATE_WRITE_KINDS,
            resource=getattr(authorized, "resource", ""),
        )
        _verify(token)
        claimed = getattr(record, "tenant", authorized.tenant)
        if claimed != authorized.tenant:
            raise StateTenantMismatch(
                f"the record declares tenant {claimed!r} but the capability is"
                f" for {authorized.tenant!r}; state is filed under the"
                " capability's tenant and a record may not name another"
                " (D-IMPL-353 §1.3)"
            )
        key = state_key(tenant=authorized.tenant, record_id=record_id)
        with self._write_lock:
            current = self._versions.get((record_class, key), 0)
            if current != expected_version:
                raise StateConflict(
                    f"the record under {key!r} is at version {current}, not"
                    f" {expected_version}: another writer moved it after this"
                    " writer read it, so this write is refused rather than"
                    " overwriting what it never saw"
                )
            self._records[(record_class, key)] = record
            self._versions[(record_class, key)] = current + 1
            return current + 1

    def items(self, record_class: str) -> tuple[tuple[str, object], ...]:
        """Every ``(key, record)`` pair in one class, key-sorted."""
        return tuple(
            (key, record)
            for (cls, key), record in sorted(self._records.items())
            if cls == record_class
        )


class AuditedStateWriter:
    """The ergonomic — and only supported — Control Plane state-write surface.

    Constructor-injected (store + the one existing
    :class:`~ccf.controlplane.audit.AuditLog`, keyword-only, house pattern),
    it mints the :class:`StateWriteToken` internally, performs the write, and
    appends the caller's domain event — both mechanisms of D-08 in one place:
    the audit-bearing path as the ergonomic surface, the token as what the
    raw seam requires. The capability is *not* minted here: it arrives from
    the handle that holds it, and travels through unchanged (D-IMPL-353 §1.2).

    **Audit-event policy (fixed in 07-02; INV-CH7-71).** ``write`` takes the
    caller's domain :class:`~ccf.controlplane.audit.AuditEvent` as a required
    parameter and appends exactly that one event per write: the write
    evidence rides on the domain event, so domain transition evidence is
    never lost and the journal never doubled. The log reassigns the
    ``sequence`` on append — sequencing belongs to the log, which is its own
    stated contract ("callers cannot mis-number the log"); every other field
    is the caller's, verbatim. Callers with no domain semantics use the
    generic ``state_written`` :data:`~ccf.controlplane.audit.AuditAction`.

    There is no parallel log type: this appends to
    :class:`~ccf.controlplane.audit.AuditLog` and nothing else (D-08).
    """

    def __init__(
        self, *, store: ControlPlaneStateStore, audit: AuditLog
    ) -> None:
        self._store = store
        self._audit = audit

    def write(
        self,
        authorized: StateWriteAuthority,
        record_class: str,
        record: object,
        *,
        record_id: str,
        event: AuditEvent,
    ) -> AuditEvent:
        """Write ``record``, then append ``event``: two writes, one event for the one state write.

        The store verifies ``authorized``; a refusal there propagates and no
        event is appended, because there was no write to evidence. The append
        is a separate write that runs after the store's write lands: if it
        fails, the record has moved and no event exists for that transition —
        the same window :meth:`write_if` states (``D-IMPL-378`` decision 7:
        detection and recovery are being designed, not built).

        Returns the appended event, sequence assigned by the log.
        """
        self._store.put(
            authorized,
            record_class,
            record,
            record_id=record_id,
            token=StateWriteToken(_STATE_WRITE_TOKEN),
        )
        return self._audit.append(
            action=event.action,
            key=event.key,
            version=event.version,
            resolved=event.resolved,
            occurred_at=event.occurred_at,
            actor=event.actor,
            artifact_class=event.artifact_class,
        )

    def write_if(
        self,
        authorized: StateWriteAuthority,
        record_class: str,
        record: object,
        *,
        record_id: str,
        event: AuditEvent,
        expected_version: int,
    ) -> tuple[AuditEvent, int]:
        """:meth:`write`, conditional (``D-IMPL-378``).

        The store's :meth:`ConditionalStateStore.put_if` first, then the event:
        a refused write appends nothing, so the audit log never records a
        transition the store did not take. Returns the appended event and the
        record's new version.

        These are two writes, not one atomic step. If the append fails after
        ``put_if`` landed, the record has moved and the log holds no event for
        the transition; the append's error propagates to the caller
        (``tests/controlplane/test_audited_write_is_two_writes.py``). Making
        such a transition detectable and recoverable is being designed
        (``D-IMPL-378``, decision 7 (b)), not built.

        Raises:
            StateConflict: the record moved since ``expected_version`` was read.
            TypeError: the store offers no conditional write.
        """
        if not isinstance(self._store, ConditionalStateStore):
            raise TypeError(
                f"the Control Plane state store {type(self._store).__name__}"
                " offers no conditional write (get_versioned / put_if)"
            )
        version = self._store.put_if(
            authorized,
            record_class,
            record,
            record_id=record_id,
            token=StateWriteToken(_STATE_WRITE_TOKEN),
            expected_version=expected_version,
        )
        appended = self._audit.append(
            action=event.action,
            key=event.key,
            version=event.version,
            resolved=event.resolved,
            occurred_at=event.occurred_at,
            actor=event.actor,
            artifact_class=event.artifact_class,
        )
        return appended, version

