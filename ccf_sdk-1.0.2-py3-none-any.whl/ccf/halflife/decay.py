# Copyright (c) 2026 David Castillo. All rights reserved.
# Use, copying, modification, and distribution of the covered material
# are governed by the CCF SDK Interim Software and Patent License
# in the repository-root LICENSE.md and any controlling signed agreement.
# Rights under that interim license begin only upon its execution
# and are limited to its stated scope and term.
"""λ_c — Context Half-life as formal decay (whitepaper §7.7).

The whitepaper commits to one formula::

    R(t) = R₀ × (1/2)^((t − t₀) / λ_c)

and to two properties of λ_c that shape this module more than the arithmetic
does:

**λ_c is Control Plane configuration per observation type, never code**
(INV-CH7-58). A 10-K's half-life is months; a sanctions match's is minutes.
The SDK ships the curve and refuses to ship the calibration — the whitepaper's
own illustrative table says as much ("these values are illustrative, not
empirical"). So there is no table in this module, no fallback rate, and no
``default=`` anywhere: an observation type the deployment never declared raises
:class:`MissingHalfLife` (D-IMPL-38). A fabricated decay rate would express a
confidence nobody chose, and it would express it in the one number the
Conditional Assessment Routing predicate reads.

**λ_c is not a TTL** (INV-CH7-57). Decay is a continuous curve, not a cutoff:
:func:`relevance_ratio` never returns zero and never raises on age, because
data past its half-life stays accessible for historical reconstruction —
Decision Replay depends on it (whitepaper §7.10) — while no longer counting as
current for decision purposes.

Determinism
-----------
Every quantity is :class:`~decimal.Decimal` and every computation runs in a
pinned decimal context, because these numbers reach the replay record. Floats
are excluded by construction: the canonical serializer refuses them (they are
not bit-stable across platforms), and a freshness figure that reproduces
differently on the auditor's machine is not a freshness figure. Elapsed time is
measured in whole microseconds rather than ``timedelta.total_seconds()``, which
returns a float.

The clock is always injected. Decay reads ``now`` as an argument, never from
the wall clock, so a decision's freshness re-computes identically years later.

The supersede-only mode
-----------------------
Whitepaper §7.7.1–§7.7.2 binds λ_c to the observation type and gives one class
an *event-driven* λ_c rather than a band: an observation that a later event
rewrites outright — the whitepaper's restatement case — does not lose relevance
along a curve, it loses all of it at once when the superseding event arrives.
:class:`~ccf.controlplane.artifacts.HalfLifeEntry` can now declare that shape
(``decay: "supersede-only"``, ledger row ``24.5-L-22``), and this module reads
it: :func:`decay_mode_of` reports the mode, :func:`half_life_of` raises
:class:`NoDecayCurve` rather than hand a curve for a class that has none, and
:func:`freshness` returns retained relevance **1** for such an observation at
any age. That figure is not a claim that the observation is current — it is
the statement that *nothing but the supersession event* ends its relevance,
and a superseded observation is excluded from the as-of view by logical
supersession (INV-CH7-14) before freshness is ever read, so the value never
scores a stale one. Both refusals this function makes for a curve class (a
naive instant, an observation from the future) are made first and in both
modes; the mode decides only what happens to an observation that passed them.

Algorithmic module (CINV-03): pure functions over typed inputs, no I/O, no
clock, no LLM dependency ever.
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import datetime, timedelta
from decimal import Decimal, localcontext
from typing import Final

from pydantic import Field, field_validator

from ccf.controlplane.artifacts import (
    DecayBasis,
    DecayMode,
    FreshnessAggregation,
    HalfLifeEntry,
    HalfLifeTable,
)
from ccf.contracts.base import CCFContract
from ccf.contracts.canonical import HASH_TRANSPARENT_KEY
from ccf.halflife.assessment import (
    _SDK_NAMESPACE,
    _as_a_reader_sees_it,
    _refuse_an_impersonation_of_an_sdk_marker,
    _refuse_an_instant_that_named_no_zone,
)

__ccf_mode__ = "algorithmic"

__all__ = [
    "NO_SUBJECT_IDENTITY",
    "HalfLifeEntry",
    "HalfLifeTable",
    "MissingDecayInstant",
    "MissingHalfLife",
    "NoDecayCurve",
    "Observation",
    "TemporalOrderError",
    "decay_basis_of",
    "decay_mode_of",
    "freshness_over_of",
    "leading_edge",
    "series_key_attribute_of",
    "effective_half_life",
    "freshness",
    "half_life_of",
    "relevance_ratio",
]

#: Working precision for the decay computation. Pinned rather than inherited
#: from the ambient decimal context so that two processes with different
#: contexts cannot produce two freshness figures for one observation.
DECIMAL_PRECISION = 28

#: Quantum every returned ratio is rounded to. Rounding at a fixed exponent is
#: what makes the value stable enough to compare bit-for-bit in replay; the
#: exponent is deep below any threshold band a deployment would configure.
RATIO_QUANTUM = Decimal(1).scaleb(-18)

_HALF = Decimal(1) / Decimal(2)
_MICROSECOND = timedelta(microseconds=1)


class MissingHalfLife(LookupError):
    """No λ_c is declared for the requested observation type.

    Raised instead of substituting a rate. See the module docstring
    (INV-CH7-58, D-IMPL-38).
    """


class NoDecayCurve(LookupError):
    """The requested observation type is declared supersede-only: it has no curve.

    Raised by :func:`half_life_of` instead of fabricating a rate. A caller that
    wants a curve for an event-driven class is asking the wrong question — the
    class's relevance is ended by its supersession event, not read off a
    half-life — and handing back any ``timedelta`` at all would express a decay
    nobody declared, which is the same silent default :class:`MissingHalfLife`
    exists to refuse (whitepaper §7.7.2; INV-CH7-58; ``24.5-L-22``).

    A ``LookupError`` sibling of :class:`MissingHalfLife` rather than a subclass
    of it: an undeclared type and a declared-supersede-only type are different
    authoring states, and a handler that catches the first to prompt for a
    calibration must not swallow the second, whose fix is to stop asking.
    """


class MissingDecayInstant(LookupError):
    """A row declares ``valid-from`` and the observation carries none (``D-IMPL-331``).

    **Refused rather than fallen back.** A silent fallback to ``observed_at``
    would report a perfectly fresh figure for a claim whose real age nobody
    knows — and it would do it for exactly the observations a deployment
    declared ``valid-from`` *because* it cared about their real age. The two
    instants answer different questions (:data:`~ccf.controlplane.artifacts.DecayBasis`),
    and an absent answer is not the other answer.
    """


class TemporalOrderError(ValueError):
    """An observation is timestamped after the instant it is evaluated at.

    Surfaced rather than clamped to "perfectly fresh": an observation from the
    future means a clock, a source, or an as-of boundary is wrong, and silently
    scoring it at full relevance would convert a data-integrity fault into a
    confident decision.
    """


#: The positive assertion that an observation was recorded **without** a subject
#: identity — *this observation names nothing it is an observation of* — in the
#: voice of :data:`~ccf.halflife.assessment.NO_SCORER_PINS` and
#: :data:`~ccf.replay.record.NO_GRAPH_QUERIES`, and for their reason.
#:
#: ``D-IMPL-120`` ruled the identity **optional** (``qc-optional``) and ruled out
#: expressing its absence as ``None``: an assembler that had no identity to
#: carry and one that dropped the identity it held would then be the same
#: artifact, which is the repudiation failure mode every sentinel in this fabric
#: closes (``D-IMPL-38``'s no-silent-defaults discipline). A marker string rather
#: than an empty container because the field is one opaque string and must stay
#: one shape.
#:
#: **SDK-namespaced on purpose**, in
#: :data:`~ccf.halflife.assessment.NO_OBLIGATION_IN_FORCE`'s style and for its
#: stated reason: the marker must read as SDK structure rather than as a word
#: from somebody's domain, and a deployment must not be able to collide with it
#: by accident while reaching for an ordinary phrase. Phase 15.6's close-time
#: cross-AI panel found this constant spelled ``"no-subject-identity"`` — bare —
#: and demonstrated by execution that an observation whose real opaque subject
#: happened to be spelled that way was indistinguishable from one recorded with
#: no subject at all, which is exactly the artifact ``D-IMPL-120`` forbids.
#: :data:`_SUBJECT_NAMESPACE` closes the deliberate case as well as the
#: accidental one.
NO_SUBJECT_IDENTITY: Final[str] = "ccf.no-subject-identity"

#: The reservation, shared with every other opaque string this package puts
#: inside a content address.
#:
#: **Both names moved to** :mod:`ccf.halflife.assessment` **at Phase 15.6's
#: close.** They were written module-private here on the stated ground that "a
#: public constant would promise a tree-wide rule this commit does not ship" —
#: and the single-agent review then found the rule shipped on this field and on
#: none of the three siblings the same phase gave the same kind of value. One
#: rule needs one implementation; the import direction is safe because
#: ``assessment`` depends on nothing but
#: :class:`~ccf.contracts.base.CCFContract`, which is why it holds them.
_SUBJECT_NAMESPACE: Final[str] = _SDK_NAMESPACE


class Observation(CCFContract):
    """One dated observation, typed by the vocabulary λ_c is configured against.

    Whitepaper §7.7 binds λ_c to the observation *type* in Control Plane
    configuration and explicitly not to the individual document, so decay reads
    exactly two things from an observation — which type it is, and when it was
    made. Nothing about the rate travels on the observation itself.

    The third field is **carried, never consumed**: no function in this module
    reads ``subject``, and the freshness figure is identical whether it is
    populated or not. It exists so that a downstream consumer of D_c can say
    *which* observations a debt figure summarises (CLAUDE.md §11 — an SDK
    extension; see below).

    Attributes:
        observation_type: The deployment's observation-type name. Its
            vocabulary is user configuration; the SDK never enumerates it.
        observed_at: When the fabric learned the observation (the T axis's
            ``observed_at``, :mod:`ccf.contracts.claims`). Timezone-aware; a
            naive instant is rejected **at construction**, because an implicit
            timezone is a silent default (D-IMPL-38) — see
            :meth:`_the_instant_names_its_zone`.
        valid_from: When the SOURCE says it observed the thing, or ``None``
            when the source could not say (``D-IMPL-331``). Distinct from
            :attr:`observed_at`, which is when the FABRIC learned the claim —
            :meth:`ccf.assembly.worker.AssemblyWorker._stitch` sets the second
            to ingestion always and routes the source's own instant here. A
            λ_c row declares which of the two it decays against
            (:data:`~ccf.controlplane.artifacts.DecayBasis`); this field is
            read by :func:`freshness` only when the row declares
            ``valid-from``, and its absence under that declaration is
            :class:`MissingDecayInstant` rather than a fallback. Optional and
            **hash-transparent at** ``None``, so an observation constructed
            before this field existed hashes as it did.
        series: WHICH LOGICAL SERIES this observation belongs to, or ``None``
            when the deployment declared none (``D-IMPL-333``). Read only by
            :func:`leading_edge`, and only for a λ_c row declaring
            ``freshness_over: leading-edge``: two observations sharing a series
            are two readings of ONE thing, so only the newest is current and
            the rest are history. Resolved by the scorer from the row's
            ``series_key_attribute``; the SDK never parses it and never
            compares it to anything but another value of itself. Hash-transparent
            at ``None``.
        subject: What this observation is an observation *of*. An opaque
            identifier the deployment chooses — an entity URI, a claim id, a
            document id, or something else again. Its scheme is user
            configuration; the SDK never enumerates it, never parses it and
            never compares it to anything. Optional (D-IMPL-120), defaulting to
            :data:`NO_SUBJECT_IDENTITY` rather than to ``None``. Two values are
            refused and only two: a blank, and anything inside the SDK's own
            :data:`_SUBJECT_NAMESPACE` other than the sentinel — see
            :meth:`_the_subject_is_declared_and_stays_out_of_the_sdk_namespace`.

            **SDK extension (CLAUDE.md §11), not whitepaper-derived.** Whitepaper
            §7.7 binds λ_c to the observation *type* and says nothing about
            subject identity; this field is the carrying structure D-IMPL-117
            assigns to the SDK, and none of the judgement about which
            observations matter, which D-IMPL-117 assigns away from it.
    """

    observation_type: str
    observed_at: datetime
    subject: str = NO_SUBJECT_IDENTITY
    valid_from: datetime | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )
    series: str | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )

    @field_validator("observed_at", mode="before")
    @classmethod
    def _the_supplied_instant_names_its_own_zone(cls, value: object) -> object:
        return _refuse_an_instant_that_named_no_zone(value)

    @field_validator("observed_at")
    @classmethod
    def _the_instant_names_its_zone(cls, value: datetime) -> datetime:
        """Refuse a naive instant at construction, as this class documents.

        **The refusal this docstring described and did not have.** The attribute
        docstring above has always read *"a naive instant is rejected"*; there
        was no validator, and Phase 15.6's single-agent review demonstrated that
        a naive ``Observation`` was constructible, serialisable and storable,
        with the failure arriving at whatever call site first computed decay.
        That is the deferral CLAUDE.md §11 refuses (*"Validation is at the
        boundary, never deferred"*), and it also broke a citation:
        :meth:`~ccf.halflife.assessment.SourceRefreshWindow._the_instant_names_its_zone`
        names this field as the precedent it restates at construction, and a
        reader following the citation found nothing here.

        The pair is that class's pair, for its reasons: this after-validator
        refuses the naive ``datetime``, and
        :func:`~ccf.halflife.assessment._refuse_an_instant_that_named_no_zone`
        runs before validation, where a bare epoch — which names no zone at all
        and which Pydantic silently reads as UTC — is still visible as what the
        caller supplied.

        :func:`~ccf.halflife.debt.freshness`'s own refusal **stays**. It is not
        redundant: it also guards ``now``, which no contract validates, and it
        is the only thing standing between a ``model_construct``-built
        observation and a freshness figure computed against an implicit zone.
        """
        if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
            raise ValueError(
                "an observation must name its instant's zone; a naive datetime "
                "carries an implicit timezone, which is a silent default "
                "(D-IMPL-38), and decay is computed from this value"
            )
        return value

    @field_validator("valid_from", mode="before")
    @classmethod
    def _the_supplied_valid_from_names_its_own_zone(cls, value: object) -> object:
        return value if value is None else _refuse_an_instant_that_named_no_zone(value)

    @field_validator("valid_from")
    @classmethod
    def _the_valid_from_names_its_zone(cls, value: datetime | None) -> datetime | None:
        """The same refusal :attr:`observed_at` gets, for the same reason.

        A naive instant here would be read against an implicit timezone
        (``D-IMPL-38``) and decay is computed from this value whenever the row
        declares ``valid-from``. Refusing at construction rather than at the
        first computation is CLAUDE.md §11's *"validation is at the boundary,
        never deferred"*.
        """
        if value is None:
            return None
        if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
            raise ValueError(
                "an observation must name its instant's zone; a naive datetime "
                "carries an implicit timezone, which is a silent default "
                "(D-IMPL-38), and decay is computed from this value"
            )
        return value

    @field_validator("subject")
    @classmethod
    def _the_subject_is_declared_and_stays_out_of_the_sdk_namespace(
        cls, value: str
    ) -> str:
        """Refuse a blank subject, and refuse one inside the SDK's namespace.

        Both refusals protect one distinction — the distinction ``D-IMPL-120``
        made the whole field for: *"an omitted identity and a dropped one are
        not the same artifact."*

        A **blank** subject is what a half-finished assembler edit leaves
        behind, and admitting it would make *recorded with an unnameable
        identity* and *recorded without one* two spellings of one claim, while
        only the second has a sentinel that says so. This is
        :meth:`~ccf.halflife.assessment.SignalObligation._the_obligation_is_declared_and_is_not_the_sentinel`'s
        first limb, restated because the reason is identical.

        A subject inside :data:`_SUBJECT_NAMESPACE` is refused because that
        prefix is the SDK's own. Namespacing the sentinel makes an accidental
        collision unlikely; reserving the namespace makes impersonation
        **unavailable** — which is the property Phase 15.6's close-time panel
        found missing, having demonstrated by execution that a real subject
        could wear the sentinel's spelling and be indistinguishable from
        absence.

        **The sentinel itself is carved out**, and this is where the shape
        departs from ``SignalObligation``'s. There, the sentinel lives on a
        *different* field and can be refused outright. Here it is this field's
        own default, so a flat refusal would make
        ``Observation.model_validate(Observation(...).model_dump())`` raise for
        every unpopulated observation — ``subject`` is serialized whether or not
        it is populated — and a contract that cannot re-validate its own dump is
        not a stricter contract. Writing ``subject=NO_SUBJECT_IDENTITY``
        deliberately therefore stays legal: it is the same claim as omission,
        said louder.

        **Both checks read the value as a reader would see it**
        (:func:`_as_a_reader_sees_it`), not as bytes. The blank check always
        stripped; the namespace check did not, and Phase 15.6's single-agent
        review demonstrated by execution that ``" ccf.no-subject-identity"``,
        the non-breaking-space spelling and ``"CCF.no-subject-identity"`` all
        walked past a reservation whose entire purpose is that a reader cannot
        tell them from the marker. The sentinel carve-out stays an **exact**
        comparison, so a near-miss spelling of it is refused rather than
        silently treated as the sentinel.

        **The refusal itself is the package's shared one**
        (:func:`~ccf.halflife.assessment._refuse_an_impersonation_of_an_sdk_marker`),
        not a rule this field holds alone. It was this field's alone until Phase
        15.6's close, and the single-agent review's WR-02 is exactly that
        asymmetry: three sibling opaque strings shipped in the same phase, all
        inside the same content address, none of them reserved. The shared
        helper also records the known cost of a bare ``ccf.`` prefix — a
        deployment whose subjects are domain-shaped is refused — and why
        narrowing it is a ruling rather than a repair.

        No judgement about *meaning* is made. Every string outside the reserved
        namespace is admitted verbatim, however unfamiliar, because the SDK
        enumerates no identifier scheme and interprets nothing it is handed
        (D-IMPL-117, CLAUDE.md §11).
        """
        if not _as_a_reader_sees_it(value):
            raise ValueError(
                "a subject identity must be declared: a blank subject names"
                " nothing while claiming to name something, which is what"
                f" {NO_SUBJECT_IDENTITY!r} already asserts positively"
                " (D-IMPL-38, D-IMPL-120)"
            )
        return _refuse_an_impersonation_of_an_sdk_marker(
            value, field="a subject identity", admitted=NO_SUBJECT_IDENTITY
        )


def _entry_of(table: HalfLifeTable, observation_type: str) -> HalfLifeEntry:
    """The declared row for ``observation_type``, or :class:`MissingHalfLife`."""
    try:
        return table.entries[observation_type]
    except KeyError:
        raise MissingHalfLife(
            f"no half-life declared for observation type {observation_type!r};"
            " declare one in the Control Plane λ_c table (no default rate exists)"
        ) from None


def decay_mode_of(table: HalfLifeTable, observation_type: str) -> DecayMode:
    """Return the declared decay mode for ``observation_type``.

    The one read :func:`freshness` makes before it touches a curve, so that a
    supersede-only class is branched on *before* any rate is looked up
    (``24.5-L-22``; whitepaper §7.7.2).

    Raises:
        MissingHalfLife: the table declares no entry for that type — the same
            refusal, for the same reason, as :func:`half_life_of` (INV-CH7-58,
            D-IMPL-38).
    """
    return _entry_of(table, observation_type).decay


def freshness_over_of(
    table: HalfLifeTable, observation_type: str
) -> FreshnessAggregation:
    """Return the declared freshness aggregation for a type (``D-IMPL-333``)."""
    return _entry_of(table, observation_type).freshness_over


def series_key_attribute_of(
    table: HalfLifeTable, observation_type: str
) -> str | None:
    """Return the claim attribute that names a logical series, if declared."""
    return _entry_of(table, observation_type).series_key_attribute


def leading_edge(
    observations: Sequence[Observation], *, table: HalfLifeTable, now: datetime
) -> tuple[Observation, ...]:
    """Reduce each ``leading-edge`` series to its newest member at or before ``now``.

    **The set, not the value** (``D-IMPL-333``). ``decay`` and ``decay_basis``
    answer *how fast* and *against which instant*; this answers *which
    observations constitute the thing being scored*. A type declaring
    ``series-mean`` — every table written before the field existed — passes
    through untouched, which is what keeps this additive.

    **Newest AS OF ``now``, never wall-clock newest.** A replay at an earlier
    instant must see the edge that was leading *then*; selecting the globally
    newest would let a later observation leak into an earlier answer and make
    the figure unreproducible.

    Observations are grouped by ``(observation_type, series)``. Where the row
    declared no ``series_key_attribute`` the whole type is one series, so one
    observation survives it; where it did, one survives per distinct key.

    Ordering is by the instant the row decays against, so the edge is the
    newest by the same clock the curve reads — a series decaying on
    ``valid-from`` is led by the newest source observation, not by whichever
    row the fabric happened to learn last.
    """
    kept: dict[tuple[str, str | None], Observation] = {}
    passthrough: list[Observation] = []
    for observation in observations:
        if freshness_over_of(table, observation.observation_type) != "leading-edge":
            passthrough.append(observation)
            continue
        instant = _instant_for(observation, table)
        if instant is not None and instant > now:
            # Not yet knowable at the decision instant, so it cannot lead.
            continue
        key = (observation.observation_type, observation.series)
        standing = kept.get(key)
        if standing is None:
            kept[key] = observation
            continue
        standing_instant = _instant_for(standing, table)
        if instant is not None and (
            standing_instant is None or instant > standing_instant
        ):
            kept[key] = observation
    return (*passthrough, *(kept[k] for k in sorted(kept, key=lambda k: (k[0], k[1] or ""))))


def _instant_for(
    observation: Observation, table: HalfLifeTable
) -> datetime | None:
    """The instant this observation's own row decays against."""
    if decay_basis_of(table, observation.observation_type) == "valid-from":
        return observation.valid_from
    return observation.observed_at


def decay_basis_of(table: HalfLifeTable, observation_type: str) -> DecayBasis:
    """Return the declared decay basis for ``observation_type`` (``D-IMPL-331``).

    The twin of :func:`decay_mode_of`, and read at the same point in
    :func:`freshness`: which of the observation's two instants this row decays
    against. Every table written before the field existed answers
    ``observed-at``, which is the behavior it already had.

    Raises:
        MissingHalfLife: the table declares no entry for that type.
    """
    return _entry_of(table, observation_type).decay_basis


def half_life_of(table: HalfLifeTable, observation_type: str) -> timedelta:
    """Return the declared λ_c for ``observation_type``.

    Raises:
        MissingHalfLife: the table declares no entry for that type. There is no
            fallback rate (INV-CH7-58, D-IMPL-38).
        NoDecayCurve: the entry is declared ``supersede-only``. There is no
            curve to hand back and none is fabricated; read
            :func:`decay_mode_of` first if the class may be event-driven.
    """
    entry = _entry_of(table, observation_type)
    if entry.half_life_seconds is None:
        raise NoDecayCurve(
            f"observation type {observation_type!r} is declared supersede-only:"
            " its relevance is ended by its supersession event"
            f" ({entry.supersession_event!r}), not read off a curve, and no"
            " curve exists to return (whitepaper §7.7.2; 24.5-L-22)"
        )
    return timedelta(seconds=entry.half_life_seconds)


def effective_half_life(
    half_life: timedelta, risk_sensitivity: Decimal
) -> timedelta:
    """Scale ``half_life`` into a decision class's Freshness Budget.

    Whitepaper §7.7 defines the Freshness Budget as ``λ_c × Risk Sensitivity``:
    the more consequential the decision class, the less staleness it tolerates,
    so its budget is spent sooner on the same observation. A sensitivity below
    one shortens the effective half-life; above one widens it. The multiplier
    is a per-class Control Plane value
    (:class:`ccf.controlplane.artifacts.DebtProfile`), never an SDK constant.

    Raises:
        ValueError: ``half_life`` or ``risk_sensitivity`` is not positive. Zero
            is not "no decay" and not "instant decay" — it is an undeclared
            calibration, and guessing which meaning was intended is exactly the
            silent default this subsystem refuses.
    """
    if half_life <= timedelta(0):
        raise ValueError("half-life must be positive")
    if risk_sensitivity <= Decimal(0):
        raise ValueError("risk sensitivity must be positive")
    micros = Decimal(half_life // _MICROSECOND) * risk_sensitivity
    scaled = timedelta(microseconds=int(micros))
    if scaled <= timedelta(0):
        raise ValueError(
            "risk sensitivity collapses the freshness budget below the"
            " representable minimum"
        )
    return scaled


def relevance_ratio(*, elapsed: timedelta, half_life: timedelta) -> Decimal:
    """Return ``R(t) / R₀`` for an observation aged ``elapsed`` (whitepaper §7.7).

    The whitepaper's formula with ``R₀`` divided out, so the result is the
    dimensionless retained-relevance fraction the freshness factor F composes
    from. Exactly ``1`` at the observation instant, exactly one half at one
    half-life, and asymptotic toward — never equal to — zero thereafter:
    aged context stays reconstructible (INV-CH7-57).

    Raises:
        ValueError: ``half_life`` is not positive.
        TemporalOrderError: ``elapsed`` is negative.
    """
    if half_life <= timedelta(0):
        raise ValueError("half-life must be positive")
    if elapsed < timedelta(0):
        raise TemporalOrderError(
            "elapsed time is negative: the observation is dated after the"
            " instant it is evaluated at"
        )
    if elapsed == timedelta(0):
        return Decimal(1)
    with localcontext() as context:
        context.prec = DECIMAL_PRECISION
        exponent = Decimal(elapsed // _MICROSECOND) / Decimal(
            half_life // _MICROSECOND
        )
        ratio = _HALF**exponent
    return ratio.quantize(RATIO_QUANTUM)


def freshness(
    observation: Observation,
    *,
    now: datetime,
    table: HalfLifeTable,
    risk_sensitivity: Decimal,
) -> Decimal:
    """Return the retained decision-relevance of ``observation`` at ``now``.

    Under a ``curve`` class, composes the two configured inputs — the type's
    declared λ_c and the decision class's risk sensitivity — into the Freshness
    Budget, then reads the decay curve at the observation's age. Under a
    ``supersede-only`` class (``24.5-L-22``; the module docstring), returns
    exactly ``1``: retained relevance is whole until the supersession event,
    and an observation that event has already superseded is not in the as-of
    view this function is called over (INV-CH7-14), so no stale observation
    ever reaches the value. Either way this is the per-observation input the F
    factor of ``D_c = 1 − (F · C · S)`` aggregates (:mod:`ccf.halflife.debt`).

    The refusals come **first and hold in both modes**: a naive instant, an
    observation from the future, and a non-positive sensitivity are refused
    before the mode is read, so declaring a class supersede-only cannot make a
    clock fault or an undeclared calibration score as perfectly fresh.

    Args:
        observation: The dated, typed observation.
        now: The decision instant. Injected, never read from a clock, so the
            figure re-computes identically at replay time.
        table: The resolved, versioned λ_c table artifact.
        risk_sensitivity: The decision class's budget multiplier.

    Raises:
        MissingHalfLife: the type has no declared entry.
        MissingDecayInstant: the row declares ``valid-from`` and the
            observation carries none (``D-IMPL-331``).
        TemporalOrderError: the observation post-dates ``now``.
        ValueError: ``now`` or ``observed_at`` is naive, or the sensitivity is
            not positive.
    """
    if now.tzinfo is None or observation.observed_at.tzinfo is None:
        raise ValueError(
            "decay requires timezone-aware instants; a naive datetime carries"
            " an implicit timezone, which is a silent default (D-IMPL-38)"
        )
    elapsed = now - observation.observed_at
    if elapsed < timedelta(0):
        raise TemporalOrderError(
            "elapsed time is negative: the observation is dated after the"
            " instant it is evaluated at"
        )
    if risk_sensitivity <= Decimal(0):
        raise ValueError("risk sensitivity must be positive")
    if decay_mode_of(table, observation.observation_type) == "supersede-only":
        return Decimal(1)

    # THE DECLARED BASIS DECIDES WHICH INSTANT DECAYS (``D-IMPL-331``), and it
    # is read here — after the three refusals above, which hold in every mode
    # and on every basis. A table written before this field existed answers
    # ``observed-at`` and reaches `elapsed` unchanged, which is what keeps
    # every existing table's F identical.
    if decay_basis_of(table, observation.observation_type) == "valid-from":
        if observation.valid_from is None:
            raise MissingDecayInstant(
                f"observation type {observation.observation_type!r} declares"
                " `decay_basis: valid-from` and this observation carries no"
                " `valid_from`. Refused rather than read from `observed_at`:"
                " that instant is when the FABRIC learned the claim, so"
                " falling back would report a perfectly fresh figure for an"
                " observation whose real age is unknown — which is the defect"
                " the basis exists to end"
            )
        if observation.valid_from.tzinfo is None:
            raise ValueError(
                "decay requires timezone-aware instants; a naive datetime"
                " carries an implicit timezone, which is a silent default"
                " (D-IMPL-38)"
            )
        elapsed = now - observation.valid_from
        if elapsed < timedelta(0):
            raise TemporalOrderError(
                "elapsed time is negative: the source's observation instant is"
                " dated after the instant it is evaluated at"
            )

    budget = effective_half_life(
        half_life_of(table, observation.observation_type), risk_sensitivity
    )
    return relevance_ratio(elapsed=elapsed, half_life=budget)
