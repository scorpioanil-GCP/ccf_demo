# Copyright (c) 2026 David Castillo. All rights reserved.
# Use, copying, modification, and distribution of the covered material
# are governed by the CCF SDK Interim Software and Patent License
# in the repository-root LICENSE.md and any controlling signed agreement.
# Rights under that interim license begin only upon its execution
# and are limited to its stated scope and term.
"""MCP-backed ArtifactStore — the §7.4 reference implementation.

SDK-defined (CLAUDE.md §7.4: users "are free to use their own persistent store
and decision-playback data store by standing up (or pointing at) an MCP server
that implements the artifact resource contract"); addressing per D-IMPL-26.
The server half is :mod:`ccf_runtime.mcp.artifact_server`.

This class is the file-backed store's peer, not its successor: it presents the
same four synchronous :class:`~ccf.artifacts.protocol.ArtifactStoreProtocol`
methods and passes the same conformance suite, so swapping one for the other is
a change of constructor and nothing else.

**It reuses the shared bridge; it does not build one.** The async→sync seam
lives in :mod:`ccf.mcp.client` because ``Agent.invoke_skill`` needs the same
one. A second bridge here would fork the deadlock risk across two modules, and
the deadlock in question is real: a held ``ClientSession`` entered from a
blocking portal never returns (06-RESEARCH.md B3, verified at a 120 s timeout).
No loop is created here and no work is scheduled onto one here — the two names
that would do either are absent from this file by assertion, because writing
them would be rebuilding what is already imported.

**It reuses the shared URI grammar; it does not re-derive it.**
:func:`~ccf.artifacts.protocol.parse_artifact_uri` is what a URI *means*, for
every store. Routing through it is why this store refuses ``@latest`` with the
same typed error the file store does, without a line here that mentions the
moving target.

**Absence and outage are discriminated on a structured answer, never a
message.** ``McpError``'s text is a stringified server-side exception with no
typed code, so matching it would bind this store's absent/unreachable
distinction to another project's error formatting — a server that reworded
itself would silently start reporting missing artifacts as outages
(06-RESEARCH.md Pitfall 2, T-06-21). A failed blob read is therefore *not*
taken as absence: the store asks the presence resource, which answers
``found: false`` on a successful read, and only that answer becomes
:class:`~ccf.artifacts.protocol.ArtifactNotFound`. Everything else stays
:class:`~ccf.mcp.errors.McpServerUnreachable`, but for the guard's 401 below —
over-reporting absence is the dangerous direction, because absence is what a
replay writes down as a fact about the past. There is no ``except McpError``
handler in this file.

**A call the server's guard did not authenticate is a typed refusal, never an
outage** (``D-IMPL-378``: repair 2.5 (a) for reads, decision 10 (b) for the
write). The guard answers HTTP 401 — no credential, one that is not a bearer
token, or a token its verifier does not know — before any handler runs, so
nothing about the call was decided and nothing was written. Every read here,
and :meth:`McpArtifactStore.put`, raises
:class:`~ccf.artifacts.protocol.ArtifactStoreUnauthenticated` for it, judged on
the 401 response's status code, never on message text. The guard's other
refusals are not this: a 403, for a credential without a required scope,
still arrives as :class:`~ccf.mcp.errors.McpServerUnreachable` on every call,
and the tenancy guard's denial does on a read, while :meth:`McpArtifactStore.put`
receives it as the server's declined write (``ArtifactStoreError``).

**A write requires the capability for its own action, here AND at the
server (D-IMPL-353 §1.2).** :func:`~ccf.artifacts.protocol.authorized_write_target`
runs before the payload is even encoded, so a fabricated, retargeted or
wrong-kind capability never reaches the wire and the refusal is this store's
own; the store the artifact server holds runs the identical check over the
capability the server's wrapper minted for the remote caller — so a remote
client that skips this class entirely and speaks to the server directly meets
the same rule. That is the property that makes the rule the store's rather
than any transport's. The capability itself never crosses the wire — the
server mints its own for the caller it authenticated.

**What crosses the wire is the class, the name and the bytes — never the
tenant** (``D-IMPL-353`` §1.2, §1.3). The tenant travels in the credential the
server verifies and is the server-minted capability's, exactly as it is this
store's; a wire argument for it would be a second source, and
``put_artifact(artifact_class, name, canonical_b64)`` takes none.

**A governed refusal on the read path is a shell, and this store reads it as
absence** (``D-IMPL-353`` §2 P5; the join's split). The server's blob and
presence resources answer a refusal — a missing address, an address filed
under another tenant, a governed record the caller may not read — as the
canonical bytes of an already-recorded, already-disclosed refusal shell rather
than as a transport error, so a client can tell a governed *no* from an
outage. On the blob the shell cannot hash to the address asked for, so
:meth:`get` verifies ``sha256(bytes)`` against the address and refuses to
hand back bytes that are not the artifact; on the presence resource the shell
stands where ``found: false`` would and is read as exactly that. The names
resource answers a refusal with the same shell, and there it is read as what it
is, a refusal: :meth:`names_at` raises
:class:`~ccf.artifacts.protocol.ArtifactReadRefused` carrying it, never an
outage and never an empty list (``D-IMPL-378``, decision 1 (A)). Nothing here
parses the shell's cause — what a consumer may learn of it is the disclosure
layer's decision, made at the server.

**The naming index is the server's.** This store holds none. Two stores
pointed at one server therefore resolve identically, which is what makes a URI
recorded years ago resolvable by a process that never wrote it — and it is why
nothing here caches an address.

**What this cannot do.** It reads and writes artifacts and nothing else. It
holds no graph handle of any kind and imports nothing from L3; an artifact
retrieved through here enters the Context Graph only by going through L2 like
any other claim, so the single-writer invariant (CLAUDE.md §10) is untouched by
this store's existence.

The server URL, the credentials, and the call deadline are all deployment
values supplied by the caller. This module holds none of them (CINV-01).

Algorithmic module (CINV-03).
"""

from __future__ import annotations

import base64
import hashlib
import json
from collections.abc import Coroutine
from http import HTTPStatus
from typing import Any, Final, TypeVar

import httpx
from mcp import ClientSession
from mcp.types import BlobResourceContents, CallToolResult, TextResourceContents
from pydantic import AnyUrl

from ccf.artifacts.protocol import (
    ArtifactName, ArtifactNotFound,
    ArtifactReadRefused,
    ArtifactRef,
    ArtifactResolutionRefused,
    ArtifactStoreError,
    ArtifactStoreUnauthenticated,
    ArtifactUriUnresolvable,
    ArtifactWriteAuthority,
    MalformedContentAddress,
    WriteKinds,
    artifact_uri,
    authorized_write_target,
    held_content_address,
    parse_artifact_uri,
)
from ccf.contracts.canonical import canonical_bytes
from ccf.erasure.subject_match import (
    DoorNamingAnswer,
    DoorNamingQuery,
    SubjectMatchAnswer,
    SubjectMatchQuery,
    SubjectMatchVerdict,
)
from ccf.products.refusal import RefusalEnvelope
from ccf.mcp.client import (
    HttpClientFactory,
    SessionOperation,
    SyncMcpBridge,
    run_with_session,
)
from ccf.mcp.errors import McpServerUnreachable

_T = TypeVar("_T")

__ccf_mode__ = "algorithmic"

__all__ = ["McpArtifactStore"]

#: Kept in step with :mod:`ccf_runtime.mcp.artifact_server` by the invariant
#: test that reads both modules; declared here rather than imported because
#: ``/src`` does not depend on ``/runtime`` (D-04), and a client that could not
#: talk to a third party's server would not be a Protocol implementation.
_BLOB_SCHEME = "ccf-artifact-blob"
_META_SCHEME = "ccf-artifact-meta"
#: The naming resource (SEC-009; `D-IMPL-374` (4), ruling 2).
_NAMES_SCHEME = "ccf-artifact-names"
_PUT_TOOL = "put_artifact"
#: The erasure door's server-side subject match (SEC-009; `D-IMPL-378`, D3b).
_SUBJECT_MATCH_TOOL = "match_artifact_subject"
#: What :meth:`McpArtifactStore.names_for_erasure` raises when the server declines
#: the door's naming query or answers something that is not a naming answer.
_DOOR_NAMING_DECLINED: Final[str] = (
    "the artifact server declined the erasure door's naming query, or did not answer one"
    " (SEC-009; D-IMPL-378, design 1.3)"
)
#: The artifact server's door naming tool (`D-IMPL-378`, design 1.3), by its registered name.
_DOOR_NAMING_TOOL = "name_artifact_for_erasure"


class McpArtifactStore:
    """Content-addressed artifacts held by an MCP artifact server (§7.4).

    Args:
        url: The server's streamable-HTTP endpoint. A deployment value.
        bridge: The shared sync↔async bridge from :mod:`ccf.mcp.client`.
            Injected rather than constructed here: it owns a background thread,
            and an object that manufactured one internally would hide that
            thread's lifetime from the caller who has to close it.
        http_client_factory: Builds the HTTP client each call runs on — where
            the bearer token for an authenticated server goes (D-26). Optional
            only because the seam has to admit an unauthenticated development
            server; a deployment that omits it against an authenticated one
            gets the guard's refusal, not silent anonymous access:
            :class:`~ccf.artifacts.protocol.ArtifactStoreUnauthenticated`, on a
            read and on a write.
        write_kinds: The deployment's declaration of which artifact classes
            are mechanism-written and under which kinds (D-IMPL-353 §1.2).
            **Required, no default.** Enforced *before the call leaves this
            process*, exactly as ``@latest`` is, so the refusal is this
            store's own and a server outage cannot turn it into something
            else. The server behind the URL runs the identical check over its
            own store's declaration.
    """

    def __init__(
        self,
        *,
        url: str,
        bridge: SyncMcpBridge,
        write_kinds: WriteKinds,
        http_client_factory: HttpClientFactory | None = None,
    ) -> None:
        self._url = url
        self._bridge = bridge
        self._http_client_factory = http_client_factory
        self._write_kinds = write_kinds

    @property
    def url(self) -> str:
        """The server this store reads and writes through."""
        return self._url

    @property
    def write_kinds(self) -> WriteKinds:
        """Which artifact classes are mechanism-written here, and by which kinds."""
        return self._write_kinds

    # --- transport ---------------------------------------------------------

    def _session(
        self, operation: SessionOperation[_T]
    ) -> Coroutine[Any, Any, _T]:
        """One session-per-call coroutine, credentials attached."""
        return run_with_session(
            url=self._url,
            operation=operation,
            http_client_factory=self._http_client_factory,
        )

    async def _guarded_session(self, operation: SessionOperation[_T]) -> _T:
        """:meth:`_session` for every call: the guard's 401 is the typed authentication refusal (``D-IMPL-378``).

        Repair 2.5 (a) for the reads, decision 10 (b) for :meth:`put`. The
        session runner reports a call that did not complete as
        :class:`~ccf.mcp.errors.McpServerUnreachable`, an authentication
        refusal included (:func:`ccf.mcp.client.run_with_session`). Where the
        one failure that stands for is the server guard's HTTP 401 — read by
        :func:`_guard_refused_the_credential` from the response's status code —
        the call raises
        :class:`~ccf.artifacts.protocol.ArtifactStoreUnauthenticated` instead,
        chained from that response and raised outside the handler, so no outage
        is in its chain. Every other failure stays an outage.
        """
        refused: httpx.HTTPStatusError | None
        try:
            return await self._session(operation)
        except McpServerUnreachable as unreachable:
            refused = _guard_refused_the_credential(unreachable)
            if refused is None:
                raise
        raise ArtifactStoreUnauthenticated(
            f"the artifact server at {self._url!r} answered HTTP"
            f" {refused.response.status_code}: it did not authenticate the"
            " credential this store presented, so nothing about the call was"
            " decided"
        ) from refused

    def _read_blob(self, uri: str) -> bytes:
        """Read one resource as bytes, concatenated in server order.

        ``BlobResourceContents`` carries base64 and is what a ``-> bytes``
        server handler produces. Text parts are ignored rather than decoded:
        mixing them in would silently reintroduce the text round trip this
        whole path exists to avoid (Pitfall 4).
        """

        async def operation(session: ClientSession) -> bytes:
            result = await session.read_resource(AnyUrl(uri))
            return b"".join(
                base64.b64decode(contents.blob)
                for contents in result.contents
                if isinstance(contents, BlobResourceContents)
            )

        return self._bridge.run(self._guarded_session(operation))

    def _read_text(self, uri: str) -> str:
        """Read one resource as text, concatenated in server order."""

        async def operation(session: ClientSession) -> str:
            result = await session.read_resource(AnyUrl(uri))
            return "".join(
                contents.text
                for contents in result.contents
                if isinstance(contents, TextResourceContents)
            )

        return self._bridge.run(self._guarded_session(operation))

    # --- the four Protocol methods -----------------------------------------

    def put(self, authorized: ArtifactWriteAuthority, artifact: object) -> ArtifactRef:
        """Store ``artifact`` under the capability's tenant and return its reference.

        :func:`~ccf.artifacts.protocol.authorized_write_target` runs before the
        payload is even encoded, so a refused write never reaches the wire and
        the refusal is typed rather than whatever a remote server happened to
        answer. The canonical bytes are computed here, by the same serializer
        the content address is defined over, and carried as base64; the server
        re-derives them from what it parses and refuses the write if the two
        disagree, so neither side has to trust the other's serializer.

        Raises:
            ccf.authz.capability.CapabilityBypassError: the capability is
                fabricated, retargeted, or not of a kind that writes the
                target class. Raised before the call leaves this process.
            ccf.artifacts.protocol.ArtifactWriteRefused: the target shape.
            ccf.contracts.canonical.CanonicalizationError: the artifact has no
                canonical form and therefore no stable identity. Raised before
                anything reaches the wire.
            ccf.artifacts.protocol.ArtifactStoreUnauthenticated: the server's
                guard answered HTTP 401 — it did not authenticate this store's
                credential — so nothing was written and nothing about the write
                was decided (``D-IMPL-378``, decision 10 (b)). Neither a
                declined write nor an outage.
            ccf.mcp.errors.McpServerUnreachable: the substrate is unreachable,
                or its guard refused the call with any status but 401, or it
                answered with something that is not an artifact reference,
                which says nothing about whether the write happened.
            ArtifactStoreError: the server declined the write: the call
                completed and the server answered it as an error, or with no
                artifact reference. A declined write is an answer, not an
                outage, so it is judged after the session closes and is never
                reported as unreachability.
        """
        target, payload_artifact = authorized_write_target(
            authorized, artifact, write_kinds=self._write_kinds
        )
        payload = base64.b64encode(canonical_bytes(payload_artifact)).decode("ascii")

        async def operation(session: ClientSession) -> CallToolResult:
            # Exactly what `put_artifact(artifact_class, name, canonical_b64)`
            # takes: the tenant is the credential's, never a wire argument
            # (D-IMPL-353 §1.2, §1.3).
            return await session.call_tool(
                _PUT_TOOL,
                {
                    "artifact_class": target.artifact_class,
                    "name": target.name,
                    "canonical_b64": payload,
                },
            )

        # Judged here, after the session closed, never inside the operation: the
        # session runner reports anything the operation raises as unreachability
        # (`ccf.mcp.client.run_with_session`), and a declined write is an answer,
        # not an outage to retry. The guard's 401 is the typed authentication
        # refusal, as for every read (`D-IMPL-378`, decision 10 (b)).
        result = self._bridge.run(self._guarded_session(operation))
        if result.isError or result.structuredContent is None:
            raise ArtifactStoreError(
                f"the artifact server declined to store {target.name!r}"
            )
        try:
            return ArtifactRef.model_validate(result.structuredContent)
        except ValueError as malformed:
            raise McpServerUnreachable(
                f"artifact server returned a non-reference answer: {result.structuredContent!r}"[:300]
            ) from malformed

    def get(self, *, content_address: str) -> bytes:
        """Return the exact canonical bytes stored at ``content_address``.

        Raises:
            ArtifactNotFound: the server answered a governed refusal shell
                where the bytes would be — nothing at that address is
                available to this credential — or answered, on the presence
                resource, that it holds nothing there. Only those structured
                answers produce this error; the bytes are verified against the
                address, so a shell is never mistaken for the artifact.
            ccf.artifacts.protocol.ArtifactStoreUnauthenticated: the server's
                guard answered HTTP 401 — it did not authenticate this
                store's credential — so it said nothing about the address.
                Neither an absence nor an outage.
            ccf.mcp.errors.McpServerUnreachable: the read failed and the server
                did not say the artifact was absent — so it is an outage, which
                invites a retry, rather than an absence, which gets written
                down.
        """
        address = held_content_address(content_address)
        try:
            payload = self._read_blob(f"{_BLOB_SCHEME}://{address}")
        except McpServerUnreachable:
            # The failed read tells us nothing typed; the presence resource
            # does. Asking costs a round trip only on the failure path, which
            # is the right place to spend it.
            if not self.exists(content_address=content_address):
                raise ArtifactNotFound(content_address) from None
            raise
        if hashlib.sha256(payload).hexdigest() != address:
            # Not the artifact: a governed refusal shell standing where the
            # bytes would (D-IMPL-353 §2 P5). Absence to this credential.
            raise ArtifactNotFound(content_address)
        return payload

    def exists(self, *, content_address: str) -> bool:
        """Whether an artifact is stored at ``content_address``.

        A successful read either way — ``found: false`` is an answer, not a
        failure. That is what makes this the discriminator :meth:`get` leans on.

        Raises:
            ccf.artifacts.protocol.ArtifactStoreUnauthenticated: the server's
                guard answered HTTP 401: it did not authenticate this store's
                credential.
            ccf.mcp.errors.McpServerUnreachable: the substrate is unreachable,
                or its guard refused the call with any status but 401.
        """
        try:
            addressed = held_content_address(content_address)
        except MalformedContentAddress:
            # Not an address, so nothing is stored at it — and no round trip
            # is spent asking a server about a string it could not hold
            # (`D-IMPL-345` `S-02`).
            return False
        answer = self._read_text(f"{_META_SCHEME}://{addressed}")
        return _presence_of(answer)

    def names_at(self, *, content_address: str) -> tuple[ArtifactName, ...]:
        """Every ``(tenant, class, name)`` this address was filed under, for this credential's tenant.

        SEC-009 (``D-IMPL-374`` (4), ruling 2): naming introspection, read
        from the server's names resource, so the erasure door can verify an
        address's STORED class and tenant over the §7.4 reference store. Not
        one of the Protocol's four verbs — the same introspection
        :meth:`~ccf.artifacts.file_store.FileArtifactStore.names_at` offers.
        Empty, with no round trip, for a string that is not a content address.

        Raises:
            ccf.artifacts.protocol.ArtifactReadRefused: the server answered
                with its governed refusal shell instead of names: the address
                cannot be verified through this credential. Carries the shell
                as ``envelope``. What the shell says of why is the server's:
                one answer, the ``nonexistent`` shell, for an address this
                credential's tenant never filed (another tenant's, or nobody's)
                and for a present governed address that holds no record; a
                governed record this credential may not read can be refused
                with its own cause (see
                :class:`~ccf.artifacts.protocol.ArtifactReadRefused`). An
                access refusal, never an outage and never an absence
                (``D-IMPL-378``, decision 1 (A)).
            ccf.artifacts.protocol.ArtifactStoreUnauthenticated: the server's
                guard answered HTTP 401: it did not authenticate this store's
                credential, so no access decision about the address was made
                (``D-IMPL-378``, repair 2.5 (a)).
            ccf.mcp.errors.McpServerUnreachable: the substrate is unreachable,
                its guard refused the call with any status but 401, or it
                answered something that is neither a list of names nor a
                refusal envelope.
        """
        try:
            addressed = held_content_address(content_address)
        except MalformedContentAddress:
            return ()
        answer = self._read_text(f"{_NAMES_SCHEME}://{addressed}")
        try:
            parsed = json.loads(answer)
            if isinstance(parsed, dict):
                # The server's governed refusal (decision 1 (A), `D-IMPL-378`),
                # recognized as `_presence_of` recognizes it: an answer that
                # validates as a refusal envelope. Judged here, after the
                # session closed, so it is never reported as unreachability.
                refused = RefusalEnvelope.model_validate(parsed)
                raise ArtifactReadRefused(
                    f"the artifact server refused to name {addressed!r} to this"
                    f" credential ({refused.kind}); the address cannot be verified"
                    " through it",
                    envelope=refused,
                )
            if not isinstance(parsed, list):
                raise ValueError("not a list")
            return tuple(ArtifactName.model_validate(item) for item in parsed)
        except ValueError as error:
            raise McpServerUnreachable(
                f"artifact server returned a non-naming answer: {answer!r}"[:300]
            ) from error

    def match_subject(self, *, query: SubjectMatchQuery, door_signature: str) -> SubjectMatchVerdict:
        """The artifact server's verdict on ``query``, judged where the bytes are (SEC-009; `D-IMPL-378`, D3b).

        For the erasure door, and only for a request it signed: the server's
        ``match_artifact_subject`` tool judges the bytes stored at
        ``query.content_address`` with :func:`~ccf.erasure.judge_subject` and
        answers one :data:`~ccf.erasure.SubjectMatchVerdict` — never the bytes.
        The tenant does not cross the wire: the server rebuilds the query under
        the caller's verified tenant, so ``door_signature``
        (:func:`~ccf.erasure.sign_subject_match_query`) verifies only for the
        tenant it was made for. Not one of the Protocol's four verbs.

        Raises:
            ccf.artifacts.protocol.MalformedContentAddress: ``query`` names no
                content address; raised before the call leaves this process.
            ArtifactStoreError: the server declined the call — it refuses every
                caller but the erasure door of the caller's tenant, and a server
                without the tool declines too — or answered something that is
                not a verdict.
            ccf.artifacts.protocol.ArtifactStoreUnauthenticated: the server's
                guard answered HTTP 401: it did not authenticate this store's
                credential.
            ccf.mcp.errors.McpServerUnreachable: the substrate is unreachable.
        """
        address = held_content_address(query.content_address)

        async def operation(session: ClientSession) -> CallToolResult:
            return await session.call_tool(
                _SUBJECT_MATCH_TOOL,
                {
                    "content_address": address,
                    "subject_ref": query.subject_ref,
                    "key_paths": list(query.key_paths),
                    "subject_ref_salt": query.subject_ref_salt,
                    "door_signature": door_signature,
                },
            )

        # Judged here, after the session closed, never inside the operation: the
        # session runner reports anything the operation raises as unreachability
        # (`ccf.mcp.client.run_with_session`), and a refusal is an answer, not an
        # outage to retry. The guard's 401 is the typed refusal, as for every call.
        result = self._bridge.run(self._guarded_session(operation))
        if result.isError or result.structuredContent is None:
            raise ArtifactStoreError("the artifact server declined the erasure door's subject match")
        try:
            return SubjectMatchAnswer.model_validate(result.structuredContent).verdict
        except ValueError as malformed:
            raise ArtifactStoreError(
                "the artifact server's answer to the subject match is not a verdict"
            ) from malformed

    def names_for_erasure(self, *, query: DoorNamingQuery, door_signature: str) -> DoorNamingAnswer:
        """The server's door naming path for ``query``: its tenant's names at the address, never the bytes (``D-IMPL-378``, design 1.3).

        For the erasure door, and only for a query it signed
        (:func:`~ccf.erasure.sign_door_naming_query`): the server's
        ``name_artifact_for_erasure`` tool answers, under the subject match's
        three authorizations, every name the caller's verified tenant filed
        the address under and whether its record writer filed it there. The
        door names and judges an address over this store only through this
        path and :meth:`match_subject`, never through the names, blob or
        presence resources a requester reads (Dave, 2026-10-09 10:54 MST,
        design 1.3: *"Q2 (a), two tools. Q3 (a), no fallback."*). Not one of
        the Protocol's four verbs.

        Raises:
            ccf.artifacts.protocol.MalformedContentAddress: ``query`` names no
                content address; raised before the call leaves this process.
            ArtifactStoreError: the server declined the call — it refuses every
                caller but the erasure door of the caller's tenant, and it
                answers the door itself the same one refusal for an address it
                cannot verify (design 1.3, Q1 (b)) — or answered something
                that is not a naming answer.
            ccf.artifacts.protocol.ArtifactStoreUnauthenticated: the server's
                guard answered HTTP 401 (``D-IMPL-378``, repair 2.5 (a)).
            ccf.mcp.errors.McpServerUnreachable: the substrate is unreachable.
        """
        address = held_content_address(query.content_address)

        async def operation(session: ClientSession) -> CallToolResult:
            return await session.call_tool(
                _DOOR_NAMING_TOOL, {"content_address": address, "door_signature": door_signature}
            )

        # Judged after the session closed, as `match_subject` is: a decline is
        # an answer, not an outage, and the guard's 401 is the typed refusal.
        result = self._bridge.run(self._guarded_session(operation))
        if result.isError or result.structuredContent is None:
            raise ArtifactStoreError(_DOOR_NAMING_DECLINED)
        try:
            return DoorNamingAnswer.model_validate(result.structuredContent)
        except ValueError as malformed:
            raise ArtifactStoreError(_DOOR_NAMING_DECLINED) from malformed

    def resolve_uri(self, *, uri: str) -> str:
        """Return the content address ``uri`` names, exactly.

        Raises:
            ccf.artifacts.protocol.MovingTargetRefused: the URI asks for the
                moving target. Raised by the shared parser before the call
                leaves this process, so every store refuses it identically and
                a server outage cannot turn the refusal into something else.
            ArtifactUriUnresolvable: the URI is malformed, or the server
                answered that it registered no such version under that name.
            ccf.artifacts.protocol.ArtifactStoreUnauthenticated: the server's
                guard answered HTTP 401: it did not authenticate this store's
                credential, so it said nothing about the name.
            ccf.artifacts.protocol.ArtifactResolutionRefused: the server decided
                the URI — a class its substrate declares under ``ReplayMint`` —
                through the governed read and answered its refusal shell, carried
                as ``envelope``: nothing that URI names is available to this
                credential (``D-IMPL-378``, design 1.1). An
                ``ArtifactUriUnresolvable`` and an ``ArtifactNotFound``, never an
                outage.
            ccf.mcp.errors.McpServerUnreachable: the substrate is unreachable.
        """
        parsed = parse_artifact_uri(uri)
        # Re-rendered through the shared renderer rather than forwarding the
        # caller's string: the parser is what a URI means, and a store that
        # passed the raw text on would let a malformed-but-prefixed URI reach
        # the server as though the grammar had accepted it.
        answer = self._read_text(
            artifact_uri(
                tenant_id=parsed.tenant_id,
                artifact_class=parsed.artifact_class,
                name=parsed.name,
                artifact_version=parsed.artifact_version,
            )
        )
        address = _resolution_of(answer, uri=uri)
        if address is None:
            raise ArtifactUriUnresolvable(
                f"{uri!r} names no version the artifact server registered"
            )
        return address


def _guard_refused_the_credential(unreachable: McpServerUnreachable) -> httpx.HTTPStatusError | None:
    """The server guard's HTTP 401, where that is the one failure ``unreachable`` stands for; else ``None``.

    :func:`ccf.mcp.client.run_with_session` chains the failure it caught, and
    the streamable-HTTP transport raises the guard's answer as an
    ``httpx.HTTPStatusError`` from a task in its task group, which wraps it.
    Read as the runner names a failure — an exception group of exactly one
    member is that member — and judged on the response's status code, a
    structured signal, never on message text (:mod:`ccf.mcp.errors`). A group
    of several failures names no single cause and stays an outage, as does
    every other status: a 403, for a credential without a required scope, is
    not this refusal.
    """
    cause = unreachable.__cause__
    while isinstance(cause, BaseExceptionGroup) and len(cause.exceptions) == 1:
        cause = cause.exceptions[0]
    if isinstance(cause, httpx.HTTPStatusError) and cause.response.status_code == HTTPStatus.UNAUTHORIZED:
        return cause
    return None


def _presence_of(answer: str) -> bool:
    """Read the ``found`` flag out of a presence answer.

    Parsed structurally, with a hard failure when the shape is wrong: a
    malformed answer coerced to ``False`` would be this module reporting an
    absence it was never told about. A governed refusal shell — the server's
    positive statement that nothing at the address is available to this
    credential (``D-IMPL-353`` §2 P5) — is the one other structured answer,
    and it is read as ``False``: the server SAID so, and the shell's cause is
    the disclosure layer's business, not this store's.

    Raises:
        McpServerUnreachable: the answer is neither the presence contract nor
            a refusal shell, which means the thing on the other end is not an
            artifact server.
    """
    try:
        parsed = json.loads(answer)
    except ValueError as error:
        raise McpServerUnreachable(
            f"artifact server returned a non-presence answer: {answer!r}"
        ) from error
    if isinstance(parsed, dict) and "found" not in parsed and "kind" in parsed:
        try:
            RefusalEnvelope.model_validate(parsed)
        except ValueError as error:
            raise McpServerUnreachable(
                f"artifact server returned a non-presence answer: {answer!r}"
            ) from error
        return False
    try:
        found = parsed["found"]
    except (KeyError, TypeError) as error:
        raise McpServerUnreachable(
            f"artifact server returned a non-presence answer: {answer!r}"
        ) from error
    if not isinstance(found, bool):
        raise McpServerUnreachable(
            f"artifact server returned a non-boolean presence: {answer!r}"
        )
    return found


def _resolution_of(answer: str, *, uri: str) -> str | None:
    """Read the resolved address, or ``None``, out of a resolution answer.

    A governed refusal shell — recognized as :func:`_presence_of` recognizes
    one, an answer that validates as a refusal envelope — is the server's
    decision on a governed URI (``D-IMPL-378``, design 1.1), raised typed.

    Raises:
        ccf.artifacts.protocol.ArtifactResolutionRefused: the answer is the
            server's governed refusal shell.
        McpServerUnreachable: the answer is not the resolution contract.
    """
    try:
        shell = json.loads(answer)
    except ValueError:
        shell = None
    if isinstance(shell, dict) and "found" not in shell and "kind" in shell:
        try:
            refused = RefusalEnvelope.model_validate(shell)
        except ValueError as error:
            raise McpServerUnreachable(
                f"artifact server returned a non-resolution answer: {answer!r}"
            ) from error
        raise ArtifactResolutionRefused(
            f"the artifact server refused to resolve {uri!r} to this credential"
            f" ({refused.kind}): nothing it names is available through it",
            envelope=refused,
        )
    try:
        parsed = json.loads(answer)
        found = parsed["found"]
        address = parsed["content_address"]
    except (ValueError, KeyError, TypeError) as error:
        raise McpServerUnreachable(
            f"artifact server returned a non-resolution answer: {answer!r}"
        ) from error
    if not found:
        return None
    if not isinstance(address, str):
        raise McpServerUnreachable(
            f"artifact server resolved to a non-address: {answer!r}"
        )
    return address
