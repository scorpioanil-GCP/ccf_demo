# Copyright (c) 2026 David Castillo. All rights reserved.
# Use, copying, modification, and distribution of the covered material
# are governed by the CCF SDK Interim Software and Patent License
# in the repository-root LICENSE.md and any controlling signed agreement.
# Rights under that interim license begin only upon its execution
# and are limited to its stated scope and term.
"""The HITL transport seam — a typed queue, and the only authority path.

SDK-defined (CLAUDE.md §8.2 — an extension beyond the whitepaper, and it
says so). D-IMPL-20 rules the ``HITLTransportProtocol`` typed queue as the
core mechanism: pending HITL events (ApprovalGate, ExceptionEscalation,
OverrideBoundary, ReviewQueue items) are typed records enqueued by the HITL
primitives, and actions (approve/reject/override/annotate) return through
the same surface. **Notification and authority are separated by ruling**:
this transport carries authority; the webhook leg is notify-only — the
webhook notifies, the action always flows back through this typed queue, so
audit-by-construction cannot be bypassed from a notification channel. The
notify-only webhook emitter ships in :mod:`ccf.hitl.webhook` per D-IMPL-64;
MCP server endpoints exposing these queues are the Experience-Layer
primary (D-IMPL-20) and live on that surface, not here.

**The audit claim is D-22-scoped.** The transport carries the
:class:`~ccf.hitl.principal.HumanPrincipalBinding` — the action-submission
contract requires it by type, so an unattributed action is unrepresentable
through this surface. The *recording* obligation — landing the action in
the Decision Replay record — is discharged by the HITL primitives
(07-07/07-08) that consume this seam, not by the queue: a transport that
recorded replay dimensions itself would be a second writer to the replay
surface.

**The authority path requires the capability for its own action (D-IMPL-353
§1.2, §2 P6).** :meth:`HITLTransportProtocol.submit` takes an
``Authorized[HitlSubmit]`` and :meth:`HITLTransportProtocol.view` an
``Authorized[HitlQueueRead]`` — each verified by
:func:`~ccf.authz.capability.verify` for its kind and for the event
it acts on before the handle's first real statement. The tenant a
submission is filed under and the tenant a view reads are the capability's,
and only the capability's: :class:`HitlActionSubmission` carries no tenant
field, so there is no second source. The recorded actor is the capability's
principal — a binding over anyone else is refused
(:class:`PrincipalMismatchRefused`) — and the record names the authorizer's
decision (``authorizing_decision_id``), transport-stamped like the claim
stamp. The in-process reads the primitives and the workflow engine use
(``pending``, ``submissions``, ``remove``, ``dequeue``) keep their tenant
parameter: those callers hold ``Execute``/``Resume``/``HitlSubmit``
capabilities, not a queue-read one, and in-process trust is the deployment's
(design §5 — the same limit single-writer states). The served doors call
``view`` and ``submit`` and nothing else.

:class:`InMemoryHitlTransport` ships in this module per CLAUDE.md §11
(reference implementations alongside Protocols): it is a reference
implementation, not a placeholder for one — the in-process queue matches
the v0 Control Plane posture, and a durable or remote transport is an
alternative implementation of the same Protocol, added without touching a
consumer.

Algorithmic module (CINV-03).
"""

from __future__ import annotations

import threading
from collections import deque
from collections.abc import Mapping
from typing import TYPE_CHECKING, Literal, Protocol, runtime_checkable

from pydantic import Field, field_validator, model_validator

from ccf.artifacts.protocol import ArtifactStoreError, parse_artifact_uri
from ccf.contracts.base import CCFContract
from ccf.contracts.canonical import HASH_TRANSPARENT_KEY
from ccf.controlplane.artifact_base import ArtifactClass, validate_semver
from ccf.controlplane.registry import ControlPlaneProtocol
from ccf.controlplane.resolution import ControlPlaneResolution, resolve_pinned
from ccf.hitl.approval_policy import APPROVAL_POLICY, ApprovalPolicy
from ccf.hitl.identity_binding import (
    AttestationInvalid,
    HitlActionClaims,
    SignedHitlAction,
    verify_hitl_action,
)
from ccf.hitl.principal import HumanPrincipalBinding, validate_content_hash
from ccf.peering.identity import IdentityProvider, JsonWebKey

if TYPE_CHECKING:
    from ccf.graph.protocols import WriterLease
from ccf.authz.capability import (
    Authorized,
    HitlQueueRead,
    HitlSubmit,
    Resume,
    verify,
    verify_any,
)

__ccf_mode__ = "algorithmic"

__all__ = [
    "APPROVAL_GATE_EVENT_CLASS",
    "HITL_ACTIONS",
    "HITL_EVENT_CLASSES",
    "HITL_POLICY",
    "HITLTransportProtocol",
    "ApproverNotEligible",
    "EventStateAtSubmit",
    "GateAlreadyClosed",
    "GateClosure",
    "GateVerdictsChanged",
    "HitlActionReceipt",
    "HitlActionRequest",
    "HitlActionSubmission",
    "HitlEventRevalidationRefused",
    "HitlGateClosed",
    "HitlPolicy",
    "InMemoryHitlTransport",
    "PendingHitlEvent",
    "PrincipalMismatchRefused",
    "SignedBindingInvalidRefused",
    "SignedBindingMismatchRefused",
    "SignedBindingRequiredRefused",
    "SignedBindingStaleRefused",
    "check_approver_eligibility",
    "enforce_attestation",
    "resolve_hitl_policy",
    "signed_binding_required",
]

#: The four HITL primitive event classes (CLAUDE.md §8.2). Mechanism
#: identifiers, not domain values: each names an SDK-shipped primitive, and
#: an event declaring anything else is malformed rather than merely unknown.
HITL_EVENT_CLASSES: frozenset[str] = frozenset(
    {
        "approval-gate",
        "exception-escalation",
        "override-boundary",
        "review-queue",
    }
)

#: The approval-gate member of :data:`HITL_EVENT_CLASSES` — the ONE class
#: approver eligibility is judged for (SEC-006; `D-IMPL-366`, RULED: approval
#: gates only). Spelled here, beside the roster, because the transport
#: dispatches on it and cannot import :mod:`ccf.hitl.approval_gate`, which
#: imports this module; ``ccf.hitl.approval_gate.GATE_EVENT_CLASS`` is the
#: same string.
APPROVAL_GATE_EVENT_CLASS = "approval-gate"

#: The two approval-gate VERDICTS — ``ccf.hitl.approval_gate.GATE_ACTIONS``,
#: spelled here for the same import-cycle reason as
#: :data:`APPROVAL_GATE_EVENT_CLASS` and pinned equal to it by
#: ``tests/workflow/test_conflict_population_eligibility.py``. The only actions
#: the workflow engine's conflict population counts, and so the only ones an
#: engine-bound eligibility judge refuses (map B item 3): an annotation or an
#: override beside a verdict holds no gate.
_GATE_VERDICTS: frozenset[str] = frozenset({"approve", "reject"})

#: The state the transport found for a submission's event at ``submit``
#: (`D-IMPL-366` H2; brief §4b): ``claimed`` (a primitive holds the atomic
#: claim), ``pending`` (queued, no claim — a door submission) or ``missing``
#: (no request waiting). Judged against the request for the pause the
#: submission NAMES — its ``product_content_hash`` — never against another
#: pause's request under the same key (``D-IMPL-391``; Dave, 2026-10-17 18:54
#: MST: *"Count an approval sent straight to the queue only while the request
#: for this exact pause is waiting."*). Stamped on the recorded submission and
#: never rewritten; ``None`` only on a record written before the field existed.
EventStateAtSubmit = Literal["claimed", "pending", "missing"]

#: The action vocabulary D-IMPL-20 names (approve/reject/override/annotate).
#: Mechanism identifiers: which actions a given gate *permits* is the
#: approval policy's statement, never enumerated here.
HITL_ACTIONS: frozenset[str] = frozenset(
    {"approve", "reject", "override", "annotate"}
)


class PendingHitlEvent(CCFContract):
    """One pending HITL event awaiting a human (D-IMPL-20; CLAUDE.md §8.2).

    SDK-defined. The typed record the ruling specifies: event class,
    workflow state reference, the identity of the Context Product the human
    must see (its D-IMPL-26 content hash — the same identity the
    :class:`~ccf.hitl.principal.HumanPrincipalBinding` echoes back, so
    "what was shown" and "what was approved" are comparable byte for byte),
    and the deadline/escalation policy reference, pinned.
    """

    event_key: str
    event_class: str
    tenant: str
    workflow_state_ref: str
    product_content_hash: str
    policy_ref: str | None = None
    #: The REQUESTER — the ``subject_id``-shaped principal string of whoever
    #: STARTED the execution this event belongs to (`D-IMPL-366` G1 (a): the
    #: starter, stamped by the engine from the ``Execute`` capability's
    #: principal and copied onto every gate event of that execution — not the
    #: principal who reached the gate, not every prior actor). Approver
    #: eligibility refuses the requester approving their own gate (SPEC F3).
    #: Carried as data and NOT judged on the other three event classes (G6
    #: (a)). Hash-transparent at ``None`` (CINV-06; D-IMPL-243): an event
    #: written before this field existed renders exactly as it did — and on a
    #: bound approval-gate event ``None`` is a fail-closed refusal (G5 (a)),
    #: never an unconstrained default.
    requested_by: str | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )

    @field_validator("event_class")
    @classmethod
    def _event_class_is_a_known_primitive(cls, value: str) -> str:
        if value not in HITL_EVENT_CLASSES:
            raise ValueError(
                f"unknown HITL event class {value!r}; the shipped primitives"
                f" are {sorted(HITL_EVENT_CLASSES)} (CLAUDE.md §8.2;"
                " D-IMPL-20)"
            )
        return value

    @field_validator("policy_ref")
    @classmethod
    def _policy_ref_is_pinned(cls, value: str | None) -> str | None:
        if value is None:
            return None
        try:
            parse_artifact_uri(value)
        except ArtifactStoreError as error:
            raise ValueError(str(error)) from error
        return value


class SignedBindingRequiredRefused(PermissionError):
    """Policy requires a signed attestation and none was presented.

    SDK-defined (CLAUDE.md §8.2); the D-16 composition (08-CONTEXT),
    designed within the D-IMPL-21/63/67 contract envelope. Raised at the
    transport authority path when the Control Plane HITL policy in force
    declares ``signed_binding_required: true`` and the submission carries
    no :class:`~ccf.hitl.identity_binding.SignedHitlAction`. A
    distinct class from :class:`SignedBindingInvalidRefused` so the
    Experience-Layer doors can map absence and invalidity to their own
    error-code constants (``ERROR_SIGNED_BINDING_REQUIRED``).
    """


class SignedBindingInvalidRefused(PermissionError):
    """A signed attestation was presented and its signature does not hold.

    SDK-defined (CLAUDE.md §8.2); D-16 within D-IMPL-21/63/67. Raised when
    the presented attestation fails cryptographic verification
    (:func:`~ccf.hitl.identity_binding.verify_hitl_action`, with the
    typed identity error chained as the cause) under the keys the pinned
    policy declares for its subject. A signature that VERIFIES but whose
    claims disagree with the capability, the request or the minted binding
    is :class:`SignedBindingMismatchRefused` (`D-IMPL-363` E6), not this.
    Maps to ``ERROR_SIGNED_BINDING_INVALID`` at the doors.
    """


class PrincipalMismatchRefused(PermissionError):
    """The submission's binding names a subject other than the capability's principal.

    SDK-defined (CLAUDE.md §8.2; D-IMPL-353 §2 P6). The actor of a recorded
    human action is the principal the authorizer decided *allowed* for —
    ``authorized.principal`` — and the binding is the record of that actor.
    A binding over anyone else binds nothing here, in the same sense a
    validly signed binding over someone else's identity binds nothing
    (:class:`SignedBindingInvalidRefused`). Unreachable from the served doors,
    which mint the binding from the capability; raised for an in-process
    caller that built one for the wrong subject. Refused rather than
    rewritten, because a signed binding covers the subject and a transport
    that overwrote it would record a signature over someone else.
    """


class ApproverNotEligible(PermissionError):
    """The capability's principal may not approve this gate (SEC-006; `D-IMPL-366`).

    Raised by :func:`check_approver_eligibility` at the transport, the
    primitive and the engine's authority predicate. **Non-enumerating by
    ruling (G3 (a))**: the message names the reason class and the policy
    reference, never an eligible principal, the requester or the refused
    subject — the wire carries the distinct code ``approver-not-eligible`` and
    nothing that would let a refused caller learn who could have approved.
    A sibling of :class:`PrincipalMismatchRefused`, not of the attestation
    family: eligibility is a policy judgment about a principal the fabric has
    already identified.
    """


class GateClosure(CCFContract):
    """The authority path's record that one suspension's gate was decided.

    SDK-defined (``D-IMPL-378``; Dave's ruling of 2026-10-07 approved the
    atomic gate close). Written by :meth:`HITLTransportProtocol.close_gate` in
    the one atomic step that judged the suspension's recorded verdicts and
    retired its event, so after it no verdict can join that suspension's
    population: a later one is refused by name (:class:`HitlGateClosed`).

    It is also the durable claim a retried passage presents. ``passage`` names
    what was decided — the suspension, the authority submission and the
    verdict, never who decided it — so a retry of a passage whose commit never
    landed re-takes this closure instead of a second one, and the workflow
    engine's conditional passage commit lets exactly one attempt land.

    Attributes:
        tenant: The capability's tenant.
        event_key: The gate event's key.
        product_content_hash: The suspension the decision is about.
        passage: The deciding passage's identity — the idempotency key a
            retry of the SAME passage presents again.
        decided_action: The verdict the passage routes on.
        decided_by: The authority submission's approver.
        observed_submissions: How many submissions recorded on this
            suspension the decision judged.
        authorizing_decision_id: The ``Resume`` capability's decision id.
    """

    tenant: str
    event_key: str
    product_content_hash: str
    passage: str
    decided_action: str
    decided_by: str
    observed_submissions: int
    authorizing_decision_id: str


class GateAlreadyClosed(PermissionError):
    """Another passage already decided this suspension's gate (``D-IMPL-378``).

    Raised by :meth:`HITLTransportProtocol.close_gate`; nothing changed.
    """


class GateVerdictsChanged(PermissionError):
    """A verdict was recorded on this suspension after the caller read the verdicts (``D-IMPL-378``).

    Raised by :meth:`HITLTransportProtocol.close_gate`. Nothing changed: the
    gate is still open, and a resumption presented again judges the verdicts
    that now stand.
    """


class HitlGateClosed(PermissionError):
    """The suspension this verdict names was already decided (``D-IMPL-378``).

    Raised by :meth:`HITLTransportProtocol.submit` in the step that would have
    recorded it, before any nonce is consumed or claim popped: nothing is
    recorded, so a verdict either joined the population the decision judged
    or is refused by name — never both. The HTTP and MCP action doors answer
    it with the ``hitl-gate-closed`` code (HTTP 409).
    """


class HitlEventRevalidationRefused(ValueError):
    """The event under the submission's key changed between snapshot and record.

    `D-IMPL-366` §4b step 6a (RULED ordering: event revalidation precedes nonce
    consumption; refused submissions introduce no state mutations). The
    transport judged the submission against a snapshot of the SELECTED event
    and its state (``claimed`` / ``pending`` / ``missing``); under the one
    lock acquisition that records, it re-reads the same state and admits only
    if the re-read agrees — the same frozen event in the same state, or
    ``missing`` both times. A different event under the same key (the
    second-suspension shape), a claim that appeared or vanished, or an event
    that arrived where there was none refuses here, BEFORE the nonce is
    consumed or anything is recorded, so the same attestation re-presented
    against the now-stable state is admitted once. A ``GateActionError``-class
    (``ValueError``-family) refusal, not a ``PermissionError``: nothing about
    the human's authority was judged — the thing they were answering moved.
    """


class HitlPolicy(CCFContract):
    """The Control Plane HITL policy artifact (CLAUDE.md §8.2; D-16).

    SDK-defined mechanism schema: which HITL postures a deployment
    requires are the artifact's statements, never code constants
    (No-Hardcoding, CLAUDE.md §6.4). This is the schema behind the
    documented ``hitl.signed_binding_required`` surface examples set in
    their ``artifacts/`` HITL policy YAML, registered under the deployment's
    chosen HITL-policy key. A policy that does not require signing is as
    small as ``{semver: "1.0.0", signed_binding_required: false}``; one that
    DOES require it must also state the window and the per-subject keys
    (`D-IMPL-363` E3/E5) — ``{semver: "1.0.0", signed_binding_required: true,
    signature_max_age_seconds: 300, permitted_clock_skew_seconds: 60,
    trusted_keys: {"<approver subject_id>": {"<kid>": <public JWK>}}}`` —
    and is refused at parse without them (the close-panel finding CR-363-04
    on `D-IMPL-363`: the former example here omitted them).

    Attributes:
        semver: The artifact's own semver lane (whitepaper §6.3).
        signed_binding_required: Whether a submission at the authority
            path must carry a verifiable
            :class:`~ccf.hitl.identity_binding.SignedHitlAction` (the
            ``attestation``; `D-IMPL-363`).
            Defaults to ``False`` when the key is absent from the
            document, so a missing key is well-defined rather than a
            ``KeyError`` — requiredness *true* can only ever come from a
            registered Control Plane value (T-08-07).
    """

    semver: str
    signed_binding_required: bool = False
    #: `D-IMPL-363` E3 — the directional freshness window the shared verifier
    #: applies to a signed attestation, against the RECORDED door-minted
    #: ``action_time`` and never a verifier clock: ``issued_at`` may be at
    #: most ``signature_max_age_seconds`` BEFORE the recorded instant and at
    #: most ``permitted_clock_skew_seconds`` AFTER it. Both are REQUIRED
    #: whenever ``signed_binding_required`` is true — no SDK default
    #: (CINV-01) — and refused at parse when absent, so a required policy
    #: never admits under an invented window. Hash-transparent at ``None``
    #: (CINV-06; D-IMPL-243): a policy written before the window existed keeps
    #: its content address.
    signature_max_age_seconds: int | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )
    permitted_clock_skew_seconds: int | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )
    #: `D-IMPL-363` E5 / C6(a) — the ONE trust source: approver subject →
    #: ``kid`` → public JWK. The verifier offers an attestation's verifier
    #: exactly the keys declared for ``claims.subject_id``, so a key trusted
    #: for one approver signs for no other; a ``kid`` not declared for the
    #: subject refuses as a mismatch. Required with ``signed_binding_required``;
    #: hash-transparent at ``None`` for the same reason as the window.
    trusted_keys: Mapping[str, Mapping[str, JsonWebKey]] | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )

    @field_validator("semver")
    @classmethod
    def _semver_is_well_formed(cls, value: str) -> str:
        return validate_semver(value)

    @field_validator("signature_max_age_seconds")
    @classmethod
    def _max_age_is_positive(cls, value: int | None) -> int | None:
        if value is not None and value <= 0:
            raise ValueError("signature_max_age_seconds must be a positive number of seconds (D-IMPL-363 E3)")
        return value

    @field_validator("permitted_clock_skew_seconds")
    @classmethod
    def _skew_is_non_negative(cls, value: int | None) -> int | None:
        if value is not None and value < 0:
            raise ValueError("permitted_clock_skew_seconds cannot be negative (D-IMPL-363 E3)")
        return value

    @model_validator(mode="after")
    def _a_required_policy_states_its_window_and_keys(self) -> "HitlPolicy":
        """E3 / E5: ``signed_binding_required: true`` without the window or the
        per-subject keys is refused at parse — never admitted with a default
        the deployment did not write (CINV-01)."""
        if not self.signed_binding_required:
            return self
        missing = [
            name
            for name in ("signature_max_age_seconds", "permitted_clock_skew_seconds", "trusted_keys")
            if getattr(self, name) is None
        ]
        if missing:
            raise ValueError(
                "signed_binding_required is true but the policy does not state"
                f" {missing}; a required attestation needs the window and the"
                " per-subject trusted keys the verifier judges it against, and"
                " the SDK supplies no default (D-IMPL-363 E3/E5; CINV-01)"
            )
        return self

    def keys_for(self, subject_id: str) -> Mapping[str, JsonWebKey]:
        """The public keys this policy declares for ``subject_id`` — possibly none."""
        return {} if self.trusted_keys is None else self.trusted_keys.get(subject_id, {})

    def pinned_ref(self, *, key: str, version: str) -> str:
        """The ``key@version`` a submission records as the policy that admitted it (E3)."""
        return f"{key}@{version}"


#: The HITL policy artifact class (CLAUDE.md §8.2; D-16).
HITL_POLICY = ArtifactClass(class_id="ccf.hitl-policy", contract=HitlPolicy)


def signed_binding_required(
    *,
    control_plane: ControlPlaneProtocol | None,
    hitl_policy_key: str | None,
) -> bool:
    """Whether the HITL policy in force requires a signed binding.

    The shared verification helper (D-IMPL-69): one implementation consumed
    by the transport authority path and by every HITL primitive resolution
    surface. Sharing *code* is deliberate and permitted — D-13 forbids only
    verified-marker plumbing between layers (a forgeable trust marker),
    never a shared implementation each layer invokes independently.

    Resolved from the Control Plane per call — the requiredness value lives
    ONLY in the registered :class:`HitlPolicy` artifact, never here
    (T-08-07). An unbound Control Plane or key is the pre-composition
    posture: not required.

    Raises:
        TypeError: the key names a registered artifact that is not a
            :class:`HitlPolicy` — broken deployment wiring.
    """
    resolved = resolve_hitl_policy(
        control_plane=control_plane, hitl_policy_key=hitl_policy_key
    )
    return False if resolved is None else resolved[1].signed_binding_required


def resolve_hitl_policy(
    *,
    control_plane: ControlPlaneProtocol | None,
    hitl_policy_key: str | None,
) -> tuple[str, HitlPolicy] | None:
    """The HITL policy in force and its pinned version, or ``None`` when unbound.

    One resolution for the three readers that need the policy itself rather
    than its boolean — the shared verifier (the window and the per-subject
    keys), the transport's ``hitl_policy_ref`` stamp, and
    :func:`signed_binding_required`. Resolved latest per call, as before
    (`D-IMPL-363` E3: the pin makes replay honest, not admission immutable).

    Raises:
        TypeError: the key names a registered artifact that is not a
            :class:`HitlPolicy` — broken deployment wiring.
    """
    if control_plane is None or hitl_policy_key is None:
        return None
    version, artifact = control_plane.resolve_latest(hitl_policy_key)
    if not isinstance(artifact, HitlPolicy):
        raise TypeError(
            f"artifact under {hitl_policy_key!r} is not a HitlPolicy (got"
            f" {type(artifact).__name__}); the bound policy key must name a"
            " registered ccf.hitl-policy artifact"
        )
    return str(version), artifact


def check_approver_eligibility(
    *,
    policy_ref: str | None,
    requested_by: str | None,
    subject_id: str,
    control_plane: object | None,
) -> None:
    """Refuse unless ``subject_id`` may approve the gate ``policy_ref`` governs.

    The ONE eligibility judgment (SEC-006; `D-IMPL-366` §4 (3)), shared by
    :meth:`InMemoryHitlTransport.submit`, :meth:`ccf.hitl.approval_gate
    .ApprovalGate.resolve` and the engine's ``_gate_authority`` so the three
    sites cannot drift apart. The comparand is one string — the capability's
    principal, which the D-16 check has already forced equal to the binding's
    ``subject_id`` and, where a signature is required, to the signed subject.

    **Reads no clock and no "latest".** ``policy_ref`` resolves through
    :func:`~ccf.controlplane.resolution.resolve_pinned`, the same call the
    workflow factory makes, so the version that judges is the version the
    event pinned at suspension — replayable, which the deployment-wide
    :class:`HitlPolicy` (resolved latest per call) is not.

    **Fail-closed, by ruling.** With ``control_plane`` bound the judgment
    refuses :class:`ApproverNotEligible` when: ``policy_ref`` is ``None``,
    resolves to nothing, or resolves to anything other than an
    :class:`~ccf.hitl.approval_policy.ApprovalPolicy` (every pre-change
    ``DeclaredArtifact`` policy included — the wrong-class case); the Control
    Plane does not offer the pinned-read surface; ``requested_by`` is ``None``
    (an in-flight suspension persisted before the change — G5 (a), the
    migration note); ``subject_id`` is not in ``eligible_principals``; or
    ``subject_id == requested_by`` (requester ≠ approver, unconditional). An
    unbound ``control_plane`` (``None``) performs no check — the
    pre-composition posture :func:`signed_binding_required` keeps. The
    reference transport composed into a workflow engine always passes a plane
    for an approval-gate verdict: the engine binds its own
    (:meth:`InMemoryHitlTransport.bind_approver_eligibility`).

    The refusal message is NON-ENUMERATING (G3 (a)): it names the reason class
    and the policy reference only — never a principal.

    Raises:
        ApproverNotEligible: as above.
        ccf.controlplane.registry.AmbiguousPinnedVersionError: two contents
            under the policy's key declare the pinned version — broken
            deployment wiring, surfaced rather than judged.
    """
    if control_plane is None:
        return

    def refuse(reason: str) -> ApproverNotEligible:
        return ApproverNotEligible(
            f"approver not eligible ({reason}) under approval policy"
            f" {policy_ref!r}; who may approve a gate is the pinned"
            " ccf.approval-policy's statement, the requester never approves"
            " their own gate, and the refusal names no principal"
            " (SEC-006; D-IMPL-366 G3 (a))"
        )

    if policy_ref is None:
        raise refuse("no approval policy bound to the event")
    if not isinstance(control_plane, ControlPlaneResolution):
        raise refuse("the bound Control Plane offers no pinned-read surface")
    policy = resolve_pinned(control_plane, policy_ref)
    if policy is None:
        raise refuse("the pinned approval policy resolves to nothing")
    if not isinstance(policy, ApprovalPolicy):
        raise refuse(
            f"the pinned artifact is not a {APPROVAL_POLICY.class_id}"
            f" (got {type(policy).__name__})"
        )
    if requested_by is None:
        raise refuse("the event records no requester")
    if subject_id not in policy.eligible_principals:
        raise refuse("the principal is not among the policy's eligible principals")
    if subject_id == requested_by:
        raise refuse("the principal is the requester of the gate it is approving")


class SignedBindingMismatchRefused(PermissionError):
    """A presented attestation verifies but a signed claim does not match the
    capability or the request (`D-IMPL-363` E6; SEC-005): another tenant,
    another event, a subject other than the capability's principal, a key not
    declared for that subject in the pinned policy, a product hash other than
    the one the door minted, or a verdict other than the one presented.
    Maps to ``signed-binding-mismatch`` at both doors.
    """


class SignedBindingStaleRefused(PermissionError):
    """A presented attestation verifies and matches but is not fresh
    (`D-IMPL-363` E3/E4/E6; SEC-005): ``issued_at`` falls outside the pinned
    window against the RECORDED door instant, or its nonce was already
    presented for this event. Maps to ``signed-binding-stale`` at both doors.
    """


def enforce_attestation(
    authorized: Authorized[HitlSubmit],
    submission: HitlActionSubmission,
    *,
    identity_provider: IdentityProvider | None,
    policy: HitlPolicy,
) -> HitlActionClaims:
    """Refuse the submission unless its attestation holds; return the verified claims.

    The shared verification helper (D-16; D-IMPL-69; D-IMPL-21; `D-IMPL-363`
    E2; CLAUDE.md §8.2): one implementation, invoked independently by the
    transport and by the HITL primitives — idempotent double verification
    (D-13), never a trust marker crossing the layer seam. **It reads no
    clock.** Every comparison is between the signed claims, the capability,
    the door-minted binding on the submission and the pinned policy, so the
    transport site (which has no clock) and a replay re-verify identically.

    In order, after the attestation is present and the wiring is whole:

    1. **Subject ↔ key (E5 / C6(a)).** The envelope's ``key_id`` must be one
       the pinned policy declares for ``claims.subject_id``; any other key
       — trusted for someone else, or for no one — is a mismatch. The
       signature is then verified against exactly those keys.
    2. **Claims ↔ capability and request (E1, C1(a)).** ``tenant`` is the
       capability's; ``event_key`` is the capability's resource;
       ``subject_id`` is the capability's principal and the minted binding's
       approver; ``action`` is the presented action and the minted binding's
       verdict; ``product_content_hash`` is the minted binding's. Each a
       mismatch.
    3. **Freshness (E3), directional, against the RECORDED instant.**
       ``issued_at <= action_time + permitted_clock_skew_seconds`` and
       ``action_time − issued_at <= signature_max_age_seconds``, where
       ``action_time`` is the door-minted ``submission.principal.action_time``
       — never a verifier clock. An absolute delta would admit a claim issued
       after the door recorded the action. Each a stale refusal.

    The nonce is NOT consumed here: reuse is refused by the transport,
    atomically under its lock, at :meth:`InMemoryHitlTransport.submit`
    (E4 / C11(a)), so a verifier that runs twice does not burn it.

    Raises:
        SignedBindingRequiredRefused: the policy requires an attestation and
            the submission carries none.
        SignedBindingInvalidRefused: the attestation's signature does not
            verify under the keys declared for its subject.
        SignedBindingMismatchRefused: a signed claim disagrees with the
            capability, the request, the minted binding, or the key map.
        SignedBindingStaleRefused: ``issued_at`` is outside the window.
        RuntimeError: attestations are required but no identity provider was
            supplied, or the policy states no window — broken deployment
            wiring, not an expected refusal.
    """
    signed = submission.attestation
    if signed is None:
        raise SignedBindingRequiredRefused(
            "the HITL policy in force requires a signed attestation and this"
            " submission carries none (D-16; D-IMPL-21; D-IMPL-69;"
            " D-IMPL-363; CLAUDE.md §8.2)"
        )
    if identity_provider is None:
        raise RuntimeError(
            "the HITL policy requires signed attestations but no identity"
            " provider was supplied — broken composition-root wiring"
        )
    max_age = policy.signature_max_age_seconds
    skew = policy.permitted_clock_skew_seconds
    if max_age is None or skew is None:
        raise RuntimeError(
            "the HITL policy requires signed attestations but states no"
            " freshness window — broken Control Plane wiring (D-IMPL-363 E3)"
        )
    claims = signed.claims
    declared = policy.keys_for(claims.subject_id)
    if signed.key_id not in declared:
        raise SignedBindingMismatchRefused(
            f"key {signed.key_id!r} is not declared for subject"
            f" {claims.subject_id!r} in the HITL policy in force; a key trusted"
            " for another approver, or for no one, signs for no one"
            " (D-IMPL-363 E5)"
        )
    try:
        verified = verify_hitl_action(
            signed, provider=identity_provider, public_keys=declared
        )
    except AttestationInvalid as error:
        raise SignedBindingInvalidRefused(
            "the presented signed attestation does not verify"
            " (D-16; D-IMPL-21; D-IMPL-69; D-IMPL-363)"
        ) from error
    principal = submission.principal
    mismatches: list[str] = []
    if verified.tenant != authorized.tenant:
        mismatches.append("tenant")
    if verified.event_key != authorized.resource:
        mismatches.append("event_key")
    if (
        verified.subject_id != authorized.principal
        or verified.subject_id != principal.approver.subject_id
    ):
        mismatches.append("subject_id")
    if verified.action != submission.action or verified.action != principal.verdict:
        mismatches.append("action")
    if verified.product_content_hash != principal.product_content_hash:
        mismatches.append("product_content_hash")
    if mismatches:
        raise SignedBindingMismatchRefused(
            f"the signed claims {mismatches} do not match the capability, the"
            " request or the door-minted binding; a signature over one"
            " statement does not authorize another (SEC-005; D-IMPL-363 E1)"
        )
    recorded_at = principal.action_time
    ahead = (verified.issued_at - recorded_at).total_seconds()
    behind = (recorded_at - verified.issued_at).total_seconds()
    if ahead > skew:
        raise SignedBindingStaleRefused(
            f"the attestation is post-dated: issued_at is {ahead:.0f}s after"
            f" the recorded action instant, beyond the permitted clock skew of"
            f" {skew}s (D-IMPL-363 E3)"
        )
    if behind > max_age:
        raise SignedBindingStaleRefused(
            f"the attestation is expired: issued_at is {behind:.0f}s before"
            f" the recorded action instant, beyond the signature max age of"
            f" {max_age}s (D-IMPL-363 E3)"
        )
    return verified


class HitlActionRequest(CCFContract):
    """What a caller may say about a human action at a served door (D-IMPL-353 §2 P6).

    SDK-defined (CLAUDE.md §8.2/§8.3). The request half of the authority
    path — the HTTP ``POST /hitl/actions`` body, and the field set the MCP
    ``submit_hitl_action`` tool takes as arguments. Deliberately **not** the
    submission: the :class:`~ccf.hitl.principal.HumanPrincipalBinding` is
    minted by the door from the capability, the verified credential's
    :class:`~ccf.hitl.principal.AuthenticationClaims` and the door's clock
    (:func:`ccf_runtime.identity_binding.principal_from_authorized`), so this
    contract has no ``principal``, no ``subject_id``, no
    ``identity_provider_ref``, no ``method``, no ``assurance_level``, no
    ``session_ref``, no ``action_time`` and no ``tenant``. ``extra=forbid``
    makes a body that still sends any of them a boundary refusal — and a
    caller-typed step-up-MFA claim unrepresentable rather than refused.

    What remains is what only the human can state: which event, which
    action, the content hash of what they actually saw, an optional
    annotation, and — where the HITL policy requires non-repudiation — the
    signed :class:`~ccf.hitl.identity_binding.HitlActionClaims` the human
    made about this action (D-16; `D-IMPL-363` E1): the ``attestation``, one
    object in one shape at both doors (C12(a)), replacing the former signed
    copy of the door-minted binding whose ``action_time`` a signer had to
    predict.
    """

    event_key: str
    action: str
    product_content_hash: str
    annotation: str | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )
    attestation: SignedHitlAction | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )

    @field_validator("action")
    @classmethod
    def _action_is_known(cls, value: str) -> str:
        if value not in HITL_ACTIONS:
            raise ValueError(
                f"unknown HITL action {value!r}; the typed queue carries"
                f" {sorted(HITL_ACTIONS)} (D-IMPL-20)"
            )
        return value

    @field_validator("product_content_hash")
    @classmethod
    def _product_hash_is_a_content_hash(cls, value: str) -> str:
        return validate_content_hash(value)


class HitlActionSubmission(CCFContract):
    """One human action returning through the authority path (D-IMPL-20/21).

    SDK-defined. ``principal`` is required by type: there is no way to
    construct a submission without a complete
    :class:`~ccf.hitl.principal.HumanPrincipalBinding`, which is how the
    no-unrecorded-human-action commitment (CLAUDE.md §8.2) is enforced at
    the contract boundary rather than audited after the fact.

    **No tenant field (D-IMPL-353 §1.3).** The tenant a submission is filed
    under is the capability's — ``authorized.tenant`` at
    :meth:`HITLTransportProtocol.submit` — and a second source on the
    contract would be a value a door could forget to compare. Deleted, not
    deprecated: a document that still carries one is refused at the boundary.
    """

    event_key: str
    action: str
    principal: HumanPrincipalBinding
    annotation: str | None = None
    #: The optional D-16 non-repudiation leg (`D-IMPL-363` E1): the signer's
    #: detached-JWS-signed :class:`~ccf.hitl.identity_binding.HitlActionClaims`.
    #: Whether it is required is the Control Plane HITL policy's statement
    #: (:class:`HitlPolicy`), enforced at the transport authority path —
    #: never a code constant. When present it travels on the recorded
    #: submission, so the audit/receipt surface and the dimension-2 block
    #: carry it verbatim. Hash-transparent at ``None`` (CINV-06; D-IMPL-243):
    #: an unsigned submission renders exactly as it did before the field
    #: existed. Replaces ``signed_binding``, a base-roster field retired by
    #: ruling under `D-IMPL-363` (replaced, not deprecated).
    attestation: SignedHitlAction | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )
    #: **Transport-stamped, never caller-authored** (`D-IMPL-363` E3): the
    #: pinned ``key@version`` of the :class:`HitlPolicy` that was in force
    #: when this submission was admitted — so the recorded submission, which
    #: the engine's authority join consumes later and the dimension-2 block
    #: embeds, says which window and which keys decided its admission.
    #: Stamped whenever a Control Plane and a policy key are bound; ``None``
    #: on an unbound transport, hash-transparent at that sentinel. The pin
    #: makes replay honest; it does not make admission immutable — the policy
    #: is resolved latest at submit.
    hitl_policy_ref: str | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )
    #: **Transport-stamped, never caller-authored** (SEC-001 Tier 0; the
    #: 2026-09-24 follow-up read). The :data:`HITL_EVENT_CLASSES` member of
    #: the pending event this action was recorded as answering, and that
    #: event's ``workflow_state_ref``. A submitter cannot decide either:
    #: :meth:`HITLTransportProtocol.submit` overwrites both from the event
    #: the transport ITSELF observed being claimed through
    #: :meth:`HITLTransportProtocol.remove`, and writes ``None`` when no
    #: claim exists. Declared on the contract rather than kept in a
    #: side-table because the stamp travels with the action wherever the
    #: recorded submission travels.
    #:
    #: They are what lets a consumer of
    #: :meth:`HITLTransportProtocol.submissions` ask **which primitive
    #: answered, and about which execution** — questions a submission could
    #: not answer before, so an approval-gate authority check could be
    #: satisfied by an action taken against an escalation, an override or a
    #: review item that happened to name the same event key.
    #:
    #: **Hash-transparent at the sentinel (CINV-06; D-IMPL-243).** ``None``
    #: here is not "an older record that did not declare" — it is a live,
    #: current state the transport writes on purpose: *this submitter
    #: claimed nothing*. That is exactly what was true of every submission
    #: recorded before the stamp existed, so "silence equals yesterday"
    #: holds literally and the two fields render into
    #: :func:`~ccf.contracts.canonical.canonical_bytes` only once a claim
    #: was actually observed. Note the direction, because it is what
    #: separates this from the ``False`` cases: the sentinel is the
    #: RESTRICTIVE reading everywhere it is consumed — an unstamped
    #: submission fails the gate check's stamped leg and the escalation
    #: authority join outright — so an unset value never means
    #: "unconstrained".
    answered_event_class: str | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )
    answered_workflow_state_ref: str | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )
    #: **Transport-stamped, never caller-authored** (D-IMPL-353 §2 P6; design
    #: §3, *deny audit contents*). The ``decision_id`` of the authorizer's
    #: *allow* the capability presented at :meth:`HITLTransportProtocol.submit`
    #: is evidence of — so every recorded human action is traceable to the
    #: decision that authorized it. Overwritten from ``authorized`` on every
    #: submit, exactly as the claim stamp is; a caller-supplied value is
    #: discarded. Hash-transparent at the sentinel (CINV-06; D-IMPL-243):
    #: ``None`` is what was true of every submission recorded before the
    #: capability existed.
    authorizing_decision_id: str | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )
    #: **Transport-stamped, never caller-authored** (SEC-006; `D-IMPL-366`
    #: H3 (a)). The ``policy_ref`` of the event the transport found (and
    #: revalidated) for this submission — the pinned ``ccf.approval-policy``
    #: version the eligibility judgment used — and that event's
    #: ``requested_by``, the requester the self-approval rule compared against.
    #: Both ``None`` when no event was under the key (``event_state_at_submit
    #: == "missing"``). A caller-supplied value is overwritten, as every stamp
    #: above is. Hash-transparent at ``None`` (CINV-06; D-IMPL-243): a
    #: submission recorded before these fields existed rehydrates unchanged.
    approval_policy_ref: str | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )
    requested_by: str | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )
    #: **Transport-stamped, never caller-authored** (`D-IMPL-366` H2, the
    #: RULED requirement). The state the transport found for this
    #: submission's event under its lock and revalidated before recording:
    #: ``claimed``, ``pending`` or ``missing`` (:data:`EventStateAtSubmit`).
    #: A ``missing`` submission is recorded UNJUDGED and can never become
    #: authority — including after a later enqueue or re-enqueue of an event
    #: under its key — because the engine's authority predicate excludes it
    #: structurally and nothing rewrites a recorded submission. ``None`` only
    #: on a record written before the field existed, which keeps today's
    #: semantics (the fixture rule). Hash-transparent at ``None``.
    event_state_at_submit: EventStateAtSubmit | None = Field(
        default=None, json_schema_extra={HASH_TRANSPARENT_KEY: True}
    )

    @field_validator("action")
    @classmethod
    def _action_is_known(cls, value: str) -> str:
        if value not in HITL_ACTIONS:
            raise ValueError(
                f"unknown HITL action {value!r}; the typed queue carries"
                f" {sorted(HITL_ACTIONS)} (D-IMPL-20)"
            )
        return value


class HitlActionReceipt(CCFContract):
    """The honest submit-only receipt (D-IMPL-62).

    SDK-defined. D-IMPL-62 rules the HTTP/CLI HITL action door submit-only:
    a submission enqueues on the typed transport and effects no state
    transition and no authority action by itself — the owning primitive
    resolves it. This receipt is the ruled hardening of that contract:
    ``status`` is the literal ``"submitted"`` (it cannot state or imply
    ``resolved`` — the field is type-closed to the one honest word), and
    the two disposition fields carry real queue state so the caller sees
    the action's disposition rather than inferring it from an echo:
    ``event_pending`` — whether the submission's event is still on the
    tenant's pending queue: the request for the pause the submission names
    (``D-IMPL-391``), so it agrees with ``event_state_at_submit`` (it is
    pending immediately after a submit judged ``pending``; resolution is the
    primitive's act) — and ``submissions_for_event`` — how many
    actions the transport has recorded against this event key, this one
    included.
    """

    status: Literal["submitted"]
    submission: HitlActionSubmission
    event_pending: bool
    submissions_for_event: int


@runtime_checkable
class HITLTransportProtocol(Protocol):
    """The typed HITL queue surface (D-IMPL-20; CLAUDE.md §8.2).

    A Protocol because delivery to humans is the deployment's
    infrastructure — an enterprise task system, an MCP-exposed queue, a
    bespoke pager — and the SDK has no business choosing
    (:class:`InMemoryHitlTransport` is the development reference, not a
    recommendation). What the Protocol omits is deliberate: there is no
    notification hook here — webhooks are notify-only and live in
    :mod:`ccf.hitl.webhook` (D-IMPL-64) — and no replay handle: recording
    is the primitives' obligation.

    ``runtime_checkable`` supports composition-root wiring checks; it
    verifies method presence only, so static conformance still rests on
    mypy.

    **Concurrency contract (WR-02; D-IMPL-69 adjacency; CLAUDE.md §8.2).**
    All methods of every conforming implementation must be safe for
    concurrent calls from multiple threads. The Experience-Layer HITL
    doors (HTTP and MCP) invoke the transport from FastAPI's threadpool,
    so enqueue/dequeue/pending/remove/retire/submit/submissions race by
    construction in any real deployment — an implementation whose queue
    state can be lost, duplicated, or corrupted under concurrent access
    does not conform to this Protocol. ``remove`` exists precisely for
    that mode (WR-02): consuming one resolved event must be a single
    atomic operation of the implementation, because a caller-side
    drain-and-requeue over ``dequeue``/``enqueue`` exposes concurrent
    readers to a partially drained queue and lets two racing resolves
    double-submit. ``close_gate`` and ``submit`` are atomic with respect to
    each other (``D-IMPL-378``): a verdict on a suspension is either inside the
    population that suspension's closure judged, or refused by name. This
    docstring is the contract's sole documentation surface (Phase-9 CONTEXT
    D-05/D-08).

    **Composed into a workflow engine, a transport also judges approver
    eligibility** (SEC-006; the security close-out's map B item 3,
    ``D-GATE-357`` (2)). :class:`~ccf_runtime.workflow.engine.WorkflowEngine`
    requires, beyond this Protocol, a ``bind_approver_eligibility(control_plane)``
    method, calls it at construction with its own Control Plane, and refuses a
    transport that offers none. A conforming implementation then judges every
    verdict on an approval-gate event that names an approval policy at
    :meth:`submit` with :func:`check_approver_eligibility` against that plane,
    before anything is recorded, as
    :meth:`InMemoryHitlTransport.bind_approver_eligibility` does.
    The method is not a member of this Protocol, so a transport the primitives
    use without an engine need not offer it. The engine cannot see whether a
    third-party implementation judges what it is bound to judge; the
    reference implementation does.

    **A path-backed transport declaring ``scope = "process"`` MUST hold an
    exclusive SEC-013 lease on its substrate from open to close**
    (``D-IMPL-391``; Dave's ruling 2(a) of 2026-10-17 and his answer of 15:25
    MST: *"Cover the queue as well. A second process must be unable to submit a
    verdict or read in-flight state."*). The obligation is the one
    :class:`~ccf.controlplane.state.ConditionalStateStore` states for a
    single-process state store, word for word: the lease
    (``src/ccf/graph/leases.py::LockFileWriterLease``, on a lock file inside the
    queue's own directory) is taken when the transport is OPENED, before any
    event, verdict or closure is read; a second holder is refused with
    :class:`~ccf.graph.protocols.WriterLeaseHeld` naming the lock and the rule,
    logged in the refused process only; the lease is released on close and when
    the object is collected; and it is offered as ``writer_lease()``, which is
    not a member of this Protocol (a ``"shared"`` transport takes none) but
    which :class:`~ccf_runtime.workflow.engine.WorkflowEngine` requires of a
    ``"process"`` transport, refusing one that offers none by name.
    """

    def enqueue(self, *, event: PendingHitlEvent) -> None:
        """Queue ``event`` for its tenant, preserving arrival order — once per paused run.

        **Atomic on ``(tenant, event_key, product_content_hash)``**
        (``D-IMPL-391``; Dave's ruling 4(a) of 2026-10-17 and his answer of
        15:25 MST: *"The same paused run's request is filed only once.
        Third-party transports must meet the contract."*). An event whose
        triple is already PENDING is not queued again, and the call does
        nothing else. The absence check and the append are ONE atomic step of
        the implementation, so of any number of concurrent enqueues of one
        paused run's request exactly one is queued. The key is the paused run's
        fingerprint — the content hash of the suspended record, which names the
        state store that wrote it — so nothing about the store is shown on the
        request, and two independent stores' requests under one key are both
        queued (each needs its own approval). This supersedes the "no change"
        of DESIGN-2b §6.4.

        **A claim is not pending.** An event claimed through :meth:`remove`
        and not yet answered does not count as present, so the primitives'
        give-back (``remove`` → refused ``submit`` → ``enqueue``) re-files its
        event. An enqueue that appends discards any outstanding claim for the
        same ``(tenant, event_key)``: a re-enqueued event is pending again, so
        nothing has answered it. That is what keeps the primitives'
        give-the-claim-back rollback honest — a refused authority submission
        must leave no residue that a later bare submission could inherit as a
        stamp.
        """
        ...

    def dequeue(self, *, tenant: str) -> PendingHitlEvent | None:
        """Pop the oldest pending event for ``tenant``, or ``None``.

        A drain, not a resolution: it records no claim, so a submission
        made against a drained event carries no stamp (see :meth:`submit`).
        """
        ...

    def pending(self, *, tenant: str) -> tuple[PendingHitlEvent, ...]:
        """The tenant's pending events, oldest first, without consuming."""
        ...

    def remove(
        self, *, tenant: str, event_key: str
    ) -> PendingHitlEvent | None:
        """Atomically remove and return the tenant's pending event with
        ``event_key``, or ``None`` when no such event is pending.

        The compare-and-consume primitive (WR-02): removal is one atomic
        operation of the conforming implementation — never a caller-side
        drain-and-requeue over ``dequeue``/``enqueue``, which would expose
        concurrent readers to a partially drained queue and let two
        concurrent resolves both pass a ``pending()`` snapshot check. The
        relative order of every event not removed is preserved. Exactly
        one of any number of concurrent ``remove`` calls for the same
        event receives it; the rest receive ``None``.

        **Removal is a claim, and the transport records it** (SEC-001 Tier
        0). The winning caller is the primitive that is about to resolve
        this event, so the transport retains the removed event against
        ``(tenant, event_key)`` and stamps the next :meth:`submit` for that
        pair that names the removed event's pause (its
        ``product_content_hash``) with its class and ``workflow_state_ref``.
        The claim is consumed by that submit and discarded by a
        re-:meth:`enqueue`; a submit naming another pause neither uses nor
        consumes it (``D-IMPL-391``). Conforming implementations must do all
        three, because a consumer asking "which primitive answered this?" gets
        ``None`` — and must fail closed — from an implementation that stamps
        nothing. ``remove`` takes the oldest event under the key whatever its
        pause, so a primitive that finds it took a request for a pause other
        than the one its principal names gives it back unanswered
        (re-:meth:`enqueue`) and refuses, rather than leave a claim no
        submission of its own will consume.
        """
        ...

    def retire(
        self, *, tenant: str, event_key: str, product_content_hash: str
    ) -> tuple[PendingHitlEvent, ...]:
        """Remove every pending request for one paused run, recording no claim.

        ``D-IMPL-391``; Dave's ruling of 2026-10-17 18:54 MST (option 3):
        *"remove the old request with a new queue step that matches its exact
        fingerprint and leaves no claim"*, and *"Third-party queues must
        implement the new exact-fingerprint removal."* Every PENDING event whose
        ``(tenant, event_key, product_content_hash)`` is the given triple is
        removed, wherever it sits in the tenant's queue, and returned oldest
        first; every other event keeps its place and relative order. Nothing
        pending under the triple returns ``()``.

        **A retirement is not a resolution.** Unlike :meth:`remove` it records
        no claim, so no later :meth:`submit` is stamped as answering a retired
        request. An outstanding claim on ``(tenant, event_key)`` is discarded
        when, and only when, the claimed event bears the same
        ``product_content_hash``: it names the retired pause too. A claim on any
        other pause's request is left for the primitive that holds it.

        The search, the removal and the claim check are ONE atomic step of the
        implementation, as :meth:`remove`'s are: of any number of concurrent
        retirements of one pause, exactly one returns each request.
        """
        ...

    def view(
        self, authorized: Authorized[HitlQueueRead]
    ) -> tuple[PendingHitlEvent, ...]:
        """The served queue view: the capability's tenant's pending events.

        The read the Experience-Layer doors make (D-IMPL-353 §1.2). Requires
        an ``Authorized[HitlQueueRead]`` — verified for its kind and for the
        door's own action id as resource, since a queue is addressed by
        tenant alone and the tenant is the capability's — and returns what
        :meth:`pending` would for ``authorized.tenant``. There is no tenant
        parameter: whose queue is read is not a thing the door decides.
        """
        ...

    def submit(
        self,
        authorized: Authorized[HitlSubmit],
        *,
        submission: HitlActionSubmission,
    ) -> HitlActionSubmission:
        """Record one human action returning through the authority path.

        Requires an ``Authorized[HitlSubmit]`` for exactly
        ``submission.event_key`` (D-IMPL-353 §1.2, §1.5f), verified before
        the handle's first real statement; files the record under
        ``authorized.tenant``; refuses a binding whose subject is not
        ``authorized.principal`` (:class:`PrincipalMismatchRefused`).

        The recorded submission is stamped with the class and
        ``workflow_state_ref`` of the event this action claimed — taken
        from the transport's own :meth:`remove` observation, never from
        ``submission`` — stamped ``None`` when this submitter claimed
        nothing, and stamped with the capability's ``decision_id``.

        **Judged against its own pause** (``D-IMPL-391``; Dave, 2026-10-17
        18:54 MST: *"Count an approval sent straight to the queue only while
        the request for this exact pause is waiting."*). The event a
        submission is judged against, and its ``event_state_at_submit``, are
        those of the request for the pause it names —
        ``(authorized.tenant, submission.event_key,
        submission.principal.product_content_hash)``: ``claimed`` when the
        outstanding claim on the key is on that pause's request, else
        ``pending`` when that pause's request is waiting (wherever it sits
        under the key), else ``missing``. A claim on another pause's request is
        neither used nor consumed. A conforming implementation judges this way;
        the workflow engine never counts a ``missing`` submission.
        ``submission`` itself is not mutated (it is a frozen contract); the
        stamped copy is what :meth:`submissions` returns, and it is returned
        here so a door can answer with what was recorded rather than with
        an echo of what was sent.
        """
        ...

    def submissions(self, *, tenant: str) -> tuple[HitlActionSubmission, ...]:
        """The tenant's recorded actions, oldest first."""
        ...

    @property
    def scope(self) -> str:
        """``"process"`` (no other process reaches the queues) or ``"shared"`` (``D-IMPL-378``).

        A durable transport several processes reach declares ``"shared"``;
        the workflow engine refuses at construction a ``"shared"`` Control
        Plane state store paired with a transport that does not.
        """
        ...

    def close_gate(
        self,
        authorized: Authorized[Resume],
        *,
        event_key: str,
        product_content_hash: str,
        passage: str,
        decided_action: str,
        decided_by: str,
        observed_submissions: int,
    ) -> GateClosure:
        """Decide one suspension's gate once, over the verdicts the caller judged.

        SDK-defined (``D-IMPL-378``; Dave's ruling of 2026-10-07). ``authorized``
        is the ``Resume`` capability of the resumption deciding the gate,
        verified for its kind; the tenant is its tenant. ONE atomic step of the
        implementation, under the same lock or transaction as :meth:`submit`
        and :meth:`remove`:

        * a closure of ``(tenant, event_key, product_content_hash)`` already
          recorded is returned when its ``passage`` is this one (a retry of the
          same passage), and refused when it is another's;
        * otherwise, when the number of submissions recorded on that
          suspension (of any action) is not ``observed_submissions``, the call
          is refused and nothing changes — submissions are append-only, so an
          equal count is an equal population;
        * otherwise the closure is recorded, every event under ``event_key``
          for that suspension is removed from ``pending``, and a claim on one
          is discarded.

        After it, :meth:`submit` refuses a verdict on that suspension with
        :class:`HitlGateClosed`, and the queue no longer offers its event. A
        conforming implementation keeps closures exactly as durable as its
        submissions: a closure is the durable claim a retried passage presents
        (:class:`GateClosure`). The behavior under concurrent callers is pinned
        by ``tests/conformance/test_gate_closure_and_conditional_write.py``.

        Raises:
            GateAlreadyClosed: another passage decided this suspension.
            GateVerdictsChanged: a submission was recorded on it since the
                caller's read; nothing changed.
        """
        ...

    def closures(self, *, tenant: str) -> tuple[GateClosure, ...]:
        """The tenant's gate closures, oldest first (``D-IMPL-378``).

        What an operator reads to reconcile an execution whose passage was
        interrupted after its commit: the workflow engine never retries one.
        """
        ...


class InMemoryHitlTransport:
    """In-process reference implementation of :class:`HITLTransportProtocol`.

    Ships alongside the Protocol per CLAUDE.md §11 — a reference
    implementation, not a placeholder for one. Queues are partitioned by
    tenant (D-23): two tenants' events and actions never interleave, and a
    view of one tenant's queue says nothing about another's.

    **The D-16 composition (SDK-defined; CLAUDE.md §8.2; within
    D-IMPL-21/63/67).** When a Control Plane and an HITL-policy key are
    bound at construction, :meth:`submit` resolves the policy in force at
    submission time and — when it declares ``signed_binding_required`` —
    verifies the submission's attestation through
    :func:`enforce_attestation` and refuses a reused nonce under its lock
    before recording (`D-IMPL-363`). The policy is re-resolved per submission, so
    registering a flipped value changes behavior with zero code change.
    All four D-16 arguments are optional together: an unconfigured
    transport behaves exactly as before this composition existed.

    **Approver eligibility, and the workflow engine's binding** (SEC-006,
    `D-IMPL-366`; the security close-out's map B item 3, SEC-001-adjacent
    (f), ``D-GATE-357`` (2); Dave's GO of 2026-10-12 08:45 MST, step 1:
    *"enforce eligibility on supported approval transports"*). The Control
    Planes that judge an approval-gate verdict (``approve`` or ``reject``) on
    an event that names an approval policy, at :meth:`submit`, are the one
    bound at construction, if any, and every one a
    :class:`~ccf_runtime.workflow.engine.WorkflowEngine` composed over this
    transport bound through :meth:`bind_approver_eligibility`; each must admit
    the verdict. Any other approval-gate submission is judged by the
    construction plane alone, as before. A transport constructed without a
    Control Plane therefore still judges eligibility once an engine is
    composed over it, so a principal the gate's policy does not admit cannot
    record, while the gate's event is queued, the opposite verdict that would
    hold the gate as a conflict for good. A transport composed into no engine
    and constructed without a Control Plane judges nothing, as before — the
    pre-composition posture the primitives used alone keep.

    **Thread safety (WR-02; Phase-9 CONTEXT D-06).** A single plain
    :class:`threading.Lock` guards every queue mutation and snapshot read
    — the Protocol's concurrency contract, discharged here. The lock
    scope is deliberately minimal: D-16 verification
    (:meth:`_signed_binding_required` — a Control Plane resolve — and
    :func:`enforce_attestation` — JWS verification) runs *outside*
    the lock, per D-IMPL-69's "JWS verification stays outside any
    transport lock." A refused submission never touches the queues, so
    the refusal contract is unaffected; no locked method calls another
    locked method, so no reentrant locking is needed.

    Args:
        control_plane: The registry the HITL policy resolves through. The
            deployment's composition root supplies it; the transport never
            constructs one.
        hitl_policy_key: The Control Plane key the deployment registered
            its :class:`HitlPolicy` under — deployment vocabulary, no
            default (CINV-01).
        identity_provider: The D-IMPL-15 provider signatures verify
            through when the policy requires them. The keys they verify
            under are the pinned :class:`HitlPolicy`'s per-subject map —
            the ONE trust source (`D-IMPL-363` E5 / C6(a)); there is no
            constructor fallback.
    """

    def __init__(
        self,
        *,
        control_plane: ControlPlaneProtocol | None = None,
        hitl_policy_key: str | None = None,
        identity_provider: IdentityProvider | None = None,
    ) -> None:
        self._lock = threading.Lock()
        self._pending: dict[str, deque[PendingHitlEvent]] = {}
        self._submissions: dict[str, list[HitlActionSubmission]] = {}
        #: Nonces already presented, keyed ``(tenant, event_key, nonce)`` —
        #: the reference transport's seen-set (`D-IMPL-363` E4 / C11(a)).
        #: Checked and inserted in ONE step under the lock, after
        #: verification and before recording, so two racing presentations
        #: of one attestation cannot both land. Retained for the transport's
        #: lifetime; a user-implemented transport stays as replayable as
        #: before until the Protocol amendment (1.0.3, its own entry).
        self._seen_nonces: set[tuple[str, str, str]] = set()
        #: Events claimed through :meth:`remove` and not yet answered or
        #: given back, keyed ``(tenant, event_key)`` — the transport's own
        #: record of which primitive is resolving what (SEC-001 Tier 0).
        #: Guarded by the same lock as the queues.
        self._claims: dict[tuple[str, str], PendingHitlEvent] = {}
        #: Decided suspensions, keyed ``(tenant, event_key,
        #: product_content_hash)`` (``D-IMPL-378``). Guarded by the same lock as
        #: the queues, so a closure and a submission are ordered.
        self._closures: dict[tuple[str, str, str], GateClosure] = {}
        self._control_plane = control_plane
        self._hitl_policy_key = hitl_policy_key
        self._identity_provider = identity_provider
        #: The Control Planes workflow engines composed over this transport
        #: bound as approver-eligibility judges (:meth:`bind_approver_eligibility`),
        #: in binding order, each once by identity. Replaced, never mutated in
        #: place, under the lock.
        self._engine_planes: tuple[ControlPlaneProtocol, ...] = ()

    #: No other process reaches these queues (``D-IMPL-378``).
    scope = "process"

    def writer_lease(self) -> WriterLease:
        """The ``"process"`` declaration: exact, because no other process can reach this memory.

        ``D-IMPL-391`` (ruling 2(a)). A disclosure, not a lock: there is no
        substrate a second process could open.
        """
        from ccf.graph.protocols import ProcessScopedWriterLease

        return ProcessScopedWriterLease(substrate="in-memory HITL transport")

    def bind_approver_eligibility(self, control_plane: ControlPlaneProtocol) -> None:
        """Judge approval-gate verdicts against ``control_plane`` at :meth:`submit`.

        SDK-defined (CLAUDE.md §8.2; SEC-006, `D-IMPL-366`; the security
        close-out's map B item 3, ``D-GATE-357`` (2)). Called by
        :class:`~ccf_runtime.workflow.engine.WorkflowEngine` at construction
        with the engine's own Control Plane — the plane whose pinned
        ``ccf.approval-policy`` versions the engine's authority predicate
        judges — so a verdict (``approve`` or ``reject``, the actions the
        engine's conflict population counts) on an approval-gate event that
        names an approval policy is judged by the same
        :func:`check_approver_eligibility`, before attestation, and a refused
        one is recorded nowhere. An ``annotate`` or ``override``, and any
        action on an event that names no policy (a gate the engine never
        passes, `D-IMPL-366`), is judged only by a plane given at construction,
        as before. Binding a plane already bound is a no-op, so an engine
        rebuilt over the same pair builds again; a second engine's different
        plane is ADDED, and a verdict must then satisfy every bound plane
        (fail-closed).

        Nothing else changes: the HITL policy (signed bindings, the
        ``hitl_policy_ref`` stamp) still resolves only through the Control
        Plane given at construction, and a ``missing``-state submission is
        still recorded unjudged (`D-IMPL-366` H2).
        """
        with self._lock:
            if all(plane is not control_plane for plane in self._engine_planes):
                self._engine_planes = (*self._engine_planes, control_plane)

    def _eligibility_judges_locked(
        self, action: str, event: PendingHitlEvent | None
    ) -> tuple[ControlPlaneProtocol, ...]:
        """The Control Planes that judge a submission of ``action`` on ``event``.

        CALLER HOLDS THE LOCK; the caller judges approval-gate events only. The
        plane given at construction judges every action, exactly as before.
        The planes engines bound (:meth:`bind_approver_eligibility`) judge
        exactly the submissions that could hold a gate that could otherwise
        pass (map B item 3), each plane once by identity: a verdict the
        engine's conflict population counts (:data:`_GATE_VERDICTS`), on an
        event that names an approval policy. An event that names none
        authorizes no verdict at the engine (fail-closed, `D-IMPL-366`), so its
        gate never passes and a verdict on it holds nothing. Empty for a
        transport constructed without a plane and composed into no engine:
        nothing is judged.
        """
        own: tuple[ControlPlaneProtocol, ...] = (
            () if self._control_plane is None else (self._control_plane,)
        )
        if action not in _GATE_VERDICTS or event is None or event.policy_ref is None:
            return own
        return own + tuple(
            plane for plane in self._engine_planes if plane is not self._control_plane
        )

    @property
    def hitl_policy_key(self) -> str | None:
        """The Control Plane key this transport's HITL policy resolves under; ``None`` when unbound.

        Read-only (SEC-009; `D-IMPL-374` (4), fix round 5, R5): the erasure
        door holds its authority's HITL policy key to THIS key at composition
        and refuses a mismatch by name, so the approvals it files are the ones
        this transport judged under the same policy.
        """
        return self._hitl_policy_key

    def _signed_binding_required(self) -> bool:
        """Whether the policy in force requires a signed binding.

        Resolved from the Control Plane per call — the requiredness value
        lives ONLY in the registered :class:`HitlPolicy` artifact, never
        here (T-08-07). An unbound Control Plane or key is the
        pre-composition posture: not required.
        """
        return signed_binding_required(
            control_plane=self._control_plane,
            hitl_policy_key=self._hitl_policy_key,
        )

    def _snapshot_locked(
        self, tenant: str, event_key: str, product_content_hash: str
    ) -> tuple[PendingHitlEvent | None, EventStateAtSubmit]:
        """The request for one pause under ``(tenant, event_key)`` and its state.

        CALLER HOLDS THE LOCK. The claimed event when a primitive's claim on
        the key is on this pause's request; else the oldest pending event under
        the key for this pause; else ``None`` with state ``missing``
        (`D-IMPL-366` §4b, the three states, judged per pause since
        ``D-IMPL-391``: a request for another pause under the key is not this
        submission's). Used twice per :meth:`submit`: the snapshot (step 3) and
        the revalidation (step 6a).
        """
        claimed = self._claims.get((tenant, event_key))
        if claimed is not None and claimed.product_content_hash == product_content_hash:
            return claimed, "claimed"
        for event in self._pending.get(tenant, ()):
            if event.event_key == event_key and event.product_content_hash == product_content_hash:
                return event, "pending"
        return None, "missing"

    def enqueue(self, *, event: PendingHitlEvent) -> None:
        """Queue ``event`` for its tenant, preserving arrival order — once per paused run.

        ``D-IMPL-391``: an event whose ``(tenant, event_key,
        product_content_hash)`` is already pending is not queued again, and the
        call changes nothing. The check and the append run under the one lock
        every queue mutation takes, so racing enqueues of one paused run's
        request queue exactly one. A claimed event is not pending, so the
        primitives' give-back re-files it. When the event is appended, any
        outstanding claim for the same ``(tenant, event_key)`` is discarded:
        the event is pending again, so nothing has answered it. This is what
        makes the primitives' rollback path (``remove`` → failed ``submit`` →
        ``enqueue``) leave no stamp behind for a later bare submission to
        inherit.
        """
        with self._lock:
            queued = self._pending.get(event.tenant)
            if queued is not None and any(
                pending.event_key == event.event_key
                and pending.product_content_hash == event.product_content_hash
                for pending in queued
            ):
                return
            self._claims.pop((event.tenant, event.event_key), None)
            self._pending.setdefault(event.tenant, deque()).append(event)

    def dequeue(self, *, tenant: str) -> PendingHitlEvent | None:
        """Pop the oldest pending event for ``tenant``, or ``None``."""
        with self._lock:
            queue = self._pending.get(tenant)
            if not queue:
                return None
            return queue.popleft()

    def pending(self, *, tenant: str) -> tuple[PendingHitlEvent, ...]:
        """The tenant's pending events, oldest first, without consuming."""
        with self._lock:
            return tuple(self._pending.get(tenant, ()))

    def remove(
        self, *, tenant: str, event_key: str
    ) -> PendingHitlEvent | None:
        """Atomically remove and return the named pending event (WR-02).

        One lock acquisition covers the search and the removal, so a
        concurrent ``pending()`` never observes a partially drained
        queue, a concurrent ``enqueue`` never interleaves into a drain,
        and exactly one of any number of racing removals for the same
        event key receives the event. Every retained event keeps its
        relative order.

        The removal is recorded as a claim in the same lock acquisition
        (SEC-001 Tier 0), so the next :meth:`submit` for this pair naming the
        claimed event's pause is stamped with what was actually claimed. Only the winner records a
        claim, because only the winner removes anything.
        """
        with self._lock:
            queue = self._pending.get(tenant)
            if not queue:
                return None
            for index, event in enumerate(queue):
                if event.event_key == event_key:
                    del queue[index]
                    self._claims[(tenant, event_key)] = event
                    return event
            return None

    def retire(
        self, *, tenant: str, event_key: str, product_content_hash: str
    ) -> tuple[PendingHitlEvent, ...]:
        """See :meth:`HITLTransportProtocol.retire` (``D-IMPL-391``).

        One acquisition of the lock every queue mutation takes covers the
        search, the removal and the claim check; no claim is recorded.
        """
        with self._lock:
            claimed = self._claims.get((tenant, event_key))
            if claimed is not None and claimed.product_content_hash == product_content_hash:
                del self._claims[(tenant, event_key)]
            queue = self._pending.get(tenant)
            if not queue:
                return ()
            retired = tuple(
                event
                for event in queue
                if event.event_key == event_key
                and event.product_content_hash == product_content_hash
            )
            if retired:
                self._pending[tenant] = deque(
                    event
                    for event in queue
                    if not (
                        event.event_key == event_key
                        and event.product_content_hash == product_content_hash
                    )
                )
            return retired

    def view(
        self, authorized: Authorized[HitlQueueRead]
    ) -> tuple[PendingHitlEvent, ...]:
        """The capability's tenant's pending events, oldest first.

        :func:`~ccf.authz.capability.verify` first: the kind by
        identity, and the resource against the queue-read action id — the
        one honest resource for a read addressed by tenant alone (the HTTP
        door's ``ResourceBinding.route()`` semantics). After that line the
        tenant is ``authorized.tenant`` and nothing else.
        """
        verify(authorized, kind=HitlQueueRead, resource=HitlQueueRead.action_id)
        return self.pending(tenant=authorized.tenant)

    def submit(
        self,
        authorized: Authorized[HitlSubmit],
        *,
        submission: HitlActionSubmission,
    ) -> HitlActionSubmission:
        """Record one human action returning through the authority path.

        **The capability first (D-IMPL-353 §1.5c/f).** A fabricated
        capability, a genuine one of another kind, or a submit capability
        minted for some other event dies at
        :func:`~ccf.authz.capability.verify` before anything below
        runs — before the binding is compared, before the policy is
        resolved, before the lock is taken. Then the binding's subject must
        be the capability's principal: the recorded actor has one source.

        When the Control Plane HITL policy in force requires a signed
        attestation, the submission is verified by
        :func:`enforce_attestation` before anything is recorded (D-16): a
        refused submission never lands on the queue. Verification runs
        outside the lock and before the claim is consumed, so a refusal
        leaves both the pending event and its claim untouched (D-IMPL-69;
        Pitfall 4). The nonce is then checked and inserted in ONE step under
        the lock, after verification and before recording (`D-IMPL-363` E4 /
        C11(a)), and the recorded copy carries ``hitl_policy_ref`` — the
        ``key@version`` of the policy that judged it, where ``version`` is
        the Control Plane's version identifier for the pinned artifact.

        What is recorded is a copy stamped with the claim this submitter
        actually made — ``answered_event_class`` and
        ``answered_workflow_state_ref`` come from the event the transport
        observed being :meth:`remove`\\ d, never from ``submission``, and
        are stamped ``None`` when nothing was claimed. A caller-supplied
        value on either field is therefore discarded rather than trusted
        (SEC-001 Tier 0: a guard whose input the caller supplies is not a
        guard).

        **Residual: the claim is addressed, not held.** A claim is keyed
        ``(tenant, event_key)`` and consumed by whichever submission for
        that pair, naming the claimed request's pause, arrives first
        (``D-IMPL-391``: a submission naming another pause is judged against
        that pause's request and leaves the claim alone), because ``submit``
        has no caller identity to bind it to. A submitter that races the window a primitive opens
        between its ``remove`` and its ``submit`` — the two adjacent
        statements in
        :meth:`~ccf.hitl.approval_gate.ApprovalGate.resolve` — therefore
        takes the stamp, and the primitive's own submission is recorded
        unstamped. Closing it means ``remove`` minting an opaque claim
        token that ``submit`` requires, which is a
        :class:`HITLTransportProtocol` signature change and belongs with
        the D-IMPL-62 door ruling rather than here. Recorded because it
        NARROWS an existing hole rather than opening one: a submit-only
        submission that wins no race is still admitted by the engine's
        unstamped fallback leg today, with no race at all.

        **Approver eligibility (SEC-006; `D-IMPL-366`).** With a Control Plane
        bound — at construction, or by a workflow engine composed over this
        transport (:meth:`bind_approver_eligibility`; map B item 3) — a
        submission against an APPROVAL-GATE event is judged by
        :func:`check_approver_eligibility`, once per bound plane, each of which
        must admit it (an engine's plane judges only the verdicts ``approve``
        and ``reject``, on an event that names an approval policy) — after the
        capability and the principal check, BEFORE attestation (G2 (a)) —
        against a snapshot of the selected event taken under the lock (§4b
        step 3) — the request for the pause the submission names
        (``D-IMPL-391``; see :meth:`HITLTransportProtocol.submit`). Other event classes are not judged (G6 (a)); a ``missing``
        event judges nothing and is recorded as ``missing`` (H2). Under the
        one lock acquisition that records, the event and its state are
        REVALIDATED against the
        snapshot first (6a, :class:`HitlEventRevalidationRefused`), then the
        nonce is consumed, then the claim, if the submission was judged against
        it, is popped and the copy recorded with
        ``approval_policy_ref``, ``requested_by`` and ``event_state_at_submit``
        stamped from the snapshot (H3 (a)). A submission refused at ANY step
        leaves ``_submissions``, ``_claims`` and ``_seen_nonces`` unchanged.

        Raises:
            CapabilityBypassError: ``authorized`` is not a genuine
                ``Authorized[HitlSubmit]`` for ``submission.event_key``.
            PrincipalMismatchRefused: the binding's subject is not
                ``authorized.principal``.
            ApproverNotEligible: a Control Plane is bound (at construction or
                by a workflow engine), the event is an approval gate, and the
                principal may not approve it under the
                pinned ``ccf.approval-policy`` — including a missing, unresolvable
                or wrong-class policy ref, a missing requester, or the requester
                approving their own gate (SEC-006; `D-IMPL-366`).
            HitlEventRevalidationRefused: the event under the key changed
                between the snapshot and the record (`D-IMPL-366` §4b 6a);
                nothing was consumed or recorded.
            SignedBindingRequiredRefused: attestation required and absent.
            SignedBindingInvalidRefused: the attestation's signature does
                not verify under the keys declared for its subject.
            SignedBindingMismatchRefused: a signed claim disagrees with the
                capability, the request, the door-minted binding or the
                per-subject key map (`D-IMPL-363` E6).
            SignedBindingStaleRefused: ``issued_at`` is outside the policy's
                window against the recorded ``action_time``, or the nonce
                was already presented for this ``(tenant, event_key)``
                (`D-IMPL-363` E3 / E4).
        """
        verify(authorized, kind=HitlSubmit, resource=submission.event_key)
        if submission.principal.approver.subject_id != authorized.principal:
            raise PrincipalMismatchRefused(
                "the submission's binding names a subject other than the"
                " capability's principal; the actor of a recorded human"
                " action is the principal the authorizer decided for, and a"
                " binding over anyone else binds nothing here"
                " (D-IMPL-353 §2 P6; D-IMPL-21)"
            )
        tenant = authorized.tenant
        # Step 3 (D-IMPL-366 §4b): ONE snapshot of the selected event and its
        # state, under the lock; the lock is released and the snapshot is a
        # frozen event (or None) that every judgment below reads.
        with self._lock:
            event, state = self._snapshot_locked(
                tenant, submission.event_key, submission.principal.product_content_hash
            )
            judges = self._eligibility_judges_locked(submission.action, event)
        # Step 4: eligibility, outside the lock, BEFORE attestation (G2 (a)),
        # for approval-gate events only (RULED). Missing: nothing is judged,
        # and the submission is recorded as such below (H2). Every bound plane
        # judges — the construction plane any action, each engine's a verdict
        # on an event naming a policy (map B item 3) — so an engine-composed
        # transport built without a plane still refuses a verdict by a
        # principal its gate policy does not admit, before anything is
        # recorded.
        if event is not None and event.event_class == APPROVAL_GATE_EVENT_CLASS:
            for plane in judges:
                check_approver_eligibility(
                    policy_ref=event.policy_ref,
                    requested_by=event.requested_by,
                    subject_id=authorized.principal,
                    control_plane=plane,
                )
        resolved = resolve_hitl_policy(
            control_plane=self._control_plane,
            hitl_policy_key=self._hitl_policy_key,
        )
        policy_ref: str | None = None
        verified: HitlActionClaims | None = None
        if resolved is not None:
            version, policy = resolved
            assert self._hitl_policy_key is not None
            policy_ref = policy.pinned_ref(key=self._hitl_policy_key, version=version)
            if policy.signed_binding_required:
                # Outside the lock, before the claim is consumed (D-IMPL-69).
                verified = enforce_attestation(
                    authorized,
                    submission,
                    identity_provider=self._identity_provider,
                    policy=policy,
                )
        with self._lock:
            # Step 6a: revalidate the SELECTED event and its state against the
            # snapshot — the same frozen event in the same state, or missing
            # both times. Any disagreement refuses here and NOTHING below
            # runs: no nonce is consumed, no claim popped, nothing recorded
            # (D-IMPL-366 amendment: refused submissions introduce no state
            # mutations; the attestation's nonce is single-use on SUCCESS only).
            again, state_again = self._snapshot_locked(
                tenant, submission.event_key, submission.principal.product_content_hash
            )
            if (
                tenant,
                submission.event_key,
                submission.principal.product_content_hash,
            ) in self._closures:
                # D-IMPL-378: the suspension this verdict names was decided;
                # refused before anything is consumed or recorded.
                raise HitlGateClosed(
                    f"the gate under {submission.event_key!r} was already"
                    " decided for the suspension this verdict names; the"
                    " verdict is refused and nothing was recorded"
                )
            if state_again != state or again != event:
                raise HitlEventRevalidationRefused(
                    f"the HITL event under {submission.event_key!r} changed"
                    f" between this submission's snapshot ({state}) and its"
                    f" record ({state_again}); the submission was judged"
                    " against a state that no longer holds and is refused"
                    " before anything is consumed — re-present it against the"
                    " current event (D-IMPL-366 §4b 6a)"
                )
            if verified is not None:
                # E4 / C11(a): the nonce check and insert are ONE step under
                # the lock, after verification and before anything is
                # recorded — a reuse refuses here and lands nothing, and two
                # racing presentations cannot both pass.
                nonce_key = (tenant, verified.event_key, verified.nonce)
                if nonce_key in self._seen_nonces:
                    raise SignedBindingStaleRefused(
                        "the attestation's nonce was already presented for"
                        f" event {verified.event_key!r}; a signed statement"
                        " is admitted once (D-IMPL-363 E4)"
                    )
                self._seen_nonces.add(nonce_key)
            # D-IMPL-391: only a claim on the request for the pause this
            # submission names is consumed; a claim on another pause's request
            # stays for the primitive that holds it.
            claimed = (
                self._claims.pop((tenant, submission.event_key))
                if state == "claimed"
                else None
            )
            recorded = submission.model_copy(
                update={
                    "answered_event_class": (
                        None if claimed is None else claimed.event_class
                    ),
                    "answered_workflow_state_ref": (
                        None if claimed is None else claimed.workflow_state_ref
                    ),
                    "authorizing_decision_id": authorized.decision_id,
                    "hitl_policy_ref": policy_ref,
                    # H3 (a) / H2: stamped from the revalidated snapshot.
                    "approval_policy_ref": None if event is None else event.policy_ref,
                    "requested_by": None if event is None else event.requested_by,
                    "event_state_at_submit": state,
                }
            )
            self._submissions.setdefault(tenant, []).append(recorded)
        return recorded

    def submissions(self, *, tenant: str) -> tuple[HitlActionSubmission, ...]:
        """The tenant's recorded actions, oldest first."""
        with self._lock:
            return tuple(self._submissions.get(tenant, ()))

    def close_gate(
        self,
        authorized: Authorized[Resume],
        *,
        event_key: str,
        product_content_hash: str,
        passage: str,
        decided_action: str,
        decided_by: str,
        observed_submissions: int,
    ) -> GateClosure:
        """See :meth:`HITLTransportProtocol.close_gate` (``D-IMPL-378``).

        One acquisition of the transport's lock covers the closure lookup, the
        count, the record and the retirement — the lock :meth:`submit` records
        under — so a submission is either counted or refused, never both.
        """
        verify_any(
            authorized,
            kinds=(Resume,),
            resource=getattr(authorized, "resource", ""),
        )
        tenant = authorized.tenant
        triple = (tenant, event_key, product_content_hash)
        with self._lock:
            existing = self._closures.get(triple)
            if existing is not None:
                if existing.passage == passage:
                    return existing
                raise GateAlreadyClosed(
                    f"the gate under {event_key!r} was already decided for this"
                    " suspension by another passage"
                )
            recorded = sum(
                1
                for item in self._submissions.get(tenant, ())
                if item.event_key == event_key
                and item.principal.product_content_hash == product_content_hash
            )
            if recorded != observed_submissions:
                raise GateVerdictsChanged(
                    f"{recorded} submissions are recorded on this suspension of"
                    f" {event_key!r}, not the {observed_submissions} the decision"
                    " judged; nothing was decided"
                )
            closure = GateClosure(
                tenant=tenant,
                event_key=event_key,
                product_content_hash=product_content_hash,
                passage=passage,
                decided_action=decided_action,
                decided_by=decided_by,
                observed_submissions=observed_submissions,
                authorizing_decision_id=authorized.decision_id,
            )
            self._closures[triple] = closure
            queue = self._pending.get(tenant)
            if queue:
                self._pending[tenant] = deque(
                    event
                    for event in queue
                    if not (
                        event.event_key == event_key
                        and event.product_content_hash == product_content_hash
                    )
                )
            claimed = self._claims.get((tenant, event_key))
            if claimed is not None and claimed.product_content_hash == product_content_hash:
                del self._claims[(tenant, event_key)]
            return closure

    def closures(self, *, tenant: str) -> tuple[GateClosure, ...]:
        """The tenant's gate closures, oldest first (``D-IMPL-378``)."""
        with self._lock:
            return tuple(c for c in self._closures.values() if c.tenant == tenant)
