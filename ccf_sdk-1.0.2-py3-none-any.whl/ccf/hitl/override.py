# Copyright (c) 2026 David Castillo. All rights reserved.
# Use, copying, modification, and distribution of the covered material
# are governed by the CCF SDK Interim Software and Patent License
# in the repository-root LICENSE.md and any controlling signed agreement.
# Rights under that interim license begin only upon its execution
# and are limited to its stated scope and term.
"""``OverrideBoundary`` — the typed substitution HITL primitive (CLAUDE.md §8.2).

SDK-defined (CLAUDE.md §8.2 — an extension beyond the whitepaper, and it
says so); HITL-01; D-IMPL-20/21. The third of the four HITL primitives: a
typed boundary at which a human can substitute a value the agent would
otherwise have produced. Overrides are audited; **the original agent
output and the override are both in the replay record** — T-07-16's
repudiation threat is mitigated by carrying both values, canonically
serialized, in the dimension-2 block, byte-assertable.

**The boundary is generic over the contract type being overridden.** The
deployment parameterizes :class:`OverrideBoundary` with its own
:class:`~ccf.contracts.base.CCFContract` output type; the SDK ships the
boundary mechanism only — no output schema, no substitution rule, no
policy value lives here (CINV-01). Original and override are never mutated
in place: both are preserved verbatim in the
:class:`OverrideActionRecord`.

**A declined override is an action, not an absence.** The human confirming
the agent value resolves through the same bound path (``approve``) and
lands on dimension 2 with ``overridden=False`` — a reviewer who looked and
kept the value is as auditable as one who substituted.

**D-22 scope statement — which claims are guaranteed by what.**

* **Type-unrepresentable paths:** an *unbound* override — a human action
  without a complete :class:`~ccf.hitl.principal.HumanPrincipalBinding` —
  cannot be constructed through the typed transport contract
  (:class:`~ccf.hitl.transport.HitlActionSubmission` requires the binding
  by type), so that path does not exist in the type system.
* **Lint/CI-covered paths:** *capture completeness* — that every exercised
  override resolution actually lands both values on replay dimension 2 —
  is guarded by the owning tests (``tests/hitl/test_override.py``),
  demonstrated by byte assertion, not proven by construction. Never an
  absolute "no path" claim.

**TOCTOU guard (T-07-17/T-07-39 doctrine).** ``propose`` binds the
original's content hash at proposal time; the overrider's binding echoes
the hash of what they actually reviewed. A mismatch is a returned typed
:class:`OverrideResolutionRefused`, audited ``resolved=False``, with the
event left pending.

Algorithmic module (CINV-03).
"""

from __future__ import annotations

import threading
from collections.abc import Callable, Mapping
from datetime import datetime
from typing import Generic, TypeVar

from ccf.authz.capability import Authorized, HitlSubmit, verify
from ccf.contracts.base import CCFContract
from ccf.contracts.canonical import canonical_bytes, content_hash
from ccf.controlplane.audit import AuditLog
from ccf.controlplane.registry import ControlPlaneProtocol
from ccf.hitl.approval_gate import HITL_ACTION_ARTIFACT_CLASS
from ccf.hitl.identity_binding import SignedHitlAction
from ccf.hitl.principal import HumanPrincipalBinding
from ccf.hitl.transport import (
    HITLTransportProtocol,
    HitlActionSubmission,
    PendingHitlEvent,
    enforce_attestation,
    resolve_hitl_policy,
)
from ccf.peering.identity import IdentityProvider, JsonWebKey

__ccf_mode__ = "algorithmic"

__all__ = [
    "OverrideActionRecord",
    "OverrideBoundary",
    "OverrideResolution",
    "OverrideResolutionRefused",
    "UnknownOverrideEventError",
]

ProductT = TypeVar("ProductT", bound=CCFContract)


class UnknownOverrideEventError(LookupError):
    """The named event is not pending on the transport — broken wiring.

    Raised — never a returned refusal — on the I.1 line: a caller resolving
    an override the queue does not hold is mis-wired, not an expected
    governance outcome.
    """


class OverrideActionRecord(CCFContract, Generic[ProductT]):
    """One completed override action, in full — the dimension-2 payload.

    SDK-defined (CLAUDE.md §8.2). Carries what was pending (the event, with
    the proposal-time original hash), what the human did (the submission,
    with the required principal binding), and **both values**: ``original``
    (the agent's output, verbatim) and ``final`` (the substituted value, or
    the original again on a confirm). Canonically serializable, so the
    boundary pre-serializes it once and replay records it verbatim
    (T-07-16 — losing the original would make an override unrepudiable).
    """

    event: PendingHitlEvent
    submission: HitlActionSubmission
    original: ProductT
    final: ProductT
    overridden: bool


class OverrideResolution(CCFContract, Generic[ProductT]):
    """A completed override decision — outcome plus the pre-serialized block.

    ``hitl_actions_block`` is the canonical serialization of ``record``,
    serialized once by the boundary and passed verbatim to
    :func:`ccf.replay.record.build_replay_record`'s ``hitl_actions``
    keyword (dimension 2). Derived here, never reconstructed by the record
    builder.
    """

    record: OverrideActionRecord[ProductT]
    hitl_actions_block: str


class OverrideResolutionRefused(CCFContract):
    """A resolution the boundary refuses — typed value, audited
    ``resolved=False``.

    The TOCTOU case foremost: the overrider's binding names a content hash
    other than the original's proposal-time hash. The pending event
    survives, so the human can re-review the current output.
    """

    tenant: str
    event_key: str
    reason: str


class OverrideBoundary(Generic[ProductT]):
    """The typed substitution HITL primitive (CLAUDE.md §8.2; HITL-01).

    Everything is injected — transport, audit log, clock — in the
    constructor-injection discipline of every Control Plane service: the
    boundary holds no output schema, no substitution rule, and no wall
    clock of its own. Which policy governs a boundary comes from the
    pinned ``policy_ref`` carried on the pending event (CINV-01).

    Args:
        transport: The typed HITL queue proposals surface on and actions
            return through (D-IMPL-20 — the only authority path).
        audit: The append-only log every resolution lands in, refusals
            included (``resolved=False``).
        clock: Time source for audit timestamps. Injected, never read.
        control_plane: The registry the HITL policy resolves through
            (D-IMPL-69; SDK-defined, CLAUDE.md §8.2). Optional together
            with the other three verification kwargs: all-unbound is the
            pre-Phase-10 posture, byte-identical behavior.
        hitl_policy_key: The Control Plane key the deployment registered
            its :class:`~ccf.hitl.transport.HitlPolicy` under —
            deployment vocabulary, no default (CINV-01).
        identity_provider: The D-IMPL-15 provider signatures verify
            through when the policy requires them.
    """

    def __init__(
        self,
        *,
        transport: HITLTransportProtocol,
        audit: AuditLog,
        clock: Callable[[], datetime],
        control_plane: ControlPlaneProtocol | None = None,
        hitl_policy_key: str | None = None,
        identity_provider: IdentityProvider | None = None,
    ) -> None:
        self._transport = transport
        self._audit = audit
        self._clock = clock
        self._control_plane = control_plane
        self._hitl_policy_key = hitl_policy_key
        self._identity_provider = identity_provider
        # Side-band original values, keyed (tenant, event_key). Per-instance
        # and in-memory — narrower than the transport, which may be shared
        # or durable — so :meth:`resolve` verifies this state exists
        # *before* touching the transport (WR-01) and surfaces absence as
        # the typed broken-wiring error, never a bare ``KeyError`` after
        # the authority path has already recorded the action. Guarded by
        # its own lock: the transport's lock does not cover this dict.
        self._state_lock = threading.Lock()
        self._originals: dict[tuple[str, str], ProductT] = {}

    def propose(
        self,
        *,
        tenant: str,
        event_key: str,
        workflow_state_ref: str,
        original: ProductT,
        policy_ref: str | None = None,
        requested_by: str | None = None,
    ) -> PendingHitlEvent:
        """Surface the agent's output for a possible human substitution.

        ``requested_by`` (SEC-006; `D-IMPL-366` G6 (a)) is carried on the
        event as data and NOT judged for this event class.

        The original's content hash is bound into the pending event at
        proposal time — the value the overrider's binding must echo — and
        the original itself is retained verbatim for the eventual record.
        Proposal is the agent side of the boundary, not a human action; the
        human action audits at :meth:`resolve`.
        """
        event = PendingHitlEvent(
            event_key=event_key,
            event_class="override-boundary",
            tenant=tenant,
            workflow_state_ref=workflow_state_ref,
            product_content_hash=content_hash(original),
            policy_ref=policy_ref,
            requested_by=requested_by,
        )
        self._transport.enqueue(event=event)
        with self._state_lock:
            self._originals[(tenant, event_key)] = original
        return event

    def resolve(
        self,
        authorized: Authorized[HitlSubmit],
        *,
        event_key: str,
        principal: HumanPrincipalBinding,
        override: ProductT | None = None,
        annotation: str | None = None,
        attestation: SignedHitlAction | None = None,
    ) -> OverrideResolution[ProductT] | OverrideResolutionRefused:
        """Resolve one pending boundary under a bound human decision.

        The principal binding is required by type — an unattributed
        override is unrepresentable through this signature (D-IMPL-21; the
        D-22 type-unrepresentable leg). The TOCTOU guard runs before
        anything is consumed or submitted.

        **The capability first (D-IMPL-353 §1.2).** ``authorized`` is the
        ``Authorized[HitlSubmit]`` the gate minted for exactly this event;
        :func:`~ccf.authz.capability.verify` runs before the handle's first
        real statement, so a fabricated capability, one of another kind, or
        one minted for another event dies before the queue is read, before
        anything is audited, and before the claim is taken. The tenant is
        ``authorized.tenant`` and nothing else — there is no tenant
        parameter (§1.3) — and the transport records the action under the
        capability's principal.

        **Signed-binding verification (D-IMPL-69; SDK-defined, CLAUDE.md
        §8.2).** When a Control Plane is bound and the HitlPolicy in force
        declares ``signed_binding_required``, this surface verifies
        ``attestation`` before any queue consumption — a refused
        resolution raises and leaves the event pending. Verification is
        read-only and holds no lock; the transport re-verifies
        independently at submission (idempotent double verification,
        D-13).

        Args:
            override: The substituted value, or ``None`` — the human
                confirms the agent value. **Both paths are recorded
                actions**; a confirm is never an absence.

        Returns:
            :class:`OverrideResolution` carrying both original and final
            values and the pre-serialized dimension-2 block, or
            :class:`OverrideResolutionRefused` on a hash mismatch.

        Raises:
            ccf.authz.capability.CapabilityBypassError: ``authorized`` is
                not a genuine ``Authorized[HitlSubmit]`` for ``event_key``.
            UnknownOverrideEventError: ``event_key`` names no pending
                override for the capability's tenant, this instance holds no
                proposal-time original for the pending event (WR-01 —
                the transport may be shared while side-band state is
                per-instance), or a concurrent resolve won the claim
                (WR-02) — broken wiring or a lost race, not a
                governance outcome. Checked before any transport
                mutation, so no authority action lands unresolved.
        """
        verify(authorized, kind=HitlSubmit, resource=event_key)
        tenant = authorized.tenant
        event = next(
            (
                pending
                for pending in self._transport.pending(tenant=tenant)
                if pending.event_key == event_key
                and pending.event_class == "override-boundary"
            ),
            None,
        )
        if event is None:
            raise UnknownOverrideEventError(
                f"no pending override {event_key!r} for tenant {tenant!r};"
                " resolving an event the queue does not hold is broken"
                " wiring, not a governance outcome (I.1 line)"
            )
        if principal.product_content_hash != event.product_content_hash:
            self._record(
                event_key,
                version=event.product_content_hash,
                resolved=False,
                actor=principal.approver.subject_id,
            )
            return OverrideResolutionRefused(
                tenant=tenant,
                event_key=event_key,
                reason=(
                    "the binding's product_content_hash"
                    f" {principal.product_content_hash!r} does not equal the"
                    " original's proposal-time hash"
                    f" {event.product_content_hash!r}: the output changed"
                    " between proposal and the human action, so the override"
                    " would substitute against something the human never saw"
                    " (T-07-17; T-07-39 doctrine). The event stays pending —"
                    " re-review the current output and act on its hash"
                ),
            )
        with self._state_lock:
            original = self._originals.get((tenant, event_key))
        if original is None:
            # WR-01: the pending event exists on the transport but this
            # instance holds no proposal-time original for it — the
            # transport may be shared or durable while this side-band
            # state is per-instance. Refused typed and *before* any
            # transport mutation.
            raise UnknownOverrideEventError(
                f"override {event_key!r} for tenant {tenant!r} is pending"
                " on the transport but this OverrideBoundary instance"
                " holds no proposal-time original for it; the transport"
                " is shared state while the original record is"
                " per-instance — resolve on the instance that proposed"
                " (broken wiring, not a governance outcome; WR-01)"
            )
        overridden = override is not None
        submission = HitlActionSubmission(
            event_key=event_key,
            action="override" if overridden else "approve",
            principal=principal,
            annotation=annotation,
            attestation=attestation,
        )
        resolved_policy = resolve_hitl_policy(
            control_plane=self._control_plane,
            hitl_policy_key=self._hitl_policy_key,
        )
        if resolved_policy is not None and resolved_policy[1].signed_binding_required:
            # Verify BEFORE any queue consumption: a refusal raises here
            # and the pending event survives (D-IMPL-69; Pitfall 4). The
            # nonce is not consumed here — the transport does that once,
            # atomically, at submit (D-IMPL-363 E4).
            enforce_attestation(
                authorized,
                submission,
                identity_provider=self._identity_provider,
                policy=resolved_policy[1],
            )
        claimed = self._transport.remove(tenant=tenant, event_key=event_key)
        if claimed is None:
            # A concurrent resolve claimed the event between the snapshot
            # check above and this atomic claim (WR-02): exactly one
            # resolver wins; the loser raises without submitting.
            raise UnknownOverrideEventError(
                f"no pending override {event_key!r} for tenant {tenant!r}:"
                " a concurrent resolution claimed it after this call's"
                " pending-snapshot check (WR-02 — exactly one resolve wins"
                " the claim; this one lost)"
            )
        if claimed.product_content_hash != principal.product_content_hash:
            # D-IMPL-391 (the review of 4be75f02): `remove` takes the oldest
            # request under the key whatever pause it is for, so a concurrent
            # act that took this call's request first hands it ANOTHER pause's
            # request. The transport judges a submission against the pause it
            # names, so this call's submission would not consume that claim,
            # and a claim left with its request gone would stamp a later
            # verdict sent straight to the queue. Give it back unanswered and
            # refuse as a lost race.
            self._transport.enqueue(event=claimed)
            raise UnknownOverrideEventError(
                f"the pending override {event_key!r} for tenant {tenant!r} is no"
                " longer the one this call checked: a concurrent resolution or"
                " retirement took it after this call's pending-snapshot check,"
                " and the request now in front is for another pause; it was given"
                " back unanswered (WR-02; D-IMPL-391)"
            )
        try:
            # The transport returns the RECORDED copy — stamped with the
            # authorizing decision id (D-IMPL-353 §9) — and that copy, not
            # this primitive's input, is what the replay block carries.
            recorded = self._transport.submit(authorized, submission=submission)
        except BaseException:
            # A refused authority submission never consumes the pending
            # event: the claim is given back (re-enqueued at the tail).
            self._transport.enqueue(event=claimed)
            raise
        with self._state_lock:
            self._originals.pop((tenant, event_key), None)
        final = override if override is not None else original
        self._record(
            event_key,
            version=event.product_content_hash,
            resolved=True,
            actor=principal.approver.subject_id,
        )
        record: OverrideActionRecord[ProductT] = OverrideActionRecord(
            event=event,
            submission=recorded,
            original=original,
            final=final,
            overridden=overridden,
        )
        return OverrideResolution(
            record=record,
            hitl_actions_block=canonical_bytes(record).decode("utf-8"),
        )

    # -- helpers ---------------------------------------------------------------

    def _record(
        self,
        event_key: str,
        *,
        version: str,
        resolved: bool,
        actor: str | None = None,
    ) -> None:
        self._audit.append(
            action="hitl_action",
            key=event_key,
            version=version,
            resolved=resolved,
            occurred_at=self._clock(),
            actor=actor,
            artifact_class=HITL_ACTION_ARTIFACT_CLASS,
        )
