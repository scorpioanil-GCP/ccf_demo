# Copyright (c) 2026 David Castillo. All rights reserved.
# Use, copying, modification, and distribution of the covered material
# are governed by the CCF SDK Interim Software and Patent License
# in the repository-root LICENSE.md and any controlling signed agreement.
# Rights under that interim license begin only upon its execution
# and are limited to its stated scope and term.
"""``WorkflowEngine`` — the async-first in-SDK workflow state machine.

SDK-defined (CLAUDE.md §8.1 — an extension beyond the whitepaper, and it
says so); ORCH-01; D-IMPL-17/18/27/61. The execution half of the Workflow
primitive: it interprets WorkflowFactory-built handles
(:mod:`ccf.workflow.factory`) as state machines with explicit states,
transitions, and terminal conditions, suspends on hitl-gate nodes with
typed state persisted at the Control Plane boundary through the audited
write surface only, and resumes later.

**Placement (Open Question 2, resolved in writing).** The workflow
*contracts* are synchronous ``/src`` surface (07-04); this engine and its
state record are ``/runtime`` per D-14 and the state seam's
record-next-to-the-machine doctrine — the machine runs here, so the record
lives beside it (:mod:`ccf_runtime.workflow.state`).

**Factory handles only (ORCH-01).** ``execute`` and ``resume`` accept the
:class:`~ccf.workflow.factory.Workflow` handle and nothing else; a raw
``WorkflowDefinition`` is refused with a typed error. "Via the Task
Factory" holds at the execution boundary, not only at construction.

**Harness-neutral at every node (CLAUDE.md §8.1).** Node execution travels
two injected Protocol seams — :class:`SkillNodeBinding` and
:class:`AgentNodeBinding` — that the composition root binds: skill nodes
onto the existing skill dispatch (:mod:`ccf.skills.dispatch`), agent nodes
onto an Agent-Factory-constructed agent under a
:class:`~ccf.harness.protocol.HarnessAdapterProtocol` binding (§7.3). This
module names no harness and imports none; which harness executes an agent
node is resolved through the adapter binding, never through the workflow.

**Routing is the artifact's statement (CINV-01).** Transitions, terminals,
exception refs, and gate policies are interpreted from the factory-resolved
definition content only; no routing value exists in this module. A resume
decision must name a transition target the artifact declares.

**Persistence follows the D-IMPL-18/27 mutability split.** Live suspended
state is a :class:`~ccf_runtime.workflow.state.WorkflowStateRecord` on the
native Control Plane state seam, written exclusively through
:class:`~ccf.controlplane.audit.AuditLog`-bearing
:class:`~ccf.controlplane.state.AuditedStateWriter` writes. The immutable
execution trace writes through to the injected ArtifactStore at each
suspend and at terminal as content-addressed canonical bytes.

**The tenant is the capability's (D-IMPL-353 §1.3).** ``execute`` and
``resume`` each require the :class:`~ccf.authz.capability.Authorized` for
their own action — ``Execute`` and ``Resume`` respectively — and
:func:`~ccf.authz.capability.verify` it against the handle's definition key
before anything else. From that line on the only tenant in the engine is
``authorized.tenant``: the state key is derived from it and the execution
id, every state-store and trace-store write carries the capability and that
derived key (the §1.2 derived-writes rule), and the HITL pending event is
filed under it. Nothing here reads the tenant the artifact declares; the
factory compared it with the capability once, at construction, and that is
the whole of the tenant check. A capability for tenant B therefore cannot
produce state under tenant A — not because a comparison refuses it, but
because no expression of the engine files anywhere but under
``authorized.tenant`` (§2 P2).

**Refusal doctrine (I.1 line).** Expected outcomes — gate suspension,
exception-path routing, a resume of a terminal or unknown execution, an
undeclared decision — are typed returned values, audited (refusals as
``resolved=False``). Broken wiring — a handle that is not a factory
product, a step ref the Control Plane cannot resolve, a foreign state
record, ambiguous nominal routing — raises.

Algorithmic module (CINV-03).
"""

from __future__ import annotations

import threading
import weakref
from collections.abc import Callable, Mapping
from datetime import datetime
from typing import Protocol, Union, runtime_checkable

from ccf.artifacts.protocol import (
    ArtifactRef,
    ArtifactStoreError,
    ArtifactStoreProtocol,
    DerivedWrite,
    artifact_uri,
)
from ccf.authz.capability import Authorized, Execute, Resume, verify
from ccf.contracts.base import CCFContract
from ccf.contracts.canonical import canonical_bytes, content_hash
from ccf.controlplane.audit import (
    AuditAction,
    AuditEvent,
    AuditLog,
    WorkflowVerdictIntegrityFailure,
)
from ccf.controlplane.registry import ControlPlaneRegistry
from ccf.controlplane.resolution import resolve_pinned
from ccf.controlplane.state import (
    AuditedStateWriter,
    ConditionalStateStore,
    StateConflict,
    StateStoreIdentityMissing,
    state_key,
    state_store_identity_of,
)
from ccf.halflife.debt import DebtAssessment, DebtSignal
from ccf.hitl.approval_gate import GATE_ACTIONS, GATE_EVENT_CLASS
from ccf.hitl.escalation import ESCALATION_EVENT_CLASS
from ccf.hitl.transport import (
    ApproverNotEligible,
    GateAlreadyClosed,
    GateVerdictsChanged,
    check_approver_eligibility,
    HITLTransportProtocol,
    HitlActionSubmission,
    PendingHitlEvent,
)
from ccf.replay.serve import _same_string
from ccf.skills.grants import SplitAuditPlaneError
from ccf.workflow.definitions import (
    WORKFLOW_DEFINITION,
    WORKFLOW_FAILED_STATE,
)
from ccf.workflow.factory import Workflow
from ccf_runtime.workflow.state import (
    WORKFLOW_STATE,
    TraceEntry,
    WorkflowStateRecord,
    suspension_left_by,
)

__ccf_mode__ = "algorithmic"

__all__ = [
    "WORKFLOW_TRACE_ARTIFACT_CLASS",
    "AgentNodeBinding",
    "DebtAssessmentBinding",
    "ExecutionFenced",
    "ForeignStateRecordError",
    "SkillNodeBinding",
    "UnboundDebtAssessmentError",
    "WorkflowCompleted",
    "WorkflowEngine",
    "WorkflowExceptionRouted",
    "WorkflowExecutionTypeError",
    "WorkflowOutcome",
    "WorkflowResumeRefused",
    "WorkflowSuspended",
    "WorkflowTraceReferenceMismatch",
    "WorkflowWiringError",
]

#: The artifact class execution traces write through under (D-IMPL-18). A
#: mechanism identifier: it names the engine's own trace artifacts, exactly
#: as ``WORKFLOW_STATE`` names its state records.
WORKFLOW_TRACE_ARTIFACT_CLASS = "ccf.workflow-trace"

#: Executions with a resumption in flight IN THIS PROCESS (D-IMPL-377), each
#: as ``(id(state_store), state_key)``: the Control Plane state store the
#: execution's record lives in, and the key it lives under. Module-level and
#: not per engine, because two engines over one Control Plane read and write
#: the same record and must be refused against each other. Membership IS the
#: claim; the lock guards only the test-and-set and the discard, and is never
#: held across an ``await``.
_RESUMPTIONS_IN_FLIGHT: set[tuple[int, str]] = set()
_RESUMPTIONS_IN_FLIGHT_LOCK = threading.Lock()

#: The two sharing scopes a Control Plane state store and a HITL transport
#: declare (``D-IMPL-378``): ``process`` — no other process reaches them — and
#: ``shared`` — a durable implementation several processes reach. Mechanism
#: vocabulary, read by the construction checks; no deployment value.
_SCOPES: frozenset[str] = frozenset({"process", "shared"})

#: The methods a :class:`~ccf.controlplane.state.ConditionalStateStore` offers
#: beside its ``scope`` and ``identity`` (``D-IMPL-378``). Read by the first
#: construction check, so a store missing the conditional write is refused as
#: such before its identity is asked for (``D-IMPL-391``).
_CONDITIONAL_STORE_METHODS: tuple[str, ...] = ("get", "put", "items", "get_versioned", "put_if")

#: Each process-scoped HITL transport, mapped to a weak reference to the one
#: process-scoped state store it was first built with (Tuesday GO item 4). A
#: dead reference still refuses a new store: the transport's approvals belong
#: to a store that no longer exists, and a fresh store would accept the same
#: execution id again.
_TRANSPORT_STORES: weakref.WeakKeyDictionary[object, weakref.ref[object]] = (
    weakref.WeakKeyDictionary()
)
#: Fallback for a transport that cannot be weakly keyed: kept by identity, with
#: a strong reference so its id cannot be reused while the entry stands.
_TRANSPORT_STORES_BY_ID: dict[int, tuple[object, weakref.ref[object]]] = {}
_TRANSPORT_STORES_LOCK = threading.Lock()


def _bind_transport_to_store(transport: object, store: object) -> None:
    """Refuse a process-scoped transport already serving another store object."""
    with _TRANSPORT_STORES_LOCK:
        try:
            bound = _TRANSPORT_STORES.get(transport)
        except TypeError:
            entry = _TRANSPORT_STORES_BY_ID.get(id(transport))
            bound = None if entry is None else entry[1]
            if bound is None:
                _TRANSPORT_STORES_BY_ID[id(transport)] = (transport, weakref.ref(store))
                return
        else:
            if bound is None:
                _TRANSPORT_STORES[transport] = weakref.ref(store)
                return
        if bound() is not store:
            raise WorkflowWiringError(
                f"the HITL transport {type(transport).__name__} is already bound"
                " to another Control Plane state store: one queue serving two"
                " independent stores lets one approval release the same"
                " execution in each (SEC-001). Build every engine over one"
                " transport with the same state store, or give each store its"
                " own transport"
            )


def _claim_resumption(claim: tuple[int, str]) -> bool:
    """Take one execution's single-flight claim, or report it already taken.

    A test-and-set that returns at once either way (D-IMPL-377): the caller
    refuses rather than waits, so no thread blocks on another resumption and
    no event loop blocks on itself.
    """
    with _RESUMPTIONS_IN_FLIGHT_LOCK:
        if claim in _RESUMPTIONS_IN_FLIGHT:
            return False
        _RESUMPTIONS_IN_FLIGHT.add(claim)
        return True


def _release_resumption(claim: tuple[int, str]) -> None:
    """Give one execution's single-flight claim back (D-IMPL-377)."""
    with _RESUMPTIONS_IN_FLIGHT_LOCK:
        _RESUMPTIONS_IN_FLIGHT.discard(claim)


class WorkflowExecutionTypeError(TypeError):
    """The execute surface was handed something other than a factory handle.

    ORCH-01's "via the Task Factory", enforced at the execution boundary: a
    raw ``WorkflowDefinition`` — or anything else that is not the
    WorkflowFactory-built :class:`~ccf.workflow.factory.Workflow` — is not
    an accepted input type (CINV-01c, one level further up).
    """


class WorkflowWiringError(RuntimeError):
    """Broken wiring between the handle and this engine's Control Plane.

    A step ref that resolves to nothing, or nominal routing the artifact
    leaves ambiguous — a raised exception on the I.1 line, never a returned
    refusal: this is a broken deployment, not an expected outcome.
    """


class UnboundDebtAssessmentError(WorkflowWiringError):
    """An agent-node handoff was attempted with no bound debt assessment.

    D-IMPL-65's committed engine refusal, delivered in the 7.1 gap cycle
    per D-IMPL-66(b): DESIGN.md §4 names per-handoff ``D_c`` recomputation
    with fail-closed routing as a Workflow-primitive invariant
    (INV-CH7-68), so an engine asked to hand off to an agent node without a
    :class:`DebtAssessmentBinding` is a broken deployment — a raised
    exception on the I.1 line, never a returned refusal.
    """


class ExecutionFenced(RuntimeError):
    """A later write of a passage found the record moved by another writer.

    SDK-defined (``D-IMPL-378``). Every write after a passage commit is
    conditional on the version that passage wrote. A conflict means a writer
    other than this passage moved the execution's record while the passage
    ran — which the engine's own refusals make impossible on a conforming
    store, since a ``running`` execution is never resumed or restarted — so the
    engine fails closed rather than overwrite what it never saw.
    """


class ForeignStateRecordError(TypeError):
    """The state store returned a record this machine did not write.

    The ``GrantStateRecord`` isinstance discipline applied to workflows: the
    :data:`~ccf_runtime.workflow.state.WORKFLOW_STATE` record class is the
    workflow machine's alone (D-IMPL-18/27).
    """


class WorkflowTraceReferenceMismatch(ArtifactStoreError):
    """The store answered an execution trace's write with a reference that is not that trace's own.

    SDK-defined per CLAUDE.md §11; the ruling of record is ``D-IMPL-378``
    decision 5 (Dave, 2026-10-09 16:38 MST, adopting Grok's recommendation):
    *"(a) Fix the four writers in one small lane."* It extends decision 5 (a)
    (06:21 MST), *"Verify the returned record address against the record
    actually written."*, from
    ``src/ccf/replay/serve.py::ReplayWriter.write_replay_record`` to the trace
    the engine writes through to the artifact store (D-IMPL-18).

    **What the engine knows before the store answers.** Under ``D-IMPL-26``
    the whole reference of a trace it files is fixed by the trace, the
    execution and the capability that authorized the run: the content address
    is :func:`~ccf.contracts.canonical.content_hash` of the trace, the name is
    the execution id, the tenant is the capability's, the class is
    :data:`WORKFLOW_TRACE_ARTIFACT_CLASS`, and the versioned URI is
    ``ccf-artifact://{tenant}/{class}/{execution id}@{address}``. Every field
    of the store's answer is held to that as an exact string. Before this
    check the answer was handed to callers unchecked as the outcome's
    ``trace_artifact``. Measured on ``dl-378-integ`` @ ``6cd6023e``: a store
    that filed a second execution's trace faithfully and answered with the
    first execution's trace reference had the second execution's suspended,
    exception-routed and completed outcomes carry the first execution's
    reference, and one changed field was handed out the same way
    (``tests/workflow/test_trace_writer_checks_the_returned_reference.py``).

    **The reference is derived before the store's** ``put`` **is called**
    (``D-IMPL-380``, ruling 1 (a), 2026-10-10 05:34 MST), from the trace as
    the engine built it, so a store that rewrites the trace while holding it
    and answers the rewritten trace's own reference is refused here too
    (``tests/workflow/test_trace_writer_hashes_before_put.py``).

    **Raised after the store's ``put`` returns, so no outcome carrying the
    reference is returned** — at the point, and with the effect, of a store
    failure there. The engine writes the trace after it persists the
    transition the trace describes, so that transition and its audit row
    stand; at a suspension the approval request has not yet been enqueued.
    An :class:`~ccf.artifacts.protocol.ArtifactStoreError`, because the
    store's answer is what failed. The text names the fields that differ and
    no value the store answered.

    **What it does not check:** the bytes the store holds. It reads the store's
    answer, not the store; a store that answers the trace's own reference
    while holding other bytes under it is found by a reader that re-hashes
    what it fetches before using it, such as
    :func:`~ccf.replay.engine.resolve_artifact`.

    Attributes:
        fields: The names of the reference's fields that differ from the
            trace's own, in :class:`~ccf.artifacts.protocol.ArtifactRef`'s
            field order.
    """

    def __init__(self, *, fields: tuple[str, ...]) -> None:
        self.fields = fields
        super().__init__(
            f"the artifact store answered an execution trace's write with a"
            f" reference whose {', '.join(fields)} are not the trace's own; the"
            " engine hands out only the reference of the trace it wrote, so no"
            " outcome carrying it is returned (D-IMPL-378 decision 5 (a))"
        )


@runtime_checkable
class SkillNodeBinding(Protocol):
    """The seam a ``skill`` node executes through (CLAUDE.md §8.1).

    The composition root binds this onto the existing skill dispatch
    (:mod:`ccf.skills.dispatch`); the engine holds only the Protocol, so no
    dispatch target — and no transport behind one — is named here.
    """

    async def run_skill(
        self, *, tenant: str, step_name: str, ref: str
    ) -> Mapping[str, str]:
        """Invoke the skill the step's pinned ref names."""
        ...


@runtime_checkable
class AgentNodeBinding(Protocol):
    """The seam an ``agent`` node executes through (CLAUDE.md §7.3/§8.1).

    The composition root binds this onto an Agent-Factory-constructed agent
    running under a :class:`~ccf.harness.protocol.HarnessAdapterProtocol`
    adapter. Which harness executes is the binding's business — the engine
    never names one, which is what "harness-neutral at every node" means.
    """

    async def run_agent(
        self, *, tenant: str, step_name: str, ref: str
    ) -> Mapping[str, str]:
        """Invoke the agent the step's pinned definition ref names."""
        ...


@runtime_checkable
class DebtAssessmentBinding(Protocol):
    """The seam a ``D_c`` assessment travels before every agent handoff.

    INV-CH7-68 (debt cascades across multi-agent handoffs), D-IMPL-65's
    named next-phase commitment, accelerated by D-IMPL-66(b). The
    composition root binds this onto :func:`ccf.halflife.debt.assess_debt`
    against the Control Plane's resolved debt-profile artifact
    (``ccf.controlplane.artifacts``) for the decision class. The engine
    holds no profile and no threshold (CINV-01):
    it consumes only the :class:`~ccf.halflife.debt.DebtSignal` band the
    assessment already carries — the artifact's statement, never a value of
    this module's.
    """

    async def assess(
        self, *, tenant: str, step_name: str, ref: str
    ) -> DebtAssessment:
        """Assess ``D_c`` for the handoff to the agent ``ref`` names."""
        ...


class WorkflowSuspended(CCFContract):
    """A typed suspended handle — suspension is a value, not an exception.

    Returned when execution reaches a hitl-gate node (CLAUDE.md §8.1). The
    gate interaction in 07-06 goes through the injected HITL transport stub
    only; the real ApprovalGate (07-07) owns gate semantics.
    """

    tenant: str
    execution_id: str
    gate: str
    event_key: str
    trace_artifact: ArtifactRef


class WorkflowCompleted(CCFContract):
    """A terminal outcome, with the replay handoff the engine serialized.

    ``step_sequence_block`` is the canonical serialization of the execution
    trace — serialized once, here, and passed verbatim to replay dimension 5
    (07-05 keyword); ``delegation_chain`` extends dimension 4 with the
    workflow execution id followed by the agent-definition identities the
    execution invoked, in declaration order (CLAUDE.md §8.1).
    """

    tenant: str
    execution_id: str
    terminal_state: str
    step_sequence_block: str
    delegation_chain: tuple[str, ...]
    trace_artifact: ArtifactRef


class WorkflowExceptionRouted(CCFContract):
    """An exception path taken to its ref'd handler — an expected outcome.

    First-class recorded transition (D-13; CLAUDE.md §8.1): the node's
    exception ref resolved and the execution's state was handed to it. A
    node with *no* ref never produces this — absence propagates to the
    reserved ``failed`` terminal instead (D-IMPL-61 option-a).
    """

    tenant: str
    execution_id: str
    node: str
    handler_ref: str
    trace_artifact: ArtifactRef


class WorkflowResumeRefused(CCFContract):
    """A resume the engine refuses — typed value, audited ``resolved=False``.

    Unknown execution, already-terminal execution, a handle that does not
    describe the suspended execution, or a decision the artifact declares no
    transition for. All expected outcomes on the I.1 line.
    """

    tenant: str
    execution_id: str
    reason: str


WorkflowOutcome = Union[
    WorkflowSuspended,
    WorkflowCompleted,
    WorkflowExceptionRouted,
    WorkflowResumeRefused,
]


class WorkflowEngine:
    """The async-first workflow state machine (CLAUDE.md §8.1; D-IMPL-04/17).

    Everything is injected — Control Plane, artifact store, HITL transport,
    node bindings, clock — in the constructor-injection discipline of every
    Control Plane service: the engine holds no routing, no vocabulary of the
    deployment's, and no wall clock of its own.

    Args:
        control_plane: The registry the engine resolves step refs through
            and whose state seam and audit plane it writes (D-IMPL-18).
        artifact_store: Where execution traces write through at suspend and
            terminal (D-IMPL-18; content-addressed, D-IMPL-26).
        hitl_transport: The typed HITL queue hitl-gate suspensions enqueue
            into (D-IMPL-20). In 07-06 this is the gate interaction in its
            entirety; the ApprovalGate primitive (07-07) owns the rest.
        skill_binding: The ``skill``-node execution seam.
        agent_binding: The ``agent``-node execution seam (§7.3 — resolved
            through a harness adapter at the composition root).
        clock: Time source for trace and audit timestamps. Injected, never
            read from the wall.
        debt_binding: The per-agent-handoff ``D_c`` assessment seam
            (INV-CH7-68; D-IMPL-65/66(b)). Optional at construction so a
            skill-and-gate-only deployment carries no obligation it never
            exercises — but an *agent-node* handoff on an engine with no
            binding raises :class:`UnboundDebtAssessmentError`.
        audit: Optional explicitness affordance, constrained exactly as the
            grant ledger's: the Control Plane is the audit plane and there
            is one of it (INV-CH7-71), so this defaults to — and may only
            be — ``control_plane.audit_log``.

    Raises:
        SplitAuditPlaneError: ``audit`` is a log other than
            ``control_plane.audit_log``.
    """

    def __init__(
        self,
        *,
        control_plane: ControlPlaneRegistry,
        artifact_store: ArtifactStoreProtocol,
        hitl_transport: HITLTransportProtocol,
        skill_binding: SkillNodeBinding,
        agent_binding: AgentNodeBinding,
        clock: Callable[[], datetime],
        audit: AuditLog | None = None,
        debt_binding: DebtAssessmentBinding | None = None,
    ) -> None:
        if audit is not None and audit is not control_plane.audit_log:
            raise SplitAuditPlaneError(
                "the engine's audit log is not the log its Control Plane"
                " records into; workflow transitions would land in two"
                " partial journals and no complete one. Omit `audit` (it"
                " defaults to `control_plane.audit_log`) or pass that same"
                " log (INV-CH7-71; CLAUDE.md §10)"
            )
        # D-IMPL-378 (Dave: "Unsupported third-party implementations must fail
        # at construction"): a store or transport that cannot make a gate's
        # passage exactly-once is refused here, by name, before any execution
        # runs — never discovered at the first resumption.
        store = control_plane.state_store
        store_scope = getattr(store, "scope", None)
        not_conditional = (
            f"the Control Plane state store {type(store).__name__} is not a"
            " ConditionalStateStore declaring a scope of 'process' or"
            " 'shared' (get_versioned, put_if, scope); without a conditional"
            " write, two resumptions of one suspension, or two starts of one"
            " execution id, can both commit (D-IMPL-378; SEC-001)"
        )
        if (
            not all(callable(getattr(store, name, None)) for name in _CONDITIONAL_STORE_METHODS)
            or store_scope not in _SCOPES
        ):
            raise WorkflowWiringError(not_conditional)
        # D-IMPL-391 (design 1.4; D-IMPL-378 decision 2 (b): "Unsupported
        # implementations refuse construction"): a store with no well-formed
        # identity is refused by the identity rule, by name. Asked BEFORE the
        # runtime-checkable isinstance below, which would refuse a store lacking
        # `identity` with the generic message above.
        try:
            store_identity = state_store_identity_of(store)
        except StateStoreIdentityMissing as error:
            raise WorkflowWiringError(str(error)) from error
        if not isinstance(store, ConditionalStateStore):
            raise WorkflowWiringError(not_conditional)
        transport_scope = getattr(hitl_transport, "scope", None)
        if (
            not isinstance(hitl_transport, HITLTransportProtocol)
            or transport_scope not in _SCOPES
        ):
            raise WorkflowWiringError(
                f"the HITL transport {type(hitl_transport).__name__} does not"
                " offer the whole HITLTransportProtocol (close_gate, closures,"
                " retire, scope among it) with a scope of 'process' or 'shared'; without"
                " close_gate, a verdict recorded while a gate is being decided"
                " is never judged (D-IMPL-378; SEC-001)"
            )
        if store_scope == "shared" and transport_scope != "shared":
            raise WorkflowWiringError(
                "the Control Plane state store is shared between processes but"
                " the HITL transport is not: a verdict recorded through another"
                " process would never be judged here, and that process's gate"
                " closures would never be seen (D-IMPL-378; SEC-001)"
            )
        # Tuesday GO item 4 (Dave, 2026-10-11 14:51): "implement the refusal of
        # unsupported queue/store sharing". A queue that outlives or reaches
        # past its store can release one approval twice: a shared transport
        # beside a process-scoped store keeps its approvals across a restart
        # that empties the store, and one process-scoped transport serving two
        # independent stores sees the same suspension twice. Both are refused
        # here. Scope: this check sees one Python process; independent shared
        # stores behind one shared queue in different processes are excluded by
        # deployment configuration, not by this check.
        if transport_scope == "shared" and store_scope != "shared":
            raise WorkflowWiringError(
                "the HITL transport is shared between processes but the Control"
                " Plane state store is not: an approval held by the transport"
                " outlives the store that suspended it, and a restarted store"
                " would let it release the same execution again (SEC-001)"
            )
        # The security close-out's map B item 3 (SEC-001-adjacent (f),
        # D-GATE-357 (2)); Dave's GO of 2026-10-12 08:45 MST, step 1: "enforce
        # eligibility on supported approval transports". A transport that
        # judges no approver eligibility lets any HitlSubmit holder record a
        # verdict that can never authorize passage and still holds the gate as
        # a conflict for good (the conflict population is not narrowed,
        # D-IMPL-366 H2). So the engine binds its own Control Plane into the
        # transport as an eligibility judge, and refuses here, by name, a
        # transport that cannot take that binding. Checked before any binding
        # below, so a refused construction binds nothing.
        bind_eligibility = getattr(hitl_transport, "bind_approver_eligibility", None)
        if not callable(bind_eligibility):
            raise WorkflowWiringError(
                f"the HITL transport {type(hitl_transport).__name__} offers no"
                " bind_approver_eligibility, so it cannot judge approver"
                " eligibility for this engine's gates: any holder of HitlSubmit,"
                " eligible or not, could record a verdict that never authorizes"
                " passage and still holds the gate as a conflict (SEC-006;"
                " D-GATE-357 (2))"
            )
        # D-IMPL-391, Dave's ruling 2(a) of 2026-10-17: "Stores labeled
        # single-process get the graph store's lock. A second process is
        # refused by name." A store or transport declaring "process" holds an
        # exclusive SEC-013 lease from open to close (the MUST in both Protocol
        # docstrings) and offers it as writer_lease(); one that offers none is
        # refused here. The engine sees that the lease is offered, never that it
        # was taken at open. After the eligibility check and before any binding,
        # so a refused construction binds nothing. Not a Protocol member: a
        # "shared" seam is multi-process by declaration and takes no lease.
        for seam_scope, seam, what in (
            (store_scope, store, f"the Control Plane state store {type(store).__name__}"),
            (transport_scope, hitl_transport, f"the HITL transport {type(hitl_transport).__name__}"),
        ):
            if seam_scope == "process" and not callable(getattr(seam, "writer_lease", None)):
                raise WorkflowWiringError(
                    f"{what} declares scope 'process' but offers no writer_lease:"
                    " a single-process substrate holds an exclusive SEC-013 lease"
                    " from open to close, so a second process can neither submit a"
                    " verdict nor read in-flight state, and is refused by name"
                    " (SEC-001; D-IMPL-391, ruling 2(a))"
                )
        if store_scope == "process":
            _bind_transport_to_store(hitl_transport, store)
        bind_eligibility(control_plane)
        self._control_plane = control_plane
        #: Stamped on every record this engine writes (D-IMPL-391).
        self._store_identity = store_identity
        self._artifact_store = artifact_store
        self._hitl_transport = hitl_transport
        self._skill_binding = skill_binding
        self._agent_binding = agent_binding
        self._clock = clock
        self._debt_binding = debt_binding
        self._audit = control_plane.audit_log if audit is None else audit
        self._writer = AuditedStateWriter(
            store=control_plane.state_store, audit=self._audit
        )

    @property
    def artifact_store(self) -> ArtifactStoreProtocol:
        """The injected trace write-through substrate (D-IMPL-18)."""
        return self._artifact_store

    def _is_own_store(self, identity: object) -> bool:
        """Whether ``identity`` names this engine's state store (``D-IMPL-391``).

        Exactly a ``str`` and equal: a ``str`` subclass read back from a store
        could override comparison and pass for any store.
        """
        return type(identity) is str and identity == self._store_identity

    # -- the execution surfaces (factory handles only, ORCH-01) --------------

    async def execute(
        self,
        authorized: Authorized[Execute],
        workflow: Workflow,
        *,
        execution_id: str,
    ) -> WorkflowOutcome:
        """Run one execution from its start node.

        Args:
            authorized: The ``Execute`` capability the gate minted for this
                handle's definition key (D-IMPL-353 §1.2). Verified first;
                its tenant is the tenant the execution is filed under.
            workflow: A WorkflowFactory-built handle — the ONLY accepted
                input type (ORCH-01).
            execution_id: Caller-supplied execution identity; state is keyed
                ``(authorized.tenant, execution_id)`` (D-23; §1.3).

        An execution id is started once (D-23): the start is recorded
        ``running`` by a create-if-absent write before its first node runs, and
        a second start is refused. One exception is the starter's own retry
        of a start whose first node is a ``hitl-gate`` and whose engine stopped
        before suspending there: no step ran, so it is FINISHED — the
        version-fenced suspension write and its one queue event — never started
        again (``D-IMPL-378``, Dave's D2 ruling). The other is the starter's own
        retry of an execution left ``suspended`` with no approval request, its
        engine having stopped, or its artifact store failed, between the
        suspension write and the queue: the retry RESTORES that one request and
        returns the suspension, and no step runs (Dave's decision 8 (a);
        :meth:`_restore_request`).

        Raises:
            WorkflowExecutionTypeError: ``workflow`` is not a factory-built
                handle.
            CapabilityBypassError: ``authorized`` is fabricated, retargeted,
                not an ``Execute``, or minted for another definition key.
            WorkflowWiringError: a step ref resolves to nothing, or nominal
                routing is ambiguous.
            ExecutionFenced: a finished start lost its suspension write, or a
                restored request its write, to another writer.
        """
        self._require_handle(workflow)
        verify(authorized, kind=Execute, resource=workflow.definition_key)
        tenant = authorized.tenant
        key = self._key(tenant, execution_id)
        # D-IMPL-378: the execution is recorded as started BEFORE its first
        # node runs, by a create-if-absent write, so a second start of the same
        # id is refused before it runs anything — in this process or any other
        # over the same store (D-23: an execution id is started once).
        try:
            version = self._write_state(
                authorized,
                workflow,
                key,
                self._record(
                    workflow,
                    tenant=tenant,
                    execution_id=execution_id,
                    current_state=workflow.definition.start,
                    status="running",
                    trace=(),
                    started_by=authorized.principal,
                ),
                action="workflow_started",
                actor=None,
                expected_version=0,
            )
        except StateConflict:
            # D-IMPL-378, Dave's D2: the retry of a start whose commit landed
            # and whose engine stopped before suspending on its first node — a
            # gate, so no step ran — is FINISHED for its own starter, never
            # started again. Anything else under this id is a second start.
            finished = self._finish_start(
                authorized, workflow, execution_id=execution_id, key=key
            )
            if finished is not None:
                return finished
            return self._refuse(
                authorized,
                workflow,
                execution_id=execution_id,
                reason=(
                    f"execution {key!r} already exists; an execution id is"
                    " started once and thereafter resumed (D-23)"
                ),
            )
        return await self._advance(
            authorized,
            workflow,
            execution_id=execution_id,
            state=workflow.definition.start,
            trace=(),
            # SEC-006 (D-IMPL-366 G1 (a)): the REQUESTER of every gate this
            # execution reaches is the starter — the Execute capability's
            # principal — stamped once here and carried on every record.
            started_by=authorized.principal,
            version=version,
        )

    async def resume(
        self,
        authorized: Authorized[Resume],
        workflow: Workflow,
        *,
        execution_id: str,
        decision: str,
    ) -> WorkflowOutcome:
        """Continue a suspended execution under ``decision``.

        ``authorized`` is the ``Resume`` capability — its own kind, never
        ``Execute``: a deployment that granted *start a workflow* has not
        granted *carry a human decision past its gate* (D-IMPL-353 §1.5).
        Verified first against the handle's definition key; the state key
        is derived from ``authorized.tenant`` and ``execution_id``, so a
        capability for another tenant reads and writes nothing of this one.

        ``decision`` must name a transition target the artifact declares
        from the suspended node (CINV-01 — routing is the artifact's
        statement; the engine interprets, never decides).

        **One approval, one passage, however many processes resume**
        (``D-IMPL-378``; ``SEC-001``). Three mechanisms stand between one
        human approval and a second passage, and each is measured on its own:

        * **The in-process claim** (``D-IMPL-377``). Before the state record
          is read, the resumption takes a single-flight claim on the
          execution, keyed by the Control Plane state store the record lives
          in and by its state key, and shared by every engine in this process
          over that store. While it is held, a second resumption of the same
          execution is REFUSED, never queued: a typed
          :class:`WorkflowResumeRefused`, audited ``resolved=False``, which the
          HTTP door answers with the same 409 as the sequential refusal. It is
          released on every exit — completion, refusal, exception and
          cancellation — and its lock guards only the test-and-set, never an
          ``await``.
        * **The gate's closure on the authority path.** After every check has
          passed and before anything is written, the resumption asks the HITL
          transport to close the gate on exactly the verdicts it judged
          (:meth:`~ccf.hitl.transport.HITLTransportProtocol.close_gate`). A
          verdict recorded after the resumption read the verdicts makes the
          closure fail, and the resumption is refused ("present the resumption
          again"); a verdict arriving after the closure is refused at every
          door with ``hitl-gate-closed``, so it never stands beside a decision
          it can no longer reach, and the queue stops offering the gate.
        * **The conditional passage commit.** The passage — the record leaving
          the gate — is committed conditionally on the version the resumption
          read, BEFORE the step after the gate runs, and its attributed
          ``workflow_resumed`` row is appended after the commit lands
          (:meth:`~ccf.controlplane.state.AuditedStateWriter.write_if`). Of two
          resumptions in two processes, or through two state-store objects
          over one durable store, exactly one commit lands; the other is
          refused before it runs anything. The commit and the row are two
          writes, not one: an append that fails after the commit landed leaves
          the execution past its gate with no ``workflow_resumed`` row
          (``public/how-to/security-and-deployment.md`` §4.13 states what an
          operator then finds). Detecting and recovering such a passage is
          being designed (``D-IMPL-378``, decision 7 (b)), not built.

        **An approval counts only in the store that paused the run**
        (``D-IMPL-391``, design 1.4). Every record carries its state store's
        identity, so the suspension hash every request, verdict, closure and
        passage names carries the store. A record another store wrote is
        refused by name, and a run paused before the identity existed is
        refused by name until :meth:`rebind_legacy_suspension` re-pauses it.

        **An interrupted passage is never re-run** (Dave's Q4 and D2 rulings
        on ``D-IMPL-378``). A passage whose commit never landed leaves the
        record ``suspended`` with no step started, so presenting the
        resumption again re-takes the same closure (it names the passage, not
        the engine) and exactly one commit can land. A passage whose commit
        landed is ``running`` until it suspends or completes. When its state
        is a ``hitl-gate`` or a terminal state, no step lies between that
        commit and its next write, so a resumption that finds it FINISHES it —
        the version-fenced suspension or completion write and, at a gate, its
        one queue event, nothing else — provided its durable claim names it:
        the gate's closure, found by the suspension the passage left
        (:func:`~ccf_runtime.workflow.state.suspension_left_by`) and routing
        its decided verdict to that state; for an execution's start, the
        create-if-absent record. A finisher racing the original passage loses
        or wins the fenced write; the loser raises :class:`ExecutionFenced`
        and writes nothing. A ``running`` record at a step is refused, typed,
        because the step may already have had effects no engine can see, and
        an operator reconciles the execution outside the fabric.

        **A suspension whose approval request never reached the queue** (its
        suspension write landed and its engine stopped, or its artifact store
        failed, before the enqueue) has no approval to find. A resumption that
        finds none is refused, and its refusal row (``workflow_resumed``,
        ``resolved=False``) is appended first, as for any refused resumption
        (Dave's repair 1.4 (a)). It then RESTORES that one request, built as
        the suspension built it and bound to its unchanged content hash, and
        returns the suspension: nothing passes the gate, and a verdict
        recorded while the request was missing is never authority (Dave's
        decision 8 (a); :meth:`_restore_request`, which also states what a
        recovery cannot see). The row and the restore are separate writes: a
        restore that fails after the row leaves the row and no request, and
        the next resumption that finds no approval is refused and restores in
        the same way.

        Measured by ``tests/workflow/test_approval_gate_limits.py``,
        ``tests/http_api/test_approval_gate_limits_door.py``,
        ``tests/workflow/test_resume_single_flight.py``,
        ``tests/workflow/test_finish_interrupted_passage.py``,
        ``tests/workflow/test_restore_missing_approval_request.py`` and
        ``tests/workflow/test_restore_keeps_the_refused_resumption_row.py``.

        Raises:
            WorkflowExecutionTypeError: ``workflow`` is not a factory-built
                handle.
            CapabilityBypassError: ``authorized`` is fabricated, retargeted,
                not a ``Resume``, or minted for another definition key.
            ForeignStateRecordError: the state store returned a record this
                machine did not write.
            ExecutionFenced: a writer other than this passage moved the
                execution's record while the passage ran.
        """
        self._require_handle(workflow)
        verify(authorized, kind=Resume, resource=workflow.definition_key)
        tenant = authorized.tenant
        key = self._key(tenant, execution_id)
        # D-IMPL-377: taken BEFORE the record is read, so no second
        # resumption can read what this one has not yet committed over.
        claim = (id(self._control_plane.state_store), key)
        if not _claim_resumption(claim):
            return self._refuse(
                authorized,
                workflow,
                execution_id=execution_id,
                reason=(
                    f"execution {key!r} already has a resumption in flight in"
                    " this process; a suspended execution is resumed by one"
                    " request at a time, so this one is refused rather than"
                    " queued — present it again once the other has returned"
                    " (D-IMPL-377; CLAUDE.md §8.1)"
                ),
            )
        try:
            return await self._resume_claimed(
                authorized,
                workflow,
                execution_id=execution_id,
                decision=decision,
                key=key,
            )
        finally:
            _release_resumption(claim)

    def rebind_legacy_suspension(
        self,
        authorized: Authorized[Resume],
        workflow: Workflow,
        *,
        execution_id: str,
    ) -> WorkflowOutcome:
        """Re-pause a run that was paused before the state store identity existed.

        SDK-defined (``D-IMPL-391``, design 1.4; SEC-001). Dave's ruling 1(a) of
        2026-10-17: *"Pre-upgrade paused runs are refused by name, re-paused with
        an audit record, and need a fresh approval."* A ``suspended`` record with
        no ``state_store_identity`` was written by an engine that bound approvals
        to no store, so :meth:`resume` refuses it by name. This re-pauses it
        under this engine's store: one version-fenced write of the suspension,
        stamped with the store's identity (audited ``workflow_suspended``), its
        trace — the original trace plus one ``suspend`` entry, so the re-pause is
        on the record — and one new approval request under the SAME event key.

        **A fresh approval is required.** The re-paused record has a new content
        hash, and every verdict recorded before names the old one, so none of
        them authorizes anything (Dave's decision 8 (a): *"never manufacture
        approval"*).

        **The fresh request is filed first; then every pre-upgrade request is
        retired** (Dave's ruling of 2026-10-17 18:54 MST, option 3: *"File the
        new request first, then remove the old request with a new queue step
        that matches its exact fingerprint and leaves no claim."* It replaces
        his 15:25 MST wording, *"The re-pause retires the legacy request before
        enqueueing the fresh one"*, and the plain "file then remove" of 18:43:
        both were measured to leave a claim — ``D-IMPL-391``).
        ``ApprovalGate.resolve`` takes the oldest pending request under a key, so
        a pre-upgrade request left in front of the fresh one made the fresh
        approval fail until someone acted on the stale one (measured). The
        retirement is the transport's
        :meth:`~ccf.hitl.transport.HITLTransportProtocol.retire` on the legacy
        record's exact fingerprint ``(tenant, event_key, legacy hash)``: every
        pending request bound to it, wherever it sits, in one atomic step, with
        no claim recorded. Each request retired is audited
        ``workflow_request_retired``. A request for any other pause under the key
        keeps its place. This departs from DESIGN-2b §6.5, which left the request
        listed until an operator removed it.

        **The order**: the trace, the version-fenced state write, the fresh
        request, the retirement. The rebind claims nothing on the transport, a
        verdict sent straight to the queue counts only while the request for its
        own pause is waiting (the transport judges it against that request at
        :meth:`~ccf.hitl.transport.HITLTransportProtocol.submit`, and
        :meth:`resume` asks again), and a gate primitive that finds it claimed
        another pause's request gives it back and refuses, so no failure point
        and no race with a primitive lends a verdict authority. A trace or state
        write that fails moves nothing on the transport: the run stays a
        pre-upgrade pause and the rebind can be presented again. Two windows
        remain, disclosed, both about progress, never a passage: (1) a process
        that dies, or a transport that fails, after the state write and before
        the retirement leaves the pre-upgrade request in front of the fresh one
        (which the next resumption restores if it was never filed), so an
        approval through ``ApprovalGate`` is refused until an operator retires
        the stale request; a verdict sent straight to the queue naming the
        re-paused run counts once the fresh request is waiting. (2) A gate
        primitive that had claimed the pre-upgrade request before the rebind,
        and whose submission is then refused because the queue changed under it,
        gives that request back behind the fresh one; it is not retired or
        audited as retired, and a verdict on it names the old suspension and
        authorizes nothing (as on ``4569d9f0``).

        Runs under the same in-process single-flight claim as :meth:`resume`.
        Anything other than a legacy ``suspended`` record of this definition is
        refused, typed and audited, and nothing is written.

        Raises:
            WorkflowExecutionTypeError: ``workflow`` is not a factory-built
                handle.
            CapabilityBypassError: ``authorized`` is fabricated, retargeted,
                not a ``Resume``, or minted for another definition key.
            ForeignStateRecordError: the state store returned a record this
                machine did not write.
            ExecutionFenced: another writer moved the record after it was read;
                nothing on the transport moved, and the record stays a legacy
                suspension that can be rebound again.
        """
        self._require_handle(workflow)
        verify(authorized, kind=Resume, resource=workflow.definition_key)
        tenant = authorized.tenant
        key = self._key(tenant, execution_id)
        claim = (id(self._control_plane.state_store), key)
        if not _claim_resumption(claim):
            return self._refuse(
                authorized,
                workflow,
                execution_id=execution_id,
                reason=(
                    f"execution {key!r} already has a resumption in flight in"
                    " this process; present the rebind again once it has"
                    " returned (D-IMPL-377; D-IMPL-391)"
                ),
            )
        try:
            record, version = self._read_versioned(key)
            if record is None:
                return self._refuse(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    reason=f"no execution exists under {key!r}",
                )
            if not isinstance(record, WorkflowStateRecord):
                raise ForeignStateRecordError(
                    f"the Control Plane state store returned a"
                    f" {type(record).__name__} under workflow state key"
                    f" {key!r}, not a WorkflowStateRecord; the"
                    f" {WORKFLOW_STATE!r} record class is the workflow"
                    " machine's alone (D-IMPL-18/27)"
                )
            gate = record.current_state
            step = next(
                (s for s in workflow.task_definition.steps if s.name == gate), None
            )
            if (
                record.status != "suspended"
                or record.state_store_identity is not None
                or step is None
                or step.kind != "hitl-gate"
                or record.workflow_definition_uri != workflow.identity.definition_uri
                or record.workflow_definition_hash != workflow.identity.definition_hash
            ):
                return self._refuse(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    reason=(
                        f"execution {key!r} is not a run of this definition paused"
                        " at a HITL gate before the state store identity existed;"
                        " there is nothing to rebind (D-IMPL-391)"
                    ),
                )
            event_key = self._event_key(key, gate)
            legacy = content_hash(record)
            # The fallible writes FIRST, before anything on the HITL transport
            # moves (found by the independent review of the build): a trace or
            # state write that fails here leaves the run a pre-upgrade pause
            # with its request pending, and the rebind can be presented again.
            trace = record.trace + (self._entry(record.trace, gate, gate, "suspend"),)
            rebound = self._record(
                workflow,
                tenant=tenant,
                execution_id=execution_id,
                current_state=gate,
                status="suspended",
                trace=trace,
                started_by=record.started_by,
            )
            trace_artifact = self._write_trace(authorized, key, execution_id, trace)
            self._fenced_write(
                authorized, workflow, key, rebound, action="workflow_suspended", version=version
            )
            event = self._gate_event(workflow, tenant=tenant, key=key, record=rebound)
            # Dave's ruling of 2026-10-17 18:54 MST (option 3): the fresh
            # request FIRST, then the pre-upgrade requests retired by their
            # exact fingerprint, recording no claim (D-IMPL-391).
            self._hitl_transport.enqueue(event=event)
            retired = self._hitl_transport.retire(
                tenant=tenant, event_key=event_key, product_content_hash=legacy
            )
            for _ in retired:
                self._append(
                    workflow,
                    key,
                    action="workflow_request_retired",
                    resolved=True,
                    actor=None,
                )
            return WorkflowSuspended(
                tenant=tenant,
                execution_id=execution_id,
                gate=gate,
                event_key=event.event_key,
                trace_artifact=trace_artifact,
            )
        finally:
            _release_resumption(claim)

    async def _resume_claimed(
        self,
        authorized: Authorized[Resume],
        workflow: Workflow,
        *,
        execution_id: str,
        decision: str,
        key: str,
    ) -> WorkflowOutcome:
        """:meth:`resume`'s body, run only while its single-flight claim is held."""
        tenant = authorized.tenant
        record, version = self._read_versioned(key)
        if record is None:
            return self._refuse(
                authorized,
                workflow,
                execution_id=execution_id,
                reason=f"no execution exists under {key!r}",
            )
        if not isinstance(record, WorkflowStateRecord):
            raise ForeignStateRecordError(
                f"the Control Plane state store returned a"
                f" {type(record).__name__} under workflow state key"
                f" {key!r}, not a WorkflowStateRecord; the"
                f" {WORKFLOW_STATE!r} record class is the workflow"
                " machine's alone (D-IMPL-18/27)"
            )
        # D-IMPL-391 (design 1.4; SEC-001): an approval counts only in the
        # store that paused the run, so a record another store wrote is never
        # acted on here, and a run paused before the store identity existed is
        # refused until it is re-paused. Before every status branch, so no
        # legacy suspension reaches the restore below.
        if record.state_store_identity is None:
            if record.status == "suspended":
                return self._refuse(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    reason=(
                        f"execution {key!r} was suspended before the state store"
                        " identity existed, so its approval request and any verdict"
                        " on it name no store; it is refused until it is re-paused"
                        " with WorkflowEngine.rebind_legacy_suspension, after which"
                        " a fresh approval is required (SEC-001; D-IMPL-391)"
                    ),
                )
        elif not self._is_own_store(record.state_store_identity):
            return self._refuse(
                authorized,
                workflow,
                execution_id=execution_id,
                reason=(
                    f"execution {key!r} was written by a Control Plane state store"
                    " other than this engine's; an approval binds the store that"
                    " paused the run, and this engine acts only on its own store's"
                    " records (SEC-001; D-IMPL-391, D-IMPL-378 decision 2 (b))"
                ),
            )
        if record.status == "terminal":
            return self._refuse(
                authorized,
                workflow,
                execution_id=execution_id,
                reason=(
                    f"execution {key!r} is terminal; a terminal execution"
                    " never transitions again (CLAUDE.md §8.1)"
                ),
            )
        if (
            record.workflow_definition_uri != workflow.identity.definition_uri
            or record.workflow_definition_hash
            != workflow.identity.definition_hash
        ):
            return self._refuse(
                authorized,
                workflow,
                execution_id=execution_id,
                reason=(
                    f"execution {key!r} was started under"
                    f" {record.workflow_definition_uri!r} at content"
                    f" {record.workflow_definition_hash!r}, not"
                    f" {workflow.identity.definition_uri!r} at"
                    f" {workflow.identity.definition_hash!r}; an execution"
                    " continues only under the definition it was started"
                    " with, matched by content because the URI is the"
                    " artifact's statement about itself (D-IMPL-26;"
                    " SEC-001)"
                ),
            )
        if record.status == "running":
            # D-IMPL-378. A ``running`` record is a passage whose commit LANDED.
            # Dave's Q4 ruling: an interrupted passage is never retried unless
            # a durable claim identifies it and no effect can repeat. His D2
            # ruling: a passage whose current state is a gate or a terminal
            # state ran no step — what is left is this engine's own
            # version-fenced write and, at a gate, its one queue event — so it
            # is FINISHED, never re-run, under the claim that names it
            # (:meth:`_remainder`). At a step, what the step did is outside
            # anything this engine can see, so it is refused, typed, whoever
            # asks, until an operator reconciles the execution outside the
            # fabric. (A passage whose commit never landed is still
            # ``suspended`` and IS retried below: its step never started, its
            # gate's closure names it, and only one commit can land.)
            remainder = self._remainder(
                workflow, tenant=tenant, key=key, record=record
            )
            if remainder == "complete":
                return self._complete(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    terminal_state=record.current_state,
                    trace=record.trace,
                    started_by=record.started_by,
                    version=version,
                )
            if remainder == "suspend":
                return self._suspend(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    gate=record.current_state,
                    trace=record.trace,
                    started_by=record.started_by,
                    version=version,
                )
            if remainder == "unclaimed":
                return self._refuse(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    reason=(
                        f"execution {key!r} has a committed passage that has"
                        f" not finished and ran no step since, at"
                        f" {record.current_state!r}, but no durable claim on the"
                        " HITL authority path names it. An interrupted passage"
                        " is never retried without the claim that identifies"
                        " it; an operator reconciles it outside the fabric"
                        " (D-IMPL-378; SEC-001)"
                    ),
                )
            return self._refuse(
                authorized,
                workflow,
                execution_id=execution_id,
                reason=(
                    f"execution {key!r} has a committed passage that has not"
                    " finished: it is running in another process, or it was"
                    " interrupted after its step began. An interrupted passage"
                    " is never retried, because the effects its step may"
                    " already have had cannot be shown not to repeat; an"
                    " operator reconciles it outside the fabric (D-IMPL-378;"
                    " SEC-001)"
                ),
            )
        if record.status == "suspended":
            # SEC-001: a gate opens on a human action returned through the
            # HITL authority path, never on the caller's decision string.
            # The authority is bound to THIS suspension, so one approval
            # authorizes exactly the passage it was taken against
            # (CLAUDE.md §8.2 audit-by-construction).
            #
            # The check is UNCONDITIONAL on the suspended branch, and that
            # is the whole of its integrity. ``status == "suspended"`` is
            # written in exactly one place — :meth:`_suspend`, reachable
            # only from a ``hitl-gate`` step — so a suspended record IS a
            # gate suspension, as a fact the fabric recorded about itself.
            # The first version of this fix asked
            # ``_is_gate(workflow, record.current_state)`` instead, reading
            # the kind out of the CALLER'S handle. That was walk-around-able
            # and was demonstrated: ``definition_uri`` is built from the
            # artifact's own declared tenant, name and artifact_version, so
            # a second definition registered under a different key carries
            # the same URI, and one whose task calls the gate node an
            # ordinary step skipped this block entirely and completed the
            # workflow with the approval still pending and
            # ``resolved=True, actor=None`` in the audit — the exact
            # signature SEC-001 named. Never ask the caller what kind of
            # node the fabric is waiting on.
            # D-IMPL-378: ONE read of the recorded verdicts, from which the
            # authority, the conflict population and the count the gate's
            # closure is judged against are all derived.
            snapshot = self._hitl_transport.submissions(tenant=tenant)
            qualifying = self._gate_authority(
                tenant=tenant,
                key=key,
                gate=record.current_state,
                record=record,
                workflow=workflow,
                snapshot=snapshot,
            )
            if not qualifying:
                # D-IMPL-378, Dave's repair 1.4 (a) of 2026-10-09: "Preserve the
                # refused-resumption audit row, then restore the missing approval
                # request idempotently." No approval qualifies, so this
                # resumption is refused, and its refusal row is appended FIRST,
                # whatever follows. THEN, by his decision 8 (a), a suspension
                # whose approval request never reached the queue gets that one
                # request back, and nothing passes the gate. Two separate acts: a
                # restore that fails after the row leaves the row standing.
                refused = self._refuse(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    reason=(
                        f"execution {key!r} is suspended on HITL gate"
                        f" {record.current_state!r} and no approval for"
                        " this suspension has returned through the HITL"
                        " authority path; a gate is opened by a recorded"
                        " human action, never by naming a transition"
                        " (CLAUDE.md §8.2; D-IMPL-20)"
                    ),
                )
                restored = self._restore_request(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    key=key,
                    record=record,
                    version=version,
                    snapshot=snapshot,
                )
                if restored is not None:
                    return restored
                return refused
            # Selection is UNCHANGED (D-IMPL-357 A4): the head of the
            # eligible tuple is the submission the single-submission form
            # returned, because ``submissions`` is oldest-first. What changed
            # is that selection no longer runs alone — the verdicts recorded
            # against this suspension must not disagree before one of them is
            # allowed to route.
            authority = qualifying[0]
            actor: str | None = authority.principal.approver.subject_id
            recorded = self._recorded_gate_verdicts(
                tenant=tenant,
                key=key,
                gate=record.current_state,
                record=record,
                snapshot=snapshot,
            )
            if len({submission.action for submission in recorded}) > 1:
                # D-IMPL-357 A4: two distinct human verdicts on ONE
                # suspension. Ordered ahead of the declared-target and route
                # compares deliberately — with the contradicting verdict at
                # the head of the eligible tuple the route compare would
                # refuse on its own, and the record would then say a caller
                # named the wrong transition rather than that two humans
                # disagreed. Names NEITHER verdict and NEITHER target
                # (SEC-001 remedy 3); the audit event carries the rule and
                # the approver selection reached, for the reader who is
                # entitled to them.
                return self._refuse(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    reason=(
                        f"execution {key!r} carries conflicting human"
                        f" verdicts on gate {record.current_state!r}; a gate"
                        " routes on one recorded verdict and the fabric will"
                        " not choose between two, and it offers no primitive"
                        " for reconciling a conflicted suspension, so this"
                        " gate stays suspended until the disagreement is"
                        " settled operationally, outside the fabric"
                        " (D-IMPL-357 A4; CLAUDE.md §8.2)"
                    ),
                    verdict_integrity="conflicting_verdicts",
                    recorded_approver=actor,
                )
            targets = self._targets(workflow, record.current_state)
            if decision not in targets:
                return self._refuse(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    reason=(
                        f"decision {decision!r} names no declared transition"
                        f" target from {record.current_state!r}; routing is"
                        " interpreted from the artifact only (CINV-01;"
                        " CLAUDE.md §8.1)"
                    ),
                )
            route = workflow.definition.gate_routes.get(record.current_state, {}).get(
                authority.action
            )
            if route is None or decision != route:
                # D-IMPL-357 A3/A4: the artifact declares where the recorded
                # verdict goes; the caller's decision is a double-entry that
                # must agree. Names NEITHER the verdict nor the route (remedy 3:
                # the refusal never answers the caller's question for them).
                #
                # ``.get(..., {}).get(...)`` and not an index, deliberately
                # — now as disclosed defense-in-depth rather than as live
                # coverage. The shape that motivated it was a gate which is
                # both the start node and a declared terminal state: the
                # factory's completeness population subtracts terminal
                # states, so no route map was required, the A1 validator
                # forbade declaring one, and ``_advance`` suspends on the
                # step's kind before any terminal test — so such a gate
                # could hold a resume, and an unguarded index would raise
                # where a typed refusal is owed. D-IMPL-357 A2 (review round
                # 1, item 7) now REFUSES that construction outright, in
                # either position, so ``route is None`` is structurally
                # unreachable with a usable target rather than merely
                # improbable. No behavioral test can distinguish this from a
                # plain index; it stands so that no later edit of this path
                # reaches an unguarded one.
                return self._refuse(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    reason=(
                        f"decision {decision!r} does not agree with the route"
                        " the workflow definition declares for the verdict"
                        " the HITL authority path recorded on"
                        f" {record.current_state!r}; routing is interpreted"
                        " from the artifact only (CINV-01; D-IMPL-357)"
                    ),
                    verdict_integrity="route_disagreement",
                    recorded_approver=actor,
                )
            # D-IMPL-378: decide the gate ONCE, on exactly the verdicts judged
            # above, in the authority path's own atomic step. A verdict recorded
            # since the read changes the count and the decision fails; one
            # arriving after it is refused by name at every door; another
            # passage cannot take the closure.
            event_key = self._event_key(key, record.current_state)
            suspension = content_hash(record)
            observed = sum(
                1
                for submission in snapshot
                if submission.event_key == event_key
                and submission.principal.product_content_hash == suspension
            )
            # The passage is named by WHAT it decides — this suspension, this
            # authority submission, this verdict — never by who decides it. A
            # retry of a passage whose commit never landed re-presents the same
            # name, so the gate's closure (the durable claim on the authority
            # path) is re-taken idempotently, and the conditional passage
            # commit below lets exactly one attempt land (D-IMPL-378, Q4).
            passage = content_hash(
                {
                    "suspension": suspension,
                    "authority": content_hash(authority),
                    "action": authority.action,
                }
            )
            try:
                self._hitl_transport.close_gate(
                    authorized,
                    event_key=event_key,
                    product_content_hash=suspension,
                    passage=passage,
                    decided_action=authority.action,
                    decided_by=authority.principal.approver.subject_id,
                    observed_submissions=observed,
                )
            except GateAlreadyClosed:
                return self._refuse(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    reason=(
                        f"the gate {record.current_state!r} of execution"
                        f" {key!r} was already decided by another passage; one"
                        " approval authorizes one passage (D-IMPL-378; SEC-001)"
                    ),
                )
            except GateVerdictsChanged:
                return self._refuse(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    reason=(
                        f"a verdict on gate {record.current_state!r} of"
                        f" execution {key!r} was recorded while this resumption"
                        " was deciding, so nothing was decided; present the"
                        " resumption again and it judges the verdicts that now"
                        " stand (D-IMPL-378; D-IMPL-357 A4)"
                    ),
                )
            trace = record.trace + (
                self._entry(
                    record.trace, record.current_state, decision, "resume"
                ),
            )
            # D-IMPL-378: the passage — the record leaving the gate — is
            # committed conditionally on the version read, BEFORE the step
            # after the gate runs, and its attributed row is appended after the
            # commit lands: two writes, not one. Of two resumptions anywhere,
            # exactly one commit lands; a refused or failed commit appends no
            # row, and a row append that fails after the commit leaves the
            # passage without its row (decision 7 of D-IMPL-378; SP §4.13).
            try:
                version = self._write_state(
                    authorized,
                    workflow,
                    key,
                    self._record(
                        workflow,
                        tenant=tenant,
                        execution_id=execution_id,
                        current_state=decision,
                        status="running",
                        trace=trace,
                        started_by=record.started_by,
                    ),
                    action="workflow_resumed",
                    actor=actor,
                    expected_version=version,
                )
            except StateConflict:
                return self._refuse(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    reason=(
                        f"execution {key!r} moved while this resumption decided"
                        " its gate; the passage that moved it stands, and one"
                        " approval authorizes one passage (D-IMPL-378; SEC-001)"
                    ),
                )
            if decision in workflow.definition.effective_terminal_states:
                return self._complete(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    terminal_state=decision,
                    trace=trace,
                    started_by=record.started_by,
                    version=version,
                )
            return await self._advance(
                authorized,
                workflow,
                execution_id=execution_id,
                state=decision,
                trace=trace,
                started_by=record.started_by,
                version=version,
            )
        # exception-routed: the handler handed the state back — retry the
        # node it was routed from.
        #
        # SEC-001, one branch over. This path used to advance with NO
        # authority check at all and audit ``resolved=True, actor=None`` —
        # the exact signature the finding named — on the reading that an
        # exception path "crosses no gate, so it acquires no approver".
        # :meth:`_route_exception` really does enqueue nothing, but
        # :class:`~ccf.hitl.escalation.ExceptionEscalation` is the shipped
        # primitive FOR a routed state (CLAUDE.md §8.2), and a deployment
        # that composes it puts a human in the loop that the engine then
        # walked straight past.
        #
        # Applicability is the fabric's recorded fact, never the caller's:
        # an escalation is in force iff the transport HOLDS a pending
        # ``exception-escalation`` event bound to this execution's own
        # state key. The resume caller supplies nothing that decides
        # whether this runs — the key is derived from the record the state
        # store returned — and a deployment that composes no escalation
        # has no such event and is unaffected.
        if self._escalation_pending(tenant=tenant, key=key):
            return self._refuse(
                authorized,
                workflow,
                execution_id=execution_id,
                reason=(
                    f"execution {key!r} was routed to an exception path and"
                    " an escalation of this state is still open on the HITL"
                    " authority path; the designated role has not acted, and"
                    " retrying the node would spend their decision before"
                    " they made it (CLAUDE.md §8.2; D-IMPL-20)"
                ),
            )
        resolution = self._escalation_authority(
            tenant=tenant, key=key, record=record
        )
        # D-IMPL-378: the retry of the routed node is a passage too, committed
        # conditionally before the node runs, so two resumptions of one
        # exception-routed execution cannot both re-run it.
        try:
            version = self._write_state(
                authorized,
                workflow,
                key,
                self._record(
                    workflow,
                    tenant=tenant,
                    execution_id=execution_id,
                    current_state=record.current_state,
                    status="running",
                    trace=record.trace,
                    started_by=record.started_by,
                ),
                action="workflow_resumed",
                actor=(
                    None
                    if resolution is None
                    else resolution.principal.approver.subject_id
                ),
                expected_version=version,
            )
        except StateConflict:
            return self._refuse(
                authorized,
                workflow,
                execution_id=execution_id,
                reason=(
                    f"execution {key!r} moved while this resumption decided its"
                    " retry; the passage that moved it stands (D-IMPL-378;"
                    " SEC-001)"
                ),
            )
        return await self._advance(
            authorized,
            workflow,
            execution_id=execution_id,
            state=record.current_state,
            trace=record.trace,
            started_by=record.started_by,
            version=version,
        )

    # -- the machine ----------------------------------------------------------

    async def _advance(
        self,
        authorized: Authorized[Execute] | Authorized[Resume],
        workflow: Workflow,
        *,
        execution_id: str,
        state: str,
        trace: tuple[TraceEntry, ...],
        started_by: str | None,
        version: int,
    ) -> WorkflowOutcome:
        """Drive the machine from ``state`` until suspend or terminal.

        ``version`` is the state record's version this passage wrote
        (``D-IMPL-378``); the one write this drive ends in is conditional on
        it.

        ``started_by`` is the starter recorded for this execution (SEC-006;
        `D-IMPL-366` G1 (a)), threaded unchanged into every record and every
        gate event this drive produces.

        The tenant is read from the capability and nowhere else (§1.3).
        """
        tenant = authorized.tenant
        key = self._key(tenant, execution_id)
        step_kinds = {
            step.name: step for step in workflow.task_definition.steps
        }
        while True:
            step = step_kinds.get(state)
            if step is None:
                raise WorkflowWiringError(
                    f"node {state!r} names no step in the resolved task"
                    " definition; the factory's semantic layer should have"
                    " refused this handle (D-12)"
                )
            if step.kind == "hitl-gate":
                return self._suspend(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    gate=state,
                    trace=trace,
                    started_by=started_by,
                    version=version,
                )
            assert step.ref is not None  # non-gate steps carry refs by schema
            if resolve_pinned(self._control_plane, step.ref) is None:
                raise WorkflowWiringError(
                    f"step {state!r} references {step.ref!r}, which resolves"
                    " to nothing this engine's Control Plane has registered;"
                    " broken wiring raises (I.1 line; DESIGN.md §3.5)"
                )
            if step.kind == "agent":
                # INV-CH7-68 debt cascade: D_c is assessed BEFORE every
                # agent handoff, outside the try/except so a fail-closed
                # route is a deliberate transition, never an accident
                # (D-IMPL-65; D-IMPL-66(b)).
                if self._debt_binding is None:
                    raise UnboundDebtAssessmentError(
                        f"agent node {state!r} was reached on an engine"
                        " with no bound DebtAssessmentBinding; INV-CH7-68"
                        " requires D_c recomputed at every agent handoff"
                        " (D-IMPL-65). Bind `debt_binding=` at the"
                        " composition root onto ccf.halflife.debt"
                        ".assess_debt against the class's debt profile"
                    )
                assessment = await self._debt_binding.assess(
                    tenant=tenant, step_name=state, ref=step.ref
                )
                if assessment.signal is DebtSignal.FAIL_CLOSED:
                    # The fabric does not know enough to support the
                    # handoff: route the node's exception path without
                    # ever invoking the agent (fail-closed, DESIGN.md §4).
                    return self._route_exception(
                        authorized,
                        workflow,
                        execution_id=execution_id,
                        node=state,
                        trace=trace,
                        started_by=started_by,
                        version=version,
                    )
            try:
                if step.kind == "skill":
                    await self._skill_binding.run_skill(
                        tenant=tenant, step_name=state, ref=step.ref
                    )
                else:
                    await self._agent_binding.run_agent(
                        tenant=tenant, step_name=state, ref=step.ref
                    )
            except Exception:
                return self._route_exception(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    node=state,
                    trace=trace,
                    started_by=started_by,
                    version=version,
                )
            targets = self._targets(workflow, state)
            if len(targets) != 1:
                raise WorkflowWiringError(
                    f"node {state!r} declares {len(targets)} outgoing"
                    " transitions; a non-gate node's nominal path must"
                    " declare exactly one successor for the engine to"
                    " interpret (CLAUDE.md §8.1; CINV-01)"
                )
            (target,) = targets
            trace = trace + (self._entry(trace, state, target, "transition"),)
            self._append(
                workflow,
                key,
                action="workflow_transition",
                resolved=True,
                actor=None,
            )
            if target in workflow.definition.effective_terminal_states:
                return self._complete(
                    authorized,
                    workflow,
                    execution_id=execution_id,
                    terminal_state=target,
                    trace=trace,
                    started_by=started_by,
                    version=version,
                )
            state = target

    def _suspend(
        self,
        authorized: Authorized[Execute] | Authorized[Resume],
        workflow: Workflow,
        *,
        execution_id: str,
        gate: str,
        trace: tuple[TraceEntry, ...],
        started_by: str | None,
        version: int,
    ) -> WorkflowSuspended:
        """Suspend on a hitl-gate: persist, enqueue, return a typed handle.

        The record, the state key, the trace artifact and the pending HITL
        event are all filed under ``authorized.tenant`` (§1.3). A suspension
        whose request never reached the queue, after its persist landed, gets
        that request back from :meth:`_restore_request`.

        **The HITL stall, disclosed** (``D-IMPL-380``, fifth round, ruling 1
        (a); Dave, 2026-10-10 12:57 MST: *"Put that sentence, in the same
        words, on ``_suspend`` and ``_restore_request``."*). A HITL transport is
        handed the engine's own pending event, which is not copied. A transport
        that alters it can change the ``event_key`` the caller is told in
        ``WorkflowSuspended``, and, because resume looks for the key it
        recomputes (``_event_key``) among the events the transport holds, a
        transport that alters the key can keep the gate from ever opening, and
        each recovery queues another request. Nothing is wrongly approved: the
        approval binding, the hash of the suspension record as built, does not
        change.
        """
        tenant = authorized.tenant
        key = self._key(tenant, execution_id)
        trace = trace + (self._entry(trace, gate, gate, "suspend"),)
        record = self._record(
            workflow,
            tenant=tenant,
            execution_id=execution_id,
            current_state=gate,
            status="suspended",
            trace=trace,
            started_by=started_by,
        )
        self._fenced_write(
            authorized, workflow, key, record, action="workflow_suspended", version=version
        )
        trace_artifact = self._write_trace(authorized, key, execution_id, trace)
        event = self._gate_event(workflow, tenant=tenant, key=key, record=record)
        self._hitl_transport.enqueue(event=event)
        return WorkflowSuspended(
            tenant=tenant,
            execution_id=execution_id,
            gate=gate,
            event_key=event.event_key,
            trace_artifact=trace_artifact,
        )

    def _gate_event(
        self,
        workflow: Workflow,
        *,
        tenant: str,
        key: str,
        record: WorkflowStateRecord,
    ) -> PendingHitlEvent:
        """The one approval request a suspension files on the HITL transport.

        Built here for :meth:`_suspend` and :meth:`_restore_request` alike, from
        the suspension record and the definition alone, so a restored request is
        the request the suspension filed, whoever restores it (``D-IMPL-378``;
        Dave's decision 8 (a): *"Preserve the original authorization and
        suspension identity"*). The gate's event key and class, the execution's
        state key, the record's own content hash, the gate's pinned approval
        policy, and the starter as requester (SEC-006; ``D-IMPL-366`` G1 (a)).
        """
        gate = record.current_state
        return PendingHitlEvent(
            event_key=self._event_key(key, gate),
            event_class=GATE_EVENT_CLASS,
            tenant=tenant,
            workflow_state_ref=key,
            product_content_hash=content_hash(record),
            policy_ref=workflow.definition.gate_policies.get(gate),
            requested_by=record.started_by,
        )

    def _route_exception(
        self,
        authorized: Authorized[Execute] | Authorized[Resume],
        workflow: Workflow,
        *,
        execution_id: str,
        node: str,
        trace: tuple[TraceEntry, ...],
        started_by: str | None,
        version: int,
    ) -> WorkflowOutcome:
        """Take ``node``'s exception path (D-13; D-IMPL-61 option-a)."""
        tenant = authorized.tenant
        key = self._key(tenant, execution_id)
        handler_ref = workflow.definition.exception_refs.get(node)
        if handler_ref is not None:
            trace = trace + (
                self._entry(trace, node, handler_ref, "exception"),
            )
            record = self._record(
                workflow,
                tenant=tenant,
                execution_id=execution_id,
                current_state=node,
                status="exception-routed",
                trace=trace,
                started_by=started_by,
            )
            self._fenced_write(
                authorized, workflow, key, record, action="workflow_exception", version=version
            )
            trace_artifact = self._write_trace(
                authorized, key, execution_id, trace
            )
            return WorkflowExceptionRouted(
                tenant=tenant,
                execution_id=execution_id,
                node=node,
                handler_ref=handler_ref,
                trace_artifact=trace_artifact,
            )
        # Absent ref: a defined, audited transition to the reserved terminal
        # (D-IMPL-61) — a positive recorded event, never a fall-through.
        trace = trace + (
            self._entry(trace, node, WORKFLOW_FAILED_STATE, "exception"),
        )
        self._append(
            workflow,
            key,
            action="workflow_exception",
            resolved=True,
            actor=None,
        )
        return self._complete(
            authorized,
            workflow,
            execution_id=execution_id,
            terminal_state=WORKFLOW_FAILED_STATE,
            trace=trace,
            started_by=started_by,
            version=version,
        )

    def _complete(
        self,
        authorized: Authorized[Execute] | Authorized[Resume],
        workflow: Workflow,
        *,
        execution_id: str,
        terminal_state: str,
        trace: tuple[TraceEntry, ...],
        started_by: str | None,
        version: int,
    ) -> WorkflowCompleted:
        """Reach a terminal condition: persist, write through, hand to replay."""
        tenant = authorized.tenant
        key = self._key(tenant, execution_id)
        record = self._record(
            workflow,
            tenant=tenant,
            execution_id=execution_id,
            current_state=terminal_state,
            status="terminal",
            trace=trace,
            started_by=started_by,
        )
        self._fenced_write(
            authorized, workflow, key, record, action="workflow_completed", version=version
        )
        trace_artifact = self._write_trace(authorized, key, execution_id, trace)
        visited = {entry.source for entry in trace} | {
            entry.target for entry in trace
        }
        delegation_chain = (f"workflow:{key}",) + tuple(
            step.ref
            for step in workflow.task_definition.steps
            if step.kind == "agent"
            and step.name in visited
            and step.ref is not None
        )
        return WorkflowCompleted(
            tenant=tenant,
            execution_id=execution_id,
            terminal_state=terminal_state,
            step_sequence_block=canonical_bytes(trace).decode("utf-8"),
            delegation_chain=delegation_chain,
            trace_artifact=trace_artifact,
        )

    # -- helpers --------------------------------------------------------------

    @staticmethod
    def _require_handle(workflow: object) -> None:
        if not isinstance(workflow, Workflow):
            raise WorkflowExecutionTypeError(
                f"the engine executes WorkflowFactory-built handles only;"
                f" got {type(workflow).__name__}. Construct through"
                " ccf.workflow.factory.WorkflowFactory — ORCH-01's 'via the"
                " Task Factory' holds at the execution boundary (CINV-01c)"
            )

    @staticmethod
    def _key(tenant: str, execution_id: str) -> str:
        """The state key an execution lives under — the seam's own derivation.

        :func:`~ccf.controlplane.state.state_key` rather than a local
        f-string (D-IMPL-353 §1.3): the state store derives the key it writes
        under from the capability's tenant and the record id, and the engine's
        reads must derive the same key the same way or a suspended execution
        could be written under one key and looked for under another. Every
        caller passes ``authorized.tenant``; the injectivity rules (a tenant
        may not carry the separator) are the seam's, stated once.
        """
        return state_key(tenant=tenant, record_id=execution_id)

    @staticmethod
    def _event_key(key: str, gate: str) -> str:
        """The pending-event key a gate suspension enqueues under."""
        return f"{key}/{gate}"

    def _gate_authority(
        self,
        *,
        tenant: str,
        key: str,
        gate: str,
        record: WorkflowStateRecord,
        workflow: Workflow,
        snapshot: tuple[HitlActionSubmission, ...],
    ) -> tuple[HitlActionSubmission, ...]:
        """Every recorded human verdict ELIGIBLE to authorize passage past ``gate``.

        SEC-001. Reads the HITL transport's authority path — the only
        surface a human action returns through (D-IMPL-20) — and returns
        the submissions that may authorize THIS suspension, oldest first, or
        an empty tuple.

        **Eligibility only; it decides nothing about agreement**
        (D-IMPL-357 A4). The caller selects the authority from the head of
        this tuple, exactly as the single-submission form selected it, and
        asks :meth:`_recorded_gate_verdicts` — a deliberately BROADER
        population — whether the verdicts recorded against this suspension
        disagree. The two questions cannot share one predicate: the rules
        below are what make a verdict *routable*, and a verdict that is not
        routable can still be a recorded human decision that contradicts
        the one that is. Reading agreement off this tuple would leave the
        transport's stamp race wide open, because the racing officer's
        rejection is recorded unstamped and fails the unstamped leg.

        Three conditions, all necessary:

        * the submission names this gate's pending event. **A backstop,
          not the load-bearing check** — two suspensions differ in at
          least ``execution_id`` or ``current_state``, so the hash below
          already separates them and severing this line reddens nothing.
          Kept because it is what a reader expects to see, and stated so
          nobody mistakes it for the guard that is doing the work;
        * **(load-bearing)** its principal echoes ``content_hash(record)``
          — the suspension's
          own identity, which is what the pending event bound at suspend
          time and what :class:`~ccf.hitl.approval_gate.ApprovalGate`
          already makes the approver attest to (T-07-39). A suspension's
          trace is unique to it, so an approval cannot be replayed onto
          another execution, another tenant, or a later suspension of the
          same gate. This is what refuses a submission made through the
          submit-only action door (D-IMPL-62), which compares no hashes of
          its own;
        * the action is an approval-gate verdict. Both verdicts authorize
          the engine to leave the gate — a rejection routes to whichever
          target the artifact declares for it, which is why the check is
          ``in GATE_ACTIONS`` and not ``== GATE_APPROVE``;
        * **(added by the 2026-09-24 follow-up read)** an approval gate is
          what the action answered. A submission carries the same two
          verdicts as
          :data:`~ccf.hitl.escalation.ESCALATION_ACTIONS`, so before this
          the three conditions above could all be met by a human action
          taken against a *different* primitive's event that happened to
          name this event key — a reachable composition, because handing a
          stuck gate to
          :class:`~ccf.hitl.escalation.ExceptionEscalation` is what that
          primitive is for, and the duty officer who takes the hand-off has
          not approved the credit.

        **Why the answered-class test has two legs, and what decides which
        one runs.** Not the caller: the submission's own
        ``answered_event_class`` does, and the transport — not the
        submitter — writes it (see
        :class:`~ccf.hitl.transport.HitlActionSubmission`).

        * **Stamped.** Some primitive claimed an event through
          :meth:`~ccf.hitl.transport.HITLTransportProtocol.remove` before
          submitting. The class it claimed must be
          :data:`~ccf.hitl.approval_gate.GATE_EVENT_CLASS` and the claimed
          event must have been bound to this execution's state key. This is
          the leg that refuses the escalation-answered action above.
          :meth:`~ccf.hitl.approval_gate.ApprovalGate.resolve` consumes the
          pending event, so by resume time this is the ONLY leg a
          gate-resolved approval can take — which is why the class cannot
          simply be read off the pending queue.
        * **Unstamped.** Nothing was claimed: the shape the submit-only
          action door produces (D-IMPL-62 — it records and resolves
          nothing). Then the join is to the gate's own event, which is
          still pending precisely because nothing resolved it, and its
          class must be ``GATE_EVENT_CLASS``. Both terms are the engine's
          own: the event key is minted by :meth:`_event_key` and the class
          was written by :meth:`_suspend`.

        **The residual that leaves, stated so it is not read as closed.**
        The unstamped leg accepts an action that the ApprovalGate primitive
        never resolved — so the gate's TOCTOU guard and its signed-binding
        enforcement did not run, only the transport's own D-16 leg did.
        That path is not anonymous (the door derives the principal from a
        verified token grant, D-IMPL-67, and the hash binding above still
        holds), but it is weaker than a gate resolution, and closing it
        means giving the door a *resolve* route rather than a submit-only
        one — a change to D-IMPL-62's ruled contract and to
        ``runtime/ccf_runtime/http_api/routes/hitl.py``, not something this
        module may decide alone.

        **The verdict→target binding, and exactly how far it closes.**
        Declared on the artifact as ``gate_routes`` (D-IMPL-357 A1) and
        enforced in :meth:`resume` after the declared-target check, pinned
        by ``tests/workflow/test_engine.py::
        test_a_recorded_rejection_cannot_be_routed_down_the_approving_branch``.
        Given one recorded human action, the caller's decision must agree
        with the target the artifact declares for the verdict that action
        carries.

        **No verdict recorded on this suspension is outvoted by a passage**
        (``D-IMPL-378``). A verdict recorded before the resumption reads the
        verdicts is in the population judged here and refuses the resumption if
        it disagrees (``D-IMPL-357`` A3 + A4); one recorded after that read and
        before the decision makes the gate's closure fail, and the resumption
        is refused; one arriving after the closure is refused at the door
        (``hitl-gate-closed``). Routing is the compare in :meth:`resume`;
        selection integrity is the conflict refusal over
        :meth:`_recorded_gate_verdicts`; timing integrity is the closure. The
        paths A3's review measured are shut, and each was measured again going
        red:

        * **Two distinct verdicts on one suspension** no longer resolve to
          the oldest and route on it. They refuse, in either arrival order,
          and the refusal is ordered ahead of the route compare so the
          record says two humans disagreed rather than that a caller named
          the wrong transition. Pinned in process and through the served
          doors.
        * **The transport's stamp race** no longer decides a verdict. Its
          recorded end state — one stamped verdict and one unstamped
          opposite verdict on the same suspension — is precisely what
          :meth:`_recorded_gate_verdicts` refuses, which is why that
          population is deliberately unfiltered by eligibility.

        **What remains OPEN, stated here because this docstring is the
        residual ledger a close panel, an adopter and the next maintainer
        read.**

        * **(1) The stamp race itself is still there, in the transport.**
          A claim is keyed ``(tenant, event_key)`` and consumed by whichever
          submission for that pair, naming the claimed request's pause
          (``D-IMPL-391``), arrives first, so an attacker holding
          submit authority can still cause an officer's verdict to be
          recorded unstamped. What changed is the consequence: the pair now
          REFUSES and demands human reconciliation instead of routing on
          the attacker's verdict. So the race has become an availability
          problem — anyone with submit authority for the event can park a
          contradicting verdict and hold the gate until a human
          reconciles — rather than an integrity one. Closing it means
          ``remove`` minting an opaque claim token that ``submit``
          requires, a :class:`~ccf.hitl.transport.HITLTransportProtocol`
          signature change that belongs with the D-IMPL-62 door ruling.
        * **(2) A conflicted gate stays suspended for good** (``D-GATE-357``
          (2)). The fabric offers no primitive that reopens it; a human settles
          the disagreement outside the fabric.
        * **(3) An interrupted passage at a step stays ``running`` for good.**
          It is never retried (Dave's Q4 ruling on ``D-IMPL-378``), and the
          fabric offers no primitive that reconciles it; an operator reads the
          gate's closure
          (:meth:`~ccf.hitl.transport.HITLTransportProtocol.closures`) and the
          audit row, and reconciles outside the fabric. One at a gate or a
          terminal state ran no step, and is finished under its durable claim
          (Dave's D2 ruling; :meth:`resume`).
        * **(4) The guarantees are the store's and the transport's.** They
          hold over a :class:`~ccf.controlplane.state.ConditionalStateStore`
          and a transport whose ``close_gate`` and ``submit`` are atomic with
          respect to each other, as the reference implementations are. The
          engine refuses at construction an implementation that offers neither
          the methods nor a declared scope; it cannot see whether a
          third-party implementation keeps the atomicity it declares —
          ``tests/conformance/test_gate_closure_and_conditional_write.py`` is
          the suite a deployment runs against its own.

        **What the closure replaced, carried so it is not re-derived.**
        Before ``D-IMPL-378`` the read-decide-commit was atomic only against
        other resumptions in one process. Measured on 2026-10-07: two
        resumptions through two state-store objects over one durable store
        both passed the gate on one approval; a rejection recorded right
        after the resumption's last read of the verdicts was outvoted
        (15 of 15 forced-timing runs), and so was one recorded through the
        served action door while the step after the gate ran. A second read
        before the commit was rejected as a fix: it narrows the window and
        invites a reader to think the class is handled, and when the step
        after the gate has already run there is nothing left to refuse.

        The bound on the claim above is deliberate, because this project
        has already paid once for stating it wider: an earlier fix on this
        same vulnerability was reported complete, and the close panel on
        the follow-on work reproduced the CRITICAL finding with that fix
        in place.

        Note the direction of trust: the engine *reads* the authority path
        and never writes a verdict to it. The one thing it records there is
        the gate's closure (``D-IMPL-378``), which decides no verdict: it
        freezes the verdicts the engine judged. Resolution stays the gate
        primitive's act (CLAUDE.md §8.2).
        """
        event_key = self._event_key(key, gate)
        suspension = content_hash(record)
        # D-IMPL-391 (Dave, 2026-10-17 18:54 MST): "Count an approval sent
        # straight to the queue only while the request for this exact pause is
        # waiting." The request for THIS suspension, not any request under the
        # key (D-IMPL-366 H2, narrowed); the transport judged the same at submit.
        gate_still_pending = any(
            event.event_key == event_key
            and event.event_class == GATE_EVENT_CLASS
            and event.product_content_hash == suspension
            for event in self._hitl_transport.pending(tenant=tenant)
        )
        # SEC-006 (D-IMPL-366 §4 (4)): the engine site is the BACKSTOP for
        # every path — eligibility judged inside the per-submission predicate,
        # before the conflict count in `resume`, against the definition's
        # pinned gate policy and the RECORD's starter (the engine holds no
        # event here). The engine's Control Plane is always bound, so a gate
        # with no policy, an unresolvable or wrong-class policy, or a record
        # with no starter (an in-flight pre-change suspension, G5 (a)) admits
        # nothing: fail-closed by ruling.
        policy_ref = workflow.definition.gate_policies.get(gate)

        def eligible(submission: HitlActionSubmission) -> bool:
            try:
                check_approver_eligibility(
                    policy_ref=policy_ref,
                    requested_by=record.started_by,
                    subject_id=submission.principal.approver.subject_id,
                    control_plane=self._control_plane,
                )
            except ApproverNotEligible:
                return False
            return True

        return tuple(
            submission
            for submission in snapshot
            if submission.event_key == event_key
            and submission.principal.product_content_hash == suspension
            and submission.action in GATE_ACTIONS
            # D-IMPL-366 H2 (RULED): a submission recorded while NO event was
            # under its key is never authority — whatever is pending now.
            and submission.event_state_at_submit != "missing"
            and (
                submission.answered_event_class == GATE_EVENT_CLASS
                and submission.answered_workflow_state_ref == key
                if submission.answered_event_class is not None
                # The unstamped leg: a door submission recorded against a
                # PENDING event — the request for this suspension, judged at
                # submit and still waiting now (D-IMPL-391) — counts, and so
                # does a pre-change record (None) — the fixture rule.
                else submission.event_state_at_submit in (None, "pending")
                and gate_still_pending
            )
            and eligible(submission)
        )

    def _recorded_gate_verdicts(
        self,
        *,
        tenant: str,
        key: str,
        gate: str,
        record: WorkflowStateRecord,
        snapshot: tuple[HitlActionSubmission, ...],
    ) -> tuple[HitlActionSubmission, ...]:
        """Every gate verdict RECORDED against this suspension, oldest first.

        D-IMPL-357 A4, and the population is broader than
        :meth:`_gate_authority`'s on purpose: every submission naming this
        gate's pending event, bound to this suspension's own content hash,
        carrying a :data:`~ccf.hitl.approval_gate.GATE_ACTIONS` verdict —
        **stamped or not, eligible to be the authority or not.** The caller
        refuses the resumption when the distinct verdicts here number more
        than one.

        **Why eligibility is deliberately not applied.** Round 1 of A4's
        review measured the sequence that walks straight through a
        predicate that does apply it. A credit officer resolves the gate
        ``reject``, which REMOVES the pending claim and then submits; an
        attacker holding submit authority for the same event lands
        ``approve`` in that window; the transport stamps whichever submit
        arrives first (documented at
        :meth:`~ccf.hitl.transport.HITLTransportProtocol.submit`), so the
        attacker's verdict takes the stamp and the officer's is recorded
        UNSTAMPED. The gate is no longer pending, so the officer's
        rejection fails the unstamped leg and is not eligible at all — and
        an eligibility-filtered verdict set then has exactly one member,
        detects no conflict, and the routing compare faithfully agrees with
        the attacker. Raced for real: **823 of 3000 executions succeeded
        with four attacker threads.** Filtering nothing here is what closes
        it, without weakening what selection requires of an authority.

        **The suspension hash stays in the predicate**, and it is what
        keeps this from over-refusing: a verdict recorded against an
        EARLIER suspension of the same gate — a loop, an exception route
        and a re-suspension — carries that suspension's content hash and is
        correctly invisible here. Dropping it would let a resolved
        disagreement poison every later suspension of the same node
        forever.

        **The event-key term is a BACKSTOP, not the load-bearing check** —
        the same disclosure :meth:`_gate_authority` carries for its own copy
        of this term, restated here so this predicate's reader does not have
        to infer it. Two suspensions differ in at least ``execution_id`` or
        ``current_state``, so the suspension hash above already separates
        them, and dropping this line reddens nothing across
        ``tests/workflow`` and ``tests/http_api/test_routes.py``. Measured,
        not assumed. Kept because it is what a reader expects to see, and
        stated so nobody mistakes it for the guard doing the work.

        **The verdict-vocabulary term, by contrast, IS load-bearing and is
        pinned** — by ``tests/workflow/test_engine.py::
        test_an_annotation_and_an_override_beside_an_approval_still_route``.
        :data:`~ccf.hitl.transport.HITL_ACTIONS` carries ``override`` and
        ``annotate`` alongside the two gate verdicts, so without ``action in
        GATE_ACTIONS`` either of those bound to this suspension would count
        as a distinct verdict and wedge the gate. That failure direction is
        over-refusal rather than bypass, which is exactly why it could sit
        here unpinned — and it is still a denial of service on approvals,
        the mirror image of the vulnerability this task closes.

        **What it costs, stated rather than assumed.** Agreeing submissions
        carry one distinct verdict, so nothing that previously proceeded on
        agreement now refuses — a second approver recording the same
        verdict (D-23 quorum) is unaffected. The one real behavior change
        is the intended one: where a verdict was recorded that never became
        the authority and the opposite verdict was then recorded, the
        resumption previously proceeded on whichever one selection reached
        and now refuses. A bank's answer to *two humans recorded opposite
        verdicts on one decision* is to stop and require reconciliation,
        not to resolve silently in favor of whichever one won a race.

        A verdict recorded against a DIFFERENT primitive's event that
        happens to name this event key and this suspension hash — the
        escalation composition :meth:`_gate_authority` describes — counts
        here even though it can never be the authority. That is the same
        ruling applied consistently: it is a recorded human decision about
        this suspension, and if it contradicts the routable one the fabric
        does not get to pick.
        """
        event_key = self._event_key(key, gate)
        suspension = content_hash(record)
        return tuple(
            submission
            for submission in snapshot
            if submission.event_key == event_key
            and submission.principal.product_content_hash == suspension
            and submission.action in GATE_ACTIONS
        )

    def _escalation_pending(self, *, tenant: str, key: str) -> bool:
        """Whether an unanswered escalation of ``key`` is on the transport.

        SEC-001 Tier 0, the exception-routed branch's applicability test
        (CLAUDE.md §8.2; D-IMPL-20). True iff the HITL transport HOLDS a
        pending :data:`~ccf.hitl.escalation.ESCALATION_EVENT_CLASS` event
        whose ``workflow_state_ref`` is this execution's own state key.

        Every term is a fact the fabric recorded about itself. ``key`` is
        derived from the tenant the artifact declares and the execution id
        the state store answered under; the event class and the state ref
        were written by
        :meth:`~ccf.hitl.escalation.ExceptionEscalation.escalate` at
        hand-off. The resume caller declares, sends and omits nothing that
        reaches this test — which is the lesson the first SEC-001 fix
        taught at cost (a guard whose applicability the caller decides is
        not a guard).

        Pending is the right state to read because resolution *consumes*
        the event: every shipped primitive claims through
        :meth:`~ccf.hitl.transport.HITLTransportProtocol.remove` before it
        submits, so an event that is still pending is an unanswered one. A
        deployment that composes no escalation holds no such event and is
        unaffected — pinned by ``test_an_exception_routed_resume_without_
        escalation_is_unaffected``.

        **The escalation leg's OWN remaining gap — no longer the gate's**
        (D-IMPL-357 A4). The gate's verdict→target residual is closed to
        the bound :meth:`_gate_authority`'s ledger states — read it there
        rather than inferring an unconditional close from this sentence:
        ``gate_routes`` declares where each verdict goes (A1), the route
        compare enforces it (A3), and conflicting verdicts recorded before
        the resumption's own read refuse (A4). None of that reaches here,
        because
        ``gate_routes`` is keyed by the two
        :data:`~ccf.hitl.approval_gate.GATE_ACTIONS` verdicts on a gate
        NODE, and an escalation is a hold on an exception-routed state
        rather than a gate. So for this leg it remains true that either
        :data:`~ccf.hitl.escalation.ESCALATION_ACTIONS` verdict releases
        the hold: a declined hand-off is still a recorded human decision
        about this state, and nothing a
        :class:`~ccf.workflow.definitions.WorkflowDefinition` carries maps
        an escalation verdict to a route. What the SEC-001 work did change
        here is that some human must have acted on this routing at all, and
        the audit names them.

        This is stated rather than deleted because it is a distinct open
        question with a distinct answer: declaring escalation routes would
        be a new generation of the workflow contract (the shape A1 took for
        gates), and whether a declined hand-off should route somewhere
        other than a retry of the same node is a ruling nobody has made.
        """
        return any(
            event.event_class == ESCALATION_EVENT_CLASS
            and event.workflow_state_ref == key
            for event in self._hitl_transport.pending(tenant=tenant)
        )

    def _escalation_authority(
        self, *, tenant: str, key: str, record: WorkflowStateRecord
    ) -> HitlActionSubmission | None:
        """The recorded human action that released this routed state.

        SEC-001 Tier 0. The attribution half of the exception-routed
        branch: :meth:`_escalation_pending` decides whether the resume may
        proceed, this decides whose name the audit carries. ``None`` is the
        honest answer for a deployment that composed no escalation — the
        audit then states positively that no human acted, which
        :meth:`_append`'s defaultless ``actor`` keyword forces every call
        site to do.

        Three conditions, all read off recorded facts:

        * the transport stamped the submission as answering an
          ``exception-escalation`` — its own observation of which event was
          claimed, overwritten on every submit and therefore not something
          a submitter can assert about itself (the submit-only action door,
          D-IMPL-62, claims nothing and is stamped ``None``);
        * the claimed event was bound to THIS execution's state key, which
          the escalating deployment stated at hand-off and the engine
          re-derives here — so one execution's escalation never attributes
          another's resume;
        * **(binding to the specific routing)** the resolver's principal
          echoes ``content_hash(record)``, the routed state's own identity,
          exactly as :meth:`_gate_authority` binds an approval to its
          suspension. A later routing of the same execution has a different
          trace and therefore a different hash.

        **Known residual, stated rather than implied.** The third condition
        holds only when the deployment hands
        :meth:`~ccf.hitl.escalation.ExceptionEscalation.escalate` the
        content hash of the routed :class:`WorkflowStateRecord` — the
        composition its own ``product_content_hash`` docstring describes
        ("the content hash of the state the human will review") and the one
        ``tests/workflow/test_exception_paths.py`` exercises. A deployment
        that binds some other hash still cannot resume past an OPEN
        escalation — that is :meth:`_escalation_pending`, which compares no
        hashes — but its resolver will not be named in the audit. Losing an
        attribution is not the same defect as losing the control, and the
        alternative (naming whoever last answered any escalation about this
        execution) would put a human's name against a decision that may not
        be theirs.
        """
        routing = content_hash(record)
        return next(
            (
                submission
                for submission in self._hitl_transport.submissions(
                    tenant=tenant
                )
                if submission.answered_event_class == ESCALATION_EVENT_CLASS
                and submission.answered_workflow_state_ref == key
                and submission.principal.product_content_hash == routing
            ),
            None,
        )

    @staticmethod
    def _targets(workflow: Workflow, source: str) -> frozenset[str]:
        return frozenset(
            transition.target
            for transition in workflow.definition.transitions
            if transition.source == source
        )

    def _entry(
        self,
        trace: tuple[TraceEntry, ...],
        source: str,
        target: str,
        kind: str,
    ) -> TraceEntry:
        return TraceEntry(
            sequence=len(trace),
            source=source,
            target=target,
            kind=kind,
            occurred_at=self._clock(),
        )

    def _record(
        self,
        workflow: Workflow,
        *,
        tenant: str,
        execution_id: str,
        current_state: str,
        status: str,
        trace: tuple[TraceEntry, ...],
        started_by: str | None,
    ) -> WorkflowStateRecord:
        return WorkflowStateRecord(
            tenant=tenant,
            execution_id=execution_id,
            current_state=current_state,
            status=status,
            trace=trace,
            workflow_definition_uri=workflow.identity.definition_uri,
            workflow_definition_hash=workflow.identity.definition_hash,
            started_by=started_by,
            state_store_identity=self._store_identity,
        )

    def _remainder(
        self,
        workflow: Workflow,
        *,
        tenant: str,
        key: str,
        record: WorkflowStateRecord,
    ) -> str:
        """What is left of a ``running`` record's passage, and whether this engine may finish it.

        ``D-IMPL-378``; Dave's D2 ruling of 2026-10-07 under his Q4 condition.
        Returns:

        * ``"step"`` — the record's state is a step, which may have run: never
          retried (Q4 (b));
        * ``"complete"`` or ``"suspend"`` — the state is a terminal state or a
          ``hitl-gate``, so no step lies between the commit and the passage's
          next write, and the passage's durable claim names it;
        * ``"unclaimed"`` — no step can have run, but no durable claim names
          the passage.

        The durable claim never names an engine. For an execution's start —
        an empty trace at the start node — it is the create-if-absent record
        itself. For a passage past a gate it is that gate's closure on the
        HITL authority path, found by the content hash of the suspension the
        passage left (:func:`~ccf_runtime.workflow.state.suspension_left_by`),
        and its decided verdict must route to the record's state.
        """
        at = record.current_state
        if at in workflow.definition.effective_terminal_states:
            remainder = "complete"
        else:
            step = next(
                (s for s in workflow.task_definition.steps if s.name == at), None
            )
            if step is None or step.kind != "hitl-gate":
                return "step"
            remainder = "suspend"
        if not record.trace:
            if remainder == "suspend" and at == workflow.definition.start:
                return remainder
            return "unclaimed"
        left = suspension_left_by(record)
        if left is None:
            return "unclaimed"
        event_key = self._event_key(key, left.current_state)
        suspension = content_hash(left)
        claim = next(
            (
                closure
                for closure in self._hitl_transport.closures(tenant=tenant)
                if closure.event_key == event_key
                and closure.product_content_hash == suspension
            ),
            None,
        )
        if claim is None:
            return "unclaimed"
        routes = workflow.definition.gate_routes.get(left.current_state, {})
        if routes.get(claim.decided_action) != at:
            return "unclaimed"
        return remainder

    def _finish_start(
        self,
        authorized: Authorized[Execute],
        workflow: Workflow,
        *,
        execution_id: str,
        key: str,
    ) -> WorkflowSuspended | None:
        """Finish, for its own starter, a start that committed and never suspended on its first node.

        ``D-IMPL-378``; Dave's D2 ruling. The start's durable claim is the
        create-if-absent record: ``running`` at the start node with an empty
        trace, under this definition, stamped with this starter. When the start
        node is a ``hitl-gate`` no step ran, and what is left is the version-fenced
        suspension write and its one queue event. ``None`` for anything else,
        which the caller refuses as a second start.

        Extended by Dave's decision 8 (a) of 2026-10-09: when the record, under
        this definition and stamped with this starter, is ``suspended`` and its
        approval request never reached the queue, the starter's retry restores
        that request (:meth:`_restore_request`).

        Raises:
            ExecutionFenced: another finisher, or the original start, wrote the
                suspension first; or another recovery restored the request
                first.
        """
        record, version = self._read_versioned(key)
        if (
            not isinstance(record, WorkflowStateRecord)
            or record.started_by != authorized.principal
            or record.workflow_definition_uri != workflow.identity.definition_uri
            or record.workflow_definition_hash
            != workflow.identity.definition_hash
        ):
            return None
        # D-IMPL-391 (DESIGN-2b §6.3): only a start this store wrote, or one
        # written before the store identity existed (which has no approval to
        # cross-bind), is finished. A legacy suspension is re-paused by
        # rebind_legacy_suspension, never restored under its legacy hash.
        if record.state_store_identity is not None and not self._is_own_store(
            record.state_store_identity
        ):
            return None
        if record.status == "suspended":
            if record.state_store_identity is None:
                return None
            return self._restore_request(
                authorized,
                workflow,
                execution_id=execution_id,
                key=key,
                record=record,
                version=version,
            )
        if (
            record.status != "running"
            or record.trace
            or self._remainder(
                workflow, tenant=authorized.tenant, key=key, record=record
            )
            != "suspend"
        ):
            return None
        return self._suspend(
            authorized,
            workflow,
            execution_id=execution_id,
            gate=record.current_state,
            trace=record.trace,
            started_by=record.started_by,
            version=version,
        )

    def _restore_request(
        self,
        authorized: Authorized[Execute] | Authorized[Resume],
        workflow: Workflow,
        *,
        execution_id: str,
        key: str,
        record: WorkflowStateRecord,
        version: int,
        snapshot: tuple[HitlActionSubmission, ...] | None = None,
    ) -> WorkflowSuspended | None:
        """File, once, the approval request a suspension never got onto the queue.

        ``D-IMPL-378``; Dave's decision 8 (a) of 2026-10-09, which extends his D2
        ruling: *"Recover the suspended run by idempotently restoring its missing
        approval request. Preserve the original authorization and suspension
        identity; never manufacture approval or rerun an effect."* A suspension
        is three acts (:meth:`_suspend`): the version-fenced ``suspended`` write,
        the trace write-through, and the enqueue of its one request. A process
        that dies, or an artifact store that fails, after the first act leaves
        ``record`` suspended at its gate with no request, so no verdict on it
        could ever count. D2's two triggers reach it, the starter's retried
        start (:meth:`_finish_start`) and a resumption that finds no approval
        (:meth:`resume`, which appends its refusal row first, Dave's repair
        1.4 (a)), and this files what is left of the suspension, in this
        order:

        * the trace artifact, from the record's own trace. It is
          content-addressed, so it is the artifact the suspension meant to file,
          at the same address, and one already filed is unchanged;
        * the record, re-written UNCHANGED, conditionally on ``version``, the
          version the caller read (:meth:`_fenced_write`). Its content hash,
          which the request, every verdict and the gate's closure are bound to,
          does not change, and the write appends one more ``workflow_suspended``
          row for the same suspension. That row is the suspension's own row in
          every field but its sequence and its time, so nothing in it marks a
          restore
          (``tests/workflow/test_restore_keeps_the_refused_resumption_row.py::test_the_restores_row_is_the_suspensions_own_row_but_for_its_sequence_and_time``).
          Of two recoveries that read the same
          version, one write lands and the other raises
          :class:`ExecutionFenced` having filed no request (a resumption's
          refusal row, appended before, stays);
        * the one request, built by :meth:`_gate_event` exactly as the
          suspension built it, so its key, class, content hash, pinned approval
          policy and requester are the suspension's, whoever recovers it.

        No step runs, no verdict is recorded and no gate is closed. Returns
        ``None``, filing nothing, unless the record is ``suspended`` at a
        ``hitl-gate`` and the HITL transport holds nothing for this suspension:
        no pending request, no closure, and no verdict other than one recorded
        while no request was pending. So a request that is pending, answered or
        decided is never filed again. The only verdicts a recovery files around
        were recorded while the request was missing, as
        ``event_state_at_submit="missing"``, and such a verdict is never
        authority (:meth:`_gate_authority`), though it still counts as a
        disagreement (``D-IMPL-366`` H2;
        ``tests/workflow/test_sec006_engine_controls.py::test_t12b_a_missing_state_verdict_still_counts_as_a_conflict``):
        the gate opens only on a verdict recorded against the restored request.
        The closure term is a backstop: a closure is taken only on a verdict,
        which the verdict term already finds.

        **What it cannot see**, each measured by
        ``tests/workflow/test_restore_missing_approval_request.py``. Nothing in a
        suspension says whether, or where, its request was filed:

        * **Two overlapping recoveries file ONE request** (``D-IMPL-391``). The
          conditional write orders recoveries that read the same version. It
          does not order a recovery that reads the record after another write
          landed and before that write's enqueue: the suspension's own passage,
          still alive and slow at its trace write, or another recovery between
          its write and its enqueue. Each then files the request, and the
          transport's ``enqueue``, atomic on the paused run's fingerprint
          (``(tenant, event_key, product_content_hash)``,
          :meth:`~ccf.hitl.transport.HITLTransportProtocol.enqueue`), queues it
          once. Before that contract two identical requests were possible; the
          gate still opened once on one approval.
        * **A request a gate primitive has claimed and not yet answered is filed
          again.** A claim is not visible through the transport Protocol. The
          enqueue discards the claim, as the Protocol documents, so the
          primitive's verdict is recorded against the restored request,
          ``pending`` and unstamped, and it carries the run past the gate once.
        * **The request is filed on this engine's own transport.** Deployed with
          one HITL transport per Control Plane state store, as
          ``public/how-to/security-and-deployment.md`` §4.13 requires, that is
          the suspension's own. With more than one, a request pending on another
          engine's transport is filed again on this one, whose verdicts this
          engine judges.

        **The HITL stall, disclosed** (``D-IMPL-380``, fifth round, ruling 1
        (a); Dave, 2026-10-10 12:57 MST, and 11:56 MST: *"Use the same words.
        Do not write a second disclosure."*). A HITL transport is handed the
        engine's own pending event, which is not copied. A transport that
        alters it can change the ``event_key`` the caller is told in
        ``WorkflowSuspended``, and, because resume looks for the key it
        recomputes (``_event_key``) among the events the transport holds, a
        transport that alters the key can keep the gate from ever opening, and
        each recovery queues another request. Nothing is wrongly approved: the
        approval binding, the hash of the suspension record as built, does not
        change.
        """
        gate = record.current_state
        step = next(
            (s for s in workflow.task_definition.steps if s.name == gate), None
        )
        if record.status != "suspended" or step is None or step.kind != "hitl-gate":
            return None
        tenant = authorized.tenant
        event_key = self._event_key(key, gate)
        suspension = content_hash(record)
        if snapshot is None:
            snapshot = self._hitl_transport.submissions(tenant=tenant)
        if (
            any(
                event.event_key == event_key
                and event.event_class == GATE_EVENT_CLASS
                and event.product_content_hash == suspension
                for event in self._hitl_transport.pending(tenant=tenant)
            )
            or any(
                closure.event_key == event_key
                and closure.product_content_hash == suspension
                for closure in self._hitl_transport.closures(tenant=tenant)
            )
            or any(
                submission.event_key == event_key
                and submission.principal.product_content_hash == suspension
                and submission.event_state_at_submit != "missing"
                for submission in snapshot
            )
        ):
            return None
        trace_artifact = self._write_trace(authorized, key, execution_id, record.trace)
        self._fenced_write(
            authorized, workflow, key, record, action="workflow_suspended", version=version
        )
        event = self._gate_event(workflow, tenant=tenant, key=key, record=record)
        self._hitl_transport.enqueue(event=event)
        return WorkflowSuspended(
            tenant=tenant,
            execution_id=execution_id,
            gate=gate,
            event_key=event.event_key,
            trace_artifact=trace_artifact,
        )

    def _read_versioned(self, key: str) -> tuple[object | None, int]:
        """The execution's record and its version (``D-IMPL-378``)."""
        store = self._control_plane.state_store
        assert isinstance(store, ConditionalStateStore)  # refused at construction otherwise
        return store.get_versioned(WORKFLOW_STATE, key)

    def _write_state(
        self,
        authorized: Authorized[Execute] | Authorized[Resume],
        workflow: Workflow,
        key: str,
        record: WorkflowStateRecord,
        *,
        action: AuditAction,
        actor: str | None,
        expected_version: int,
    ) -> int:
        """Write state through the audited surface, conditionally: the state write, then its one event (two writes).

        A DERIVED write (D-IMPL-353 §1.2, derived-writes rule): the state
        store derives the key it writes under from ``authorized.tenant`` and
        the execution id — the engine hands it the record id and the
        capability that authorized the run, and names no key and no tenant.
        ``key`` here is the engine's own reading of that same derivation
        (:meth:`_key`), used for the audit event and asserted equal to what
        the store derives, so the two cannot drift apart silently.

        The write is conditional on ``expected_version`` and the event is
        appended only when it lands (``D-IMPL-378``), so the audit log never
        records a transition the store did not take.

        **The state store is handed a deep copy of the record, taken before the
        save** (``D-IMPL-380``, third round, ruling 2 (a), 2026-10-10 09:18
        MST: *"The workflow state store is not trusted because it is the
        Control Plane. That is the same hole as the artifact store, one writer
        over."*), and the engine keeps its own record. Every state write passes
        through this function (no other ``write_if`` or ``put_if`` exists in
        ``runtime/ccf_runtime/workflow/``), and in every passage but
        :meth:`_restore_request`, which writes the trace first (from a record
        read back from the store), the state write comes before
        :meth:`_write_trace` (``D-IMPL-380``, fourth round, ruling 3 (a);
        Dave, 2026-10-10 10:58 MST: *"Always comes before"* *"is false on
        `_restore_request`."*), so a state store that altered
        the record it held — its trace entries are the engine's own — would
        otherwise reach the trace artifact, a completed outcome's
        ``step_sequence_block`` and a suspension's approval binding. They are
        built from the engine's record, which the store never held.

        **The saved-bytes limit, state-store form, disclosed.** The record the
        state store saves is its copy. A state store that alters its copy saves
        the alteration, and a LATER passage that reads the record back (a
        resume, a retry, the recovery path) reads what the store saved. Nothing
        here re-reads what the store saved: the same posture as the artifact
        store's (:meth:`_write_trace`).

        Raises:
            StateConflict: the record moved since ``expected_version`` was read.
        """
        execution_id = key[len(authorized.tenant) + 1 :]
        assert self._key(authorized.tenant, execution_id) == key
        _, version = self._writer.write_if(
            authorized,
            WORKFLOW_STATE,
            # A deep copy taken now, before the save; the engine keeps its own
            # record (`D-IMPL-380`, third round; Dave, 2026-10-10 09:23 MST:
            # *"Each of the three writers copies before the save and keeps its
            # own."*).
            record.model_copy(deep=True),
            record_id=execution_id,
            event=AuditEvent(
                sequence=0,  # reassigned by the log; sequencing is its own
                action=action,
                key=key,
                version=workflow.identity.definition_hash,
                resolved=True,
                occurred_at=self._clock(),
                actor=actor,
                artifact_class=WORKFLOW_DEFINITION.class_id,
            ),
            expected_version=expected_version,
        )
        return version

    def _fenced_write(
        self,
        authorized: Authorized[Execute] | Authorized[Resume],
        workflow: Workflow,
        key: str,
        record: WorkflowStateRecord,
        *,
        action: AuditAction,
        version: int,
    ) -> int:
        """A write that ends a passage, conditional on the version the passage wrote.

        ``D-IMPL-378``. A conflict here means a writer other than this passage
        moved the execution's record while the passage ran; fail closed
        (:class:`ExecutionFenced`).
        """
        try:
            return self._write_state(
                authorized,
                workflow,
                key,
                record,
                action=action,
                actor=None,
                expected_version=version,
            )
        except StateConflict as error:
            raise ExecutionFenced(
                f"execution {key!r} was moved by another writer while this"
                " passage ran; nothing was written (D-IMPL-378)"
            ) from error

    def _append(
        self,
        workflow: Workflow,
        key: str,
        *,
        action: AuditAction,
        resolved: bool,
        actor: str | None,
        verdict_integrity: WorkflowVerdictIntegrityFailure | None = None,
        recorded_approver: str | None = None,
    ) -> None:
        """Audit one transition that changes no persisted state.

        ``actor`` carries no default (SEC-001 remedy 2): every call site
        states who acted, or states positively that no human did. A default
        would let a gate resolution be audited with the approver silently
        omitted — the shape that let the pre-fix engine record
        ``resolved=True`` for an approval that never happened.

        ``verdict_integrity`` and ``recorded_approver`` DO default, because
        their absence is the ordinary case and the log's default event class
        is the honest record of it (D-IMPL-357 A4). Supplying the member
        makes the appended event a
        :class:`~ccf.controlplane.audit.WorkflowVerdictIntegrityAuditEvent`,
        which is how a refusal caused by a recorded human verdict stops
        being byte-identical to a caller's typo. They travel as a pair:
        every site that names a rule also names the approver it reached.
        """
        self._audit.append(
            action=action,
            key=key,
            version=workflow.identity.definition_hash,
            resolved=resolved,
            occurred_at=self._clock(),
            actor=actor,
            artifact_class=WORKFLOW_DEFINITION.class_id,
            workflow_verdict_integrity=verdict_integrity,
            workflow_recorded_approver=recorded_approver,
        )

    def _refuse(
        self,
        authorized: Authorized[Execute] | Authorized[Resume],
        workflow: Workflow,
        *,
        execution_id: str,
        reason: str,
        verdict_integrity: WorkflowVerdictIntegrityFailure | None = None,
        recorded_approver: str | None = None,
    ) -> WorkflowResumeRefused:
        """Return a typed refusal, audited ``resolved=False``.

        A refusal the caller's own request produced — no execution, a
        terminal one, a definition mismatch, no authority, an undeclared
        decision — audits with no actor, because no human's recorded
        verdict is what refused it.

        The two verdict-integrity refusals are different in kind and now
        different in the record (D-IMPL-357 A4): they refuse BECAUSE a
        human's verdict was recorded, so they name the rule and the
        approver, and the appended event is a
        :class:`~ccf.controlplane.audit.WorkflowVerdictIntegrityAuditEvent`.
        ``actor`` carries the same approver: the refusal row is not an
        attributed passage — ``resolved`` is ``False`` — but it IS about a
        human action, and an investigator filtering the log by actor must
        find it.
        """
        tenant = authorized.tenant
        self._append(
            workflow,
            self._key(tenant, execution_id),
            action="workflow_resumed",
            resolved=False,
            actor=recorded_approver,
            verdict_integrity=verdict_integrity,
            recorded_approver=recorded_approver,
        )
        return WorkflowResumeRefused(
            tenant=tenant, execution_id=execution_id, reason=reason
        )

    def _write_trace(
        self,
        authorized: Authorized[Execute] | Authorized[Resume],
        key: str,
        execution_id: str,
        trace: tuple[TraceEntry, ...],
    ) -> ArtifactRef:
        """Write the trace through to the ArtifactStore (D-IMPL-18).

        A DERIVED write (D-IMPL-353 §1.2): the engine names the record it
        produced — the trace class and the execution id — in a
        :class:`~ccf.artifacts.protocol.DerivedWrite`, presents the capability
        that authorized the run, and the store files it under
        ``authorized.tenant`` after verifying the capability against the kinds
        the deployment declared for the trace class. **The deployment must
        declare** :data:`WORKFLOW_TRACE_ARTIFACT_CLASS` **under**
        ``(Execute, Resume)`` in the store's
        :class:`~ccf.artifacts.protocol.WriteKinds`: a store that has not makes
        the class the client lane, and the engine's ``Execute``/``Resume``
        capability dies at the store's ``verify_any`` on the first trace write
        — fail closed, nothing filed, no execution reported as run.

        **The store's answer is held to the trace written** (``D-IMPL-378``
        decision 5, extending 5 (a)): every field of the reference ``put``
        returns must be the trace's own — its content address, the URI naming
        it under the capability's tenant and the trace class with the
        execution id as name and that address as version, and the tenant,
        class and name — or no reference is returned. The reference returned,
        which callers receive as the outcome's ``trace_artifact``, is the one
        the engine derived, which the store's answer equals field for field.
        **That reference is derived before** ``put`` **is called**, from the
        trace as built, and never from the trace after the store has held it
        (``D-IMPL-380``, ruling 1 (a), 2026-10-10 05:34 MST): a store that
        rewrites the trace while holding it (``object.__setattr__`` passes a
        frozen model's guard) and answers the rewritten trace's genuine
        reference is refused, not believed. What is not checked: the bytes
        the store holds (see :class:`WorkflowTraceReferenceMismatch`).

        **The store is handed a deep copy of the trace, taken before** ``put``
        (``D-IMPL-380``, second round, ruling 2 (a), 2026-10-10 07:39 MST),
        and the engine keeps its own entries. So a store that alters what it
        is handed and answers the trace's original reference — which passes
        the check above, because the reference is right — alters only its
        copy: the trace behind a completed outcome's ``step_sequence_block``,
        the trace inside the state record the engine keeps, and the trace in
        the record the recovery path (:meth:`_restore_request`) writes after
        this ``put`` are the engine's own, as built. The saved-bytes limit
        stands: such a store files altered bytes under the original's address,
        and nothing here re-reads what it filed; a reader that re-hashes what
        it fetches finds the difference.

        Raises:
            WorkflowTraceReferenceMismatch: the store's answer is not the
                trace's own reference. Raised after the store returns.
        """
        del key  # the state key; the trace is named by the execution id alone
        # The reference of the trace as built, derived BEFORE the store is
        # handed it (`D-IMPL-380`, ruling 1 (a); Dave, 2026-10-10 05:34 MST:
        # *"Hash before put in both writers. Compare the store's answer to
        # that precomputed reference. Do not hash the object again after the
        # store has held it."*). The entries are frozen, but
        # ``object.__setattr__`` passes a frozen model's guard, so a store
        # that rewrote the trace while holding it would otherwise be compared
        # against the rewritten trace. `D-IMPL-26`: the version IS the
        # address; the name is the execution id.
        address = content_hash(trace)
        own = ArtifactRef(
            content_address=address,
            uri=artifact_uri(
                tenant_id=authorized.tenant,
                artifact_class=WORKFLOW_TRACE_ARTIFACT_CLASS,
                name=execution_id,
                artifact_version=address,
            ),
            tenant_id=authorized.tenant,
            artifact_class=WORKFLOW_TRACE_ARTIFACT_CLASS,
            name=execution_id,
        )
        # The store is handed a deep copy taken now, before the save, and never
        # the engine's own entries (`D-IMPL-380`, second round, ruling 2 (a);
        # Dave, 2026-10-10 07:39 MST: *"Each writer gives the store a deep copy
        # made before the save and keeps its own."*): the entries are the ones
        # behind ``step_sequence_block`` and inside the state record, so an
        # alteration the store made to the objects it held would otherwise
        # reach the caller and the replay record under a reference that checks
        # out.
        answered = self._artifact_store.put(
            authorized,
            DerivedWrite(
                artifact_class=WORKFLOW_TRACE_ARTIFACT_CLASS,
                name=execution_id,
                artifact=tuple(entry.model_copy(deep=True) for entry in trace),
            ),
        )
        # Decision 5 (a) (`D-IMPL-378`), at this writer by decision 5: the
        # store's answer held to the reference derived above, field for field,
        # as exact strings — never re-derived from the trace the store held.
        differing = tuple(
            field
            for field in ArtifactRef.model_fields
            if not _same_string(getattr(answered, field, None), getattr(own, field))
        )
        if differing:
            raise WorkflowTraceReferenceMismatch(fields=differing)
        return own
