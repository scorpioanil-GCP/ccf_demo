# Copyright (c) 2026 David Castillo. All rights reserved.
# Use, copying, modification, and distribution of the covered material
# are governed by the CCF SDK Interim Software and Patent License
# in the repository-root LICENSE.md and any controlling signed agreement.
# Rights under that interim license begin only upon its execution
# and are limited to its stated scope and term.
"""The mandatory guard over every MCP surface — and the MCP mint site.

**SDK-defined** (CLAUDE.md §7.1, §8.3, §11; ``SEC-018``; ``D-IMPL-353`` §1.1).
Two findings meet in this module and it answers both with one mechanism.

``SEC-018``: :class:`~ccf_runtime.mcp.auth.TokenGrant` carried ``client_id``
and ``scopes`` and **no tenant**, so a bearer minted for tenant A reached
tenant B's artifacts, queue and products. The library's authentication was
never the weakness — ``mcp==1.28.1`` engages ``RequireAuthMiddleware``
correctly on the HTTP transports. The gap was that the thing it verified could
not express whose data its bearer was entitled to.

``D-IMPL-353``: a checklist of doors each remembering to ask an authorizer does
not ensure anything. Authorization is a **capability**,
:class:`~ccf_runtime.authz.capability.Authorized`, minted at exactly two sites
after the deployment's authorizer returns *allowed* — the HTTP
:class:`~ccf_runtime.http_api.gate.AuthorizationGate` and **this wrapper** —
and required, as a typed first parameter with no default, by every handle that
mutates or reads tenant data. A body registered here has no ``authorizer``
parameter and no ``tenant`` argument. It has ``authorized``, or it has nothing
to hand any handle.

Why a wrapper, and not a helper
-------------------------------
The obvious repair is a function each handler calls. That repair reproduces
the defect class it is repairing: a tool body that must *remember* to consult
the grant has its guard's applicability decided by its author. So the guard is
not offered to handlers; it is **installed on them at registration**, and the
capability a body needs to do anything is minted by that installation and by
nothing else a body can reach.

Three independent controls make that stick:

1. :meth:`TenantGuardedServer.tool` and :meth:`TenantGuardedServer.resource`
   take ``action``, ``subject``, ``resource`` and ``mutating`` as **required
   keyword arguments**. There is no defaulted registration, so a surface cannot
   be added without its author stating what it does, whose tenant it acts on,
   what it acts on, and whether it writes.
2. **Registration behind the wrapper is a boot failure** (§2 P9).
   :func:`unguarded_surfaces` compares the wrapper's ledger against
   ``FastMCP``'s own registry, and :meth:`TenantGuardedServer.build` — the only
   way a builder obtains the server to mount — raises if the two disagree. So
   does the constructor, for a server that carried surfaces before it was
   wrapped. The raw ``FastMCP`` is not exposed for registration.
3. A body's first parameter is the capability. The wrapper mints it for the
   body's **declared** action (:func:`~ccf_runtime.authz.capability
   .kind_for_action`) on the body's **declared** resource under the **selected**
   tenant, and mints nothing on any refusal. What the body then hands to a
   handle is verified there by identity (§1.5c) — a ``list_agents`` capability
   presented to a write handle dies before the handle's first statement.

What this decides, in order
---------------------------
verified identity → ambient-mutation refusal → tenant selection (§1.3) →
resource extraction → the authorizer's four-axis decision → mint → body. The
order is the property: the tenancy floor runs before the authorizer is asked,
so a deployment's authorizer can never be what lets a cross-tenant call
through, and the ambient refusal runs before the mint, so a stated stdio
identity is never even decided for a mutating kind.

**Exactly one tenant per capability** (§1.3). ``TokenGrant.tenants`` is a set —
an operator credential legitimately spans tenants — but a *decision* is about
one. The wrapper selects it: the request names one and it is a member
(:meth:`~TenantGuardedServer.from_argument`); the deployment declared it and it
is a member (:meth:`~TenantGuardedServer.declared`); or the surface carries no
tenant and the grant holds exactly one (:meth:`~TenantGuardedServer.from_grant`).
Otherwise it **refuses as ambiguous — it does not pick.** There is no
*untenanted* reading any more: every capability names its tenant.

Tenant identifiers, scope vocabulary, action grants and token material are
deployment values in their entirety. This module holds none of them (CINV-01).

Algorithmic module (CINV-03).
"""

from __future__ import annotations

import functools
import inspect
import json
import logging
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any, Final, TypeVar
from weakref import WeakKeyDictionary

from mcp.server.auth.middleware.auth_context import get_access_token
from mcp.server.auth.provider import AccessToken
from mcp.server.fastmcp import FastMCP
from pydantic import model_validator

from ccf.authz.capability import (
    ActionKind,
    AgentList,
    AgentRead,
    AgentVersions,
    ArtifactRead,
    Authorized,
    BackendsRead,
    ConfigKeysRead,
    ConfigResolve,
    ConfigVersionsRead,
    DocsRead,
    HealthRead,
    HitlQueueRead,
    OpenApiRead,
    ProductRetrieve,
    ReplayRead,
    SchemaList,
    SchemaRead,
    SkillCatalogRead,
    WorkflowStatusRead,
    kind_for_action,
    mint,
)
from ccf.skills._wire_arguments import refuse_undeclared_arguments
from ccf.skills.dispatch import TENANT_NOT_GRANTED_CODE
from ccf_runtime.authz.protocol import TenantAuthorizerProtocol
from ccf_runtime.http_api.errors import (
    ERROR_DECISION_UNMINTABLE,
    ERROR_TENANT_UNAUTHORIZED,
    refusal_detail,
)
from ccf_runtime.mcp.auth import (
    AMBIENT_STDIO_CLAIM,
    TENANT_CLAIM,
    TokenGrant,
    bounded_echo,
    granted_products,
    granted_tenants,
    is_ambient_stdio,
    tenant_claims,
)

__ccf_mode__ = "algorithmic"

_LOGGER = logging.getLogger(__name__)

#: The ONE reason every directory-resolved roster refusal gives the caller
#: (``SEC-017`` fix round 2, I-NEW-1). The roster is held before the
#: authorizer, so a caller the authorizer would deny reaches the directory
#: lookup; if *unknown agent*, *not exposed*, *no derived classes* and
#: *reaches X, off the roster* read differently, that caller learns which
#: agents exist and which classes they touch. So none of them is told: the
#: specific reason is logged server-side only, and no class name and no
#: definition key or version is echoed. The authorizer's own DENY, for a
#: rostered caller on such a surface, is this same refusal too (PC2, panel C2;
#: ``D-IMPL-374``): an agent that exists and is on the roster is the one outcome
#: that reaches the authorizer, so a distinct ``tenant-unauthorized`` there was
#: the fourth outcome that told the caller the agent exists.
_OPAQUE_DIRECTORY_REASON: Final[str] = (
    "the agent named does not resolve to one this grant's product roster"
    " reaches"
)

__all__ = [
    "AMBIENT_STDIO_CLAIM",
    "READ_KINDS",
    "ActionUnauthorizedRefused",
    "AmbientMutationRefused",
    "AmbiguousTenantRefused",
    "CrossTenantRefused",
    "DecisionUnmintableRefused",
    "GuardedSurface",
    "ProductOutsideRosterRefused",
    "ProductReach",
    "roster_refusal",
    "ResourceSubject",
    "ResourceUnreadableRefused",
    "TENANT_CLAIM",
    "TenantGuardViolation",
    "TenantGuardedServer",
    "TenantSubject",
    "TenantlessGrantRefused",
    "UnguardedSurfaceError",
    "UnverifiedTenantCallerRefused",
    "ambient_stdio_identity",
    "granted_tenants",
    "is_ambient_stdio",
    "tenant_claims",
    "unguarded_surfaces",
]

_F = TypeVar("_F", bound=Callable[..., Any])

#: The name every body's first parameter carries. Named once so the
#: registration check and the call site agree on it.
_CAPABILITY_PARAMETER: Final[str] = "authorized"

#: The kinds a **stated** (ambient stdio) identity may be minted. Process
#: ownership warrants reading what the child was spawned to serve; it does not
#: warrant a write on an authority nobody presented. **Anything absent from
#: this roster is mutating** — the fail-closed direction — and
#: :meth:`TenantGuardedServer.tool` refuses to register a surface whose action
#: mints an absent kind as ``mutating=False``, so the per-site flag the ambient
#: rule keys off cannot be false for a mutating kind. Pinned as a roster by
#: ``tests/mcp/test_mint_site.py``, which classifies every exported kind.
READ_KINDS: Final[frozenset[type[ActionKind]]] = frozenset(
    {
        AgentList,
        AgentRead,
        AgentVersions,
        ArtifactRead,
        BackendsRead,
        ConfigKeysRead,
        ConfigResolve,
        ConfigVersionsRead,
        DocsRead,
        HealthRead,
        HitlQueueRead,
        OpenApiRead,
        ProductRetrieve,
        ReplayRead,
        SchemaList,
        SchemaRead,
        SkillCatalogRead,
        WorkflowStatusRead,
    }
)


class TenantGuardViolation(RuntimeError):
    """Base for every refusal this guard raises.

    One base so a door that wants to translate all of them into its own
    protocol-native shell has a single thing to catch, and typed leaves so a
    test can tell *refused for the right reason* from *refused*.
    """


class UnverifiedTenantCallerRefused(TenantGuardViolation):
    """No verified access token accompanies this call.

    The bearer middleware refuses this before a handler runs. The guard refuses
    it again on its own account rather than on the middleware's promise,
    because a handler reachable by any path that skips the middleware — stdio,
    a mounted app, an in-process call — would otherwise be ungoverned.
    """


class TenantlessGrantRefused(TenantGuardViolation):
    """The verified grant names no tenant, so it reaches nothing.

    Fail-closed, and the loud direction: a deployment that forgot to scope a
    credential finds out immediately instead of shipping one that opens
    everything.
    """


class CrossTenantRefused(TenantGuardViolation):
    """The call acts on a tenant the verified grant does not carry.

    ``SEC-018`` itself.
    """


class ProductOutsideRosterRefused(TenantGuardViolation):
    """The call reaches a product class outside the grant's declared roster.

    ``SEC-017``; ``D-IMPL-374`` (2). Within-tenant product entitlement: a
    verified grant that declares
    :attr:`~ccf_runtime.mcp.auth.TokenGrant.products` reaches only the classes
    on it. Raised by the Experience door's agent and replay tools, after the
    tenancy floor has admitted the tenant, and its message names the tool and
    every off-roster class — the refusal is *by name*, so a deployment reading
    it learns which declaration to change.
    """


def roster_refusal(surface: str, reason: str) -> ProductOutsideRosterRefused:
    """The by-name roster refusal, phrased once for every surface (``SEC-017``)."""
    return ProductOutsideRosterRefused(
        f"{surface} refused: {reason}; the verified grant declares a product"
        " roster and reaches only the Context Product classes on it"
        " (SEC-017; D-IMPL-374)"
    )


class AmbiguousTenantRefused(TenantGuardViolation):
    """The surface names no tenant and the grant holds more than one.

    ``D-IMPL-353`` §1.3: *the gate selects it from the grant's set — or the
    grant holds exactly one; otherwise refuse as ambiguous, the gate does not
    pick.* Choosing one would be a tenant decision the caller never made and
    the deployment never declared.
    """


class AmbientMutationRefused(TenantGuardViolation):
    """A stated (not verified) identity tried to reach a mutating surface.

    See :func:`ambient_stdio_identity` for why stdio has a stated identity at
    all, and why its warrant stops at reading. Raised **before** the authorizer
    is asked, so a stated identity is never minted a mutating kind.
    """


class ResourceUnreadableRefused(TenantGuardViolation):
    """The declared resource argument carries nothing a decision can be made on.

    A resource that is absent, empty or not a string is a **deny, never a
    skip**: the caller chooses what to send, and every choice leads to the
    check running (the HTTP gate's own rule, applied to arguments).
    """


class ActionUnauthorizedRefused(TenantGuardViolation):
    """The deployment's authorizer refused the declared action on the resource.

    The message is the shared refusal constant rendered protocol-natively
    (D-08): ``json.dumps(refusal_detail(ERROR_TENANT_UNAUTHORIZED, ...))``, the
    same body the HTTP door's 403 carries, so a client parses either door's
    denial the same way. **Nothing is minted on this path.**
    """


class DecisionUnmintableRefused(TenantGuardViolation):
    """The authorizer answered *allowed* with a decision the wrapper cannot mint from.

    ``D-IMPL-353`` §1.5(a): the mint binds the authorizer's WHOLE decision,
    and the capability's ``decision_id`` is the audit event that decision is
    evidence of. An allow carrying no ``decision_id``, or deciding about a
    tenant, action or resource other than the one this wrapper asked about,
    is not minted from — the same refusal the HTTP gate makes as
    ``decision-unmintable`` (a ``503``, a deployment fault, never a ``403``
    the caller could read as a verdict). **Nothing is minted on this path and
    the body never runs.** The message is the shared refusal constant
    rendered protocol-natively (D-08), as :class:`ActionUnauthorizedRefused`'s
    is.
    """


class UnguardedSurfaceError(RuntimeError):
    """A surface reached ``FastMCP``'s registry without going through the guard.

    Raised at construction (a server that already carried surfaces) and at
    :meth:`TenantGuardedServer.build` (a registration on the underlying server
    after wrapping). A boot failure rather than a refusal: the deployment has a
    handler on the wire with no capability behind it, and the fix is in the
    builder, not in the call.
    """


@dataclass(frozen=True)
class TenantSubject:
    """How one surface's tenant is selected — a closed, stated choice (§1.3).

    Constructed only through :meth:`TenantGuardedServer.from_argument`,
    :meth:`TenantGuardedServer.declared` and
    :meth:`TenantGuardedServer.from_grant`, so the three selections are
    enumerable and a fourth cannot appear by accident.

    Attributes:
        argument: The **wire** parameter naming the tenant, when the caller
            names it. It stays on the input schema — it selects *which* of a
            multi-tenant grant's tenants — but it is consumed by the wrapper
            and never reaches the body, which reads ``authorized.tenant``.
        declared: The tenant fixed at registration, for a surface with no
            tenant on the wire and a deployment-declared address.
        grant: ``True`` when the surface carries no tenant and declares none:
            the grant's sole tenant is the decision's, and a grant holding
            several is refused as ambiguous.
    """

    argument: str | None = None
    declared: str | None = None
    grant: bool = False


@dataclass(frozen=True)
class ResourceSubject:
    """Where the thing a surface acts on comes from — a closed, stated choice.

    The fourth axis of the decision (``SEC-002``): a scope mapping says which
    keys, addresses and classes an action reaches, so the wrapper must name the
    one this call acts on. Constructed only through the four
    :class:`TenantGuardedServer` readers.

    Attributes:
        argument: The wire parameter carrying the resource — a content
            address, a product class, a definition key.
        declared: A value fixed at registration — the class a deployment
            declared a tool's address under.
        route: ``True`` when the surface acts on no addressable subject; its
            own action id is the resource, so the axis has no exempt member.
        template: A ``str.format`` template over the wire arguments, for a
            resource spelled from several of them — the artifact store's
            ``"{artifact_class}/{name}"``, the same segments the naming key
            already uses (``D-IMPL-353`` §1.2).
    """

    argument: str | None = None
    declared: str | None = None
    route: bool = False
    template: str | None = None


#: Resolves the product classes one call reaches from the selected tenant and
#: the bound wire arguments, or raises :class:`ProductOutsideRosterRefused` when
#: it cannot tell. Used where the class is not on the wire — ``invoke_agent``
#: reads it from the agent directory.
ProductResolver = Callable[[str, Mapping[str, Any]], frozenset[str]]


@dataclass(frozen=True)
class ProductReach:
    """Which Context Product classes one surface's call reaches (``SEC-017``).

    ``D-IMPL-374`` (2), fix round 1: the grant's declared roster
    (:attr:`~ccf_runtime.mcp.auth.TokenGrant.products`) is held to every
    surface where a class is known at the call, **by the wrapper, before the
    authorizer is asked** — so a refused call records no allow and mints
    nothing. A closed, stated choice, constructed only through the four
    :class:`TenantGuardedServer` readers, and declared at EVERY registration:
    a surface that reaches no class it can know says so in words.

    Attributes:
        argument: The wire parameter carrying the class.
        declared: Classes fixed at registration (the deployment's).
        undeclared: The name of a deployment declaration that is ABSENT: the
            surface reaches a class, the deployment never said which, and a
            rostered caller is refused by that name.
        resolve: A resolver for a class read from somewhere other than the
            wire (see :data:`ProductResolver`).
        unknown: Why this surface knows no product class at the call; the
            roster is not consulted on it.
    """

    argument: str | None = None
    declared: frozenset[str] | None = None
    undeclared: str | None = None
    resolve: ProductResolver | None = None
    unknown: str | None = None

    def __post_init__(self) -> None:
        """Exactly one reading, and no empty statement (fix round 2, minor (i)).

        Held at construction rather than only in the four readers, so a
        reach built directly cannot state no reading, two readings, or an
        empty one.
        """
        stated = [
            self.argument,
            self.declared,
            self.undeclared,
            self.resolve,
            self.unknown,
        ]
        if sum(value is not None for value in stated) != 1:
            raise ValueError(
                "a product reach states exactly one reading — argument,"
                " declared, undeclared, resolve or unknown (SEC-017)"
            )
        # PM9 (panel C9; `D-IMPL-374`): `declared` included — an empty
        # declared set reaches no class, so the roster hold would pass every
        # call, an empty roster's too, and the surface would be silently
        # roster-unbound.
        for name in ("argument", "declared", "undeclared", "unknown"):
            value = getattr(self, name)
            if value is not None and not value:
                raise ValueError(
                    f"a product reach's {name} is non-empty: an empty"
                    " statement is a reading nobody made (SEC-017)"
                )


def _hold_to_roster(
    surface: str,
    reach: ProductReach,
    tenant: str,
    arguments: Mapping[str, Any],
    roster: frozenset[str],
) -> None:
    """Refuse, by name, a call reaching a class outside ``roster`` (``SEC-017``)."""
    if reach.unknown is not None:
        return
    if reach.undeclared is not None:
        raise roster_refusal(
            surface,
            f"the deployment declared no {reach.undeclared}, so what this"
            " surface serves is on no roster",
        )
    if reach.argument is not None:
        value = arguments.get(reach.argument)
        if not isinstance(value, str) or not value:
            raise roster_refusal(
                surface, f"argument {reach.argument!r} names no product class"
            )
        reached = frozenset({value})
    elif reach.declared is not None:
        reached = reach.declared
    elif reach.resolve is not None:
        # A resolved reach reads a directory before the authorizer: every
        # outcome refuses alike, and only the log knows which (I-NEW-1).
        try:
            reached = reach.resolve(tenant, arguments)
        except ProductOutsideRosterRefused as specific:
            raise _opaque_directory_refusal(surface, str(specific)) from None
        outside = reached - roster
        if outside:
            raise _opaque_directory_refusal(
                surface,
                "reaches "
                + ", ".join(bounded_echo(name) for name in sorted(outside))
                + ", outside the roster",
            )
        return
    else:  # pragma: no cover - unconstructible: __post_init__
        raise roster_refusal(surface, "this surface states no product reading")
    outside = reached - roster
    if outside:
        named = ", ".join(bounded_echo(name) for name in sorted(outside))
        raise roster_refusal(surface, f"it reaches {named}, outside the roster")


def _opaque_directory_refusal(
    surface: str, specific: str
) -> ProductOutsideRosterRefused:
    """Log ``specific`` server-side; return the one refusal the caller sees (I-NEW-1)."""
    _LOGGER.info(
        "SEC-017 roster refusal on %s before authorization: %s", surface, specific
    )
    return roster_refusal(surface, _OPAQUE_DIRECTORY_REASON)


@dataclass(frozen=True)
class GuardedSurface:
    """Everything one registration declared, as the ledger keeps it.

    Attributes:
        action: The door-declared action id the wrapper mints for.
        subject: How the tenant is selected.
        resource: Where the resource is read.
        mutating: Whether the surface writes.
        products: Which product classes the call reaches (``SEC-017``).
    """

    action: str
    subject: TenantSubject
    resource: ResourceSubject
    mutating: bool
    products: ProductReach


#: Each built server's ledger of guarded surfaces. Keyed weakly so a server
#: built in a test does not outlive the test.
_LEDGERS: WeakKeyDictionary[FastMCP, dict[str, GuardedSurface]] = (
    WeakKeyDictionary()
)


def ambient_stdio_identity(
    *, credential: str, principal_id: str, scope: str, tenant: str
) -> AccessToken:
    """The identity an MCP **stdio** host states for its caller.

    MCP stdio carries no authentication channel: ``FastMCP`` installs its
    bearer middleware on the HTTP app and there is no HTTP app on stdio, so a
    door that demanded a presented credential would refuse every caller. The
    transport's own security boundary is process ownership — the server is a
    child the deployment's client spawned, under the same user, on the same
    host — and stating the identity is how that boundary is made legible
    instead of smuggled.

    **What this narrows.** Two things, and the reviewers' complaint ("no
    ambient identity") is answered by both rather than by removing the
    transport's only workable identity:

    * The grant is scoped to **exactly one tenant** — the door's own. Process
      ownership authorizes the tenant the child was spawned to serve and no
      other.
    * It is **marked ambient**, and :class:`TenantGuardedServer` refuses every
      surface registered ``mutating=True`` to a marked identity **before the
      authorizer is asked** — so a stated identity may be minted a kind in
      :data:`READ_KINDS` and never a mutating one. Process ownership is a
      defensible warrant for reading what the child exists to serve; it is not
      a warrant for writing on an authority nobody presented.

    The marker cannot be forged or cleared from the wire. Claims reach a
    handler only from
    :meth:`~ccf_runtime.mcp.auth.SourceBackedTokenVerifier.verify_token`, which
    composes them from the deployment's own grant; a remote caller supplies a
    token string and nothing else.

    **The loopback transport is untouched.** Its bearer authentication is real
    because the middleware is on the HTTP app, its identity is not ambient, and
    nothing here narrows it.

    Args:
        credential: This boot's credential. Carried so the stated token is the
            same string the loopback transport would verify.
        principal_id: The declared principal the door serves.
        scope: The bearer scope the door requires.
        tenant: The one tenant this door serves as.
    """
    grant = TokenGrant(
        client_id=principal_id, scopes=(scope,), tenants=frozenset({tenant})
    )
    return AccessToken(
        token=credential,
        client_id=principal_id,
        scopes=[scope],
        claims={**tenant_claims(grant), AMBIENT_STDIO_CLAIM: True},
    )


def unguarded_surfaces(server: FastMCP) -> frozenset[str]:
    """Names registered on ``server`` that did not go through the guard.

    ``FastMCP``'s managers are the authority on what is actually reachable;
    :class:`TenantGuardedServer`'s ledger is the record of what was governed.
    A surface in the first and not the second is a handler on the wire with no
    capability behind it, which is the shape of ``SEC-018`` and of §2 P9.

    Templates are counted by their URI template rather than by function name,
    because that is the identity ``ResourceManager`` files them under.
    """
    ledger = _LEDGERS.get(server, {})
    registered = {tool.name for tool in server._tool_manager.list_tools()}
    registered |= {
        str(resource.uri) for resource in server._resource_manager.list_resources()
    }
    registered |= {
        template.uri_template
        for template in server._resource_manager.list_templates()
    }
    return frozenset(registered - set(ledger))


def _close_wire_arguments(server: FastMCP, name: str) -> None:
    """Refuse, never drop, a wire argument the registered tool does not declare.

    ``SEC353-J-01`` (``D-IMPL-353`` residual R4), ruled with ``TP-04`` as one
    defect class (``D-IMPL-361``). Measured against ``mcp==1.28.1``: FastMCP's
    per-tool argument model is a pydantic model with the default
    ``extra="ignore"`` (``fastmcp/utilities/func_metadata.py:48-66``), it hands
    the body only the declared fields (``:87-89``), and the low-level handler is
    registered with ``validate_input=False`` (``fastmcp/server.py:308``) — so an
    undeclared argument was silently dropped and the call served as though the
    caller had sent a different question.

    The registered tool's argument model is replaced by a subclass whose
    ``before`` validator runs the one shared rule
    (:func:`ccf.skills._wire_arguments.refuse_undeclared_arguments`) over the
    RAW wire mapping, before any field is parsed and before the guard or the
    body runs. The refusal is raised as the typed
    :class:`~ccf.skills._wire_arguments.UndeclaredArgumentRefused` (not a
    ``ValueError``, so pydantic does not re-type it), and FastMCP surfaces it to
    the client as a tool error naming the key. The advertised ``inputSchema``
    gains ``additionalProperties: false`` so what the tool advertises is what
    it enforces. Declared names are read off the model's own fields, by wire
    alias where FastMCP assigned one.
    """
    tool = server._tool_manager.get_tool(name)
    if tool is None:  # pragma: no cover - registered on the line before
        raise LookupError(f"tool {name!r} was not registered")
    base = tool.fn_metadata.arg_model
    declared = frozenset(
        field.alias or field_name for field_name, field in base.model_fields.items()
    )

    class _Closed(base):  # type: ignore[valid-type, misc]
        @model_validator(mode="before")
        @classmethod
        def _refuse_undeclared(cls, data: Any) -> Any:
            if isinstance(data, Mapping):
                refuse_undeclared_arguments(data, declared=declared, surface=name)
            return data

    _Closed.__name__ = base.__name__
    _Closed.__qualname__ = base.__qualname__
    tool.fn_metadata = tool.fn_metadata.model_copy(update={"arg_model": _Closed})
    tool.parameters = {**tool.parameters, "additionalProperties": False}


class TenantGuardedServer:
    """A ``FastMCP`` whose surfaces cannot be registered ungoverned — the MCP mint site.

    Holds the server rather than subclassing it, so the registration methods a
    handler author reaches are *these* — which require a declaration — rather
    than the library's, which do not. The underlying instance is handed back
    only by :meth:`build`, which refuses a server carrying any surface the
    ledger does not know.

    Args:
        server: The ``FastMCP`` to govern. Refused if it already carries a
            surface. Authentication configuration is the caller's — this class
            decides on a verified identity and never establishes one.
        authorizer: The deployment's authorizer. **Required**, with no
            default: there is no arm of this class in which the decision is
            skipped (§2 P4), and the lint refuses a defaulted authority type.

    Raises:
        UnguardedSurfaceError: ``server`` already carries a tool, resource or
            template.
    """

    def __init__(self, server: FastMCP, *, authorizer: TenantAuthorizerProtocol) -> None:
        self._server = server
        self._authorizer = authorizer
        _LEDGERS[server] = {}
        self._refuse_unguarded(when="wrapped")

    def build(self) -> FastMCP:
        """The governed server, for mounting — or refuse to hand one back.

        The one way a builder obtains the ``FastMCP`` it returns, so a
        registration on the underlying server after wrapping is a boot failure
        rather than a test failure (§2 P9).

        Raises:
            UnguardedSurfaceError: a surface reached the registry behind the
                wrapper's back.
        """
        self._refuse_unguarded(when="built")
        return self._server

    @property
    def ledger(self) -> Mapping[str, GuardedSurface]:
        """Every surface registered through this wrapper, and what it declared."""
        return dict(_LEDGERS[self._server])

    def _refuse_unguarded(self, *, when: str) -> None:
        smuggled = unguarded_surfaces(self._server)
        if smuggled:
            raise UnguardedSurfaceError(
                f"these surfaces were registered on the FastMCP behind the"
                f" guard and reach the wire with no capability behind them:"
                f" {sorted(smuggled)}; found when the server was {when}."
                " Register every tool and resource through"
                " TenantGuardedServer.tool / .resource (SEC-018; D-IMPL-353"
                " §2 P9)"
            )

    # --- the three tenant selections (§1.3) ---------------------------------

    @staticmethod
    def from_argument(name: str) -> TenantSubject:
        """The wire parameter ``name`` names the tenant; it must be a member of the grant."""
        return TenantSubject(argument=name)

    @staticmethod
    def declared(tenant: str) -> TenantSubject:
        """The tenant is fixed at registration; it must be a member of the grant."""
        return TenantSubject(declared=tenant)

    @staticmethod
    def from_grant() -> TenantSubject:
        """The surface carries no tenant: the grant's sole tenant, or refuse as ambiguous."""
        return TenantSubject(grant=True)

    # --- the four resource readings -------------------------------------------

    @staticmethod
    def resource_argument(name: str) -> ResourceSubject:
        """The resource is the wire parameter ``name``."""
        return ResourceSubject(argument=name)

    @staticmethod
    def resource_declared(value: str) -> ResourceSubject:
        """The resource is fixed at registration."""
        return ResourceSubject(declared=value)

    @staticmethod
    def resource_route() -> ResourceSubject:
        """The surface itself is the resource; its action id names it."""
        return ResourceSubject(route=True)

    @staticmethod
    def resource_composed(template: str) -> ResourceSubject:
        """The resource is ``template`` formatted over the wire arguments."""
        return ResourceSubject(template=template)

    # --- the four product readings (SEC-017; D-IMPL-374 (2)) ------------------

    @staticmethod
    def products_from_argument(name: str) -> ProductReach:
        """The call reaches the product class the wire parameter ``name`` carries."""
        return ProductReach(argument=name)

    @staticmethod
    def products_declared(product_class: str | None, *, declaration: str) -> ProductReach:
        """The call reaches the deployment-declared class; ``None`` = undeclared.

        ``declaration`` names the builder parameter, so a rostered caller
        refused for its absence learns which declaration is missing.
        """
        if product_class is None:
            return ProductReach(undeclared=declaration)
        return ProductReach(declared=frozenset({product_class}))

    @staticmethod
    def products_resolved(resolve: ProductResolver) -> ProductReach:
        """The call reaches the classes ``resolve`` reads for it."""
        return ProductReach(resolve=resolve)

    @staticmethod
    def products_unknown(reason: str) -> ProductReach:
        """The surface knows no product class at the call — said, with ``reason``.

        An empty ``reason`` is refused by :class:`ProductReach` itself.
        """
        return ProductReach(unknown=reason)

    # --- registration ----------------------------------------------------------

    def tool(
        self,
        *,
        name: str,
        action: str,
        subject: TenantSubject,
        resource: ResourceSubject,
        mutating: bool,
        products: ProductReach,
        on_denied: Callable[..., Any] | None = None,
        **kwargs: Any,
    ) -> Callable[[_F], _F]:
        """Register a tool whose body runs only under a capability minted for it.

        Every declaration is keyword-only with no default, so adding a tool
        without stating all four is a ``TypeError`` at import rather than a
        silent ungoverned surface.

        **A wire argument the tool does not declare is refused, never
        dropped** (``SEC353-J-01``, ruled with ``TP-04`` at ``D-IMPL-361``):
        the registered tool is closed by :func:`_close_wire_arguments`, so the
        call fails with a typed
        :class:`~ccf.skills._wire_arguments.UndeclaredArgumentRefused` naming
        the key, and the advertised ``inputSchema`` carries
        ``additionalProperties: false``.

        Args:
            name: The tool name on the wire.
            action: The door-declared action id this tool performs. The kind
                the body receives is :func:`~ccf_runtime.authz.capability
                .kind_for_action` of it; an id no door declares is refused
                here.
            subject: How the tenant is selected.
            resource: Where the resource is read.
            mutating: Whether the tool writes. A mutating tool is refused to a
                stated (ambient) identity before any decision is made. Refused
                as ``False`` for an action whose kind is outside
                :data:`READ_KINDS`.
            products: Which product classes a call reaches (``SEC-017``); a
                grant's declared roster is held to it before the authorizer.
            on_denied: What the tool answers when the AUTHORIZER denies the
                call, in place of the ``tenant-unauthorized`` tool error —
                called as ``on_denied(grant=, tenant=, arguments=, denial=)``
                with the verified grant, the selected tenant, the wire
                arguments (tenant argument removed) and the deny's statement,
                and never with a capability (none is minted). ``None`` (the
                default) keeps the tool error. The SDK's product door passes
                one so an undeclared class reads as an unentitled caller does
                (R5-CP17-F01; Dave 2026-10-11 21:19 MST, "Do (a)"). The tenant
                floor, the roster and the opaque directory refusal all still
                run first and are unchanged.
            **kwargs: Passed to ``FastMCP.tool`` untouched.
        """

        def register(handler: _F) -> _F:
            guarded, surface = self._guard(
                handler,
                surface_name=name,
                action=action,
                subject=subject,
                resource=resource,
                mutating=mutating,
                products=products,
                on_denied=on_denied,
            )
            self._server.tool(name=name, **kwargs)(guarded)
            _close_wire_arguments(self._server, name)
            _LEDGERS[self._server][name] = surface
            # The GUARDED callable, never the bare one: returning `handler`
            # would leave an ungoverned alias bound to the module-level name
            # the body was defined under.
            return guarded

        return register

    def resource(
        self,
        uri: str,
        *,
        action: str,
        subject: TenantSubject,
        resource: ResourceSubject,
        mutating: bool,
        products: ProductReach,
        **kwargs: Any,
    ) -> Callable[[_F], _F]:
        """Register a resource whose body runs only under a capability minted for it.

        That ``get_access_token()`` is populated inside a **resource** handler
        and not only inside a tool is shipped fact rather than assumption — the
        A1 spike verdict, ``tests/crossproc/test_fastmcp_resource_token_
        spike.py``.

        Args:
            uri: The URI or URI template this resource answers. A template's
                parameters are the wire parameters: the body declares every one
                of them except the tenant segment, which the wrapper consumes.
            action: The door-declared action id this resource performs.
            subject: How the tenant is selected.
            resource: Where the resource is read.
            mutating: Whether the resource writes. Resources cannot mutate by
                protocol, so this is ``False`` for every one the SDK ships; it
                is a parameter rather than an assumption so the reading is
                stated at each site.
            products: Which product classes a read reaches (``SEC-017``).
            **kwargs: Passed to ``FastMCP.resource`` untouched.
        """

        def register(handler: _F) -> _F:
            guarded, surface = self._guard(
                handler,
                surface_name=uri,
                action=action,
                subject=subject,
                resource=resource,
                mutating=mutating,
                products=products,
            )
            self._server.resource(uri, **kwargs)(guarded)
            _LEDGERS[self._server][uri] = surface
            return guarded

        return register

    # --- the guard itself ------------------------------------------------------

    def _guard(
        self,
        handler: _F,
        *,
        surface_name: str,
        action: str,
        subject: TenantSubject,
        resource: ResourceSubject,
        mutating: bool,
        products: ProductReach,
        on_denied: Callable[..., Any] | None = None,
    ) -> tuple[_F, GuardedSurface]:
        """Wrap ``handler`` so decision and mint precede its first statement.

        **The visible signature is the wire's, not the body's.** ``FastMCP``
        derives a tool's input schema and a template's parameter set from
        ``inspect.signature``, so the wrapper publishes the body's parameters
        minus ``authorized`` plus the tenant argument (when the subject names
        one). ``authorized`` is therefore never on the wire, and the tenant
        argument never reaches the body. Both ``__signature__`` and
        ``__annotations__`` are set, because the library reads the first and
        pydantic's ``validate_call`` may read the second.

        Raises:
            CapabilityBypassError: ``action`` is not one any door declares.
            ValueError: the body's first parameter is not ``authorized``; the
                body declares the tenant argument; ``mutating`` is ``False``
                for a kind outside :data:`READ_KINDS`; or a declared resource
                argument is not a wire parameter.
        """
        kind = kind_for_action(action)
        if not mutating and kind not in READ_KINDS:
            raise ValueError(
                f"{handler.__name__!r} declares action {action!r}, whose kind"
                f" {kind.__name__} is not a read kind, and is registered"
                " mutating=False; a stated stdio identity would then be minted"
                " a mutating kind. Register it mutating=True (D-IMPL-353;"
                " SEC-018)"
            )
        body = inspect.signature(handler, eval_str=True)
        parameters = list(body.parameters.values())
        if (
            not parameters
            or parameters[0].name != _CAPABILITY_PARAMETER
            or parameters[0].kind
            not in (
                inspect.Parameter.POSITIONAL_ONLY,
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
            )
        ):
            raise ValueError(
                f"{handler.__name__!r} does not take the capability as its"
                f" first parameter; a body registered through the guard is"
                f" `def body({_CAPABILITY_PARAMETER}: Authorized[Kind], ...)`"
                " and reads its tenant from it — there is no other source"
                " (D-IMPL-353 §1.2)"
            )
        wire = parameters[1:]
        wire_names = {parameter.name for parameter in wire}
        if subject.argument is not None:
            if subject.argument in wire_names:
                raise ValueError(
                    f"{handler.__name__!r} declares a parameter"
                    f" {subject.argument!r} and is registered to select its"
                    " tenant from that wire argument; the body reads"
                    f" `{_CAPABILITY_PARAMETER}.tenant` and takes no tenant of"
                    " its own — a second source is what SEC-018 was"
                    " (D-IMPL-353 §1.2)"
                )
            wire = [
                inspect.Parameter(
                    subject.argument,
                    inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    annotation=str,
                ),
                *wire,
            ]
            wire_names.add(subject.argument)
        if products.argument is not None and products.argument not in wire_names:
            raise ValueError(
                f"{handler.__name__!r} declares no parameter"
                f" {products.argument!r}; a roster held to a class the wire"
                " does not carry would silently decide nothing (SEC-017)"
            )
        if resource.argument is not None and resource.argument not in wire_names:
            raise ValueError(
                f"{handler.__name__!r} declares no parameter"
                f" {resource.argument!r}; a guard reading a resource the wire"
                " does not carry would silently decide nothing (SEC-002)"
            )
        visible = body.replace(parameters=wire)
        surface = GuardedSurface(
            action=action,
            subject=subject,
            resource=resource,
            mutating=mutating,
            products=products,
        )
        authorizer = self._authorizer

        @functools.wraps(handler)
        def guarded(*args: Any, **kwargs: Any) -> Any:
            token = get_access_token()
            if token is None:
                raise UnverifiedTenantCallerRefused(
                    "no verified access token accompanies this call; a"
                    " tenant-scoped surface decides on verified identities"
                    " only (SEC-018; D-26)"
                )
            if mutating and is_ambient_stdio(token):
                raise AmbientMutationRefused(
                    "this identity was stated by the stdio host rather than"
                    " verified from a presented credential; process ownership"
                    " warrants reading what this process was spawned to serve"
                    " and does not warrant mutating (SEC-018)"
                )
            held = granted_tenants(token)
            if not held:
                raise TenantlessGrantRefused(
                    "the verified grant names no tenant, so it reaches"
                    " nothing; a credential's tenants are a deployment value"
                    " and an unscoped credential is refused rather than"
                    " widened (SEC-018)"
                )
            bound = visible.bind(*args, **kwargs)
            bound.apply_defaults()
            arguments = dict(bound.arguments)
            tenant = _select_tenant(subject, arguments, held)
            target = _read_resource(resource, arguments, action=action)
            # SEC-017; D-IMPL-374 (2), fix round 1: the declared product roster
            # is held to this call HERE — after the tenant floor, BEFORE the
            # authorizer — so a roster refusal records no allow and mints no
            # capability. No roster declared: tenant-wide, as before.
            roster = granted_products(token)
            if roster is not None:
                _hold_to_roster(surface_name, products, tenant, arguments, roster)
            # The §6 round-trip's last step: the grant the authorizer decides
            # on is rebuilt from the VERIFIED token — the claims the verifier
            # composed from the deployment's own grant, never anything the
            # wire supplied. It carries the roster too, so the two copies of
            # the grant in this call agree (SEC-017).
            grant = TokenGrant(
                client_id=token.client_id,
                scopes=tuple(token.scopes),
                tenants=held,
                products=roster,
            )
            decision = authorizer.authorize(
                grant=grant, tenant=tenant, action_id=action, resource=target
            )
            if not decision.allowed:
                denial = json.dumps(
                    refusal_detail(
                        error_code=ERROR_TENANT_UNAUTHORIZED,
                        message=(
                            "the verified caller's grant does not"
                            f" authorize action {action!r} on"
                            f" {target!r} under tenant {tenant!r} against"
                            " the scope mapping in force (HARD-04;"
                            " D-IMPL-68 — deny-by-default)"
                        ),
                    )
                )
                if roster is not None and products.resolve is not None:
                    # PC2 (panel C2; `D-IMPL-374`): a rostered caller's reach
                    # on a directory-resolved surface was read BEFORE the
                    # authorizer, and every directory outcome refuses with one
                    # opaque reason. An agent that exists and is on the roster
                    # reached the authorizer instead — so a distinct deny here
                    # would tell the caller which agents exist. Its deny is
                    # the SAME opaque refusal, its reason logged server-side.
                    raise _opaque_directory_refusal(
                        surface_name, f"the authorizer denied the call: {denial}"
                    ) from None
                if on_denied is not None:
                    # R5-CP17-F01: the surface answers a deny its own governed
                    # way. No capability is minted and the body never runs.
                    wire_arguments = dict(arguments)
                    if subject.argument is not None:
                        wire_arguments.pop(subject.argument, None)
                    return on_denied(
                        grant=grant, tenant=tenant, arguments=wire_arguments, denial=denial
                    )
                raise ActionUnauthorizedRefused(denial)
            # §1.5(a): the mint binds the authorizer's WHOLE decision, and the
            # decision must be the answer to the question this wrapper asked.
            # An allow naming no record, or deciding about some other tenant,
            # action or resource, is not minted from — mirror of the HTTP
            # gate's `decision-unmintable`.
            if (
                decision.decision_id is None
                or decision.tenant != tenant
                or decision.action_id != action
                or decision.resource != target
            ):
                raise DecisionUnmintableRefused(
                    json.dumps(
                        refusal_detail(
                            error_code=ERROR_DECISION_UNMINTABLE,
                            message=(
                                "the bound authorizer returned an allow the"
                                " wrapper cannot mint a capability from: it"
                                " carries no decision id, or it decides about"
                                " a tenant, action or resource other than the"
                                " one this surface asked about. No capability"
                                " is minted from a partial or misdirected"
                                " decision; fix the authorizer (D-IMPL-353"
                                " §1.5a)"
                            ),
                        )
                    )
                )
            authorized: Authorized[ActionKind] = mint(
                kind,
                decision=decision,
                principal=token.client_id,
                # The decision's own identity: the audit event the authorizer
                # appended for exactly this allow (D-IMPL-353 §1.5a). Lane
                # CAP-GATE's `ControlPlaneTenantAuthorizer` populates it; a
                # content hash of the decision tuple would have named no
                # record at all.
                decision_id=decision.decision_id,
            )
            if subject.argument is not None:
                del arguments[subject.argument]
            return handler(authorized, **arguments)

        # The wire's signature, for FastMCP's schema and pydantic's validation.
        setattr(guarded, "__signature__", visible)
        setattr(
            guarded,
            "__annotations__",
            {
                **{parameter.name: parameter.annotation for parameter in wire},
                "return": body.return_annotation,
            },
        )
        return guarded, surface  # type: ignore[return-value]


def _select_tenant(
    subject: TenantSubject, arguments: Mapping[str, Any], held: frozenset[str]
) -> str:
    """The one tenant this call acts under, selected — never picked (§1.3)."""
    if subject.grant:
        if len(held) != 1:
            raise AmbiguousTenantRefused(
                "this surface carries no tenant and the verified grant holds"
                f" {len(held)}; a decision is about one tenant and the guard"
                " does not choose it (D-IMPL-353 §1.3)"
            )
        (only,) = held
        return only
    if subject.declared is not None:
        acting_on: object = subject.declared
    else:
        assert subject.argument is not None  # the three readings are closed
        acting_on = arguments[subject.argument]
    if not isinstance(acting_on, str) or not acting_on:
        raise CrossTenantRefused(
            "the tenant argument is not a tenant name; a value that cannot be"
            " compared is refused rather than admitted (SEC-018)"
        )
    if acting_on not in held:
        # `TENANT_NOT_GRANTED_CODE` leads the text so a consumer's dispatch can
        # name this refusal (`producer-tenant-mismatch`) rather than file it as
        # an outage; it discloses only the tenant the caller itself sent
        # (round 5 SDK lane A, Dave 2026-10-11 20:19 MST ruling 1).
        raise CrossTenantRefused(
            f"{TENANT_NOT_GRANTED_CODE}: the verified caller's grant does not carry tenant"
            f" {acting_on!r}; the tenant a call acts on is decided against"
            " the grant, never supplied by the call (SEC-018)"
        )
    return acting_on


def _read_resource(
    resource: ResourceSubject, arguments: Mapping[str, Any], *, action: str
) -> str:
    """The thing this call acts on, read where the registration said to."""
    if resource.route:
        return action
    if resource.declared is not None:
        return resource.declared
    if resource.template is not None:
        try:
            composed = resource.template.format(**arguments)
        except (KeyError, IndexError, ValueError) as unformattable:
            raise ResourceUnreadableRefused(
                "the resource template names a wire argument this call did"
                " not carry; a resource that cannot be spelled is refused"
                " rather than skipped (SEC-002)"
            ) from unformattable
        return composed
    assert resource.argument is not None  # the four readings are closed
    value = arguments.get(resource.argument)
    if not isinstance(value, str) or not value:
        raise ResourceUnreadableRefused(
            f"the {resource.argument!r} argument carries no resource a"
            " decision can be made on; an unreadable resource is a deny,"
            " never a skip (SEC-002)"
        )
    return value
