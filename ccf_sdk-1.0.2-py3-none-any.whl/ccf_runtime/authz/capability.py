# Copyright (c) 2026 David Castillo. All rights reserved.
# Use, copying, modification, and distribution of the covered material
# are governed by the CCF SDK Interim Software and Patent License
# in the repository-root LICENSE.md and any controlling signed agreement.
# Rights under that interim license begin only upon its execution
# and are limited to its stated scope and term.
"""Re-export of :mod:`ccf.authz.capability` (D-IMPL-353). The capability moved to
``src/`` so library handles can require it without importing ``runtime/``
(D-29). Every public name is re-exported here so the gate, the MCP wrapper and
the engine keep their import path. The sentinel is NOT re-exported: the only
mint module is ``src/ccf/authz/capability.py`` (§4 rule 3).
"""

from __future__ import annotations

from ccf.authz.capability import (
    ActionKind as ActionKind,
    AgentDeclare as AgentDeclare,
    AgentList as AgentList,
    AgentRead as AgentRead,
    AgentVersions as AgentVersions,
    ArtifactRead as ArtifactRead,
    ArtifactWrite as ArtifactWrite,
    Authorized as Authorized,
    BackendsRead as BackendsRead,
    CapabilityBypassError as CapabilityBypassError,
    ConfigKeysRead as ConfigKeysRead,
    CompositionRegister as CompositionRegister,
    ConfigRegister as ConfigRegister,
    ConfigResolve as ConfigResolve,
    ConfigVersionsRead as ConfigVersionsRead,
    DocsRead as DocsRead,
    Execute as Execute,
    GrantMutate as GrantMutate,
    HealthRead as HealthRead,
    HitlQueueRead as HitlQueueRead,
    HitlSubmit as HitlSubmit,
    OpenApiRead as OpenApiRead,
    ProductRetrieve as ProductRetrieve,
    Register as Register,
    COMPOSITION_KINDS as COMPOSITION_KINDS,
    COMPOSITION_PRINCIPAL as COMPOSITION_PRINCIPAL,
    verify_any as verify_any,
    ReplayMint as ReplayMint,
    ReplayRead as ReplayRead,
    Resume as Resume,
    SchemaList as SchemaList,
    SchemaRead as SchemaRead,
    SkillCatalogRead as SkillCatalogRead,
    SkillCatalogRegister as SkillCatalogRegister,
    SkillGrant as SkillGrant,
    SkillRevoke as SkillRevoke,
    WorkflowStatusRead as WorkflowStatusRead,
    kind_for_action as kind_for_action,
    mint as mint,
    mint_at_composition as mint_at_composition,
    verify as verify,
)

__all__ = [
    'ActionKind',
    'AgentDeclare',
    'AgentList',
    'AgentRead',
    'AgentVersions',
    'ArtifactRead',
    'ArtifactWrite',
    'Authorized',
    'BackendsRead',
    'CapabilityBypassError',
    'ConfigKeysRead',
    'CompositionRegister',
    'ConfigRegister',
    'ConfigResolve',
    'ConfigVersionsRead',
    'DocsRead',
    'Execute',
    'GrantMutate',
    'HealthRead',
    'HitlQueueRead',
    'HitlSubmit',
    'OpenApiRead',
    'ProductRetrieve',
    'Register',
    'COMPOSITION_KINDS',
    'COMPOSITION_PRINCIPAL',
    'verify_any',
    'ReplayMint',
    'ReplayRead',
    'Resume',
    'SchemaList',
    'SchemaRead',
    'SkillCatalogRead',
    'SkillCatalogRegister',
    'SkillGrant',
    'SkillRevoke',
    'WorkflowStatusRead',
    'kind_for_action',
    'mint',
    'mint_at_composition',
    'verify',
]
