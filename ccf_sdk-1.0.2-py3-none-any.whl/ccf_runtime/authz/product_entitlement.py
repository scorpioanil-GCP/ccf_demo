# Copyright (c) 2026 David Castillo. All rights reserved.
# Use, copying, modification, and distribution of the covered material
# are governed by the CCF SDK Interim Software and Patent License
# in the repository-root LICENSE.md and any controlling signed agreement.
# Rights under that interim license begin only upon its execution
# and are limited to its stated scope and term.
"""``P`` at delivery: one definition of *entitled*, for every exposed door.

SDK-defined extension (CLAUDE.md §7.1, §8.3). Plan ``15.5-03`` shipped the
*artifact* — :mod:`ccf.products.entitlement`, a tenant's declaration of which
Context Product classes each principal may receive and which roles it may
assert. This module is the *door* half: the seams an exposed product door
holds, the reference source that resolves that artifact per call and audits
every decision, and the one resolution order all three doors run.

**Why this lives in a third module rather than in one of the doors.** The
tree exposes the same three-string product signature at three places — the
fabric-internal MCP egress resource, the Experience front-door resource, and
the HTTP ``GET /product/...`` route. Three doors that disagreed about what
"entitled" means is the drift ``run_gates``/``run_federated_gates`` share
their comparison functions specifically to prevent. But the doors may not
import each other either:
``tests/invariants/test_mcp_role_separation.py`` asserts that the MCP roles
are separate modules importing none of their siblings, so that the
authenticated one is never one decorator away from the anonymous one. The
resolution is the one :mod:`ccf_runtime.authz.protocol` already models for
the two HITL doors — a shared seam in a package neither door owns, imported
by both, owned by neither.

**Entitlement is checked after authentication, never instead of it**
(:mod:`ccf.peering.trust_policy`'s posture at the federated boundary,
transplanted to the local one). Every entry point here takes an
already-verified :class:`~ccf_runtime.mcp.auth.TokenGrant`; nothing in this
module verifies a credential, and nothing here accepts a caller-supplied
principal.

**The seams are required at the MCP doors, not optional-and-inert.**
``hitl.py``'s ``_enforce_tenant_authz`` is inert when no authorizer is bound
because it retrofits authorization onto a door that had already shipped. The
product doors are receiving their *first* governance, so an optional seam
would ship the exact gap ``docs/CONTEXT_PRODUCT_REVISION.md`` §11.2 measured
— a door that answers everyone — and would make deny-by-default a
deployment's choice rather than the SDK's.

**Both outcomes are audited (D-09/D-10).** The reference source appends one
``authz_decision`` event per decision to the one Control Plane audit log,
carrying the verified principal, the tenant, the declared action id
(:data:`~ccf_runtime.authz.refusals.ACTION_PRODUCT_RETRIEVE`) and the exact
policy version in force — which is only exact because the artifact is
**re-resolved on every call, with no cache and no TTL** (D-07;
:class:`~ccf_runtime.authz.protocol.ControlPlaneTenantAuthorizer`'s posture).

**The role is decided, never asserted (T-15.5-19).** A caller may *request*
a role; the deployment's :class:`PerspectiveResolverProtocol` proposes one
from the verified grant; and the entitlement decides. The resolved
perspective's role — not the requested one — is what
:meth:`~ccf.products.entitlement.ProductEntitlementGrant.require_role` is
asked about, so a resolver that ignores its argument cannot mint a view
nobody granted. The resolved perspective's ``principal_id`` must equal the
verified ``client_id`` for the same reason it does on the HITL door
(D-IMPL-67): both strings land verbatim in replay dimension 4, and a record
naming someone who never called is worse than no record.

**Nothing sinks below the door.** :meth:`ProjectionEngine.execute` still
takes an already-resolved :class:`~ccf.projection.plan.Perspective` and
learns nothing about who asked; replay feeds the *recorded* perspective and
never re-resolves one, so a decision replays even after its principal is
gone. ``tests/invariants/test_mcp_role_separation.py`` asserts both
structurally.

Principal identifiers, role names, tenant names, product-class names and
policy keys are all deployment values carried on the wire or in the
artifact. This module holds none of them (CINV-01).

Algorithmic module (CINV-03).
"""

from __future__ import annotations

import json
from collections.abc import Callable
from datetime import datetime
from typing import Protocol, runtime_checkable

from mcp.server.auth.middleware.auth_context import get_access_token

from ccf.controlplane.registry import ControlPlaneMissing, ControlPlaneRegistry
from ccf.products.disclosure import DISCLOSURE_MINIMAL, DisclosureLevel
from ccf.products.provenance import ProvenanceSource
from ccf.products.entitlement import (
    PRODUCT_ENTITLEMENT_POLICY,
    PrincipalNotEntitled,
    ProductEntitlementGrant,
    ProductEntitlementPolicy,
    ProductEntitlementViolation,
    product_entitlement_key,
)
from ccf.projection.plan import Perspective
from ccf_runtime.authz.refusals import ACTION_PRODUCT_RETRIEVE
from ccf_runtime.http_api.errors import (
    ERROR_PRINCIPAL_NOT_ENTITLED,
    ERROR_PRODUCT_CLASS_UNENTITLED,
    ERROR_PRODUCT_POLICY_ABSENT,
    ERROR_PRODUCT_ROLE_UNGRANTED,
    ERROR_SUBJECT_CONFLICT,
    refusal_detail,
)
from ccf_runtime.mcp.auth import TokenGrant, granted_products, granted_tenants

__ccf_mode__ = "algorithmic"

__all__ = [
    "ControlPlaneProductEntitlementSource",
    "EvidenceReadabilitySourceProtocol",
    "PerspectiveResolverProtocol",
    "ProductEntitlementRefused",
    "ProductEntitlementSourceProtocol",
    # Re-exported deliberately, and it is the one re-export this package makes
    # (``24.6-08``). ``TokenGrant`` is defined in the MCP auth module, but it is
    # part of THIS seam's published vocabulary: both Protocols above are typed
    # on it, so an adopter implementing either already has to name it — and
    # without this line the only way to name it is to reach into a transport
    # tree, which is exactly the reach the delivery-boundary discipline
    # discourages (``D-IMPL-256``; the governed step in
    # :mod:`ccf_runtime.authz.delivery_boundary` imports this module and no
    # transport). A second import path is normally this project's defect
    # (24.6-01 deviation 2, 24.6-02 deviation 2); here the alternative is a
    # determination module importing a transport, which is worse.
    "TokenGrant",
    "UnverifiedProductCallerRefused",
    "entitled_perspective",
    "verified_grant",
]


class ProductEntitlementRefused(ProductEntitlementViolation):
    """A door refused a verified caller, with the typed code for the refusal.

    Subclasses the artifact's own
    :class:`~ccf.products.entitlement.ProductEntitlementViolation` so a
    deployment catching the artifact's type catches the door's too, and
    carries :attr:`error_code` so each door can render the *same* decision in
    its own protocol — a typed 403 body on HTTP, a protocol-native error on
    MCP — without either inventing a string (D-08, the one-vocabulary /
    two-renderings posture the HITL doors already hold).

    ``str(...)`` is the one refusal-body shape
    (:func:`~ccf_runtime.http_api.errors.refusal_detail`) rendered as JSON, so
    the MCP rendering is machine-attributable without a second contract.

    ``24.6-08`` added :attr:`policy`, keyword-only and defaulted, so every
    existing construction is unchanged.

    Attributes:
        error_code: The typed code each door renders in its own protocol.
        message: The human-readable statement.
        policy: The pin of the policy that **decided**, when one did
            (``D-IMPL-253`` D-34 — *"under which policy"*). It travels from the
            determination itself, built by
            :meth:`ControlPlaneProductEntitlementSource.authorize` from the
            **same** ``(key, version)`` its audit event holds, so replay
            dimension 2 can never pin a policy that did not decide and a second
            registry read can never introduce a version skew. ``None`` is the
            positive *no policy was consulted*, which is the honest answer for
            the subject-conflict refusal
            :func:`entitled_perspective` raises before any source is asked.
        role: The role the determination was made under — the one
            :meth:`ControlPlaneProductEntitlementSource.authorize` was handed,
            which is the perspective's resolved role — when a role
            participated, and ``None`` when none was established for the
            verified caller (the subject-conflict refusal, reached before any
            role of the caller's own exists). ``D-IMPL-260`` P-D: *"record the
            role that actually participated, explicit absence if none was
            established, never a substituted default."* The delivery boundary
            records it on replay dimension 4 as given, and turns ``None`` into
            :data:`~ccf.replay.record.NO_ROLE_RESOLVED` — the positive claim —
            rather than reading the caller's request for a role that may
            not be the one the source decided under.
    """

    def __init__(
        self,
        *,
        error_code: str,
        message: str,
        policy: ProvenanceSource | None = None,
        role: str | None = None,
    ) -> None:
        self.error_code = error_code
        self.message = message
        self.policy = policy
        self.role = role
        super().__init__(
            json.dumps(
                refusal_detail(error_code=error_code, message=message)
            )
        )


class UnverifiedProductCallerRefused(RuntimeError):
    """No verified access token accompanies the in-flight product call.

    The D-26 auth middleware should make this unreachable — every door that
    calls :func:`verified_grant` is authenticated by construction — but the
    door refuses rather than falling back to an anonymous read when the
    precondition fails. The counterpart of
    :class:`~ccf_runtime.mcp.hitl_server.UnverifiedCallerRefused` on the
    product surfaces.
    """


@runtime_checkable
class PerspectiveResolverProtocol(Protocol):
    """How a door turns a verified grant into a Π role-conditioning tuple.

    Protocol rather than a base class (CLAUDE.md §11), on
    :class:`~ccf_runtime.mcp.egress.ProductResolverProtocol`'s own reasoning:
    which role a verified caller holds is the deployment's statement about
    its own identity substrate, and the SDK has no business owning its shape
    — only its signature. Keyword-only for the same reason that seam is, so
    the arguments cannot be transposed.

    The resolver **proposes**; it does not decide. Whatever
    :class:`~ccf.projection.plan.Perspective` it returns is checked against
    the principal's entitlement grant before any product is served, so a
    resolver cannot widen what the deployment declared.
    """

    def __call__(
        self, *, grant: TokenGrant, tenant: str, requested_role: str | None
    ) -> Perspective:
        """Return the perspective ``grant`` may be conditioned under.

        Args:
            grant: The verified caller identity. Never a caller's claim.
            tenant: The tenant the product is addressed under.
            requested_role: The role the caller asked for, or ``None`` when
                the surface carries no way to ask — the MCP product URIs
                have three segments and no role among them, so on those
                doors the resolver derives the role from ``grant`` alone.
                There is no SDK default: a role the SDK invented would be
                one no examiner could trace to a decision anyone made.
        """
        ...


@runtime_checkable
class ProductEntitlementSourceProtocol(Protocol):
    """How a door asks whether a verified caller may receive a class, as whom.

    Protocol rather than a base class (CLAUDE.md §11) on the same terms as
    :class:`~ccf_runtime.authz.protocol.TenantAuthorizerProtocol`: what
    "entitled" means is the deployment's statement, and the doors have
    business only with the signature.
    """

    #: The deployment's declared determination clock (``24.6-08``;
    #: ``D-IMPL-256`` (1)). An **additive** Protocol member, and the reason it
    #: is on the source rather than passed per call is that the audit event
    #: this source appends and the replay record the delivery boundary mints
    #: must be stamped from ONE clock — a second time source would let the two
    #: halves of a single decision disagree about when the fabric decided.
    #:
    #: Injected, never read by the SDK (``D-IMPL-98``): nothing in ``src/`` or
    #: in :mod:`ccf_runtime.authz.delivery_boundary` calls ``datetime.now``, so
    #: a replay resolves the instant the determination carried rather than the
    #: instant the replay ran. It is also what answers *"the door reads no
    #: clock"*: the door asks its entitlement source.
    clock: Callable[[], datetime]

    def authorize(
        self, *, grant: TokenGrant, tenant: str, product_class: str, role: str
    ) -> ProductEntitlementGrant:
        """Return the caller's grant, or raise; audit either way.

        Raising rather than returning a verdict is the artifact's own
        posture, carried up to the door: a delivery path must not be able to
        treat "not entitled" as "not sure".

        Raises:
            ProductEntitlementRefused: the caller is not entitled to that
                class, or not to that role, or is not declared at all, or
                the tenant declares no policy. The refusal carries
                :attr:`~ProductEntitlementRefused.policy` — the pin of the
                policy that decided — when a policy was consulted.
        """
        ...


@runtime_checkable
class EvidenceReadabilitySourceProtocol(Protocol):
    """A source that can say whether a CLASS's decision records may reach their owners.

    Dave's Q12 (2026-10-07; ``D-IMPL-378``), SDK-defined (CLAUDE.md §11): an
    optional, structural capability of a
    :class:`ProductEntitlementSourceProtocol`, asked by the governed evidence
    read (``runtime/ccf_runtime/authz/delivery_boundary.py::govern_dereference``)
    after the grant is re-decided. A source that does not implement it is read
    as answering *no* for every class — default-deny, so a deployment that never
    considered owner read-back gets the posture that cannot reveal what a
    projection withheld.
    """

    def evidence_readable(
        self, *, tenant: str, product_class: str
    ) -> tuple[bool, ProvenanceSource | None]:
        """Whether the tenant lists ``product_class``, with the pin of the policy that said so."""
        ...


class ControlPlaneProductEntitlementSource:
    """Reference :class:`ProductEntitlementSourceProtocol` over the Control Plane.

    Resolves the tenant's
    :class:`~ccf.products.entitlement.ProductEntitlementPolicy` under
    :func:`~ccf.products.entitlement.product_entitlement_key` — **per call,
    no cache, no TTL** (D-07) — runs the artifact's two raising checks, and
    appends one ``authz_decision`` event per decision to the Control Plane's
    own audit log (WR-07: one audit plane).

    Args:
        control_plane: The registry the policy resolves from and whose
            ``audit_log`` every decision lands in. No default: which Control
            Plane governs a door is a composition decision.
        clock: Time source for audit timestamps AND for the determination
            instant a delivery boundary records against (``24.6-08``).
            Injected, never read — the audit-module discipline (``D-IMPL-98``).

            **Public** as of ``24.6-08``, because
            :data:`ProductEntitlementSourceProtocol.clock` is now part of the
            seam: the governed delivery-boundary step reads this ONE clock so
            the audit event and the replay record of a single decision carry
            the same instant. Measured before renaming — ``grep -rn '_clock'``
            found this class's two lines and no other reader — so there is no
            alias to keep.
    """

    def __init__(
        self,
        *,
        control_plane: ControlPlaneRegistry,
        clock: Callable[[], datetime],
    ) -> None:
        self._control_plane = control_plane
        self.clock = clock

    def _audit(
        self, *, grant: TokenGrant, tenant: str, version: str, allowed: bool
    ) -> None:
        """Append the one ``authz_decision`` event this decision produces."""
        self._control_plane.audit_log.append(
            action="authz_decision",
            key=tenant,
            version=version,
            resolved=allowed,
            occurred_at=self.clock(),
            actor=grant.client_id,
            artifact_class=PRODUCT_ENTITLEMENT_POLICY.class_id,
            authz_action_id=ACTION_PRODUCT_RETRIEVE,
            authz_matched_pattern=None,
        )

    def authorize(
        self, *, grant: TokenGrant, tenant: str, product_class: str, role: str
    ) -> ProductEntitlementGrant:
        """Decide, audit both outcomes, and return the grant or raise.

        Raises:
            ProductEntitlementRefused: any of the four deny paths, carrying
                :attr:`~ProductEntitlementRefused.policy` — the pin of the
                policy that decided, from the same ``(key, version)`` the audit
                event below is stamped from. The absent-policy path carries
                ``None``: no artifact resolved, and
                :class:`~ccf.products.provenance.ProvenanceSource` refuses an
                ``artifact`` kind with no version by construction, so a
                versionless pin is unrepresentable rather than merely
                discouraged. Which key was consulted is still a positive claim
                on the record — the refusal's own message names it, and the
                key is a pure derivation from the tenant the resource identity
                carries (:func:`~ccf.products.entitlement.product_entitlement_key`).
            TypeError: the artifact registered under the tenant's
                entitlement key is not a ``ProductEntitlementPolicy``, **or is
                one whose own ``tenant_id`` is not the tenant whose key it was
                found under** — a near-miss is refused, never interpreted (the
                ``ControlPlaneTenantAuthorizer`` precedent). The attempt is
                audited as a deny *before* the raise (WR-04), so even a
                misregistered policy leaves a trace of who asked for what.

                The second limb is what makes
                :class:`~ccf.products.entitlement.ProductEntitlementPolicy`'s
                *"tenant-scoped by construction"* claim true at the door
                rather than at the artifact only. The key
                (:func:`~ccf.products.entitlement.product_entitlement_key`)
                and the artifact's ``tenant_id`` field are supplied
                **independently** by whoever registers the policy, and nothing
                upstream binds them; without this check a policy whose content
                says tenant B, registered under tenant A's key, authorizes
                A's door with B's grants. Found by the Phase 15.5 close-time
                cross-AI panel (`15.5-CLOSE-REVIEWS.md`, finding P1).
        """
        key = product_entitlement_key(tenant_id=tenant)
        version = ""
        entitled: ProductEntitlementGrant | None = None
        refusal: ProductEntitlementRefused | None = None
        # The pin of the policy that DECIDED (`24.6-08`, D-34). Read ONCE here,
        # from the same resolution the audit event below is stamped from, so
        # dimension 2 and the audit log cannot disagree and no second registry
        # read can introduce a version skew. The key is derived from the
        # `tenant` ARGUMENT — the caller-supplied tenant this source decided
        # against — never from any deployment tenant a door happens to hold.
        pin: ProvenanceSource | None = None
        try:
            version, resolved = self._control_plane.resolve_latest(key)
        except ControlPlaneMissing:
            # No policy registered is a deny, not an error: the default
            # posture grants nothing, and a door whose governance
            # configuration is absent must not become servable.
            refusal = ProductEntitlementRefused(
                error_code=ERROR_PRODUCT_POLICY_ABSENT,
                message=(
                    f"no product entitlement policy is registered under"
                    f" {key!r}; a delivery door with no policy in force"
                    " refuses rather than serves (deny-by-default)"
                ),
                role=role,
            )
        else:
            pin = ProvenanceSource(
                kind="artifact", identity=key, version=version
            )
            if not isinstance(resolved, ProductEntitlementPolicy):
                self._audit(
                    grant=grant, tenant=tenant, version=version, allowed=False
                )
                raise TypeError(
                    f"artifact under {key!r} is not a"
                    f" ProductEntitlementPolicy (got"
                    f" {type(resolved).__name__}); the delivery door refuses"
                    " to interpret a near-miss"
                )
            if resolved.tenant_id != tenant:
                self._audit(
                    grant=grant, tenant=tenant, version=version, allowed=False
                )
                raise TypeError(
                    f"policy under {key!r} declares tenant"
                    f" {resolved.tenant_id!r}, not {tenant!r}; the key and the"
                    " artifact's own tenant are supplied independently, so the"
                    " door compares them rather than trusting the lookup — a"
                    " misregistered policy is a near-miss and is refused, never"
                    " interpreted"
                )
            try:
                entitled = resolved.grant_for(principal_id=grant.client_id)
            except PrincipalNotEntitled as absent:
                refusal = ProductEntitlementRefused(
                    error_code=ERROR_PRINCIPAL_NOT_ENTITLED,
                    message=str(absent),
                    policy=pin,
                    role=role,
                )
            else:
                try:
                    entitled.require_schema(schema_name=product_class)
                except ProductEntitlementViolation as violation:
                    refusal = ProductEntitlementRefused(
                        error_code=ERROR_PRODUCT_CLASS_UNENTITLED,
                        message=str(violation),
                        policy=pin,
                        role=role,
                    )
                else:
                    try:
                        entitled.require_role(role=role)
                    except ProductEntitlementViolation as violation:
                        refusal = ProductEntitlementRefused(
                            error_code=ERROR_PRODUCT_ROLE_UNGRANTED,
                            message=str(violation),
                            policy=pin,
                            role=role,
                        )
        self._audit(
            grant=grant,
            tenant=tenant,
            version=version,
            allowed=refusal is None,
        )
        if refusal is not None:
            raise refusal
        if entitled is None:  # pragma: no cover - unreachable by construction
            raise ProductEntitlementRefused(
                error_code=ERROR_PRODUCT_POLICY_ABSENT,
                message="no grant resolved and no refusal raised",
                policy=pin,
                role=role,
            )
        return entitled

    def disclosure_level_for(
        self, *, tenant: str, principal_id: str
    ) -> tuple[DisclosureLevel, ProvenanceSource | None]:
        """The disclosure posture in force for one principal, with its pin.

        ``24.6-L-16``; ``D-IMPL-253`` Q17, Dave: *"Suppression silence should be
        policy-controlled, with minimal disclosure as the safe default."*

        Three answers and one order: the principal's own grant override if it
        declares one, else the tenant policy's level, else
        :data:`~ccf.products.disclosure.DISCLOSURE_MINIMAL` with a ``None``
        source — *no policy is registered, so the safe default applied*, which
        is a claim rather than a silence.

        **A different question from** :meth:`authorize`, asked of the same
        artifact. That one decides whether the caller may receive the class;
        this one decides how much of a refusal's internal truth may cross. Both
        pins land in the replay record when both exist — the entitlement
        policy in dimension 2, this level's source in dimension 5's disclosure
        decision — and both are read under the tenant the determination was
        made under: for a delivery-boundary denial, the tenant the caller
        addressed. The level was once read under the tenant of the door that
        answered, which on a door serving several tenants through one recorder
        let that tenant's policy for a colliding principal id set another
        tenant's caller's level (Dave, 2026-10-07; ``D-IMPL-378``).

        Resolved **per call, no cache, no TTL**, exactly as :meth:`authorize`
        resolves the same artifact (D-07).

        Args:
            tenant: The tenant whose policy sets the posture.
            principal_id: The verified caller, for the per-grant override.

        Returns:
            The level and the artifact source that set it, or the safe default
            with ``None``.

        Raises:
            TypeError: the artifact under the tenant's key is not a
                ``ProductEntitlementPolicy``, or declares a different tenant.
                A near-miss is refused and never interpreted — disclosing under
                another tenant's policy is the elevation the tenant-scoped key
                exists to prevent (``T-24.6-29``).
        """
        found = self._tenant_policy(tenant)
        if found is None:
            return DISCLOSURE_MINIMAL, None
        resolved, source = found
        grant = resolved.principals.get(principal_id)
        if grant is not None and grant.disclosure_level is not None:
            return grant.disclosure_level, source
        return resolved.disclosure_level, source

    def evidence_readable(
        self, *, tenant: str, product_class: str
    ) -> tuple[bool, ProvenanceSource | None]:
        """:class:`EvidenceReadabilitySourceProtocol` over the tenant's own policy.

        Dave's Q12 (2026-10-07; ``D-IMPL-378``). Whether the tenant's
        :class:`~ccf.products.entitlement.ProductEntitlementPolicy` lists
        ``product_class`` in
        :attr:`~ccf.products.entitlement.ProductEntitlementPolicy.evidence_readable_classes`,
        with the pin of the policy that answered. No policy registered answers
        ``(False, None)`` — default-deny, stated as a claim. Resolved per call,
        no cache, no TTL (D-07), held to the same two near-miss refusals as
        :meth:`disclosure_level_for`.

        Raises:
            TypeError: as :meth:`disclosure_level_for`.
        """
        found = self._tenant_policy(tenant)
        if found is None:
            return False, None
        resolved, source = found
        return product_class in resolved.evidence_readable_classes, source

    def _tenant_policy(
        self, tenant: str
    ) -> tuple[ProductEntitlementPolicy, ProvenanceSource] | None:
        """The tenant's policy and its pin, or ``None`` when none is registered.

        The one reading :meth:`disclosure_level_for` and
        :meth:`evidence_readable` share (factored with behavior unchanged,
        ``D-IMPL-378`` Q12), so the two cannot hold the artifact to different
        near-miss checks.

        Raises:
            TypeError: the artifact under the tenant's key is not a
                ``ProductEntitlementPolicy``, or declares a different tenant.
        """
        key = product_entitlement_key(tenant_id=tenant)
        try:
            version, resolved = self._control_plane.resolve_latest(key)
        except ControlPlaneMissing:
            return None
        if not isinstance(resolved, ProductEntitlementPolicy):
            raise TypeError(
                f"artifact under {key!r} is not a ProductEntitlementPolicy"
                f" (got {type(resolved).__name__}); the disclosure level is"
                " read from the tenant's own entitlement policy and the door"
                " refuses to interpret a near-miss"
            )
        if resolved.tenant_id != tenant:
            raise TypeError(
                f"policy under {key!r} declares tenant {resolved.tenant_id!r},"
                f" not {tenant!r}; the key and the artifact's own tenant are"
                " supplied independently, so the door compares them rather"
                " than trusting the lookup"
            )
        return resolved, ProvenanceSource(kind="artifact", identity=key, version=version)


def verified_grant() -> TokenGrant:
    """The in-flight caller's verified identity, or refuse.

    The A1 spike verdict (``tests/crossproc/test_fastmcp_resource_token_
    spike.py``) is what makes this usable inside an MCP **resource** handler
    and not only inside a tool: ``get_access_token()`` is populated for
    resource reads on an authenticated ``FastMCP`` instance. Both product
    resources rely on that, exactly as the HITL queue resource already does.

    Raises:
        UnverifiedProductCallerRefused: no verified token in context.
    """
    token = get_access_token()
    if token is None:
        raise UnverifiedProductCallerRefused(
            "no verified access token accompanies this call; an entitled"
            " product surface decides on verified identities only (D-26)"
        )
    return TokenGrant(
        client_id=token.client_id,
        scopes=tuple(token.scopes),
        # The verified token's tenants travel with the grant it produces.
        # Dropping them here made `verified_grant().tenants` empty, which is
        # not merely lossy: it reads as "this caller has no tenants" to every
        # later consumer, which is the opposite of what the token said. No
        # gap today — the MCP tenancy floor reads the claims directly — but a
        # latent trap for the next reader, and the durable fix for the
        # channel pre-emption noted at `ccf_runtime.mcp.tenancy` (a governed
        # cross-tenant refusal should cross as a RefusalEnvelope through
        # `govern_entitlement`, not as a transport error; D-IMPL-256).
        tenants=granted_tenants(token),
        # The declared product roster travels too (SEC-017; D-IMPL-374 (2)):
        # the Experience door's agent and replay tools read it from here, and
        # dropping it would turn every rostered caller tenant-wide.
        products=granted_products(token),
    )


def entitled_perspective(
    *,
    grant: TokenGrant,
    tenant: str,
    product_class: str,
    requested_role: str | None,
    entitlement_source: ProductEntitlementSourceProtocol,
    perspective_resolver: PerspectiveResolverProtocol,
) -> Perspective:
    """The one resolution order every exposed product door runs.

    Order, and the order *is* the security property:

    1. The caller is already authenticated — this function takes a verified
       grant and cannot be handed a claim.
    2. The deployment's resolver proposes a perspective from that grant. A
       pure derivation: no fabric is touched and no product is assembled, so
       proposing is not receiving.
    3. The proposed subject must be the verified subject (D-IMPL-67).
    4. The entitlement decides — on the **resolved** role, so a resolver
       that ignored ``requested_role`` cannot widen the grant, and on the
       requested class, so ``P`` applies per class at delivery.
    5. Only then may the caller's door resolve a product.

    Args:
        grant: The verified caller identity.
        tenant: The tenant the product is addressed under.
        product_class: The Context Product class being requested.
        requested_role: The role the caller asked for, or ``None`` on a
            surface with no way to ask.
        entitlement_source: The deployment's entitlement decision seam.
        perspective_resolver: The deployment's role-derivation seam.

    Returns:
        The perspective the caller is entitled to be conditioned under.

    Raises:
        ProductEntitlementRefused: the subject conflicts with the verified
            identity, or the entitlement refused the class or the role.
    """
    perspective = perspective_resolver(
        grant=grant, tenant=tenant, requested_role=requested_role
    )
    if perspective.principal_id != grant.client_id:
        raise ProductEntitlementRefused(
            error_code=ERROR_SUBJECT_CONFLICT,
            message=(
                "identity conflict: the resolved perspective's principal"
                " does not match the verified caller identity; the"
                " conditioned subject is derived from the verified grant,"
                " never substituted (D-IMPL-67; D-IMPL-21)"
            ),
            # Stated rather than defaulted: this refusal is reached BEFORE any
            # entitlement source is consulted, so no policy decided it and
            # replay dimension 2 must carry no entitlement pin (`24.6-08`,
            # D-34). A pin here would name a policy that never ran.
            policy=None,
            # And no role of the CALLER's was established: the resolved
            # perspective belongs to a principal the caller is not, so its
            # role is a substituted identity's role and is not recorded as
            # the caller's (`D-IMPL-260` P-D — explicit absence, never a
            # substituted default).
            role=None,
        )
    entitlement_source.authorize(
        grant=grant,
        tenant=tenant,
        product_class=product_class,
        role=perspective.role,
    )
    return perspective
