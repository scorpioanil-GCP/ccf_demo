# Copyright (c) 2026 David Castillo. All rights reserved.
# Use, copying, modification, and distribution of the covered material
# are governed by the CCF SDK Interim Software and Patent License
# in the repository-root LICENSE.md and any controlling signed agreement.
# Rights under that interim license begin only upon its execution
# and are limited to its stated scope and term.
"""``ccf skill import <dir>`` — the one-way SKILL.md importer (D-IMPL-56).

SDK-defined (D-IMPL-22 surface; the D-IMPL-56 SKILL.md-authoring ruling).
SKILL.md is an authoring format, never a canonical artifact: import maps
frontmatter ``name``/``description`` onto a ``procedure`` catalog entry,
registers the body as a ``ccf.prompt-artifact``, registers ``references/``
files as further pinned artifacts, and binds the body by
:class:`~ccf.agents.definitions.InstructionBinding` reference — the
command authors no prose of its own; everything comes from the imported
directory (No-Hardcoding, CLAUDE.md §6.4).

``allowed-tools`` is deliberately **not** mapped onto
``SkillRequirements``: a harness permission token is not a policy-regime
identifier, and the SDK never interprets a requirement identifier
(D-IMPL-29). Requirements come only from explicit ``--required-scope`` /
``--required-context-product`` flags — the operator's statement.

Registration travels the same routes any client uses (over HTTP or
``--local``), so re-import is a normal versioned Control Plane
registration — the working tree is read, never written (one-way; replay
pins exact artifact versions, D-IMPL-26).

Algorithmic module (CINV-03).
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import jinja2.meta
import jinja2.sandbox
import yaml

from ccf.agents.definitions import PROMPT_ARTIFACT
from ccf_runtime.cli.commands import CommandRefused, RequestSpec

__ccf_mode__ = "algorithmic"

__all__ = ["MAX_REFERENCES", "MAX_REFERENCE_BYTES", "register"]

#: Ceilings on what one import reads out of an untrusted skill package
#: (SEC-003, security review 2026-09-23). A skill directory is *shared
#: material* — the format exists to be distributed — so it is untrusted
#: input, and an unbounded read of untrusted input is a resource hazard
#: independent of what the bytes turn out to be. Mechanism limits on the
#: importer's own appetite, not domain values: nothing here describes any
#: deployment's skills.
MAX_REFERENCE_BYTES = 1_048_576
MAX_REFERENCES = 64

#: Current schema lanes of the two SDK artifact classes the importer emits.
_PROMPT_SCHEMA_VERSION = "1.0.0"
_ENTRY_SCHEMA_VERSION = "2.0.0"


def _read_contained(path: Path, *, within: Path) -> str:
    """Read ``path`` as text, or refuse it (SEC-003).

    An imported skill directory is shared material and therefore untrusted
    input. Three refusals, each closing a measured hole from the security
    review of 2026-09-23:

    * **Symlinks.** ``Path.is_file()`` follows them, so a package shipping
      ``references/usage.md -> ~/.aws/credentials`` had its target read and
      published into the Control Plane, where an unauthenticated read route
      served it. Refused outright rather than resolved-and-allowed: a
      symlink inside a *distributed* package has no legitimate meaning on
      the importing machine, and refusing is the only answer that does not
      depend on where the link happens to point.
    * **Escape.** The resolved path must still sit under the package, so a
      component further up the path cannot walk out of it. **A backstop:
      given the symlink refusal above, and that ``iterdir`` yields only
      direct children, nothing reachable today fails this check and
      severing it reddens nothing.** It is kept because it is the total
      statement of the property, and the symlink refusal is the specific
      one that could be loosened later; it is recorded as a backstop so it
      is never mistaken for independent evidence.
    * **Size.** A bounded read; a reference is prompt text.

    Raises:
        CommandRefused: the path is a symlink, escapes ``within``, or
            exceeds :data:`MAX_REFERENCE_BYTES`.
    """
    if path.is_symlink():
        raise CommandRefused(
            f"refusing {str(path)!r}: it is a symlink, and an imported"
            " skill package is untrusted input — a link would publish"
            " whatever it points at into the Control Plane (SEC-003)"
        )
    resolved = path.resolve()
    try:
        resolved.relative_to(within.resolve())
    except ValueError:
        raise CommandRefused(
            f"refusing {str(path)!r}: it resolves outside the imported"
            f" package {str(within)!r} (SEC-003)"
        ) from None
    if not resolved.is_file():
        raise CommandRefused(
            f"refusing {str(path)!r}: not a regular file (SEC-003)"
        )
    size = resolved.stat().st_size
    if size > MAX_REFERENCE_BYTES:
        raise CommandRefused(
            f"refusing {str(path)!r}: {size} bytes exceeds the"
            f" {MAX_REFERENCE_BYTES}-byte import ceiling (SEC-003)"
        )
    return resolved.read_text()


def _split_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    """Split a SKILL.md into (frontmatter mapping, body)."""
    parts = text.split("---", 2)
    if len(parts) < 3 or parts[0].strip():
        raise ValueError(
            "SKILL.md must open with a `---`-delimited YAML frontmatter block"
        )
    frontmatter = yaml.safe_load(parts[1])
    if not isinstance(frontmatter, dict):
        raise ValueError("SKILL.md frontmatter is not a mapping")
    return frontmatter, parts[2].strip() + "\n"


def _template_parameters(template: str) -> tuple[str, ...]:
    """Derive the declared parameters from the body itself — never invented."""
    environment = jinja2.sandbox.SandboxedEnvironment()
    return tuple(
        sorted(jinja2.meta.find_undeclared_variables(environment.parse(template)))
    )


def _prompt_registration(
    *,
    tenant: str,
    name: str,
    version: str,
    template: str,
    tolerate_empty_bump: bool = False,
) -> RequestSpec:
    return RequestSpec(
        method="POST",
        path="/config/registrations",
        tolerate_empty_bump=tolerate_empty_bump,
        json={
            "key": f"{tenant}/{PROMPT_ARTIFACT.class_id}/{name}",
            "class_id": PROMPT_ARTIFACT.class_id,
            "artifact": {
                "schema_version": _PROMPT_SCHEMA_VERSION,
                "artifact_version": version,
                "name": name,
                "tenant": tenant,
                "template": template,
                "declared_parameters": list(_template_parameters(template)),
            },
        },
    )


def _build(args: argparse.Namespace) -> tuple[RequestSpec, ...]:
    directory = Path(args.directory)
    frontmatter, body = _split_frontmatter(
        _read_contained(directory / "SKILL.md", within=directory)
    )
    name = str(frontmatter["name"])
    description = str(frontmatter["description"])
    version = args.version or str(frontmatter.get("version", ""))
    if not version:
        raise ValueError(
            "no artifact version: pass --version or declare `version` in"
            " the SKILL.md frontmatter (D-IMPL-26: registration is"
            " exact-version)"
        )

    specs: list[RequestSpec] = [
        _prompt_registration(
            tenant=args.tenant, name=name, version=version, template=body
        )
    ]
    references = directory / "references"
    if references.is_dir() and not references.is_symlink():
        entries = sorted(references.iterdir())
        if len(entries) > MAX_REFERENCES:
            raise CommandRefused(
                f"refusing {str(references)!r}: {len(entries)} references"
                f" exceeds the ceiling of {MAX_REFERENCES} artifacts one"
                " import may register (SEC-003)"
            )
        for reference in entries:
            specs.append(
                _prompt_registration(
                    tenant=args.tenant,
                    name=f"{name}-reference-{reference.stem}",
                    version=version,
                    template=_read_contained(reference, within=references),
                    # a re-import with this reference unchanged is the
                    # by-design idempotent case, not a failure
                    tolerate_empty_bump=True,
                )
            )

    prompt_uri = (
        f"ccf-artifact://{args.tenant}/{PROMPT_ARTIFACT.class_id}/"
        f"{name}@{version}"
    )
    specs.append(
        RequestSpec(
            method="POST",
            path="/skill/catalog",
            json={
                "schema_version": _ENTRY_SCHEMA_VERSION,
                "artifact_version": version,
                "name": name,
                "tenant": args.tenant,
                "skill_type": "procedure",
                "description": description,
                "argument_schema": {"properties": {}, "required": []},
                "binding": {
                    "instruction": {
                        "prompt": prompt_uri,
                        "parameters": list(_template_parameters(body)),
                    }
                },
                # allowed-tools is NOT mapped here (D-IMPL-29): only the
                # operator's explicit flags become requirement identifiers
                "requirements": {
                    "required_scopes": list(args.required_scope or ()),
                    "required_context_products": list(
                        args.required_context_product or ()
                    ),
                },
            },
        )
    )
    return tuple(specs)


def register(
    subparsers: "argparse._SubParsersAction[argparse.ArgumentParser]",
) -> None:
    """Add the import verb under the skill noun."""
    importer = subparsers.add_parser(
        "import", help="one-way SKILL.md directory import (D-IMPL-56)"
    )
    importer.add_argument("directory", help="directory holding SKILL.md")
    importer.add_argument("--tenant", required=True)
    importer.add_argument(
        "--version", help="artifact version (else frontmatter `version`)"
    )
    importer.add_argument(
        "--required-scope", action="append", default=[]
    )
    importer.add_argument(
        "--required-context-product", action="append", default=[]
    )
    importer.set_defaults(build=_build)
