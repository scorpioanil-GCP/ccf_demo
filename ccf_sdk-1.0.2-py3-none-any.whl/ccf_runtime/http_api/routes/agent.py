# Copyright (c) 2026 David Castillo. All rights reserved.
# Use, copying, modification, and distribution of the covered material
# are governed by the CCF SDK Interim Software and Patent License
# in the repository-root LICENSE.md and any controlling signed agreement.
# Rights under that interim license begin only upon its execution
# and are limited to its stated scope and term.
"""The ``agent`` noun — declare/list/show/versions (D-IMPL-22/23).

Declaration takes an artifact payload — a complete
:class:`~ccf.agents.definitions.AgentDefinition` — and registers it through
the same D-05 versioned Control Plane path any client takes; there are no
inline definition fields beyond the artifact itself (No-Hardcoding, CLAUDE.md
§6.4). Reads resolve the same versioned, audited artifacts every other
Control Plane consumer reads.

Algorithmic module (CINV-03).
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse, Response

from ccf.agents.definitions import AGENT_DEFINITION, AgentDefinition
from ccf.authz.capability import AgentDeclare, AgentList, AgentRead, AgentVersions
from ccf.contracts.base import CCFContract
from ccf.controlplane.registry import ControlPlaneMissing, RegistrationRefusal
from ccf_runtime.authz.refusals import (
    ACTION_AGENT_DECLARE,
    ACTION_AGENT_LIST,
    ACTION_AGENT_READ,
    ACTION_AGENT_VERSIONS,
)
from ccf_runtime.authz.route_declaration import ResourceBinding, authorizes
from ccf_runtime.http_api.dependencies import ApiDependencies
from ccf_runtime.http_api.grants import absent as absent_response
from ccf_runtime.http_api.grants import authorized_from_request, within_tenant
from ccf_runtime.http_api.routes import canonical_response, refusal_response

__ccf_mode__ = "algorithmic"

__all__ = ["AgentDeclarationRequest", "AgentDeclared", "build_router"]


class AgentDeclarationRequest(CCFContract):
    """One declaration: the Control Plane key and the artifact payload."""

    key: str
    definition: AgentDefinition


class AgentDeclared(CCFContract):
    """The registered outcome — the key and its content-hash version."""

    key: str
    version: str


def build_router(deps: ApiDependencies) -> APIRouter:
    """The agent router over the injected Control Plane."""
    router = APIRouter()

    @router.post(
        "/declarations",
        response_model=AgentDeclared,
        summary="Agent declare (D-IMPL-23)",
    )
    @authorizes(ACTION_AGENT_DECLARE, resource=ResourceBinding.body("key"))
    def declare(
        body: AgentDeclarationRequest, request: Request
    ) -> AgentDeclared | JSONResponse:
        # D-IMPL-353 §1.4: the handler holds the capability the gate minted
        # for THIS action, or it holds nothing and refuses. §1.2: the key the
        # registry writes IS `authorized.resource` — the gate resolved it from
        # the body's `key` and the registry takes it from the capability; the
        # handler supplies no key, and the registry compares the key's tenant
        # segment to the capability's tenant once (§1.3).
        authorized = authorized_from_request(request, kind=AgentDeclare)
        outcome = deps.control_plane.register_versioned(
            authorized, body.definition, AGENT_DEFINITION
        )
        if isinstance(outcome, RegistrationRefusal):
            return refusal_response(outcome, status_code=409)
        return AgentDeclared(key=authorized.resource, version=outcome)

    @router.get(
        "/declarations",
        response_model=list[str],
        summary="Agent list (D-IMPL-23)",
    )
    @authorizes(ACTION_AGENT_LIST, resource=ResourceBinding.route())
    def declarations(request: Request) -> list[str]:
        authorized = authorized_from_request(request, kind=AgentList)
        # The capability's tenant's declarations, and no other tenant's
        # (panel F-READ-01 at the D-IMPL-353 join).
        return [
            key
            for key in deps.control_plane.keys_of_class(AGENT_DEFINITION.class_id)
            if within_tenant(tenant=authorized.tenant, key=key)
        ]

    @router.get("/declaration", summary="Agent show (D-IMPL-23)")
    @authorizes(ACTION_AGENT_READ, resource=ResourceBinding.query("key"))
    def declaration(key: str, version: str, request: Request) -> Response:
        authorized = authorized_from_request(request, kind=AgentRead)
        # One resource source (pre-merge check R11): the gate minted from this
        # request's `key`; the handle reads the CAPABILITY's resource, and a
        # parameter that differs from it is refused before the first read.
        if key != authorized.resource or not within_tenant(tenant=authorized.tenant, key=authorized.resource):
            raise absent_response(key, version)
        try:
            artifact = deps.control_plane.resolve(authorized.resource, version)
        except ControlPlaneMissing as absent:
            raise HTTPException(status_code=404, detail=str(absent)) from absent
        return canonical_response(AGENT_DEFINITION.validate(artifact))

    @router.get(
        "/versions",
        response_model=list[str],
        summary="Agent versions (D-IMPL-23)",
    )
    @authorizes(ACTION_AGENT_VERSIONS, resource=ResourceBinding.query("key"))
    def versions(key: str, request: Request) -> list[str]:
        authorized = authorized_from_request(request, kind=AgentVersions)
        if key != authorized.resource or not within_tenant(tenant=authorized.tenant, key=authorized.resource):
            return []  # a differing parameter or another tenant's key: no versions, exactly like an absent one
        return list(deps.control_plane.versions(authorized.resource))

    return router
